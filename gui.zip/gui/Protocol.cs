// Protocol.cs - the wire format between display and sim (BRIEF.md Section 7).
// Every frame: u32 length (bytes that follow), u8 type, payload. Little-endian.
// Type 1 = JSON object with a "t" field. Type 2 = SPOKES (binary radar video).
// Units: as named in each message field (nm, s, kn, deg).
// Called by: SimLink.cs (framing), the window (message builders), SpokeSource (SPOKES).

using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace RadarSim
{
    public static class Protocol
    {
        public const byte FrameJson = 1;
        public const byte FrameSpokes = 2;
        public const int MaxFrameBytes = 8 * 1024 * 1024;   // largest value allowed in the length field
        public const int ProtocolVersion = 1;

        // ---- framing ----

        // A stream may return fewer bytes than asked for (a short read), so loop.
        private static void ReadExact(Stream stream, byte[] buffer, int byteCount)
        {
            int done = 0;
            while (done < byteCount)
            {
                int got = stream.Read(buffer, done, byteCount - done);
                if (got <= 0)
                {
                    throw new EndOfStreamException("connection closed by the sim");
                }
                done += got;
            }
        }

        // Blocks until a whole frame has arrived. Throws when the connection closes
        // or the frame is oversize.
        public static void ReadFrame(Stream stream, out byte frameType, out byte[] payload)
        {
            byte[] header = new byte[5];
            ReadExact(stream, header, 5);
            uint length = BinaryPrimitives.ReadUInt32LittleEndian(header);
            if (length < 1 || length > MaxFrameBytes)
            {
                throw new InvalidDataException("frame length " + length + " is outside 1.." + MaxFrameBytes + " bytes");
            }
            frameType = header[4];
            payload = new byte[length - 1];
            ReadExact(stream, payload, payload.Length);
        }

        public static void WriteFrame(Stream stream, byte frameType, byte[] payload)
        {
            int length = 1 + payload.Length;
            if (length > MaxFrameBytes)
            {
                throw new InvalidDataException("frame of " + length + " bytes is larger than " + MaxFrameBytes);
            }
            byte[] frame = new byte[4 + length];
            BinaryPrimitives.WriteUInt32LittleEndian(frame, (uint)length);
            frame[4] = frameType;
            Array.Copy(payload, 0, frame, 5, payload.Length);
            stream.Write(frame, 0, frame.Length);
        }

        // ---- JSON ----

        public static byte[] EncodeJson(Dictionary<string, object> message)
        {
            return JsonSerializer.SerializeToUtf8Bytes(message);
        }

        public static JsonElement DecodeJson(byte[] payload)
        {
            using (JsonDocument document = JsonDocument.Parse(payload))
            {
                return document.RootElement.Clone();
            }
        }

        // The "t" field of a message, or "" when it has none.
        public static string MessageName(JsonElement message)
        {
            JsonElement name;
            if (message.ValueKind == JsonValueKind.Object && message.TryGetProperty("t", out name)
                && name.ValueKind == JsonValueKind.String)
            {
                return name.GetString();
            }
            return "";
        }

        // ---- display -> sim messages (more arrive with later modules) ----

        public static Dictionary<string, object> Set(string path, object value)
        {
            return new Dictionary<string, object> { { "t", "set" }, { "path", path }, { "value", value } };
        }

        // An own-ship order, typed or from a button: "port 10", "heading 248", "half ahead".
        public static Dictionary<string, object> Order(string text)
        {
            return new Dictionary<string, object> { { "t", "order" }, { "text", text } };
        }

        public static Dictionary<string, object> Pause(bool paused)
        {
            return new Dictionary<string, object> { { "t", "pause" }, { "paused", paused } };
        }

        // The wheelhouse view is open (true) or closed: the sim sends "view" 5 times a second while it is open.
        public static Dictionary<string, object> ViewEnable(bool enabled)
        {
            return new Dictionary<string, object> { { "t", "view" }, { "enabled", enabled } };
        }

        // Ask the sim to write the practice chart now; it replies with a "chart" message holding the file's path.
        public static Dictionary<string, object> Chart()
        {
            return new Dictionary<string, object> { { "t", "chart" } };
        }

        // Make the number of contacts match the density setting now: contacts appear or vanish at once (the TRAFFIC NOW button).
        public static Dictionary<string, object> TrafficNow()
        {
            return new Dictionary<string, object> { { "t", "traffic_now" } };
        }

        public static Dictionary<string, object> Quit()
        {
            return new Dictionary<string, object> { { "t", "quit" } };
        }

        // ---- setup and instructor tools (M10) ----

        // A new run: seed 0 means a random seed; scenario is "random" or "calibration".
        public static Dictionary<string, object> NewRun(int seed, string scenario)
        {
            return new Dictionary<string, object> { { "t", "new_run" }, { "seed", seed }, { "scenario", scenario } };
        }

        // The sim sends "truth" 5 times a second while this is on.
        public static Dictionary<string, object> Truth(bool enabled)
        {
            return new Dictionary<string, object> { { "t", "truth" }, { "enabled", enabled } };
        }

        // ---- ARPA (M9) ----

        public static Dictionary<string, object> Acquire(double rangeNm, double bearingDegTrue)
        {
            return new Dictionary<string, object> { { "t", "acquire" }, { "range_nm", rangeNm }, { "bearing_deg_true", bearingDegTrue } };
        }

        public static Dictionary<string, object> CancelTarget(int id)
        {
            return new Dictionary<string, object> { { "t", "cancel_target" }, { "id", id } };
        }

        public static Dictionary<string, object> CancelAllTargets()
        {
            return new Dictionary<string, object> { { "t", "cancel_all_targets" } };
        }

        // One alarm by its id, or all of them.
        public static Dictionary<string, object> AckAlarm(int id)
        {
            return new Dictionary<string, object> { { "t", "ack_alarm" }, { "id", id } };
        }

        public static Dictionary<string, object> AckAllAlarms()
        {
            return new Dictionary<string, object> { { "t", "ack_alarm" }, { "id", "all" } };
        }

        // Bearings are relative or true as arpa.guard_zone_reference says.
        public static Dictionary<string, object> GuardZone(int index, bool enabled, double innerNm, double outerNm,
                                                           double startDeg, double endDeg)
        {
            return new Dictionary<string, object>
            {
                { "t", "guard_zone" }, { "index", index }, { "enabled", enabled },
                { "inner_nm", innerNm }, { "outer_nm", outerNm }, { "start_deg", startDeg }, { "end_deg", endDeg }
            };
        }

        public static Dictionary<string, object> Trial(bool enabled, double courseDegTrue, double speedKn, double delayS)
        {
            return new Dictionary<string, object>
            {
                { "t", "trial" }, { "enabled", enabled },
                { "course_deg_true", courseDegTrue }, { "speed_kn", speedKn }, { "delay_s", delayS }
            };
        }

        // ---- SPOKES (type 2) ----

        private const int SpokesHeaderBytes = 8;            // u16 count, u16 bins, f32 video_range_nm
        private const int SpokeRecordHeaderBytes = 20;      // u16 azimuth, u16 gyro, f64 time, f32 ref x, f32 ref y

        // Throws InvalidDataException when the payload is not a whole SPOKES frame.
        public static SpokeFrame ParseSpokes(byte[] payload)
        {
            if (payload.Length < SpokesHeaderBytes)
            {
                throw new InvalidDataException("SPOKES payload is shorter than its header");
            }
            int spokeCount = BinaryPrimitives.ReadUInt16LittleEndian(payload.AsSpan(0, 2));
            int binsPerSpoke = BinaryPrimitives.ReadUInt16LittleEndian(payload.AsSpan(2, 2));
            double videoRangeNm = BinaryPrimitives.ReadSingleLittleEndian(payload.AsSpan(4, 4));
            int recordBytes = SpokeRecordHeaderBytes + binsPerSpoke;
            if (payload.Length != SpokesHeaderBytes + spokeCount * recordBytes)
            {
                throw new InvalidDataException("SPOKES payload is " + payload.Length + " bytes, expected "
                    + (SpokesHeaderBytes + spokeCount * recordBytes));
            }

            SpokeFrame frame = new SpokeFrame(spokeCount, binsPerSpoke, videoRangeNm);
            for (int spoke = 0; spoke < spokeCount; spoke++)
            {
                int start = SpokesHeaderBytes + spoke * recordBytes;
                frame.AzimuthIndex[spoke] = BinaryPrimitives.ReadUInt16LittleEndian(payload.AsSpan(start, 2));
                frame.GyroHeadingCdeg[spoke] = BinaryPrimitives.ReadUInt16LittleEndian(payload.AsSpan(start + 2, 2));
                frame.SimTimeS[spoke] = BinaryPrimitives.ReadDoubleLittleEndian(payload.AsSpan(start + 4, 8));
                frame.RefXNm[spoke] = BinaryPrimitives.ReadSingleLittleEndian(payload.AsSpan(start + 12, 4));
                frame.RefYNm[spoke] = BinaryPrimitives.ReadSingleLittleEndian(payload.AsSpan(start + 16, 4));
                Array.Copy(payload, start + SpokeRecordHeaderBytes, frame.Video, spoke * binsPerSpoke, binsPerSpoke);
            }
            return frame;
        }

        // The reverse of ParseSpokes. The display never sends SPOKES; the self-tests use this.
        public static byte[] PackSpokes(SpokeFrame frame)
        {
            int recordBytes = SpokeRecordHeaderBytes + frame.BinsPerSpoke;
            byte[] payload = new byte[SpokesHeaderBytes + frame.SpokeCount * recordBytes];
            BinaryPrimitives.WriteUInt16LittleEndian(payload.AsSpan(0, 2), (ushort)frame.SpokeCount);
            BinaryPrimitives.WriteUInt16LittleEndian(payload.AsSpan(2, 2), (ushort)frame.BinsPerSpoke);
            BinaryPrimitives.WriteSingleLittleEndian(payload.AsSpan(4, 4), (float)frame.VideoRangeNm);
            for (int spoke = 0; spoke < frame.SpokeCount; spoke++)
            {
                int start = SpokesHeaderBytes + spoke * recordBytes;
                BinaryPrimitives.WriteUInt16LittleEndian(payload.AsSpan(start, 2), frame.AzimuthIndex[spoke]);
                BinaryPrimitives.WriteUInt16LittleEndian(payload.AsSpan(start + 2, 2), frame.GyroHeadingCdeg[spoke]);
                BinaryPrimitives.WriteDoubleLittleEndian(payload.AsSpan(start + 4, 8), frame.SimTimeS[spoke]);
                BinaryPrimitives.WriteSingleLittleEndian(payload.AsSpan(start + 12, 4), frame.RefXNm[spoke]);
                BinaryPrimitives.WriteSingleLittleEndian(payload.AsSpan(start + 16, 4), frame.RefYNm[spoke]);
                Array.Copy(frame.Video, spoke * frame.BinsPerSpoke, payload, start + SpokeRecordHeaderBytes, frame.BinsPerSpoke);
            }
            return payload;
        }
    }

    // One SPOKES frame, unpacked. Video holds the spokes one after the other:
    // spoke s, bin b is Video[s * BinsPerSpoke + b].
    public class SpokeFrame
    {
        public int SpokeCount;
        public int BinsPerSpoke;
        public double VideoRangeNm;             // same for every spoke in the frame
        public ushort[] AzimuthIndex;           // antenna angle clockwise from the bow, in azimuth bins
        public ushort[] GyroHeadingCdeg;        // gyro heading in hundredths of a degree
        public double[] SimTimeS;               // sim time when the spoke was taken
        public float[] RefXNm;                  // own-ship reference position when the spoke was taken
        public float[] RefYNm;
        public byte[] Video;

        public SpokeFrame(int spokeCount, int binsPerSpoke, double videoRangeNm)
        {
            SpokeCount = spokeCount;
            BinsPerSpoke = binsPerSpoke;
            VideoRangeNm = videoRangeNm;
            AzimuthIndex = new ushort[spokeCount];
            GyroHeadingCdeg = new ushort[spokeCount];
            SimTimeS = new double[spokeCount];
            RefXNm = new float[spokeCount];
            RefYNm = new float[spokeCount];
            Video = new byte[spokeCount * binsPerSpoke];
        }
    }
}
