// BigReadout.cs - the large own-ship heading (gyro, deg T) and speed (log, KN) drawn in the black area at the
// top right of the PPI window, outside the circle, as on a radar; ground speed and course in small type under
// them. The text comes from BigReadoutText.
// Called by: PpiView (OnRender).

using System.Globalization;
using System.Windows;
using System.Windows.Media;

namespace RadarSim
{
    public static class BigReadout
    {
        private const double BigPx = 40.0;              // height of the figures
        private const double SmallPx = 14.0;            // height of the labels and the ground figures

        private static double DrawLine(DrawingContext dc, string text, double size, bool bold, double right, double top,
                                       Brush brush, double pixelsPerDip)
        {
            Typeface face = new Typeface(new FontFamily("Consolas"), FontStyles.Normal, bold ? FontWeights.Bold : FontWeights.Normal, FontStretches.Normal);
            FormattedText formatted = new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight, face, size, brush, pixelsPerDip);
            dc.DrawText(formatted, new Point(right - formatted.Width, top));
            return top + formatted.Height;
        }

        // The block's right edge is at right (pixels); the top at top. Returns nothing: it is only drawn.
        public static void Draw(DrawingContext dc, double right, double top, Brush brush, double pixelsPerDip,
                                double headingDeg, double logSpeedKn, double sogKn, double cogDeg)
        {
            double y = DrawLine(dc, "HEADING deg T", SmallPx, false, right, top, brush, pixelsPerDip);
            y = DrawLine(dc, BigReadoutText.Heading(headingDeg), BigPx, true, right, y, brush, pixelsPerDip);
            y = DrawLine(dc, "SPEED (LOG) KN", SmallPx, false, right, y + 6.0, brush, pixelsPerDip);
            y = DrawLine(dc, BigReadoutText.Speed(logSpeedKn), BigPx, true, right, y, brush, pixelsPerDip);
            y = DrawLine(dc, "SOG " + BigReadoutText.Speed(sogKn) + " KN", SmallPx, false, right, y + 4.0, brush, pixelsPerDip);
            DrawLine(dc, "COG " + BigReadoutText.Heading(cogDeg) + " deg T", SmallPx, false, right, y, brush, pixelsPerDip);
        }
    }
}
