// AlarmPanel.xaml.cs - the alarm list: the active alarms in the order they were raised, each with
// its text (CPA/TCPA 3, LOST TARGET 5, GUARD ZONE 1, TARGET CAPACITY), flashing at 1 Hz until it is
// acknowledged, and an ACK button (Space does the same). While any alarm is unacknowledged and
// alarm_sound is true, SystemSounds.Exclamation plays at once and then every 2 s. Nothing else pops up.
// Units: flash 1 Hz (the window's timer toggles ArpaController.FlashOn every 0.5 s), sound every 2 s.
// Called by: MainWindow (Attach, Refresh, ShowFlash), SelfTest.

using System;
using System.Media;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace RadarSim
{
    public partial class AlarmPanel : UserControl
    {
        private const double SoundIntervalS = 2.0;              // BRIEF.md Section 11: repeat every 2 s

        private DisplayController owner;
        private ArpaController arpa;
        private readonly DispatcherTimer soundTimer;

        public AlarmPanel()
        {
            InitializeComponent();
            soundTimer = new DispatcherTimer(TimeSpan.FromSeconds(SoundIntervalS), DispatcherPriority.Normal, SoundTick, Dispatcher);
            soundTimer.Stop();
        }

        // True while the sound repeats.
        public bool SoundTimerRunning
        {
            get { return soundTimer.IsEnabled; }
        }

        // Follows the controller's Changed event, which also fires when alarm_sound changes.
        public void Attach(DisplayController controller)
        {
            if (owner != null)
            {
                owner.Changed -= Refresh;
            }
            owner = controller;
            arpa = controller.Arpa;
            owner.Changed += Refresh;
            Refresh();
        }

        private void AckButton_Click(object sender, RoutedEventArgs e)
        {
            if (arpa != null)
            {
                arpa.AcknowledgeAll();
            }
        }

        private void SoundTick(object sender, EventArgs e)
        {
            if (arpa != null && arpa.SoundWanted)
            {
                SystemSounds.Exclamation.Play();
            }
            else
            {
                soundTimer.Stop();
            }
        }

        // Rebuilds the list, and starts or stops the sound.
        public void Refresh()
        {
            if (arpa == null)
            {
                return;
            }
            AlarmList.Children.Clear();
            foreach (AlarmItem alarm in arpa.Alarms)
            {
                TextBlock text = new TextBlock();
                text.Text = alarm.Text + (alarm.Active ? "" : "  (over)");
                text.FontFamily = new FontFamily("Consolas");
                text.FontWeight = FontWeights.Bold;
                text.Padding = new Thickness(4, 2, 4, 2);
                text.Margin = new Thickness(0, 0, 0, 2);
                text.Tag = alarm.Acknowledged;
                AlarmList.Children.Add(text);
            }
            ShowFlash();
            AckButton.IsEnabled = arpa.AnyUnacknowledged;
            UpdateSound();
        }

        // Called twice a second with the flash phase: an unacknowledged alarm alternates red and plain.
        public void ShowFlash()
        {
            if (arpa == null)
            {
                return;
            }
            foreach (object child in AlarmList.Children)
            {
                TextBlock text = child as TextBlock;
                if (text == null)
                {
                    continue;
                }
                bool acknowledged = (bool)text.Tag;
                bool lit = !acknowledged && arpa.FlashOn;
                text.Background = lit ? Brushes.Red : Brushes.Transparent;
                if (lit)
                {
                    text.Foreground = Brushes.White;
                }
                else
                {
                    text.SetResourceReference(TextBlock.ForegroundProperty, "ThemeText");
                }
            }
        }

        // The sound plays at once when it becomes wanted, then every 2 s; it stops when no alarm is waiting.
        private void UpdateSound()
        {
            bool wanted = arpa.SoundWanted;
            if (wanted && !soundTimer.IsEnabled)
            {
                SystemSounds.Exclamation.Play();
                soundTimer.Start();
            }
            else if (!wanted && soundTimer.IsEnabled)
            {
                soundTimer.Stop();
            }
        }
    }
}
