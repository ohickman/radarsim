// EblVrm.cs - electronic bearing lines (EBL 1 and 2) and variable range markers
// (VRM 1 and 2): the state and the geometry (BRIEF.md Section 11). They are display
// aids, computed here and drawn by PpiView; the sim never sees them.
// An EBL is stored in the way it is read: deg T, or deg R (from the bow) when
// EblRelative is true, in which case it turns with the ship's heading.
// A VRM is stored in NM.
// Units: bearings deg, ranges NM, pixels of the PPI bitmap (see PpiGeometry).
// Called by: DisplayController (keys, typed values), PpiView (drawing, dragging),
// ControlPanel (readouts), SelfTest.

using System;

namespace RadarSim
{
    public class EblVrmSet
    {
        public const int Count = 2;
        public const int PiCount = 2;                           // two parallel index lines, often used as a pair

        public bool[] EblOn = new bool[Count];
        public double[] EblBearingDeg = new double[Count];      // deg T, or deg R when EblRelative
        public bool EblRelative;
        public bool[] VrmOn = new bool[Count];
        public double[] VrmNm = new double[Count];
        public int SelectedEbl;                                 // 0 or 1: the one the Left and Right keys move
        public int SelectedVrm;                                 // 0 or 1: the one the Up and Down keys move
        public bool[] PiOn = new bool[PiCount];                 // the parallel index lines
        public double[] PiBearingDeg = new double[PiCount];     // direction of each line, read like the EBLs (deg T or deg R)
        public double[] PiNm = new double[PiCount];             // NM, distance from own ship; + is to the right of the line's direction, - to the left

        public EblVrmSet()
        {
            Reset();
        }

        public void Reset()
        {
            for (int i = 0; i < Count; i++)
            {
                EblOn[i] = false;
                EblBearingDeg[i] = 0.0;             // EBL starts at 000
                VrmOn[i] = false;
                VrmNm[i] = -1.0;                    // not set yet; the first use sets 50 % of the range scale
            }
            for (int i = 0; i < PiCount; i++)
            {
                PiOn[i] = false;
                PiBearingDeg[i] = 0.0;
                PiNm[i] = 0.0;
            }
            EblRelative = false;
            SelectedEbl = 0;
            SelectedVrm = 0;
        }

        public string EblUnit
        {
            get { return EblRelative ? "deg R" : "deg T"; }
        }

        // ---- EBL ----

        public double EblTrueDeg(int index, double headingDegTrue)
        {
            if (EblRelative)
            {
                return PpiGeometry.Normalise360(EblBearingDeg[index] + headingDegTrue);
            }
            return PpiGeometry.Normalise360(EblBearingDeg[index]);
        }

        public void SetEblTrueDeg(int index, double bearingDegTrue, double headingDegTrue)
        {
            if (EblRelative)
            {
                EblBearingDeg[index] = PpiGeometry.Normalise360(bearingDegTrue - headingDegTrue);
            }
            else
            {
                EblBearingDeg[index] = PpiGeometry.Normalise360(bearingDegTrue);
            }
        }

        // A typed value, read in the unit the EBL reads in (deg T or deg R).
        public void SetEblReading(int index, double bearingDeg)
        {
            EblBearingDeg[index] = PpiGeometry.Normalise360(bearingDeg);
        }

        // Switching between true and relative keeps every line where it is on the screen.
        public void SetRelativeMode(bool relative, double headingDegTrue)
        {
            if (relative == EblRelative)
            {
                return;
            }
            double[] trueDeg = new double[Count];
            for (int i = 0; i < Count; i++)
            {
                trueDeg[i] = EblTrueDeg(i, headingDegTrue);
            }
            double[] piTrueDeg = new double[PiCount];
            for (int i = 0; i < PiCount; i++)
            {
                piTrueDeg[i] = PiTrueDeg(i, headingDegTrue);
            }
            EblRelative = relative;
            for (int i = 0; i < PiCount; i++)
            {
                PiBearingDeg[i] = PpiGeometry.Normalise360(EblRelative ? piTrueDeg[i] - headingDegTrue : piTrueDeg[i]);
            }
            for (int i = 0; i < Count; i++)
            {
                SetEblTrueDeg(i, trueDeg[i], headingDegTrue);
            }
        }

        public double EblScreenAngleDeg(int index, PpiGeometry geometry)
        {
            return geometry.ScreenAngleDeg(EblTrueDeg(index, geometry.HeadingDegTrue));
        }

        // The far end of the line, where it meets the edge of the PPI circle.
        public void EblEndPx(int index, PpiGeometry geometry, out double xPx, out double yPx)
        {
            geometry.EdgePointPx(EblScreenAngleDeg(index, geometry), out xPx, out yPx);
        }

        public void SetEblFromPixel(int index, PpiGeometry geometry, double xPx, double yPx)
        {
            double rangeNm, bearingDegTrue;
            geometry.RangeBearingOf(xPx, yPx, out rangeNm, out bearingDegTrue);
            SetEblTrueDeg(index, bearingDegTrue, geometry.HeadingDegTrue);
        }

        public void AdjustSelectedEbl(double deltaDeg)
        {
            EblBearingDeg[SelectedEbl] = PpiGeometry.Normalise360(EblBearingDeg[SelectedEbl] + deltaDeg);
        }

        // ---- parallel index line ----

        public double PiTrueDeg(int index, double headingDegTrue)
        {
            return PpiGeometry.Normalise360(EblRelative ? PiBearingDeg[index] + headingDegTrue : PiBearingDeg[index]);
        }

        public void SetPiBearing(int index, double bearingDeg)
        {
            PiBearingDeg[index] = PpiGeometry.Normalise360(bearingDeg);
        }

        public void SetPiNm(int index, double distanceNm, PpiGeometry geometry)
        {
            PiNm[index] = ControlMath.Clamp(distanceNm, -geometry.RangeScaleNm, geometry.RangeScaleNm);
        }

        // The two ends of the line where it meets the edge of the PPI circle (bitmap pixels). The line runs
        // in the direction PiBearingDeg, PiNm to the right of own ship. False when it misses the picture.
        public bool PiEndsPx(int index, PpiGeometry geometry, out double x1, out double y1, out double x2, out double y2)
        {
            double angleRad = geometry.ScreenAngleDeg(PiTrueDeg(index, geometry.HeadingDegTrue)) * Math.PI / 180.0;   // deg -> rad
            double dx = Math.Sin(angleRad);
            double dy = -Math.Cos(angleRad);
            double offsetPx = PiNm[index] / geometry.RangeScaleNm * geometry.RadiusPx;         // NM -> px
            double px = geometry.OwnXPx + offsetPx * -dy;               // right of the direction: (-dy, dx) on the screen
            double py = geometry.OwnYPx + offsetPx * dx;
            double wx = px - geometry.CentreXPx;
            double wy = py - geometry.CentreYPx;
            double along = wx * dx + wy * dy;
            double discriminant = along * along - (wx * wx + wy * wy) + geometry.RadiusPx * geometry.RadiusPx;
            if (discriminant <= 0.0)
            {
                x1 = y1 = x2 = y2 = 0.0;
                return false;
            }
            double root = Math.Sqrt(discriminant);
            x1 = px + (-along - root) * dx;
            y1 = py + (-along - root) * dy;
            x2 = px + (-along + root) * dx;
            y2 = py + (-along + root) * dy;
            return true;
        }

        // ---- VRM ----

        public double VrmRadiusPx(int index, PpiGeometry geometry)
        {
            return VrmNm[index] / geometry.RangeScaleNm * geometry.RadiusPx;       // NM -> px
        }

        public void SetVrmFromPixel(int index, PpiGeometry geometry, double xPx, double yPx)
        {
            double rangeNm, bearingDegTrue;
            geometry.RangeBearingOf(xPx, yPx, out rangeNm, out bearingDegTrue);
            VrmNm[index] = ControlMath.Clamp(rangeNm, 0.0, geometry.RangeScaleNm);
        }

        public void SetVrmNm(int index, double rangeNm, PpiGeometry geometry)
        {
            VrmNm[index] = ControlMath.Clamp(rangeNm, 0.0, geometry.RangeScaleNm);
        }

        // Up and Down keys: percent of the range scale (1 %, Shift 0.1 %, Ctrl 10 %).
        public void AdjustSelectedVrm(double deltaPercentOfScale, PpiGeometry geometry)
        {
            double deltaNm = deltaPercentOfScale / 100.0 * geometry.RangeScaleNm;  // % -> NM
            SetVrmNm(SelectedVrm, VrmNm[SelectedVrm] + deltaNm, geometry);
        }

        // ---- keys 1, 2, 3, 4: toggle and select ----

        public void ToggleEbl(int index)
        {
            EblOn[index] = !EblOn[index];
            if (EblOn[index])
            {
                SelectedEbl = index;
            }
        }

        public void ToggleVrm(int index, PpiGeometry geometry)
        {
            VrmOn[index] = !VrmOn[index];
            if (VrmOn[index])
            {
                SelectedVrm = index;
                if (VrmNm[index] < 0.0)
                {
                    VrmNm[index] = 0.5 * geometry.RangeScaleNm;     // default: 50 % of the range scale
                }
            }
        }

        // ---- mouse: which line or ring is under the pointer ----

        // The nearest EBL line or VRM ring to the point, within the tolerance (bitmap pixels).
        public bool HitTest(PpiGeometry geometry, double xPx, double yPx, double tolerancePx,
                            out bool isEbl, out int index)
        {
            isEbl = false;
            index = 0;
            double bestDistancePx = tolerancePx;
            bool found = false;

            for (int i = 0; i < Count; i++)
            {
                if (EblOn[i])
                {
                    double endX, endY;
                    EblEndPx(i, geometry, out endX, out endY);
                    double distancePx = DistanceToSegmentPx(xPx, yPx, geometry.OwnXPx, geometry.OwnYPx, endX, endY);
                    if (distancePx <= bestDistancePx)
                    {
                        bestDistancePx = distancePx;
                        isEbl = true;
                        index = i;
                        found = true;
                    }
                }
                if (VrmOn[i])
                {
                    double dx = xPx - geometry.OwnXPx;
                    double dy = yPx - geometry.OwnYPx;
                    double distancePx = Math.Abs(Math.Sqrt(dx * dx + dy * dy) - VrmRadiusPx(i, geometry));
                    if (distancePx <= bestDistancePx)
                    {
                        bestDistancePx = distancePx;
                        isEbl = false;
                        index = i;
                        found = true;
                    }
                }
            }
            return found;
        }

        private static double DistanceToSegmentPx(double px, double py, double ax, double ay, double bx, double by)
        {
            double abx = bx - ax;
            double aby = by - ay;
            double lengthSquared = abx * abx + aby * aby;
            double along = 0.0;
            if (lengthSquared > 0.0)
            {
                along = ControlMath.Clamp(((px - ax) * abx + (py - ay) * aby) / lengthSquared, 0.0, 1.0);
            }
            double nearestX = ax + along * abx;
            double nearestY = ay + along * aby;
            double dx = px - nearestX;
            double dy = py - nearestY;
            return Math.Sqrt(dx * dx + dy * dy);
        }
    }
}
