// ContactList.cs - the list of acquired contacts next to the PPI: one line per target (ID, range,
// bearing, CPA, TCPA, state), in ID order, the selected one highlighted; a click on a line selects
// that target. ContactListLogic has no WPF types; ContactListView is the code-built panel.
// Units: RNG and CPA NM, BRG deg T, TCPA MIN (negative = opening). A value the sim sent as null shows "--".
// Called by: MainWindow (Attach, OnControllerChanged), SelfTest.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace RadarSim
{
    public class ContactListView : Grid
    {
        private readonly ListBox box = new ListBox();
        private readonly TextBlock title = new TextBlock();
        private DisplayController owner;
        private bool filling;

        public ContactListView()
        {
            RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            title.Text = ContactListLogic.Header;
            title.FontSize = 11.0;
            title.FontFamily = new FontFamily("Consolas");
            title.FontWeight = FontWeights.Bold;
            title.Margin = new Thickness(7, 0, 0, 2);          // lines up with the text of the items below (list border and item padding)
            SetRow(title, 0);
            Children.Add(title);
            box.FontSize = 11.0;
            box.SetResourceReference(Control.BackgroundProperty, "ThemePanel");
            box.SetResourceReference(Control.ForegroundProperty, "ThemeText");
            box.SetResourceReference(Control.BorderBrushProperty, "ThemeBorder");
            box.FontFamily = new FontFamily("Consolas");
            box.MinHeight = 60;
            box.SelectionChanged += Box_SelectionChanged;
            SetRow(box, 1);
            Children.Add(box);
        }

        public void Attach(DisplayController controller)
        {
            owner = controller;
            Refresh();
        }

        public int RowCount
        {
            get { return box.Items.Count; }
        }

        public void Refresh()
        {
            if (owner == null)
            {
                return;
            }
            ArpaController arpa = owner.Arpa;
            double cpaLimit, tcpaLimit;
            if (!owner.Numbers.TryGetValue(ArpaController.CpaLimitPath, out cpaLimit)) { cpaLimit = 0.0; }
            if (!owner.Numbers.TryGetValue(ArpaController.TcpaLimitPath, out tcpaLimit)) { tcpaLimit = 0.0; }
            List<ContactLine> lines = ContactListLogic.Lines(arpa.Targets.Targets, arpa.SelectedId, cpaLimit, tcpaLimit);
            filling = true;
            box.Items.Clear();
            foreach (ContactLine line in lines)
            {
                ListBoxItem item = new ListBoxItem();
                item.Content = line.Text;
                item.Tag = line.Id;
                item.Padding = new Thickness(2, 0, 2, 0);
                if (line.Dangerous)
                {
                    item.Foreground = Brushes.Red;
                    item.FontWeight = FontWeights.Bold;
                }
                box.Items.Add(item);
                if (line.Selected)
                {
                    box.SelectedItem = item;
                }
            }
            filling = false;
        }

        private void Box_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (filling || owner == null)
            {
                return;
            }
            ListBoxItem item = box.SelectedItem as ListBoxItem;
            owner.Arpa.SelectId(item == null ? -1 : (int)item.Tag);
        }
    }
}
