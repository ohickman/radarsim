// PpiView.cs - the PPI control: shows the scan-converted bitmap and draws, over it,
// the range rings, heading line, bearing scale, own-ship mark and the cursor readout.
// The UI thread redraws about 30 times a second. Rings, heading line and bearing
// scale are computed in bitmap pixels by PpiGeometry and scaled to the window here.
// Trails (M7) are redrawn by the trail layer about 4 times a second onto a bitmap of their own,
// which is drawn over the video and under the rings and symbols. Each tick the view also takes
// own ship's reference position and the true-motion view origin from the painter, so own ship's
// mark moves in true motion.
// Targets (M9) are drawn from the ARPA controller's layout: boxes, vectors, history dots and the
// guard zones that are on, over the video and trails and under own ship's mark. A click on a box
// selects it, a click on empty screen deselects.
// Units: ranges NM, bearings deg T / deg R, brilliance 0..1, sizes in screen pixels.
// Called by: MainWindow, which owns the geometry and the options below.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace RadarSim
{
    public class PpiView : FrameworkElement
    {
        private const double CircleFractionOfSide = 0.92;       // the rest is a margin for the bearing labels
        private const int RedrawMs = 33;
        private const double RingLabelAngleDeg = 135.0;         // screen angle where range rings are labelled
        private const double LongTickPx = 12.0;
        private const double ShortTickPx = 6.0;
        private const double LabelFontPx = 11.0;
        private const double GrabTolerancePx = 8.0;             // screen pixels: how near the pointer must be to grab an EBL or VRM
        private const double TargetBoxHalfPx = 7.0;             // screen pixels: half the side of a target box
        private const double HistoryDotRadiusPx = 2.0;
        private const int TrailRedrawMs = 250;                  // trail layer redraw interval (BRIEF.md: about 4 times a second)

        public PpiGeometry Geometry;                            // the UI thread's copy, owned by MainWindow
        public bool ShowRings = true;
        public double RingIntervalNm = 1.0;
        public bool ShowHeadingLine = true;
        public bool ShowBearingScale = true;
        public double RingsBrilliance = 0.5;
        public double SymbolsBrilliance = 1.0;
        public uint SymbolColour = 0xFFFFFFFF;                  // colour mode; mono uses the mono hue
        public EblVrmSet EblVrm;                                // drawn when set; moved with the mouse
        public bool OwnInfoValid;                               // the own-ship figures below have been set
        public double OwnHeadingDeg, OwnLogSpeedKn, OwnSogKn, OwnCogDeg;     // deg T, KN, KN, deg T: drawn big at the top right
        public ArpaController Arpa;                             // targets, selection and guard zones (M9)
        public DisplayController Controller;                    // the instructor overlay's data and switch (M10)
        public Action EblVrmChanged;                            // called after the mouse moved an EBL or VRM
        public bool HeadingLineHidden;                          // H is held
        public bool CursorValid;                                // the pointer is on the PPI
        public double CursorXPx;                                // pointer position, bitmap pixels
        public double CursorYPx;

        private PpiBitmap bitmap;
        private WriteableBitmap shown;
        private WriteableBitmap trailShown;
        private uint[] trailPixels;
        private bool trailShownEmpty = true;                    // the trail bitmap holds nothing
        private readonly Stopwatch trailClock = Stopwatch.StartNew();
        private long lastTrailRedrawMs = -TrailRedrawMs;
        private string cursorText = "";
        private bool draggingEblVrm;
        private bool dragIsEbl;
        private int dragIndex;
        private readonly Typeface typeface = new Typeface("Consolas");
        private readonly DispatcherTimer timer;

        public PpiView()
        {
            Focusable = true;
            RenderOptions.SetBitmapScalingMode(this, BitmapScalingMode.Linear);
            timer = new DispatcherTimer(TimeSpan.FromMilliseconds(RedrawMs), DispatcherPriority.Render, Tick, Dispatcher);
        }

        public void Attach(PpiBitmap bitmapToShow, PpiGeometry geometry)
        {
            bitmap = bitmapToShow;
            Geometry = geometry;
            shown = new WriteableBitmap(bitmap.SizePx, bitmap.SizePx, 96.0, 96.0, PixelFormats.Pbgra32, null);
            trailShown = new WriteableBitmap(bitmap.SizePx, bitmap.SizePx, 96.0, 96.0, PixelFormats.Pbgra32, null);
            trailPixels = new uint[bitmap.SizePx * bitmap.SizePx];
            trailShownEmpty = true;
            lock (bitmap.Sync)
            {
                bitmap.Dirty = true;
            }
        }

        private void Tick(object sender, EventArgs e)
        {
            double nowSimS = 0.0;
            if (bitmap != null)
            {
                lock (bitmap.Sync)
                {
                    if (bitmap.Dirty)
                    {
                        bitmap.Colourise();
                        shown.WritePixels(new Int32Rect(0, 0, bitmap.SizePx, bitmap.SizePx), bitmap.Pixels, bitmap.SizePx * 4, 0);
                    }
                    if (Geometry != null)
                    {
                        if (bitmap.HaveRef)
                        {
                            Geometry.OwnRefXNm = bitmap.LatestRefXNm;
                            Geometry.OwnRefYNm = bitmap.LatestRefYNm;
                        }
                        Geometry.ViewOriginXNm = bitmap.ViewOriginXNm;
                        Geometry.ViewOriginYNm = bitmap.ViewOriginYNm;
                    }
                    nowSimS = bitmap.LatestSimTimeS;
                }
                RedrawTrails(nowSimS);
            }
            InvalidateVisual();
        }

        // About 4 times a second: rebuild the trail layer and copy it to its bitmap. The layer
        // is mono: the hue (or the symbol colour) scaled by the age and the video brilliance.
        private void RedrawTrails(double nowSimS)
        {
            TrailLayer trails = bitmap.Trails;
            if (Geometry == null || trailShown == null)
            {
                return;
            }
            long nowMs = trailClock.ElapsedMilliseconds;
            if (nowMs - lastTrailRedrawMs < TrailRedrawMs)
            {
                return;
            }
            lastTrailRedrawMs = nowMs;
            if (trails.Mode == TrailMode.Off && trailShownEmpty)
            {
                return;
            }
            trails.Redraw(Geometry, nowSimS);
            uint foreground = bitmap.ColourMode ? SymbolColour : bitmap.MonoHue;
            double red = (foreground >> 16) & 0xFF;
            double green = (foreground >> 8) & 0xFF;
            double blue = foreground & 0xFF;
            double brilliance = bitmap.VideoBrilliance;
            bool any = false;
            lock (trails.Sync)
            {
                byte[] alpha = trails.Alpha;
                for (int i = 0; i < alpha.Length; i++)
                {
                    if (alpha[i] == 0)
                    {
                        trailPixels[i] = 0;
                        continue;
                    }
                    any = true;
                    double a = alpha[i] / 255.0 * brilliance;
                    trailPixels[i] = ((uint)Math.Round(a * 255.0) << 24) | ((uint)Math.Round(red * a) << 16)
                        | ((uint)Math.Round(green * a) << 8) | (uint)Math.Round(blue * a);
                }
                trails.Dirty = false;
            }
            trailShown.WritePixels(new Int32Rect(0, 0, bitmap.SizePx, bitmap.SizePx), trailPixels, bitmap.SizePx * 4, 0);
            trailShownEmpty = !any;
        }

        // ---- colours ----

        private static Color ColourOf(uint argb)
        {
            return Color.FromRgb((byte)(argb >> 16), (byte)(argb >> 8), (byte)argb);
        }

        // Rings, scale and symbols: the hue (mono) or the symbol colour (colour mode),
        // faded toward the background by the brilliance.
        private Brush SymbolBrush(double brilliance)
        {
            uint foreground = bitmap.ColourMode ? SymbolColour : bitmap.MonoHue;
            uint background = bitmap.ColourMode ? bitmap.ColourBackground : bitmap.MonoBackground;
            return new SolidColorBrush(ColourOf(PpiBitmap.Blend(background, foreground, brilliance)));
        }

        // ---- layout ----

        // Where the bitmap sits in the window: its top-left corner and screen pixels per bitmap pixel.
        private void LayoutOf(out double left, out double top, out double scale)
        {
            double side = Math.Min(ActualWidth, ActualHeight);
            scale = side * CircleFractionOfSide / Geometry.SizePx;
            left = (ActualWidth - Geometry.SizePx * scale) / 2.0;
            top = (ActualHeight - Geometry.SizePx * scale) / 2.0;
        }

        // ---- drawing ----

        protected override void OnRender(DrawingContext dc)
        {
            base.OnRender(dc);
            if (Geometry == null || bitmap == null)
            {
                return;
            }
            uint background = bitmap.ColourMode ? bitmap.ColourBackground : bitmap.MonoBackground;
            dc.DrawRectangle(new SolidColorBrush(ColourOf(background)), null, new Rect(0.0, 0.0, ActualWidth, ActualHeight));
            if (ActualWidth < 100.0 || ActualHeight < 100.0)
            {
                return;
            }

            double left, top, scale;
            LayoutOf(out left, out top, out scale);
            double sizeScreen = Geometry.SizePx * scale;
            dc.DrawImage(shown, new Rect(left, top, sizeScreen, sizeScreen));
            if (trailShown != null && !trailShownEmpty)
            {
                dc.DrawImage(trailShown, new Rect(left, top, sizeScreen, sizeScreen));
            }

            Point centre = new Point(left + Geometry.CentreXPx * scale, top + Geometry.CentreYPx * scale);
            double radiusScreen = Geometry.RadiusPx * scale;
            Point own = new Point(left + Geometry.OwnXPx * scale, top + Geometry.OwnYPx * scale);
            Brush ringBrush = SymbolBrush(RingsBrilliance);
            Brush symbolBrush = SymbolBrush(SymbolsBrilliance);

            if (ShowRings && RingIntervalNm > 0.0)
            {
                DrawRings(dc, centre, radiusScreen, own, scale, ringBrush);
            }
            if (ShowBearingScale)
            {
                DrawBearingScale(dc, centre, radiusScreen, symbolBrush, left, top, scale);
            }
            if (ShowHeadingLine && !HeadingLineHidden)
            {
                double endX, endY;
                Geometry.HeadingLineEndPx(out endX, out endY);
                dc.DrawLine(new Pen(symbolBrush, 1.5), own, new Point(left + endX * scale, top + endY * scale));
            }

            DrawEblVrm(dc, left, top, scale, own, symbolBrush);
            DrawGuardZones(dc, left, top, scale, symbolBrush);
            DrawTargets(dc, left, top, scale);
            DrawInstructor(dc, left, top, scale);

            // Own-ship mark: a small ring with a cross.
            Pen markPen = new Pen(symbolBrush, 1.5);
            dc.DrawEllipse(null, markPen, own, 5.0, 5.0);
            dc.DrawLine(markPen, new Point(own.X - 9.0, own.Y), new Point(own.X + 9.0, own.Y));
            dc.DrawLine(markPen, new Point(own.X, own.Y - 9.0), new Point(own.X, own.Y + 9.0));

            DrawReadout(dc, symbolBrush);
            if (OwnInfoValid)
            {
                BigReadout.Draw(dc, ActualWidth - 14.0, 8.0, symbolBrush, VisualTreeHelper.GetDpi(this).PixelsPerDip,
                                OwnHeadingDeg, OwnLogSpeedKn, OwnSogKn, OwnCogDeg);
            }

            if (cursorText != "")
            {
                DrawText(dc, cursorText, new Point(8.0, ActualHeight - 22.0), symbolBrush, false);
            }
        }

        // The selected target's data, top left of the screen, over a dark panel so it can be read
        // over the video. Nothing is drawn while no target is selected.
        private void DrawReadout(DrawingContext dc, Brush symbolBrush)
        {
            if (Arpa == null || Arpa.SelectedTarget == null || Geometry == null)
            {
                return;
            }
            List<ReadoutRow> rows = TargetReadout.Rows(Arpa.SelectedTarget, Geometry.HeadingDegTrue, Arpa.Trial.Enabled);
            if (rows.Count == 0)
            {
                return;
            }
            Typeface mono = new Typeface("Consolas");
            double dpi = VisualTreeHelper.GetDpi(this).PixelsPerDip;
            List<FormattedText> lines = new List<FormattedText>();
            double width = 0.0;
            double height = 0.0;
            foreach (ReadoutRow row in rows)
            {
                FormattedText line = new FormattedText(row.Label.PadRight(11) + row.Text, CultureInfo.InvariantCulture,
                                                       FlowDirection.LeftToRight, mono, LabelFontPx, symbolBrush, dpi);
                lines.Add(line);
                width = Math.Max(width, line.Width);
                height += line.Height;
            }
            dc.DrawRectangle(new SolidColorBrush(Color.FromArgb(200, 0, 0, 0)), null, new Rect(4.0, 4.0, width + 12.0, height + 8.0));
            double y = 8.0;
            foreach (FormattedText line in lines)
            {
                dc.DrawText(line, new Point(10.0, y));
                y += line.Height;
            }
        }

        // ---- targets and guard zones (M9) ----

        private Point ScreenPoint(double xPx, double yPx, double left, double top, double scale)
        {
            return new Point(left + xPx * scale, top + yPx * scale);
        }

        // One box per target: ACQ dashed, TREND and TRACK solid with the ID beside it, the selected one
        // brighter and thicker, LOST crossed and flashing until acknowledged. Vectors start at the box
        // centre. Boxes are where the last message put them; they do not move between messages.
        private void DrawTargets(DrawingContext dc, double left, double top, double scale)
        {
            if (Arpa == null)
            {
                return;
            }
            List<TargetShape> shapes = Arpa.Layout(Geometry);
            Brush normalBrush = SymbolBrush(SymbolsBrilliance);
            Brush selectedBrush = SymbolBrush(1.0);
            Point centre = new Point(left + Geometry.CentreXPx * scale, top + Geometry.CentreYPx * scale);
            double radiusScreen = Geometry.RadiusPx * scale;
            dc.PushClip(new EllipseGeometry(centre, radiusScreen, radiusScreen));
            foreach (TargetShape shape in shapes)
            {
                Brush brush = shape.Selected ? selectedBrush : normalBrush;
                double thickness = shape.Selected ? 2.5 : 1.5;
                Point box = ScreenPoint(shape.BoxXPx, shape.BoxYPx, left, top, scale);

                foreach (PointPx dot in shape.HistoryPx)
                {
                    dc.DrawEllipse(brush, null, ScreenPoint(dot.X, dot.Y, left, top, scale), HistoryDotRadiusPx, HistoryDotRadiusPx);
                }
                if (shape.HasVector)
                {
                    Pen vectorPen = new Pen(brush, thickness);
                    if (shape.VectorDashed)
                    {
                        vectorPen.DashStyle = DashStyles.Dash;
                    }
                    dc.DrawLine(vectorPen, box, ScreenPoint(shape.VectorEndXPx, shape.VectorEndYPx, left, top, scale));
                }
                if (shape.Flashing && !Arpa.FlashOn)
                {
                    continue;                                       // a lost target that nobody has acknowledged blinks
                }
                Pen boxPen = new Pen(brush, thickness);
                if (shape.State == TargetState.Acq)
                {
                    boxPen.DashStyle = DashStyles.Dash;
                }
                Rect rect = new Rect(box.X - TargetBoxHalfPx, box.Y - TargetBoxHalfPx, 2.0 * TargetBoxHalfPx, 2.0 * TargetBoxHalfPx);
                dc.DrawRectangle(null, boxPen, rect);
                if (shape.Crossed)
                {
                    dc.DrawLine(boxPen, rect.TopLeft, rect.BottomRight);
                    dc.DrawLine(boxPen, rect.TopRight, rect.BottomLeft);
                }
                if (shape.Label != "")
                {
                    DrawText(dc, shape.Label, new Point(box.X + TargetBoxHalfPx + 3.0, box.Y - TargetBoxHalfPx - 4.0), brush, false);
                }
            }
            dc.Pop();
        }

        // The instructor overlay (M10): own ship's ground track as a dotted line, and for every contact a
        // diamond at its true position, a line of its true motion and a label. Orange, so that it cannot be
        // taken for the radar picture. Only while the overlay is on.
        private void DrawInstructor(DrawingContext dc, double left, double top, double scale)
        {
            if (Controller == null || !Controller.InstructorOn || !Controller.Instructor.HasData)
            {
                return;
            }
            InstructorShapes shapes = Controller.Instructor.Layout(Geometry, Controller.OwnGroundXNm, Controller.OwnGroundYNm,
                                                                   Geometry.OwnRefXNm, Geometry.OwnRefYNm);
            Brush brush = new SolidColorBrush(Color.FromRgb(255, 160, 0));
            Pen pen = new Pen(brush, 1.5);
            Point centre = new Point(left + Geometry.CentreXPx * scale, top + Geometry.CentreYPx * scale);
            double radiusScreen = Geometry.RadiusPx * scale;
            dc.PushClip(new EllipseGeometry(centre, radiusScreen, radiusScreen));
            Pen trackPen = new Pen(brush, 1.0);
            trackPen.DashStyle = DashStyles.Dot;
            for (int i = 1; i < shapes.OwnTrackPx.Count; i++)
            {
                dc.DrawLine(trackPen, ScreenPoint(shapes.OwnTrackPx[i - 1].X, shapes.OwnTrackPx[i - 1].Y, left, top, scale),
                            ScreenPoint(shapes.OwnTrackPx[i].X, shapes.OwnTrackPx[i].Y, left, top, scale));
            }
            foreach (TruthShape shape in shapes.Contacts)
            {
                Point at = ScreenPoint(shape.XPx, shape.YPx, left, top, scale);
                const double half = 4.0;
                StreamGeometry diamond = new StreamGeometry();
                using (StreamGeometryContext context = diamond.Open())
                {
                    context.BeginFigure(new Point(at.X, at.Y - half), false, true);
                    context.LineTo(new Point(at.X + half, at.Y), true, false);
                    context.LineTo(new Point(at.X, at.Y + half), true, false);
                    context.LineTo(new Point(at.X - half, at.Y), true, false);
                }
                dc.DrawGeometry(null, pen, diamond);
                dc.DrawLine(pen, at, ScreenPoint(shape.LineEndXPx, shape.LineEndYPx, left, top, scale));
                DrawText(dc, shape.Label, new Point(at.X + half + 3.0, at.Y + half), brush, false);
            }
            dc.Pop();
        }

        // A guard zone as a ring sector, only while it is on.
        private void DrawGuardZones(DrawingContext dc, double left, double top, double scale, Brush brush)
        {
            if (Arpa == null)
            {
                return;
            }
            Pen zonePen = new Pen(brush, 1.5);
            zonePen.DashStyle = DashStyles.Dot;
            foreach (GuardZoneShape zone in Arpa.ZoneShapes(Geometry))
            {
                Point centre = ScreenPoint(zone.CentreXPx, zone.CentreYPx, left, top, scale);
                double innerScreen = zone.InnerPx * scale;
                double outerScreen = zone.OuterPx * scale;
                if (zone.SweepDeg >= 360.0)
                {
                    dc.DrawEllipse(null, zonePen, centre, outerScreen, outerScreen);
                    if (innerScreen > 0.5)
                    {
                        dc.DrawEllipse(null, zonePen, centre, innerScreen, innerScreen);
                    }
                    continue;
                }
                bool largeArc = zone.SweepDeg > 180.0;
                StreamGeometry sector = new StreamGeometry();
                using (StreamGeometryContext context = sector.Open())
                {
                    context.BeginFigure(ScreenPoint(zone.StartOuter.X, zone.StartOuter.Y, left, top, scale), false, false);
                    context.ArcTo(ScreenPoint(zone.EndOuter.X, zone.EndOuter.Y, left, top, scale), new Size(outerScreen, outerScreen),
                                  0.0, largeArc, SweepDirection.Clockwise, true, false);
                    context.LineTo(ScreenPoint(zone.EndInner.X, zone.EndInner.Y, left, top, scale), true, false);
                    context.ArcTo(ScreenPoint(zone.StartInner.X, zone.StartInner.Y, left, top, scale), new Size(innerScreen, innerScreen),
                                  0.0, largeArc, SweepDirection.Counterclockwise, true, false);
                    context.LineTo(ScreenPoint(zone.StartOuter.X, zone.StartOuter.Y, left, top, scale), true, false);
                }
                sector.Freeze();
                dc.DrawGeometry(null, zonePen, sector);
            }
        }

        // EBL lines and VRM rings; the second of each is dashed and the selected one is thicker.
        // Their readouts, with units, are listed at the top left.
        private void DrawEblVrm(DrawingContext dc, double left, double top, double scale, Point own, Brush brush)
        {
            if (EblVrm == null)
            {
                return;
            }
            Point centre = new Point(left + Geometry.CentreXPx * scale, top + Geometry.CentreYPx * scale);
            double radiusScreen = Geometry.RadiusPx * scale;
            double textY = 8.0;
            for (int i = 0; i < EblVrmSet.Count; i++)
            {
                if (EblVrm.EblOn[i])
                {
                    double endX, endY;
                    EblVrm.EblEndPx(i, Geometry, out endX, out endY);
                    Pen eblPen = new Pen(brush, EblVrm.SelectedEbl == i ? 2.0 : 1.0);
                    if (i == 1)
                    {
                        eblPen.DashStyle = DashStyles.Dash;
                    }
                    dc.DrawLine(eblPen, own, new Point(left + endX * scale, top + endY * scale));
                    string eblText = "EBL " + (i + 1) + "  " + EblVrm.EblBearingDeg[i].ToString("000.0", CultureInfo.InvariantCulture)
                        + " " + EblVrm.EblUnit;
                    DrawText(dc, eblText, new Point(8.0, textY), brush, false);
                    textY += 14.0;
                }
            }
            // Parallel index lines: the first dash-dot, the second dotted.
            for (int i = 0; i < EblVrmSet.PiCount; i++)
            {
                if (!EblVrm.PiOn[i])
                {
                    continue;
                }
                double piX1, piY1, piX2, piY2;
                if (EblVrm.PiEndsPx(i, Geometry, out piX1, out piY1, out piX2, out piY2))
                {
                    Pen piPen = new Pen(brush, 1.0);
                    piPen.DashStyle = i == 0 ? DashStyles.DashDot : DashStyles.Dot;
                    dc.DrawLine(piPen, new Point(left + piX1 * scale, top + piY1 * scale), new Point(left + piX2 * scale, top + piY2 * scale));
                }
                string piText = "PI " + (i + 1) + " " + EblVrm.PiBearingDeg[i].ToString("000.0", CultureInfo.InvariantCulture) + " " + EblVrm.EblUnit
                    + "  " + Math.Abs(EblVrm.PiNm[i]).ToString("0.00", CultureInfo.InvariantCulture) + " NM "
                    + (EblVrm.PiNm[i] < 0.0 ? "LEFT" : "RIGHT");
                DrawText(dc, piText, new Point(8.0, textY), brush, false);
                textY += 14.0;
            }
            for (int i = 0; i < EblVrmSet.Count; i++)
            {
                if (EblVrm.VrmOn[i])
                {
                    double ringScreen = EblVrm.VrmRadiusPx(i, Geometry) * scale;
                    Pen vrmPen = new Pen(brush, EblVrm.SelectedVrm == i ? 2.0 : 1.0);
                    if (i == 1)
                    {
                        vrmPen.DashStyle = DashStyles.Dash;
                    }
                    dc.PushClip(new EllipseGeometry(centre, radiusScreen, radiusScreen));
                    dc.DrawEllipse(null, vrmPen, own, ringScreen, ringScreen);
                    dc.Pop();
                    string vrmText = "VRM " + (i + 1) + "  " + EblVrm.VrmNm[i].ToString("0.00", CultureInfo.InvariantCulture) + " NM";
                    DrawText(dc, vrmText, new Point(8.0, textY), brush, false);
                    textY += 14.0;
                }
            }
        }

        private void DrawRings(DrawingContext dc, Point centre, double radiusScreen, Point own, double scale, Brush ringBrush)
        {
            List<double> radiiPx = Geometry.RingRadiiPx(RingIntervalNm);
            Pen ringPen = new Pen(ringBrush, 1.0);
            dc.PushClip(new EllipseGeometry(centre, radiusScreen, radiusScreen));
            foreach (double ringPx in radiiPx)
            {
                dc.DrawEllipse(null, ringPen, own, ringPx * scale, ringPx * scale);
            }
            dc.Pop();

            double angleRad = RingLabelAngleDeg * Math.PI / 180.0;       // deg -> rad
            for (int ring = 0; ring < radiiPx.Count; ring++)
            {
                double ringScreen = radiiPx[ring] * scale;
                Point labelPoint = new Point(own.X + ringScreen * Math.Sin(angleRad), own.Y - ringScreen * Math.Cos(angleRad));
                double fromCentre = Math.Sqrt((labelPoint.X - centre.X) * (labelPoint.X - centre.X)
                                              + (labelPoint.Y - centre.Y) * (labelPoint.Y - centre.Y));
                if (fromCentre < radiusScreen - 10.0)
                {
                    double ringNm = (ring + 1) * RingIntervalNm;
                    DrawText(dc, ringNm.ToString("0.##", CultureInfo.InvariantCulture) + " NM", labelPoint, ringBrush, true);
                }
            }
        }

        // The ticks are where the lines from own ship at each bearing meet the edge, so the scale reads
        // right with an offset too.
        private void DrawBearingScale(DrawingContext dc, Point centre, double radiusScreen, Brush symbolBrush,
                                      double left, double top, double scale)
        {
            Pen scalePen = new Pen(symbolBrush, 1.0);
            dc.DrawEllipse(null, scalePen, centre, radiusScreen, radiusScreen);
            foreach (BearingTick tick in Geometry.BearingTicks())
            {
                double edgeX, edgeY, outX, outY;
                Geometry.ScaleEdgePoint(tick.ScreenAngleDeg, out edgeX, out edgeY, out outX, out outY);
                double tickPx = tick.IsLong ? LongTickPx : ShortTickPx;
                Point outer = new Point(left + edgeX * scale, top + edgeY * scale);
                Point inner = new Point(outer.X - tickPx * outX, outer.Y - tickPx * outY);
                dc.DrawLine(scalePen, inner, outer);
                if (tick.HasLabel)
                {
                    Point labelPoint = new Point(outer.X + 12.0 * outX, outer.Y + 12.0 * outY);
                    DrawText(dc, ((int)tick.BearingDegTrue).ToString("000", CultureInfo.InvariantCulture), labelPoint, symbolBrush, true);
                }
            }
        }

        // Draws text with its top-left corner at the point, or centred on it.
        private void DrawText(DrawingContext dc, string text, Point at, Brush brush, bool centred)
        {
            FormattedText formatted = new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
                                                        typeface, LabelFontPx, brush, VisualTreeHelper.GetDpi(this).PixelsPerDip);
            Point corner = centred ? new Point(at.X - formatted.Width / 2.0, at.Y - formatted.Height / 2.0) : at;
            dc.DrawText(formatted, corner);
        }

        // ---- cursor readout ----

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (Geometry == null || bitmap == null || ActualWidth < 100.0 || ActualHeight < 100.0)
            {
                return;
            }
            double left, top, scale;
            LayoutOf(out left, out top, out scale);
            Point pointer = e.GetPosition(this);
            double xPx = (pointer.X - left) / scale;
            double yPx = (pointer.Y - top) / scale;
            CursorXPx = xPx;
            CursorYPx = yPx;
            if (draggingEblVrm && EblVrm != null)
            {
                if (dragIsEbl)
                {
                    EblVrm.SetEblFromPixel(dragIndex, Geometry, xPx, yPx);
                }
                else
                {
                    EblVrm.SetVrmFromPixel(dragIndex, Geometry, xPx, yPx);
                }
                if (EblVrmChanged != null)
                {
                    EblVrmChanged();
                }
            }
            double fromCentreX = xPx - Geometry.CentreXPx;
            double fromCentreY = yPx - Geometry.CentreYPx;
            if (Math.Sqrt(fromCentreX * fromCentreX + fromCentreY * fromCentreY) > Geometry.RadiusPx)
            {
                cursorText = "";
                CursorValid = false;
                return;
            }
            CursorValid = true;
            double rangeNm, bearingDegTrue;
            Geometry.RangeBearingOf(xPx, yPx, out rangeNm, out bearingDegTrue);
            cursorText = "CURSOR  " + rangeNm.ToString("0.00", CultureInfo.InvariantCulture) + " NM  "
                + bearingDegTrue.ToString("000.0", CultureInfo.InvariantCulture) + " deg T  "
                + Geometry.RelativeBearingDeg(bearingDegTrue).ToString("000.0", CultureInfo.InvariantCulture) + " deg R";
        }

        protected override void OnMouseLeave(MouseEventArgs e)
        {
            base.OnMouseLeave(e);
            cursorText = "";
            CursorValid = false;
        }

        // A click near an EBL line or VRM ring picks it up; it follows the pointer until release.
        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            Focus();
            if (Geometry == null || bitmap == null || ActualWidth < 100.0 || ActualHeight < 100.0)
            {
                return;
            }
            double left, top, scale;
            LayoutOf(out left, out top, out scale);
            Point pointer = e.GetPosition(this);
            double xPx = (pointer.X - left) / scale;
            double yPx = (pointer.Y - top) / scale;
            bool isEbl = false;
            int index = 0;
            double fromCentreX = xPx - Geometry.CentreXPx;
            double fromCentreY = yPx - Geometry.CentreYPx;
            bool insideCircle = Math.Sqrt(fromCentreX * fromCentreX + fromCentreY * fromCentreY) <= Geometry.RadiusPx;
            if (Controller != null && Controller.OffsetPlaceArmed && insideCircle)
            {
                Controller.PlaceOffsetAtPixel(xPx, yPx);        // the PLACE button was pressed first
                return;
            }
            if (Arpa != null && Arpa.AcquireArmed && insideCircle)
            {
                Arpa.AcquireAtPixel(Geometry, xPx, yPx);        // the ACQUIRE button was pressed first
                return;
            }
            if (EblVrm != null && EblVrm.HitTest(Geometry, xPx, yPx, GrabTolerancePx / scale, out isEbl, out index))
            {
                draggingEblVrm = true;
                dragIsEbl = isEbl;
                dragIndex = index;
                if (isEbl)
                {
                    EblVrm.SelectedEbl = index;
                }
                else
                {
                    EblVrm.SelectedVrm = index;
                }
                CaptureMouse();
                e.Handled = true;
                if (EblVrmChanged != null)
                {
                    EblVrmChanged();
                }
            }
            else if (Arpa != null)
            {
                // Not on an EBL or VRM: a click on a box selects the target, a click on empty screen deselects.
                Arpa.SelectAtPixel(Geometry, xPx, yPx, ArpaController.HitRadiusScreenPx / scale);
            }
        }

        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonUp(e);
            if (draggingEblVrm)
            {
                draggingEblVrm = false;
                ReleaseMouseCapture();
                e.Handled = true;
            }
        }
    }
}
