// OwnShipPanel.xaml.cs - own-ship readouts, the order box, the engine telegraph
// buttons, a compass rose and the message pane (BRIEF.md Section 15, M1). Orders are entered in
// three boxes (COURSE, HELM, SPEED); each sends the same order text the parser already knows.
// The panel shows what the instruments show: gyro heading and log speed.
// Units: headings deg T, rudder deg, rate of turn deg/min, speeds KN.
// Called by: MainWindow, which feeds it "hello", "state" and "log" messages and
// sends the orders it raises.

using System;
using System.Globalization;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace RadarSim
{
    public partial class OwnShipPanel : UserControl
    {
        public event Action<string> OrderEntered;      // order text, typed or from a telegraph button

        private const int MessagePaneMaxChars = 1500;   // older lines are dropped beyond this; the box shows about 3 lines

        public OwnShipPanel()
        {
            InitializeComponent();
            DrawCompassTicks();
        }

        // A tick every 10 degrees, longer every 30. Angles are true bearings:
        // clockwise from north (up), so x goes with the sine and y with minus the cosine.
        private void DrawCompassTicks()
        {
            const double centre = 80.0;
            const double outerRadius = 70.0;
            for (int bearingDeg = 0; bearingDeg < 360; bearingDeg += 10)
            {
                double innerRadius = bearingDeg % 30 == 0 ? 58.0 : 64.0;
                double bearingRad = bearingDeg * Math.PI / 180.0;       // deg -> rad
                Line tick = new Line();
                tick.X1 = centre + innerRadius * Math.Sin(bearingRad);
                tick.Y1 = centre - innerRadius * Math.Cos(bearingRad);
                tick.X2 = centre + outerRadius * Math.Sin(bearingRad);
                tick.Y2 = centre - outerRadius * Math.Cos(bearingRad);
                tick.SetResourceReference(Shape.StrokeProperty, "ThemeText");
                tick.StrokeThickness = 1.0;
                CompassCanvas.Children.Add(tick);
            }
        }

        // ---- from the sim ----

        // The own_ship part of "hello": telegraph buttons follow speed_command_mode
        // ("knots", "telegraph" or "both") and show their speeds as tool tips.
        public void ShowOwnShipInfo(JsonElement ownShip)
        {
            string mode = ownShip.GetProperty("speed_command_mode").GetString();
            TelegraphButtons.IsEnabled = mode != "knots";
            foreach (object child in TelegraphButtons.Children)
            {
                Button button = child as Button;
                if (button == null)
                {
                    continue;
                }
                // Tag "half ahead" -> config key "telegraph_half_ahead_kn". "stop" has none.
                string key = "telegraph_" + ((string)button.Tag).Replace(' ', '_') + "_kn";
                JsonElement speed;
                if (ownShip.TryGetProperty(key, out speed) && speed.ValueKind == JsonValueKind.Number)
                {
                    button.ToolTip = Format(speed.GetDouble(), "0.0") + " KN";
                }
            }
        }

        // The "own" part of a "state" message.
        public void ShowState(JsonElement own)
        {
            double gyroHeadingDeg = own.GetProperty("gyro_heading_deg").GetDouble();
            HeadingText.Text = Format(gyroHeadingDeg, "000.0");
            HeadingRotation.Angle = gyroHeadingDeg;

            RudderText.Text = PortOrStarboard(own.GetProperty("rudder_deg").GetDouble());
            RotText.Text = PortOrStarboard(own.GetProperty("rot_deg_per_min").GetDouble());
            SpeedWaterText.Text = Format(own.GetProperty("log_speed_kn").GetDouble(), "0.0");
            SogText.Text = Format(own.GetProperty("sog_kn").GetDouble(), "0.0");
            CogText.Text = Format(own.GetProperty("cog_deg_true").GetDouble(), "000.0");

            JsonElement orderedHeading = own.GetProperty("ordered_heading_deg");
            OrderedHeadingText.Text = orderedHeading.ValueKind == JsonValueKind.Number
                ? Format(orderedHeading.GetDouble(), "000.0") : "--";
            JsonElement orderedSpeed = own.GetProperty("ordered_speed_kn");
            OrderedSpeedText.Text = orderedSpeed.ValueKind == JsonValueKind.Number
                ? Format(orderedSpeed.GetDouble(), "0.0") : "--";
        }

        public string Stamp = "";                             // sim time HH:MM:SS, set by MainWindow; starts every log line

        // One "log" line: an order echo or a refusal, stamped with the sim time like a voyage data recorder.
        public void AddLogLine(string text)
        {
            text = Stamp == "" ? text : Stamp + "  " + text;
            if (MessagePane.Text.Length > MessagePaneMaxChars)
            {
                MessagePane.Text = MessagePane.Text.Substring(MessagePaneMaxChars / 2);
            }
            MessagePane.AppendText(text + Environment.NewLine);
            MessagePane.ScrollToEnd();
        }

        // + is starboard and - is port, for rudder angle and rate of turn alike.
        private static string PortOrStarboard(double value)
        {
            string number = Format(Math.Abs(value), "0.0");
            if (number == "0.0")
            {
                return number;
            }
            return (value < 0.0 ? "P " : "S ") + number;
        }

        private static string Format(double value, string pattern)
        {
            return value.ToString(pattern, CultureInfo.InvariantCulture);
        }

        // Enter key: the course box takes the keyboard.
        public void FocusOrderBox()
        {
            CourseBox.Focus();
        }

        // ---- to the sim ----

        // A number typed in a box. A log line says so when it is not one; nothing is sent then.
        private bool TryNumber(TextBox box, string what, out double value)
        {
            bool ok = double.TryParse(box.Text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out value)
                && !double.IsNaN(value) && !double.IsInfinity(value);
            if (!ok)
            {
                AddLogLine("Not understood: " + what + " needs a number, not '" + box.Text.Trim() + "'");
            }
            return ok;
        }

        private static string Plain(double value)
        {
            return value.ToString("0.##", CultureInfo.InvariantCulture);
        }

        private void SendCourse()
        {
            double course;
            if (TryNumber(CourseBox, "course", out course))
            {
                RaiseOrder("heading " + Plain(course));
                CourseBox.Text = "";
            }
        }

        private void SendHelm(string side)
        {
            double angle;
            if (TryNumber(HelmBox, "helm", out angle))
            {
                RaiseOrder(side + " " + Plain(angle));
            }
        }

        private void SendSpeed()
        {
            double speed;
            if (TryNumber(SpeedBox, "speed", out speed))
            {
                RaiseOrder("speed " + Plain(speed));
                SpeedBox.Text = "";
            }
        }

        private void CourseBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                CourseBox.Text = "";
                Keyboard.ClearFocus();
            }
            else if (e.Key == Key.Enter && CourseBox.Text.Trim() != "")
            {
                SendCourse();
            }
        }

        private void HelmBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                Keyboard.ClearFocus();
            }
            else if (e.Key == Key.Enter && HelmBox.Text.Trim() != "")
            {
                SendHelm("starboard");
            }
        }

        private void SpeedBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                SpeedBox.Text = "";
                Keyboard.ClearFocus();
            }
            else if (e.Key == Key.Enter && SpeedBox.Text.Trim() != "")
            {
                SendSpeed();
            }
        }

        private void SteerButton_Click(object sender, RoutedEventArgs e)
        {
            SendCourse();
        }

        private void PortButton_Click(object sender, RoutedEventArgs e)
        {
            SendHelm("port");
        }

        private void StarboardButton_Click(object sender, RoutedEventArgs e)
        {
            SendHelm("starboard");
        }

        private void SpeedButton_Click(object sender, RoutedEventArgs e)
        {
            SendSpeed();
        }

        // STEADY and MIDSHIPS: the Tag is the order text.
        private void OrderButton_Click(object sender, RoutedEventArgs e)
        {
            RaiseOrder((string)((Button)sender).Tag);
        }

        private void TelegraphButton_Click(object sender, RoutedEventArgs e)
        {
            RaiseOrder((string)((Button)sender).Tag);
        }

        private void RaiseOrder(string text)
        {
            if (OrderEntered != null)
            {
                OrderEntered(text);
            }
        }
    }
}
