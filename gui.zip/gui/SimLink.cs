// SimLink.cs - starts the Python sim as a child process, connects to it over TCP on
// 127.0.0.1, reads frames on a background thread and hands them to the UI thread.
// The sim is started as: <python_executable> <root>/sim/sim_main.py --config <root>/radarsim.toml
// Units: none of its own; messages carry theirs.
// Called by: MainWindow. Create it and call Start/Stop/Send on the UI thread; every
// event is raised on the UI thread, except SpokesReceived, which is raised on the
// reader thread so that video never waits for the UI.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Windows.Threading;

namespace RadarSim
{
    public class SimLink
    {
        public const string StatusConnecting = "CONNECTING";
        public const string StatusConnected = "CONNECTED";
        public const string StatusSimLost = "SIM LOST";

        public event Action<string> StatusChanged;
        public event Action<JsonElement> MessageReceived;   // one JSON message from the sim
        public event Action<byte[]> SpokesReceived;         // one SPOKES payload; raised on the reader thread
        public event Action<string> ConsoleLine;            // sim stdout/stderr, and the link's own notes

        private const int ConnectTimeoutMs = 10000;         // retry connecting for 10 s (BRIEF.md Section 4)
        private const int ConnectRetryMs = 250;

        private readonly string root;
        private readonly bool launchSim;
        private readonly Dispatcher ui;
        private readonly object sendLock = new object();

        private string pythonExecutable;
        private int port;
        private Process simProcess;
        private TcpClient client;
        private NetworkStream stream;

        // Goes up by one at every Start and Stop. A background thread remembers the
        // number it was started with and keeps quiet once the number has moved on.
        private volatile int session;

        public SimLink(string root, bool launchSim)
        {
            this.root = root;
            this.launchSim = launchSim;
            this.ui = Dispatcher.CurrentDispatcher;
        }

        private string ConfigPath
        {
            get { return Path.Combine(root, App.ConfigFileName); }
        }

        // ---- start and stop ----

        public void Start()
        {
            session++;
            int mySession = session;
            RaiseStatus(StatusConnecting);

            string problem = ReadStartupKeys();
            if (problem != null)
            {
                Messages.Error(problem);
                RaiseStatus(StatusSimLost);
                return;
            }

            if (launchSim)
            {
                if (!LaunchSim(mySession))
                {
                    RaiseStatus(StatusSimLost);
                    return;
                }
            }
            else
            {
                Messages.Info("--no-launch: connecting to a sim started by hand on 127.0.0.1:" + port);
            }

            Process processToWatch = simProcess;
            Thread thread = new Thread(() => ConnectAndRead(mySession, processToWatch));
            thread.IsBackground = true;
            thread.Name = "SimLink reader";
            thread.Start();
        }

        // Closes the connection and kills the sim's process tree.
        public void Stop()
        {
            session++;
            lock (sendLock)
            {
                if (stream != null) { stream.Dispose(); stream = null; }
                if (client != null) { client.Dispose(); client = null; }
            }
            if (simProcess != null)
            {
                try
                {
                    if (!simProcess.HasExited)
                    {
                        simProcess.Kill(true);      // true = the whole process tree
                    }
                }
                catch (InvalidOperationException) { }   // it exited in the meantime
                catch (Win32Exception) { }
                simProcess.Dispose();
                simProcess = null;
            }
        }

        public void Send(Dictionary<string, object> message)
        {
            byte[] payload = Protocol.EncodeJson(message);
            lock (sendLock)
            {
                if (stream == null)
                {
                    return;
                }
                try
                {
                    Protocol.WriteFrame(stream, Protocol.FrameJson, payload);
                }
                catch (IOException) { }               // the reader thread reports the loss
                catch (ObjectDisposedException) { }
            }
        }

        // ---- start-up keys ----

        // The display takes everything from the sim's hello message, except the two
        // values it needs before there is a sim to ask: general.python_executable and
        // general.port. They are read here with a plain line scan, not a TOML library.
        // Returns null, or a message saying what to fix.
        private string ReadStartupKeys()
        {
            pythonExecutable = null;
            port = 0;
            string[] lines;
            try
            {
                lines = File.ReadAllLines(ConfigPath);
            }
            catch (IOException error)
            {
                return "Cannot read " + ConfigPath + ": " + error.Message;
            }

            string section = "";
            foreach (string line in lines)
            {
                string text = line.Trim();
                if (text.StartsWith("["))
                {
                    int end = text.IndexOf(']');
                    section = end > 0 ? text.Substring(1, end - 1).Trim() : "";
                    continue;
                }
                int equals = text.IndexOf('=');
                if (section != "general" || text.StartsWith("#") || equals < 0)
                {
                    continue;
                }
                string key = text.Substring(0, equals).Trim();
                string value = text.Substring(equals + 1).Trim();
                if (key == "python_executable")
                {
                    pythonExecutable = ReadTomlString(value);
                }
                else if (key == "message_verbosity")
                {
                    int comment = value.IndexOf('#');
                    if (comment >= 0)
                    {
                        value = value.Substring(0, comment).Trim();
                    }
                    int level;
                    if (int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out level))
                    {
                        Messages.Verbosity = Math.Max(0, Math.Min(10, level));
                    }
                }
                else if (key == "port")
                {
                    int comment = value.IndexOf('#');
                    if (comment >= 0)
                    {
                        value = value.Substring(0, comment).Trim();
                    }
                    int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out port);
                }
            }

            if (port < 1 || port > 65535)
            {
                return ConfigPath + ": general.port is missing or not a port number (1 to 65535).";
            }
            if (launchSim && string.IsNullOrEmpty(pythonExecutable))
            {
                return ConfigPath + ": general.python_executable is missing or empty. Set it to \"python\" "
                    + "or to the full path of python.exe.";
            }
            return null;
        }

        // The text of a TOML string: "basic" (with \\ and \" escapes) or 'literal'.
        // Returns null when the value is not a string.
        private static string ReadTomlString(string value)
        {
            if (value.Length < 2)
            {
                return null;
            }
            if (value[0] == '\'')
            {
                int end = value.IndexOf('\'', 1);
                return end > 0 ? value.Substring(1, end - 1) : null;
            }
            if (value[0] != '"')
            {
                return null;
            }
            StringBuilder text = new StringBuilder();
            for (int i = 1; i < value.Length; i++)
            {
                if (value[i] == '\\' && i + 1 < value.Length)
                {
                    text.Append(value[i + 1]);
                    i++;
                }
                else if (value[i] == '"')
                {
                    return text.ToString();
                }
                else
                {
                    text.Append(value[i]);
                }
            }
            return null;
        }

        // ---- the sim process ----

        private bool LaunchSim(int mySession)
        {
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = pythonExecutable;
            info.ArgumentList.Add(Path.Combine(root, "sim", "sim_main.py"));
            info.ArgumentList.Add("--config");
            info.ArgumentList.Add(ConfigPath);
            info.UseShellExecute = false;
            info.CreateNoWindow = true;
            info.RedirectStandardInput = true;      // held open; the sim exits when it closes
            info.RedirectStandardOutput = true;
            info.RedirectStandardError = true;
            info.Environment["PYTHONUNBUFFERED"] = "1";

            Process process = new Process();
            process.StartInfo = info;
            process.OutputDataReceived += (sender, e) => { if (e.Data != null) PostConsoleLine(mySession, e.Data); };
            process.ErrorDataReceived += (sender, e) => { if (e.Data != null) PostConsoleLine(mySession, e.Data); };
            try
            {
                process.Start();
            }
            catch (Exception error) when (error is Win32Exception || error is InvalidOperationException)
            {
                process.Dispose();
                Messages.Error("Cannot start Python with \"" + pythonExecutable + "\" (" + error.Message + "). "
                    + "Set general.python_executable in " + ConfigPath + " to the full path of python.exe, "
                    + "then press RESTART SIM.");
                return false;
            }
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();
            simProcess = process;
            Messages.Status("Started the sim: " + pythonExecutable + " " + Path.Combine(root, "sim", "sim_main.py"));
            return true;
        }

        // ---- background thread: connect, then read frames until the connection ends ----

        private void ConnectAndRead(int mySession, Process processToWatch)
        {
            TcpClient connection = null;
            string problem = "Could not connect to the sim on 127.0.0.1:" + port + " within 10 s.";
            Stopwatch waited = Stopwatch.StartNew();
            while (waited.ElapsedMilliseconds < ConnectTimeoutMs && mySession == session)
            {
                if (processToWatch != null && SimHasExited(processToWatch))
                {
                    problem = "The sim stopped before the display could connect. If the lines above do not say why, "
                        + "check general.python_executable in " + ConfigPath + " (now \"" + pythonExecutable + "\").";
                    break;
                }
                TcpClient attempt = new TcpClient();
                try
                {
                    attempt.Connect(IPAddress.Loopback, port);
                    attempt.NoDelay = true;
                    connection = attempt;
                    break;
                }
                catch (SocketException)
                {
                    attempt.Dispose();
                    Thread.Sleep(ConnectRetryMs);
                }
            }

            if (connection == null)
            {
                PostLost(mySession, problem);
                return;
            }

            NetworkStream connectionStream = connection.GetStream();
            lock (sendLock)
            {
                if (mySession != session)
                {
                    connection.Dispose();           // Stop was called while we were connecting
                    return;
                }
                client = connection;
                stream = connectionStream;
            }
            Post(mySession, () => RaiseStatus(StatusConnected));

            string reason = "closed";
            try
            {
                while (true)
                {
                    byte frameType;
                    byte[] payload;
                    Protocol.ReadFrame(connectionStream, out frameType, out payload);
                    if (frameType == Protocol.FrameJson)
                    {
                        JsonElement message = Protocol.DecodeJson(payload);
                        Post(mySession, () => { if (MessageReceived != null) MessageReceived(message); });
                    }
                    else if (frameType == Protocol.FrameSpokes)
                    {
                        Action<byte[]> handler = SpokesReceived;
                        if (handler != null && mySession == session)
                        {
                            handler(payload);
                        }
                    }
                }
            }
            catch (Exception error) when (error is IOException || error is ObjectDisposedException
                                          || error is InvalidDataException || error is JsonException)
            {
                reason = error.Message;
            }
            PostLost(mySession, "Connection to the sim lost (" + reason + ").");
        }

        private static bool SimHasExited(Process process)
        {
            try
            {
                return process.HasExited;
            }
            catch (InvalidOperationException)
            {
                return true;                        // disposed by Stop
            }
        }

        // ---- handing work to the UI thread ----

        private void Post(int mySession, Action action)
        {
            ui.BeginInvoke(new Action(() =>
            {
                if (mySession == session)
                {
                    action();
                }
            }));
        }

        private void PostConsoleLine(int mySession, string text)
        {
            Post(mySession, () => RaiseConsoleLine(text));
        }

        private void PostLost(int mySession, string text)
        {
            Post(mySession, () =>
            {
                Messages.Error(text);
                RaiseStatus(StatusSimLost);
            });
        }

        private void RaiseStatus(string status)
        {
            if (StatusChanged != null) StatusChanged(status);
        }

        private void RaiseConsoleLine(string text)
        {
            if (ConsoleLine != null) ConsoleLine(text);
        }
    }
}
