// ArpaController.cs - the ARPA side of the display: the latest targets and alarms, the selected
// target, vector mode and time, history dots, the two guard zones, the trial settings, and the
// commands that go to the sim (acquire, cancel, acknowledge, guard_zone, trial). It holds no WPF
// types, so the self-tests drive it with synthetic messages. DisplayController owns one and
// dispatches the ARPA hotkeys to it; ArpaPanel, AlarmPanel and PpiView show its state.
// Vector mode, vector time, history dots, the CPA and TCPA limits and alarm_sound are runtime
// settings: they live in the DisplayController's dictionaries and go out as "set" messages.
// The guard-zone and trial values are typed in the panel; the sim does not echo them, so they are kept here.
// Units: ranges NM, bearings deg (true or relative per the guard-zone reference), speeds KN,
// vector time MIN, trial delay s, TCPA MIN.
// Called by: DisplayController, ArpaPanel, AlarmPanel, PpiView, MainWindow, SelfTest.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.Json;

namespace RadarSim
{
    public class AlarmItem
    {
        public int Id;
        public string Kind = "";            // CPA_TCPA, LOST_TARGET, GUARD_ZONE, CAPACITY
        public int? TargetId;
        public int? ZoneIndex;
        public double RangeNm;
        public double BearingDegTrue;
        public bool Acknowledged;
        public bool Active;                 // false = the condition is over but the alarm is not yet acknowledged

        // The text of Section 11: CPA/TCPA 3, LOST TARGET 5, GUARD ZONE 1, TARGET CAPACITY.
        public string Text
        {
            get
            {
                if (Kind == "CPA_TCPA")
                {
                    return "CPA/TCPA " + (TargetId.HasValue ? TargetId.Value.ToString(CultureInfo.InvariantCulture) : "");
                }
                if (Kind == "LOST_TARGET")
                {
                    return "LOST TARGET " + (TargetId.HasValue ? TargetId.Value.ToString(CultureInfo.InvariantCulture) : "");
                }
                if (Kind == "GUARD_ZONE")
                {
                    return "GUARD ZONE " + (ZoneIndex.HasValue ? ZoneIndex.Value.ToString(CultureInfo.InvariantCulture) : "");
                }
                if (Kind == "CAPACITY")
                {
                    return "TARGET CAPACITY";
                }
                return Kind;
            }
        }
    }

    public class GuardZoneSettings
    {
        public bool Enabled;
        public double InnerNm = 1.0;
        public double OuterNm = 3.0;
        public double StartDeg;
        public double EndDeg = 90.0;
    }

    public class TrialSettings
    {
        public bool Enabled;
        public double CourseDegTrue;
        public double SpeedKn = 10.0;
        public double DelayS;
    }

    public class ArpaController
    {
        public const string VectorModePath = "display.vector_mode";
        public const string VectorTimePath = "display.vector_time_min";
        public const string HistoryPath = "display.history_dots";
        public const string CpaLimitPath = "arpa.cpa_limit_nm";
        public const string TcpaLimitPath = "arpa.tcpa_limit_min";
        public const string AlarmSoundPath = "arpa.alarm_sound";
        public const string GuardReferencePath = "arpa.guard_zone_reference";

        public const double SecondsPerMinute = 60.0;
        public const long AcquireTimeoutMs = 8000;                  // ms: ACQUIRE stays armed this long after the last click

        public const double HitRadiusScreenPx = 8.0;        // BRIEF.md Section 15, M9: a click this near a box selects it
        public const int ZoneCount = 2;

        // Used only when the sim's controls do not list the vector time (a test hello without them).
        private static readonly double[] DefaultVectorTimesMin = new double[] { 0.5, 1.0, 3.0, 6.0, 12.0, 15.0, 30.0, 60.0 };

        private readonly DisplayController owner;

        public readonly TargetLayer Targets = new TargetLayer();
        public readonly List<AlarmItem> Alarms = new List<AlarmItem>();
        public readonly GuardZoneSettings[] Zones = new GuardZoneSettings[ZoneCount];
        public readonly TrialSettings Trial = new TrialSettings();
        public int SelectedId = -1;                         // -1 = none
        public long AcquireArmedAtMs;                       // ms (Environment.TickCount64) of the arming or the last box
        public bool AcquireArmed;                           // the ACQUIRE button was pressed: the next click on the PPI acquires
        public bool FlashOn = true;                         // 1 Hz phase for alarms, lost boxes and the TRIAL tag

        public event Action Changed;                        // targets, alarms, selection or settings changed

        public ArpaController(DisplayController owner)
        {
            this.owner = owner;
            for (int i = 0; i < ZoneCount; i++)
            {
                Zones[i] = new GuardZoneSettings();
            }
            Zones[1].StartDeg = 270.0;
            Zones[1].EndDeg = 0.0;
        }

        private void RaiseChanged()
        {
            if (Changed != null)
            {
                Changed();
            }
            owner.RaiseChangedFromArpa();
        }

        // A new sim run: nothing is tracked and nothing is alarmed. The typed guard-zone and trial
        // values stay, but the sim has forgotten them, so they are off until sent again.
        public void Reset()
        {
            AcquireArmed = false;
            Targets.Targets.Clear();
            Alarms.Clear();
            SelectedId = -1;
            for (int i = 0; i < ZoneCount; i++)
            {
                Zones[i].Enabled = false;
            }
            Trial.Enabled = false;
        }

        // ---- the settings the sim knows ----

        public bool VectorTrue
        {
            get
            {
                string word;
                return !owner.Words.TryGetValue(VectorModePath, out word) || word != "relative";
            }
        }

        public double VectorTimeMin
        {
            get
            {
                double value;
                return owner.Numbers.TryGetValue(VectorTimePath, out value) ? value : 6.0;
            }
        }

        public bool HistoryOn
        {
            get
            {
                bool value;
                return !owner.Flags.TryGetValue(HistoryPath, out value) || value;
            }
        }

        public bool AlarmSoundOn
        {
            get
            {
                bool value;
                return !owner.Flags.TryGetValue(AlarmSoundPath, out value) || value;
            }
        }

        public bool GuardReferenceRelative
        {
            get
            {
                string word;
                return !owner.Words.TryGetValue(GuardReferencePath, out word) || word != "true";
            }
        }

        public double[] VectorTimesMin
        {
            get
            {
                ControlLimits limits;
                if (owner.Limits.TryGetValue(VectorTimePath, out limits) && limits.NumberChoices != null)
                {
                    return limits.NumberChoices;
                }
                return DefaultVectorTimesMin;
            }
        }

        public void SetVectorMode(bool trueVectors)
        {
            owner.SetRuntimeWord(VectorModePath, trueVectors ? "true" : "relative");
        }

        // V: true or relative vectors.
        public void ToggleVectorMode()
        {
            SetVectorMode(!VectorTrue);
        }

        public void SetVectorTimeMin(double minutes)
        {
            owner.SetRuntimeNumber(VectorTimePath, minutes);
        }

        // [ and ]: the next shorter or longer vector time in the sim's list; at an end nothing is sent.
        public void StepVectorTime(int direction)
        {
            double[] times = VectorTimesMin;
            int index = DisplayController.NearestIndex(times, VectorTimeMin) + direction;
            if (index < 0 || index >= times.Length)
            {
                return;
            }
            SetVectorTimeMin(times[index]);
        }

        public void SetHistory(bool on)
        {
            owner.SetRuntimeFlag(HistoryPath, on);
        }

        // ---- targets ----

        public void SetTargets(JsonElement message)
        {
            Targets.SetMessage(message);
            if (SelectedId >= 0 && Targets.Find(SelectedId) == null)
            {
                SelectedId = -1;                            // the target was cancelled or removed
            }
            RaiseChanged();
        }

        public TargetRecord SelectedTarget
        {
            get { return SelectedId >= 0 ? Targets.Find(SelectedId) : null; }
        }

        // Pushes the display options into the layer and lays the boxes out for this geometry.
        public List<TargetShape> Layout(PpiGeometry geometry)
        {
            Targets.VectorTrue = VectorTrue;
            Targets.VectorTimeMin = VectorTimeMin;
            Targets.HistoryOn = HistoryOn;
            Targets.TrialOn = Trial.Enabled;
            Targets.TrialCourseDegTrue = Trial.CourseDegTrue;
            Targets.TrialSpeedKn = Trial.SpeedKn;
            Targets.SelectedId = SelectedId;
            Targets.UnacknowledgedLostIds.Clear();
            foreach (AlarmItem alarm in Alarms)
            {
                if (alarm.Kind == "LOST_TARGET" && !alarm.Acknowledged && alarm.TargetId.HasValue)
                {
                    Targets.UnacknowledgedLostIds.Add(alarm.TargetId.Value);
                }
            }
            return Targets.Layout(geometry);
        }

        // A click: selects the box within the hit radius (the nearest), or deselects. The point is in
        // bitmap pixels; the radius too (8 screen pixels divided by the picture's scale).
        public bool SelectAtPixel(PpiGeometry geometry, double xPx, double yPx, double radiusPx)
        {
            int id = TargetLayer.HitTest(Layout(geometry), xPx, yPx, radiusPx);
            bool changed = id != SelectedId;
            SelectedId = id;
            if (changed)
            {
                RaiseChanged();
            }
            return id >= 0;
        }

        // A click on a row of the contact list.
        public void SelectId(int id)
        {
            if (id != SelectedId)
            {
                SelectedId = id;
                RaiseChanged();
            }
        }

        // A: the echo nearest the pointer. The pointer's range and true bearing come from the geometry.
        public bool AcquireAtPixel(PpiGeometry geometry, double xPx, double yPx)
        {
            if (AcquireArmed)
            {
                AcquireArmedAtMs = Environment.TickCount64;     // stays armed for the next echo
            }
            double rangeNm, bearingDegTrue;
            geometry.RangeBearingOf(xPx, yPx, out rangeNm, out bearingDegTrue);
            owner.SendMessage(Protocol.Acquire(rangeNm, bearingDegTrue));
            return true;
        }

        // The ACQUIRE button has no pointer position of its own, so it waits for a click on the picture.
        public void ArmAcquire()
        {
            AcquireArmed = !AcquireArmed;
            AcquireArmedAtMs = Environment.TickCount64;
            RaiseChanged();
        }

        // ACQUIRE gives up waiting when no box has been put down for AcquireTimeoutMs.
        public void CheckAcquireTimeout(long nowMs)
        {
            if (AcquireArmed && nowMs - AcquireArmedAtMs > AcquireTimeoutMs)
            {
                AcquireArmed = false;
                RaiseChanged();
            }
        }

        public void CancelSelected()
        {
            if (SelectedId < 0)
            {
                return;
            }
            owner.SendMessage(Protocol.CancelTarget(SelectedId));
        }

        public void CancelAll()
        {
            owner.SendMessage(Protocol.CancelAllTargets());
        }

        // ---- alarms ----

        public void SetAlarms(JsonElement message)
        {
            Alarms.Clear();
            JsonElement list;
            if (message.TryGetProperty("alarms", out list) && list.ValueKind == JsonValueKind.Array)
            {
                foreach (JsonElement item in list.EnumerateArray())
                {
                    AlarmItem alarm = new AlarmItem();
                    alarm.Id = (int)Math.Round(item.GetProperty("id").GetDouble());
                    alarm.Kind = item.GetProperty("kind").GetString();
                    JsonElement value;
                    if (item.TryGetProperty("target_id", out value) && value.ValueKind == JsonValueKind.Number)
                    {
                        alarm.TargetId = (int)Math.Round(value.GetDouble());
                    }
                    if (item.TryGetProperty("zone_index", out value) && value.ValueKind == JsonValueKind.Number)
                    {
                        alarm.ZoneIndex = (int)Math.Round(value.GetDouble());
                    }
                    if (item.TryGetProperty("range_nm", out value) && value.ValueKind == JsonValueKind.Number)
                    {
                        alarm.RangeNm = value.GetDouble();
                    }
                    if (item.TryGetProperty("bearing_deg_true", out value) && value.ValueKind == JsonValueKind.Number)
                    {
                        alarm.BearingDegTrue = value.GetDouble();
                    }
                    alarm.Acknowledged = item.TryGetProperty("acknowledged", out value) && value.ValueKind == JsonValueKind.True;
                    alarm.Active = !item.TryGetProperty("active", out value) || value.ValueKind != JsonValueKind.False;
                    Alarms.Add(alarm);
                }
            }
            Alarms.Sort((a, b) => a.Id.CompareTo(b.Id));    // the sim numbers alarms in the order they were raised
            RaiseChanged();
        }

        public bool AnyUnacknowledged
        {
            get
            {
                foreach (AlarmItem alarm in Alarms)
                {
                    if (!alarm.Acknowledged)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        // The sound repeats while any alarm is unacknowledged and alarm_sound is true.
        public bool SoundWanted
        {
            get { return AlarmSoundOn && AnyUnacknowledged; }
        }

        // Space or the ACK button. The alarms stop flashing at once; the sim's next list confirms it.
        public void AcknowledgeAll()
        {
            foreach (AlarmItem alarm in Alarms)
            {
                alarm.Acknowledged = true;
            }
            owner.SendMessage(Protocol.AckAllAlarms());
            RaiseChanged();
        }

        public void AcknowledgeOne(int id)
        {
            foreach (AlarmItem alarm in Alarms)
            {
                if (alarm.Id == id)
                {
                    alarm.Acknowledged = true;
                }
            }
            owner.SendMessage(Protocol.AckAlarm(id));
            RaiseChanged();
        }

        // Called by the 1 Hz timer.
        public void ToggleFlash()
        {
            FlashOn = !FlashOn;
        }

        // ---- guard zones and trial ----

        public void SetGuardZone(int index, bool enabled, double innerNm, double outerNm, double startDeg, double endDeg)
        {
            if (index < 1 || index > ZoneCount)
            {
                return;
            }
            GuardZoneSettings zone = Zones[index - 1];
            zone.Enabled = enabled;
            zone.InnerNm = innerNm;
            zone.OuterNm = outerNm;
            zone.StartDeg = startDeg;
            zone.EndDeg = endDeg;
            owner.SendMessage(Protocol.GuardZone(index, enabled, innerNm, outerNm, startDeg, endDeg));
            RaiseChanged();
        }

        public void SetTrial(bool enabled, double courseDegTrue, double speedKn, double delayS)
        {
            Trial.Enabled = enabled;
            Trial.CourseDegTrue = courseDegTrue;
            Trial.SpeedKn = speedKn;
            Trial.DelayS = delayS;
            owner.SendMessage(Protocol.Trial(enabled, courseDegTrue, speedKn, delayS));
            RaiseChanged();
        }

        // The zones that are on, as pixels, for PpiView to draw.
        public List<GuardZoneShape> ZoneShapes(PpiGeometry geometry)
        {
            List<GuardZoneShape> shapes = new List<GuardZoneShape>();
            foreach (GuardZoneSettings zone in Zones)
            {
                if (zone.Enabled)
                {
                    shapes.Add(TargetLayer.ZoneShape(geometry, zone.InnerNm, zone.OuterNm, zone.StartDeg, zone.EndDeg,
                                                     GuardReferenceRelative));
                }
            }
            return shapes;
        }

        // ---- typed numbers ----

        // A number typed in a box, with a point or a comma as the decimal mark.
        public static bool TryParseNumber(string text, out double value)
        {
            return double.TryParse(text.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out value);
        }
    }
}
