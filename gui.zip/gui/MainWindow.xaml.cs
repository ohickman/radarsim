// MainWindow.xaml.cs - the display window: connection state, sim clock, sim speed,
// pause, restart, the PPI, the control panel, a pane with the sim's console output, the
// own-ship panel, and the hotkeys. The settings and what changes them live in
// DisplayController; this window connects it to the link, the bitmap and the panels.
// Units: sim clock hh:mm:ss of sim time; sim speed in "x" (sim seconds per real second);
// ranges NM; offsets in % of the PPI radius; gain, STC, FTC and brilliance in %.
// Trails and true motion (M7): the trail layer's mode and time follow the controller, and in
// true motion a reset puts own ship back at the offset position from the latest spoke.
// ARPA (M9): "targets" and "alarms" go to the controller's ArpaController; the alarm panel and the ARPA
// panel show it, the PPI draws the boxes, and a 1 Hz timer flashes the alarms, lost boxes and the TRIAL tag.
// Called by: App.xaml.cs.

using System;
using System.Diagnostics;
using System.Globalization;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;

namespace RadarSim
{
    public partial class MainWindow : Window
    {
        private const string SpeedPath = DisplayController.SpeedPath;
        private const string VideoBrilliancePath = "display.video_brilliance_percent";
        private const string RingsBrilliancePath = "display.rings_brilliance_percent";
        private const string SymbolsBrilliancePath = "display.symbols_brilliance_percent";
        private const string AfterglowPath = "display.afterglow_sim_s";
        private const int ConsolePaneMaxChars = 200000;     // older output is dropped beyond this

        private readonly SimLink link;
        private readonly DisplayController controller;
        private readonly WheelhouseData wheelhouseData = new WheelhouseData();     // what the wheelhouse view draws
        private WheelhouseWindow wheelhouseWindow;
        private bool paused;
        private HelpWindow helpWindow;
        private SetupWindow setupWindow;
        private string confirmedSpeedText = "";              // last speed the sim confirmed

        private PpiBitmap ppiBitmap;
        private volatile SpokeSource spokeSource;            // read on the link's reader thread
        private uint monoGreen = 0xFF33FF33;
        private uint monoAmber = 0xFFFFB000;
        private readonly DispatcherTimer flashTimer;         // 0.5 s: alarms, lost boxes and the TRIAL tag flash at 1 Hz

        public MainWindow(string root, bool launchSim, string startupProblem)
        {
            InitializeComponent();
            Theme.Register(this);

            controller = new DisplayController(SendToSim);
            controller.GeometryChanged += OnGeometryChanged;
            controller.ColourModeChanged += OnColourModeChanged;
            controller.SettingApplied += OnSettingApplied;
            controller.OrderFocusRequested += OnOrderFocusRequested;
            controller.TrailsChanged += ApplyTrailSettings;
            controller.Notice += text => Messages.Info(text);
            controller.EventReceived += OnGameEvent;
            controller.HelpRequested += ToggleHelp;
            Messages.Pane = ShowPaneLine;
            controller.Changed += OnControllerChanged;
            Ppi.EblVrm = controller.EblVrm;
            Ppi.EblVrmChanged = controller.EblVrmDragged;
            Ppi.Arpa = controller.Arpa;
            Ppi.Controller = controller;
            AlarmPanelView.Attach(controller);
            ContactsView.Attach(controller);
            flashTimer = new DispatcherTimer(TimeSpan.FromMilliseconds(500), DispatcherPriority.Normal, FlashTick, Dispatcher);

            PreviewKeyDown += Window_PreviewKeyDown;
            PreviewKeyUp += Window_PreviewKeyUp;
            Deactivated += Window_Deactivated;
            AddHandler(System.Windows.Controls.Primitives.ButtonBase.ClickEvent, new RoutedEventHandler(AnyButtonClicked));

            if (startupProblem != null)
            {
                Messages.Error(startupProblem);
            }
            if (root == null)
            {
                ShowStatus(SimLink.StatusSimLost);
                RestartButton.IsEnabled = false;
                return;
            }

            link = new SimLink(root, launchSim);
            link.StatusChanged += ShowStatus;
            link.ConsoleLine += AddConsoleLine;
            link.MessageReceived += HandleMessage;
            link.SpokesReceived += HandleSpokes;
            OwnShipView.OrderEntered += SendOrder;
            link.Start();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            if (wheelhouseWindow != null)
            {
                wheelhouseWindow.Close();          // it has no owner (so that it can go behind the radar), so it would keep the program running
            }
            if (spokeSource != null)
            {
                spokeSource.Stop();
            }
            if (link != null)
            {
                link.Stop();        // kills the sim's process tree
            }
        }

        private void SendToSim(System.Collections.Generic.Dictionary<string, object> message)
        {
            if (link != null)
            {
                link.Send(message);
            }
        }

        // ---- from the sim ----

        private void ShowStatus(string status)
        {
            StatusText.Text = status;
            if (status != SimLink.StatusConnected)
            {
                SpeedAchievedText.Text = "--";
            }
        }

        // Messages.Pane: a line the display printed itself. May come from any thread.
        private void ShowPaneLine(string text)
        {
            if (Dispatcher.CheckAccess())
            {
                AddConsoleLine(text);
            }
            else
            {
                Dispatcher.BeginInvoke(new Action(() => AddConsoleLine(text)));
            }
        }

        // A line for the message pane. The sim's own lines come here as they are; they already
        // carry the tags of sim/messages.py.
        private void AddConsoleLine(string text)
        {
            if (ConsolePane.Text.Length > ConsolePaneMaxChars)
            {
                ConsolePane.Text = ConsolePane.Text.Substring(ConsolePaneMaxChars / 2);
            }
            ConsolePane.AppendText(text + Environment.NewLine);
            ConsolePane.ScrollToEnd();
        }

        // Reader thread: hand the frame to the painter and return at once.
        private void HandleSpokes(byte[] payload)
        {
            SpokeSource source = spokeSource;
            if (source != null)
            {
                source.Enqueue(payload);
            }
        }

        private void HandleMessage(JsonElement message)
        {
            string name = Protocol.MessageName(message);
            if (name == "state")
            {
                ShowState(message);
            }
            else if (name == "setting")
            {
                HandleSetting(message);
            }
            else if (name == "hello")
            {
                Messages.Status("Sim says hello: protocol " + message.GetProperty("protocol").GetInt32()
                    + ", seed " + message.GetProperty("seed").GetInt64()
                    + ", scenario " + message.GetProperty("scenario").GetString());
                if (message.GetProperty("protocol").GetInt32() != Protocol.ProtocolVersion)
                {
                    Messages.Error("The sim speaks protocol " + message.GetProperty("protocol").GetInt32()
                        + " but this display speaks " + Protocol.ProtocolVersion + ". Use sim and gui from the same folder.");
                }
                OwnShipView.ShowOwnShipInfo(message.GetProperty("own_ship"));
                ApplyHello(message);
            }
            else if (name == "log")
            {
                OwnShipView.AddLogLine(message.GetProperty("text").GetString());
            }
            else if (name == "targets")
            {
                controller.Arpa.SetTargets(message);
            }
            else if (name == "alarms")
            {
                controller.Arpa.SetAlarms(message);
            }
            else if (name == "truth")
            {
                controller.ApplyTruth(message);
            }
            else if (name == "event")
            {
                controller.ApplyEvent(message);
            }
            else if (name == "land_view")
            {
                wheelhouseData.SetLand(message);
            }
            else if (name == "view")
            {
                wheelhouseData.SetView(message);
            }
            else if (name == "chart")
            {
                OpenChart(message.GetProperty("path").GetString());
            }
        }

        // The sim wrote the practice chart (an SVG): open it with the program the PC uses for SVG files, a browser.
        private void OpenChart(string path)
        {
            try
            {
                Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
            }
            catch (Exception error)
            {
                Messages.Error("The chart is at " + path + " but could not be opened: " + error.Message);
            }
        }

        // Half-second tick: the flash phase for the alarms, the lost-target boxes and the TRIAL tag.
        private void FlashTick(object sender, EventArgs e)
        {
            controller.Arpa.ToggleFlash();
            controller.Arpa.CheckAcquireTimeout(Environment.TickCount64);
            AlarmPanelView.ShowFlash();
            ShowTrialTag();
        }

        private void ShowTrialTag()
        {
            bool on = controller.Arpa.Trial.Enabled;
            if (on)
            {
                TrialSettings trial = controller.Arpa.Trial;
                TrialTag.Text = "   TRIAL " + trial.CourseDegTrue.ToString("000", System.Globalization.CultureInfo.InvariantCulture) + " deg T "
                    + trial.SpeedKn.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture) + " KN after "
                    + (trial.DelayS / ArpaController.SecondsPerMinute).ToString("0.0", System.Globalization.CultureInfo.InvariantCulture) + " MIN";
            }
            TrialTag.Visibility = on ? Visibility.Visible : Visibility.Collapsed;
            TrialTag.Opacity = controller.Arpa.FlashOn ? 1.0 : 0.15;
        }

        // The controls show what the sim confirmed; a request the sim corrected snaps to its value.
        private void HandleSetting(JsonElement message)
        {
            string path = message.GetProperty("path").GetString();
            JsonElement value = message.GetProperty("value");
            if (path == SpeedPath && value.ValueKind == JsonValueKind.Number)
            {
                ShowConfirmedSpeed(value.GetDouble());
            }
            controller.ConfirmSetting(path, value);
        }

        private void ShowState(JsonElement state)
        {
            int totalSeconds = (int)state.GetProperty("sim_time_s").GetDouble();    // sim time, s
            int hours = totalSeconds / 3600;
            int minutes = totalSeconds / 60 % 60;
            int seconds = totalSeconds % 60;
            ClockText.Text = hours.ToString("00") + ":" + minutes.ToString("00") + ":" + seconds.ToString("00");
            OwnShipView.Stamp = ClockText.Text;

            SpeedAchievedText.Text = FormatSpeed(state.GetProperty("speed_achieved").GetDouble());
            ShowConfirmedSpeed(state.GetProperty("speed_requested").GetDouble());

            paused = state.GetProperty("paused").GetBoolean();
            controller.Paused = paused;
            PauseButton.Content = paused ? "RESUME" : "PAUSE";

            JsonElement own;
            if (state.TryGetProperty("own", out own))
            {
                OwnShipView.ShowState(own);
                Ppi.OwnHeadingDeg = own.GetProperty("gyro_heading_deg").GetDouble();
                Ppi.OwnLogSpeedKn = own.GetProperty("log_speed_kn").GetDouble();
                Ppi.OwnSogKn = own.GetProperty("sog_kn").GetDouble();
                Ppi.OwnCogDeg = own.GetProperty("cog_deg_true").GetDouble();
                Ppi.OwnInfoValid = true;
                Ppi.InvalidateVisual();
                controller.ApplyOwnState(own.GetProperty("x_nm").GetDouble(), own.GetProperty("y_nm").GetDouble(), paused, Environment.TickCount64);
                controller.Geometry.HeadingDegTrue = own.GetProperty("gyro_heading_deg").GetDouble();
                ShowPpiStatus();
            }
        }

        // The box always shows what the sim confirmed, except while the user is typing in it.
        private void ShowConfirmedSpeed(double speed)
        {
            confirmedSpeedText = FormatSpeed(speed);
            SpeedRequestedText.Text = confirmedSpeedText;
            controller.SimSpeedRequested = speed;
            if (!SpeedBox.IsKeyboardFocused)
            {
                SpeedBox.Text = confirmedSpeedText;
            }
        }

        private static string FormatSpeed(double speed)
        {
            return speed.ToString("0.0", CultureInfo.InvariantCulture);
        }

        // ---- hello: apply the display defaults ----

        // The display takes every default from "hello", also after the sim restarts.
        private void ApplyHello(JsonElement hello)
        {
            JsonElement radar = hello.GetProperty("radar");
            JsonElement display = hello.GetProperty("display");

            controller.ApplyHello(hello);
            int bitmapPx = display.GetProperty("ppi_bitmap_px").GetInt32();

            if (ppiBitmap == null || ppiBitmap.SizePx != bitmapPx)
            {
                if (spokeSource != null)
                {
                    spokeSource.Stop();
                }
                controller.Geometry.SizePx = bitmapPx;
                ppiBitmap = new PpiBitmap(bitmapPx);
                spokeSource = new SpokeSource(ppiBitmap, controller.Geometry);
                Ppi.Attach(ppiBitmap, controller.Geometry);
            }

            lock (ppiBitmap.Sync)
            {
                ppiBitmap.HaveRef = false;              // a new run has its own reference positions
            }
            ApplyTrailSettings();

            monoGreen = PpiBitmap.ParseHex(display.GetProperty("mono_green_hex").GetString(), monoGreen);
            monoAmber = PpiBitmap.ParseHex(display.GetProperty("mono_amber_hex").GetString(), monoAmber);
            JsonElement colourStops = display.GetProperty("color_video_stops_hex");
            lock (ppiBitmap.Sync)
            {
                ppiBitmap.AzimuthBins = radar.GetProperty("azimuth_bins").GetInt32();
                ppiBitmap.RevolutionSimS = 60.0 / radar.GetProperty("antenna_rpm").GetDouble();    // rpm -> s per turn
                ppiBitmap.MonoBackground = PpiBitmap.ParseHex(display.GetProperty("mono_background_hex").GetString(), 0xFF000000);
                ppiBitmap.ColourBackground = PpiBitmap.ParseHex(display.GetProperty("color_background_hex").GetString(), 0xFF050814);
                for (int stop = 0; stop < 3 && stop < colourStops.GetArrayLength(); stop++)
                {
                    ppiBitmap.ColourStops[stop] = PpiBitmap.ParseHex(colourStops[stop].GetString(), ppiBitmap.ColourStops[stop]);
                }
                ppiBitmap.ColourMode = controller.ColourModeName == "color";
                ppiBitmap.MonoHue = controller.ColourModeName == "mono_amber" ? monoAmber : monoGreen;
                ppiBitmap.SettingsChanged();
            }

            Ppi.SymbolColour = PpiBitmap.ParseHex(display.GetProperty("color_symbol_hex").GetString(), 0xFFFFFFFF);
            Ppi.ShowRings = display.GetProperty("range_rings").GetBoolean();
            Ppi.ShowHeadingLine = display.GetProperty("heading_line").GetBoolean();
            Ppi.ShowBearingScale = display.GetProperty("bearing_scale").GetBoolean();

            ApplyDisplaySettings();
            ControlPanelView.Build(controller);
            ArpaPanelView.Build(controller);
            AlarmPanelView.Refresh();
            ShowTrialTag();

            // A new sim run: clear the picture, and tell the sim the range and video range in use.
            controller.ApplyGeometry(true, true);
        }

        // The trail layer's mode (a new mode clears the trails), length and video threshold.
        private void ApplyTrailSettings()
        {
            if (ppiBitmap == null)
            {
                return;
            }
            TrailLayer trails = ppiBitmap.Trails;
            lock (trails.Sync)
            {
                trails.TimeMin = controller.TrailTimeMin;
                trails.VideoThreshold = controller.TrailVideoThreshold;
            }
            trails.SetMode(TrailLayer.ParseMode(controller.TrailsModeName));
            ShowPpiStatus();
        }

        // Brilliance and afterglow: display-only settings, from the controller's values.
        private void ApplyDisplaySettings()
        {
            if (ppiBitmap == null)
            {
                return;
            }
            double value;
            lock (ppiBitmap.Sync)
            {
                if (controller.Numbers.TryGetValue(VideoBrilliancePath, out value))
                {
                    ppiBitmap.VideoBrilliance = value / 100.0;          // % -> fraction
                }
                if (controller.Numbers.TryGetValue(AfterglowPath, out value))
                {
                    ppiBitmap.AfterglowSimS = value;
                }
                ppiBitmap.SettingsChanged();
            }
            if (controller.Numbers.TryGetValue(RingsBrilliancePath, out value))
            {
                Ppi.RingsBrilliance = value / 100.0;
            }
            if (controller.Numbers.TryGetValue(SymbolsBrilliancePath, out value))
            {
                Ppi.SymbolsBrilliance = value / 100.0;
            }
        }

        // ---- from the controller ----

        // The picture is cleared when range, orientation, offset or colour mode changed (BRIEF.md Section 11).
        private void OnGeometryChanged(bool clear)
        {
            if (spokeSource == null)
            {
                return;
            }
            Ppi.RingIntervalNm = controller.RingIntervalNm;
            PpiGeometry geometry = controller.Geometry;
            if (controller.ViewResetPending && geometry.TrueMotionActive)
            {
                // True motion: own ship goes to the offset position (or the centre) as of the latest spoke.
                ppiBitmap.ApplyViewReset(geometry);
            }
            controller.ViewResetPending = false;
            spokeSource.SetGeometry(geometry, clear);
            ShowPpiStatus();
        }

        private void OnColourModeChanged()
        {
            if (ppiBitmap == null)
            {
                return;
            }
            lock (ppiBitmap.Sync)
            {
                ppiBitmap.ColourMode = controller.ColourModeName == "color";
                ppiBitmap.MonoHue = controller.ColourModeName == "mono_amber" ? monoAmber : monoGreen;
                ppiBitmap.SettingsChanged();
            }
        }

        private void OnSettingApplied(string path)
        {
            if (path == VideoBrilliancePath || path == RingsBrilliancePath
                || path == SymbolsBrilliancePath || path == AfterglowPath)
            {
                ApplyDisplaySettings();
            }
        }

        private void OnControllerChanged()
        {
            Ppi.HeadingLineHidden = controller.HeadingLineHeld;
            ShowTrialTag();
            Theme.Apply(controller.DarkMode);
            ContactsView.Refresh();
            EventTag.Text = controller.EventText == "" ? "" : "   " + controller.EventText.ToUpperInvariant();
        }

        // A collision or a grounding: the line goes to the message pane; the status line shows it
        // (OnControllerChanged) until the sim runs again. No pop-up.
        private void OnGameEvent(string kind, string text)
        {
            Messages.Warn(text);
        }

        // F1 and the HELP button: open the help window, or close it when it is open.
        private void ToggleHelp()
        {
            if (helpWindow != null)
            {
                helpWindow.Close();
                return;
            }
            helpWindow = new HelpWindow();
            helpWindow.Owner = this;
            helpWindow.Closed += (sender, e) => helpWindow = null;
            helpWindow.Show();
        }

        private void HelpButton_Click(object sender, RoutedEventArgs e)
        {
            ToggleHelp();
        }

        private void SetupButton_Click(object sender, RoutedEventArgs e)
        {
            if (setupWindow != null)
            {
                setupWindow.Activate();
                return;
            }
            setupWindow = new SetupWindow(controller, wheelhouseData);
            setupWindow.Owner = this;
            setupWindow.Closed += (sender2, e2) => setupWindow = null;
            setupWindow.Show();
        }

        private void OnOrderFocusRequested(bool focus)
        {
            if (focus)
            {
                OwnShipView.FocusOrderBox();
            }
            else
            {
                Keyboard.ClearFocus();
                Ppi.Focus();
            }
        }

        private void ShowPpiStatus()
        {
            PpiGeometry geometry = controller.Geometry;
            RangeText.Text = geometry.RangeScaleNm.ToString("0.##", CultureInfo.InvariantCulture);
            RingText.Text = Ppi.RingIntervalNm.ToString("0.##", CultureInfo.InvariantCulture);
            string orientationText = "NORTH UP";
            if (geometry.Orientation == PpiOrientation.HeadUp)
            {
                orientationText = "HEAD UP";
            }
            else if (geometry.Orientation == PpiOrientation.CourseUp)
            {
                orientationText = "COURSE UP";
            }
            OrientationText.Text = orientationText;
            MotionText.Text = geometry.TrueMotionActive ? "TRUE MOTION" : "RELATIVE MOTION";
            TrailsText.Text = controller.TrailsModeName == "off" ? "OFF"
                : controller.TrailsModeName.ToUpperInvariant() + " " + controller.TrailTimeMin.ToString("0.#", CultureInfo.InvariantCulture) + " MIN";
            TopBearingText.Text = geometry.TopBearingDegTrue.ToString("000", CultureInfo.InvariantCulture);
        }

        // ---- hotkeys ----

        // Hotkeys do nothing while a text box has focus (the box handles Enter and Esc itself).
        // The arrow keys belong to a knob or list that has focus.
        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            IInputElement focused = Keyboard.FocusedElement;
            if (focused is TextBox || focused is ComboBoxItem)
            {
                return;
            }
            bool arrowKey = e.Key == Key.Left || e.Key == Key.Right || e.Key == Key.Up || e.Key == Key.Down;
            if (arrowKey && (focused is ValueControl || focused is ComboBox))
            {
                return;
            }
            if (controller.HandleKeyDown(e.Key, Keyboard.Modifiers, Ppi.CursorValid, Ppi.CursorXPx, Ppi.CursorYPx))
            {
                e.Handled = true;
            }
        }

        private void Window_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            controller.HandleKeyUp(e.Key);
        }

        // H is a held key; letting go of the window must not leave the heading line off.
        private void Window_Deactivated(object sender, EventArgs e)
        {
            controller.HandleKeyUp(Key.H);
        }

        // After a click on a button the PPI takes the keyboard back, so the hotkeys work.
        private void AnyButtonClicked(object sender, RoutedEventArgs e)
        {
            if (e.OriginalSource is Button)
            {
                Ppi.Focus();
            }
        }

        // ---- to the sim ----

        private void SpeedBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                SpeedBox.Text = confirmedSpeedText;
                Keyboard.ClearFocus();
                return;
            }
            if (e.Key != Key.Enter)
            {
                return;
            }
            double speed;
            bool understood = double.TryParse(SpeedBox.Text.Trim(), NumberStyles.Float,
                                              CultureInfo.InvariantCulture, out speed);
            if (understood && link != null)
            {
                // The sim clamps to 1..10 and answers with "setting"; the box then shows that value.
                link.Send(Protocol.Set(SpeedPath, speed));
            }
            SpeedBox.Text = confirmedSpeedText;
            Keyboard.ClearFocus();
        }

        private void SendOrder(string text)
        {
            link.Send(Protocol.Order(text));
        }

        private void PauseButton_Click(object sender, RoutedEventArgs e)
        {
            controller.TogglePause();
        }

        private void WheelhouseButton_Click(object sender, RoutedEventArgs e)
        {
            if (wheelhouseWindow != null)
            {
                wheelhouseWindow.Activate();
                return;
            }
            wheelhouseWindow = new WheelhouseWindow(wheelhouseData, SendToSim);
            wheelhouseWindow.Closed += delegate { wheelhouseWindow = null; };
            wheelhouseWindow.Show();
        }

        private void ChartButton_Click(object sender, RoutedEventArgs e)
        {
            link.Send(Protocol.Chart());
        }

        private void RestartButton_Click(object sender, RoutedEventArgs e)
        {
            Messages.Status("Restarting the sim");
            link.Stop();
            link.Start();
        }
    }
}
