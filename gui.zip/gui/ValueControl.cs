// ValueControl.cs - one reusable control with two looks, knob and slider, for every
// number the student can change (BRIEF.md Section 11, Controls). Mouse drag, mouse wheel
// (Ctrl = fine step), double-click to type a value, arrow keys when focused.
// The control style is KNOB (every control a knob), SLIDER, or HYBRID (levels and bearings are knobs,
// distances and the rest sliders). A bearing (unit "deg ...", 0 to 360) is a wrapping control: its knob
// turns round and round with no stops, and a value that runs past 360 or below 0 comes round again.
// ControlRow packs knobs side by side, a few to a line; a slider always has a line to itself.
// The value and its unit always show beside the control. The control shows what the
// sim confirmed (ConfirmFromSim) and moves at once while it is being dragged.
// ControlMath, ValueModel and SendRateLimiter hold the maths and the rules, with no
// drawing, so the self-tests can run them directly.
// Units: whatever the control's unit text says (%, NM, KN, s, ...); knob angles in deg
// from the top, clockwise; positions in pixels.
// Called by: ControlPanel (builds them from hello.controls), SelfTest.

using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace RadarSim
{
    public enum ControlLook { Knob, Slider }

    // The style the student picks in SETUP (display.control_style).
    public enum ControlStyle { Knob, Slider, Hybrid }

    // ---- pure maths ----

    public static class ControlMath
    {
        public const double KnobHalfSweepDeg = 135.0;       // a knob sweeps 270 deg, from -135 to +135 from the top

        public static double Clamp(double value, double low, double high)
        {
            if (value < low)
            {
                return low;
            }
            if (value > high)
            {
                return high;
            }
            return value;
        }

        // A value brought into the range 0 to period (a bearing into 0 to 360). The top end wraps to 0.
        public static double Wrap(double value, double period)
        {
            if (period <= 0.0)
            {
                return value;
            }
            double wrapped = value % period;
            if (wrapped < 0.0)
            {
                wrapped += period;
            }
            if (wrapped >= period)
            {
                wrapped = 0.0;
            }
            return wrapped;
        }

        // Fraction 0..1 of the knob's sweep to the knob angle, deg from the top.
        public static double KnobAngleDeg(double fraction)
        {
            return -KnobHalfSweepDeg + 2.0 * KnobHalfSweepDeg * Clamp(fraction, 0.0, 1.0);
        }

        // A pointer angle (deg from the top, clockwise, any range) to a fraction 0..1.
        // The gap at the bottom of the knob goes to the nearer end: the right half to
        // the maximum, the left half to the minimum.
        public static double FractionFromKnobAngle(double angleDeg)
        {
            double angle = angleDeg % 360.0;
            if (angle > 180.0)
            {
                angle -= 360.0;
            }
            if (angle < -180.0)
            {
                angle += 360.0;
            }
            angle = Clamp(angle, -KnobHalfSweepDeg, KnobHalfSweepDeg);
            return (angle + KnobHalfSweepDeg) / (2.0 * KnobHalfSweepDeg);
        }

        // Slider: fraction 0..1 to a pixel position along a track of the given length.
        public static double SliderPositionPx(double fraction, double trackLengthPx)
        {
            return Clamp(fraction, 0.0, 1.0) * trackLengthPx;
        }

        public static double FractionFromSliderPx(double positionPx, double trackLengthPx)
        {
            if (trackLengthPx <= 0.0)
            {
                return 0.0;
            }
            return Clamp(positionPx / trackLengthPx, 0.0, 1.0);
        }
    }

    // ---- the value, its limits and the rules for changing it ----

    public class ValueModel
    {
        public double Minimum = 0.0;
        public double Maximum = 100.0;
        public double Step = 1.0;
        public double[] Choices;            // a fixed list (for example the range scales); null for a continuous control
        public bool Wrap;                   // a bearing: values come round from the top end to the bottom end and back
        public double Value;                // the value shown, in the control's unit
        public bool Dragging;               // while true, values confirmed by the sim wait

        // A bearing: unit "deg T", "deg R" and so on, from 0 to 360. Such a control wraps and, in HYBRID style, is a knob.
        public static bool IsBearing(string unit, double minimum, double maximum)
        {
            return unit != null && unit.StartsWith("deg", StringComparison.Ordinal) && minimum == 0.0 && maximum == 360.0;
        }

        // The nearest allowed value: the nearest list entry, or the value clamped to the limits.
        public double Limit(double requested)
        {
            if (Choices != null && Choices.Length > 0)
            {
                int best = 0;
                for (int i = 1; i < Choices.Length; i++)
                {
                    if (Math.Abs(Choices[i] - requested) < Math.Abs(Choices[best] - requested))
                    {
                        best = i;
                    }
                }
                return Choices[best];
            }
            if (Wrap)
            {
                return Minimum + ControlMath.Wrap(requested - Minimum, Maximum - Minimum);
            }
            return ControlMath.Clamp(requested, Minimum, Maximum);
        }

        // The user asks for a value. The value shown is the limited one, which is returned.
        public double Request(double requested)
        {
            Value = Limit(requested);
            return Value;
        }

        // The sim confirms (and if needed corrects) a value. It is ignored during a drag.
        // Returns true when the value shown changed.
        public bool Confirm(double confirmed)
        {
            if (Dragging)
            {
                return false;
            }
            double limited = Limit(confirmed);
            bool changed = limited != Value;
            Value = limited;
            return changed;
        }

        // 0..1 position of the current value between the limits (a list: position of its entry).
        public double Fraction
        {
            get
            {
                if (Choices != null && Choices.Length > 1)
                {
                    int index = IndexOfNearest(Value);
                    return (double)index / (Choices.Length - 1);
                }
                if (Maximum <= Minimum)
                {
                    return 0.0;
                }
                return ControlMath.Clamp((Value - Minimum) / (Maximum - Minimum), 0.0, 1.0);
            }
        }

        // The value at a 0..1 position, snapped to a step (or a list entry).
        public double ValueFromFraction(double fraction)
        {
            double f = ControlMath.Clamp(fraction, 0.0, 1.0);
            if (Choices != null && Choices.Length > 0)
            {
                int index = (int)Math.Round(f * (Choices.Length - 1));
                return Choices[index];
            }
            double raw = Minimum + f * (Maximum - Minimum);
            if (Step > 0.0)
            {
                raw = Minimum + Math.Round((raw - Minimum) / Step) * Step;
            }
            return ControlMath.Clamp(Math.Round(raw, 6), Minimum, Maximum);
        }

        // A wrapping control turned by the mouse: the pointer angle (deg from the top, clockwise) is the
        // value, snapped to the step. Only for a control with Wrap set and a minimum of 0.
        public double ValueFromAngleDeg(double angleDeg)
        {
            double raw = ControlMath.Wrap(angleDeg, 360.0) / 360.0 * (Maximum - Minimum);
            if (Step > 0.0)
            {
                raw = Math.Round(raw / Step) * Step;
            }
            return Minimum + ControlMath.Wrap(Math.Round(raw, 6), Maximum - Minimum);
        }

        // Wheel and arrow keys: a number of steps up (+) or down (-); fine = a tenth of a step.
        // A list always moves one entry at a time.
        public double Nudged(int steps, bool fine)
        {
            if (Choices != null && Choices.Length > 0)
            {
                int index = IndexOfNearest(Value) + steps;
                if (index < 0)
                {
                    index = 0;
                }
                if (index > Choices.Length - 1)
                {
                    index = Choices.Length - 1;
                }
                return Choices[index];
            }
            double stepSize = fine ? Step / 10.0 : Step;
            if (Wrap)
            {
                return Minimum + ControlMath.Wrap(Math.Round(Value + steps * stepSize, 6) - Minimum, Maximum - Minimum);
            }
            return ControlMath.Clamp(Math.Round(Value + steps * stepSize, 6), Minimum, Maximum);
        }

        // Typed text: whitespace is ignored; a number outside the limits is clamped.
        // Returns false (and leaves value at the old one) when the text is not a finite number.
        public bool TryParseTyped(string text, out double value)
        {
            value = Value;
            if (text == null)
            {
                return false;
            }
            double parsed;
            if (!double.TryParse(text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out parsed))
            {
                return false;
            }
            if (double.IsNaN(parsed) || double.IsInfinity(parsed))
            {
                return false;
            }
            value = Limit(parsed);
            return true;
        }

        private int IndexOfNearest(double value)
        {
            int best = 0;
            for (int i = 1; i < Choices.Length; i++)
            {
                if (Math.Abs(Choices[i] - value) < Math.Abs(Choices[best] - value))
                {
                    best = i;
                }
            }
            return best;
        }

        // Digits after the point that the step needs.
        public int Decimals
        {
            get
            {
                if (Choices != null)
                {
                    return 2;
                }
                if (Step >= 1.0)
                {
                    return 0;
                }
                if (Step >= 0.1)
                {
                    return 1;
                }
                return 2;
            }
        }
    }

    // At most one message per MinIntervalMs; the caller sends the last value itself on release.
    public class SendRateLimiter
    {
        public long MinIntervalMs = 50;                 // 20 a second
        private long lastSentMs = -1000000;

        public bool Due(long nowMs)
        {
            if (nowMs - lastSentMs >= MinIntervalMs)
            {
                lastSentMs = nowMs;
                return true;
            }
            return false;
        }

        public void MarkSent(long nowMs)
        {
            lastSentMs = nowMs;
        }
    }

    // ---- the WPF control ----

    public class ValueControl : Grid
    {
        private const double KnobSizePx = 30.0;
        private const double PackedKnobSizePx = 40.0;
        private const double SliderHeightPx = 20.0;
        private const double SliderMarginPx = 8.0;

        public event Action<ValueControl, double> ValueSent;     // the value to send to the sim (rate limited while dragging)

        public string Path = "";
        public string Unit = "";
        public readonly ValueModel Model = new ValueModel();
        public readonly SendRateLimiter Limiter = new SendRateLimiter();

        // In HYBRID style this control is a knob (a level or a bearing); false means it stays a slider.
        public bool HybridKnob;

        private ControlLook look = ControlLook.Knob;
        private bool packed;
        private readonly TextBlock labelText = new TextBlock();
        private readonly TextBlock valueText = new TextBlock();
        private readonly TextBox typeBox = new TextBox();
        private readonly Dial dial;

        public ValueControl()
        {
            Focusable = true;
            Margin = new Thickness(0, 0, 0, 0);

            labelText.VerticalAlignment = VerticalAlignment.Center;
            Children.Add(labelText);

            dial = new Dial(this);
            Children.Add(dial);

            valueText.VerticalAlignment = VerticalAlignment.Center;
            valueText.FontFamily = new FontFamily("Consolas");
            valueText.FontWeight = FontWeights.Bold;
            valueText.MouseLeftButtonDown += ValueText_MouseLeftButtonDown;
            Children.Add(valueText);

            typeBox.Visibility = Visibility.Collapsed;
            typeBox.VerticalAlignment = VerticalAlignment.Center;
            typeBox.FontFamily = new FontFamily("Consolas");
            typeBox.KeyDown += TypeBox_KeyDown;
            typeBox.LostKeyboardFocus += TypeBox_LostFocus;
            Children.Add(typeBox);

            ApplyLook();
        }

        public ControlLook Look
        {
            get { return look; }
            set
            {
                if (look != value)
                {
                    look = value;
                    ApplyLook();
                }
            }
        }

        // The look this control takes in a style: KNOB and SLIDER decide for every control, HYBRID by HybridKnob.
        public void SetStyle(ControlStyle style)
        {
            if (style == ControlStyle.Knob)
            {
                Look = ControlLook.Knob;
            }
            else if (style == ControlStyle.Slider)
            {
                Look = ControlLook.Slider;
            }
            else
            {
                Look = HybridKnob ? ControlLook.Knob : ControlLook.Slider;
            }
        }

        // True when a ControlRow lays this control out for packing: a knob with its label above and its value below.
        public bool Packed
        {
            get { return packed; }
            set
            {
                if (packed != value)
                {
                    packed = value;
                    ApplyLook();
                }
            }
        }

        public bool IsCompact
        {
            get { return packed && look == ControlLook.Knob; }
        }

        // Limits come from hello.controls: min, max, step, or a list of choices. A bearing (unit "deg ...",
        // 0 to 360) is a wrapping control, and in HYBRID style it stays a knob.
        public void Configure(string path, string label, string unit, double minimum, double maximum, double step,
                              double[] choices, double value)
        {
            Path = path;
            Unit = unit;
            labelText.Text = label;
            Model.Minimum = minimum;
            Model.Maximum = maximum;
            Model.Step = step;
            Model.Choices = choices;
            Model.Wrap = choices == null && ValueModel.IsBearing(unit, minimum, maximum);
            HybridKnob = Model.Wrap;
            Model.Value = Model.Limit(value);
            ShowValue();
            dial.InvalidateVisual();
        }

        // Rebuilds the grid for the look: label | dial | value on one line, or in a packed knob the
        // label above the knob above the value.
        private void ApplyLook()
        {
            ColumnDefinitions.Clear();
            RowDefinitions.Clear();
            if (IsCompact)
            {
                RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                SetRow(labelText, 0);
                SetColumn(labelText, 0);
                SetRow(dial, 1);
                SetColumn(dial, 0);
                SetRow(valueText, 2);
                SetColumn(valueText, 0);
                SetRow(typeBox, 2);
                SetColumn(typeBox, 0);
                labelText.HorizontalAlignment = HorizontalAlignment.Center;
                labelText.FontSize = 11.0;
                labelText.Margin = new Thickness(0, 2, 0, 0);
                dial.Width = PackedKnobSizePx;
                dial.Height = PackedKnobSizePx;
                dial.HorizontalAlignment = HorizontalAlignment.Center;
                valueText.HorizontalAlignment = HorizontalAlignment.Center;
                valueText.TextAlignment = TextAlignment.Center;
                valueText.Margin = new Thickness(0, 0, 0, 2);
                typeBox.Width = 64.0;
                typeBox.HorizontalAlignment = HorizontalAlignment.Center;
            }
            else
            {
                ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(78) });
                ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 50 });
                ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(84) });
                SetRow(labelText, 0);
                SetColumn(labelText, 0);
                SetRow(dial, 0);
                SetColumn(dial, 1);
                SetRow(valueText, 0);
                SetColumn(valueText, 2);
                SetRow(typeBox, 0);
                SetColumn(typeBox, 2);
                labelText.HorizontalAlignment = HorizontalAlignment.Left;
                labelText.ClearValue(TextBlock.FontSizeProperty);
                labelText.Margin = new Thickness(0);
                dial.Width = double.NaN;
                dial.Height = look == ControlLook.Knob ? KnobSizePx : SliderHeightPx;
                dial.HorizontalAlignment = HorizontalAlignment.Stretch;
                valueText.HorizontalAlignment = HorizontalAlignment.Stretch;
                valueText.TextAlignment = TextAlignment.Right;
                valueText.Margin = new Thickness(0, 0, 4, 0);
                typeBox.Width = double.NaN;
                typeBox.HorizontalAlignment = HorizontalAlignment.Stretch;
            }
            dial.InvalidateVisual();
        }

        private void ShowValue()
        {
            string number;
            if (Model.Choices != null)
            {
                number = Model.Value.ToString("0.##", CultureInfo.InvariantCulture);
            }
            else
            {
                number = Model.Value.ToString("F" + Model.Decimals, CultureInfo.InvariantCulture);
            }
            valueText.Text = Unit == "" ? number : number + " " + Unit;
        }

        // ---- value changes ----

        // The one path every change takes. The shown value is the limited request.
        // While dragging, a message goes out at most 20 times a second; final always sends.
        public void ChangeValue(double requested, long nowMs, bool final)
        {
            double shown = Model.Request(requested);
            ShowValue();
            dial.InvalidateVisual();
            if (final)
            {
                Limiter.MarkSent(nowMs);
                RaiseValueSent(shown);
            }
            else if (Limiter.Due(nowMs))
            {
                RaiseValueSent(shown);
            }
        }

        // End of a drag: the last value always goes out, whatever the rate limit skipped.
        public void CommitDrag(long nowMs)
        {
            Model.Dragging = false;
            ChangeValue(Model.Value, nowMs, true);
        }

        // The unit text changes (an EBL reads deg T or deg R) or the largest value changes (a VRM
        // goes to the range scale). The value is kept, limited to the new range.
        public void ShowUnit(string unit)
        {
            if (unit != Unit)
            {
                Unit = unit;
                ShowValue();
            }
        }

        public void SetMaximum(double maximum)
        {
            SetRange(Model.Minimum, maximum);
        }

        public void SetRange(double minimum, double maximum)
        {
            if (maximum != Model.Maximum || minimum != Model.Minimum)
            {
                Model.Minimum = minimum;
                Model.Maximum = maximum;
                Model.Value = Model.Limit(Model.Value);
                ShowValue();
                dial.InvalidateVisual();
            }
        }

        public void ConfirmFromSim(double confirmed)
        {
            if (Model.Confirm(confirmed))
            {
                ShowValue();
                dial.InvalidateVisual();
            }
        }

        private void RaiseValueSent(double value)
        {
            if (ValueSent != null)
            {
                ValueSent(this, value);
            }
        }

        // ---- wheel, arrow keys, typing ----

        protected override void OnMouseWheel(MouseWheelEventArgs e)
        {
            base.OnMouseWheel(e);
            if (!IsKeyboardFocusWithin && !dial.IsMouseOver)
            {
                return;                 // neither clicked on nor under the pointer: the wheel scrolls the panel instead
            }
            int notches = e.Delta / 120;
            if (notches == 0)
            {
                notches = e.Delta > 0 ? 1 : -1;
            }
            bool fine = (Keyboard.Modifiers & ModifierKeys.Control) != 0;
            ChangeValue(Model.Nudged(notches, fine), Environment.TickCount64, true);
            e.Handled = true;
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            int steps = 0;
            if (e.Key == Key.Right || e.Key == Key.Up)
            {
                steps = 1;
            }
            else if (e.Key == Key.Left || e.Key == Key.Down)
            {
                steps = -1;
            }
            if (steps != 0)
            {
                bool fine = (Keyboard.Modifiers & ModifierKeys.Control) != 0;
                ChangeValue(Model.Nudged(steps, fine), Environment.TickCount64, true);
                e.Handled = true;
            }
        }

        private void ValueText_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                OpenTypeBox();
                e.Handled = true;
            }
        }

        private void OpenTypeBox()
        {
            typeBox.Text = Model.Value.ToString(Model.Choices != null ? "0.##" : "F" + Model.Decimals, CultureInfo.InvariantCulture);
            typeBox.Visibility = Visibility.Visible;
            valueText.Visibility = Visibility.Hidden;
            typeBox.Focus();
            typeBox.SelectAll();
        }

        private void CloseTypeBox()
        {
            typeBox.Visibility = Visibility.Collapsed;
            valueText.Visibility = Visibility.Visible;
        }

        // Enter applies (a value outside the limits is clamped, or for a bearing comes round, and the
        // resulting value is shown); Esc cancels; text that is not a number leaves the old value.
        private void TypeBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                typeBox.Visibility = Visibility.Collapsed;      // nothing is applied by the focus change that follows
                CloseTypeBox();
                Focus();
                e.Handled = true;
            }
            else if (e.Key == Key.Enter)
            {
                double typed;
                if (Model.TryParseTyped(typeBox.Text, out typed))
                {
                    ChangeValue(typed, Environment.TickCount64, true);
                }
                CloseTypeBox();
                Focus();
                e.Handled = true;
            }
        }

        // Clicking away keeps what was typed (Esc is the way to cancel).
        private void TypeBox_LostFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            if (typeBox.Visibility == Visibility.Visible)
            {
                double typed;
                if (Model.TryParseTyped(typeBox.Text, out typed))
                {
                    ChangeValue(typed, Environment.TickCount64, true);
                }
            }
            CloseTypeBox();
        }

        // ---- the drawn part: a knob or a slider ----

        private class Dial : FrameworkElement
        {
            private readonly ValueControl owner;

            public Dial(ValueControl owner)
            {
                this.owner = owner;
                Cursor = Cursors.Hand;
            }

            protected override void OnRender(DrawingContext dc)
            {
                base.OnRender(dc);
                dc.DrawRectangle(Brushes.Transparent, null, new Rect(0.0, 0.0, ActualWidth, ActualHeight));
                if (owner.look == ControlLook.Knob)
                {
                    DrawKnob(dc);
                }
                else
                {
                    DrawSlider(dc);
                }
            }

            private void DrawKnob(DrawingContext dc)
            {
                double radius = Math.Min(ActualWidth, ActualHeight) / 2.0 - 3.0;
                Point centre = new Point(ActualWidth / 2.0, ActualHeight / 2.0);
                dc.DrawEllipse(Brushes.LightGray, new Pen(Brushes.Black, 1.0), centre, radius, radius);
                if (owner.Model.Wrap)
                {
                    // A bearing knob turns all the way round: marks at 000, 090, 180 and 270, the pointer at the value.
                    for (int quarter = 0; quarter < 4; quarter++)
                    {
                        DrawRadial(dc, centre, radius + 1.0, radius + 3.0, quarter * 90.0, new Pen(Brushes.DimGray, quarter == 0 ? 2.0 : 1.0));
                    }
                    double fullAngleDeg = owner.Model.Fraction * 360.0;
                    DrawRadial(dc, centre, 2.0, radius - 2.0, fullAngleDeg, new Pen(Brushes.Black, 3.0));
                    return;
                }
                // End marks of the 270 deg sweep.
                DrawRadial(dc, centre, radius + 1.0, radius + 3.0, ControlMath.KnobAngleDeg(0.0), new Pen(Brushes.DimGray, 1.0));
                DrawRadial(dc, centre, radius + 1.0, radius + 3.0, ControlMath.KnobAngleDeg(1.0), new Pen(Brushes.DimGray, 1.0));
                DrawRadial(dc, centre, 2.0, radius - 2.0, ControlMath.KnobAngleDeg(owner.Model.Fraction), new Pen(Brushes.Black, 3.0));
            }

            private static void DrawRadial(DrawingContext dc, Point centre, double fromRadius, double toRadius, double angleDeg, Pen pen)
            {
                double angleRad = angleDeg * Math.PI / 180.0;       // deg -> rad
                Point from = new Point(centre.X + fromRadius * Math.Sin(angleRad), centre.Y - fromRadius * Math.Cos(angleRad));
                Point to = new Point(centre.X + toRadius * Math.Sin(angleRad), centre.Y - toRadius * Math.Cos(angleRad));
                dc.DrawLine(pen, from, to);
            }

            private void DrawSlider(DrawingContext dc)
            {
                double trackLength = ActualWidth - 2.0 * SliderMarginPx;
                double y = ActualHeight / 2.0;
                dc.DrawLine(new Pen(Brushes.DimGray, 3.0), new Point(SliderMarginPx, y), new Point(SliderMarginPx + trackLength, y));
                double x = SliderMarginPx + ControlMath.SliderPositionPx(owner.Model.Fraction, trackLength);
                dc.DrawRectangle(Brushes.LightGray, new Pen(Brushes.Black, 1.0), new Rect(x - 5.0, y - 9.0, 10.0, 18.0));
            }

            // ---- mouse ----

            protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
            {
                base.OnMouseLeftButtonDown(e);
                owner.Focus();
                if (e.ClickCount == 2)
                {
                    owner.OpenTypeBox();
                    return;
                }
                owner.Model.Dragging = true;
                CaptureMouse();
                FollowPointer(e.GetPosition(this));
            }

            protected override void OnMouseMove(MouseEventArgs e)
            {
                base.OnMouseMove(e);
                if (IsMouseCaptured)
                {
                    FollowPointer(e.GetPosition(this));
                }
            }

            protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
            {
                base.OnMouseLeftButtonUp(e);
                if (IsMouseCaptured)
                {
                    ReleaseMouseCapture();
                    owner.CommitDrag(Environment.TickCount64);
                }
            }

            // The knob follows the pointer around its centre (a bearing knob all the way round, with no stops);
            // the slider follows it along the track.
            private void FollowPointer(Point pointer)
            {
                if (owner.look == ControlLook.Knob)
                {
                    double dx = pointer.X - ActualWidth / 2.0;
                    double dy = pointer.Y - ActualHeight / 2.0;
                    double angleDeg = Math.Atan2(dx, -dy) * 180.0 / Math.PI;      // rad -> deg, clockwise from the top
                    double knobValue;
                    if (owner.Model.Wrap)
                    {
                        knobValue = owner.Model.ValueFromAngleDeg(angleDeg);
                    }
                    else
                    {
                        knobValue = owner.Model.ValueFromFraction(ControlMath.FractionFromKnobAngle(angleDeg));
                    }
                    owner.ChangeValue(knobValue, Environment.TickCount64, false);
                    return;
                }
                double fraction = ControlMath.FractionFromSliderPx(pointer.X - SliderMarginPx, ActualWidth - 2.0 * SliderMarginPx);
                owner.ChangeValue(owner.Model.ValueFromFraction(fraction), Environment.TickCount64, false);
            }
        }
    }

    // ---- a row of controls: knobs side by side, sliders each on a line of their own ----

    public class ControlRow : Panel
    {
        public int Columns = 3;                 // knobs to a line

        public void AddControl(ValueControl control)
        {
            control.Packed = true;
            Children.Add(control);
        }

        protected override Size MeasureOverride(Size available)
        {
            double width = double.IsInfinity(available.Width) ? Columns * 110.0 : available.Width;
            double cellWidth = width / Columns;
            double y = 0.0;
            double lineHeight = 0.0;
            int inLine = 0;
            foreach (UIElement child in InternalChildren)
            {
                ValueControl control = child as ValueControl;
                if (control != null && control.IsCompact)
                {
                    if (inLine == Columns)
                    {
                        y += lineHeight;
                        lineHeight = 0.0;
                        inLine = 0;
                    }
                    child.Measure(new Size(cellWidth, double.PositiveInfinity));
                    lineHeight = Math.Max(lineHeight, child.DesiredSize.Height);
                    inLine++;
                }
                else
                {
                    y += lineHeight;
                    lineHeight = 0.0;
                    inLine = 0;
                    child.Measure(new Size(width, double.PositiveInfinity));
                    y += child.DesiredSize.Height;
                }
            }
            return new Size(width, y + lineHeight);
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            double cellWidth = finalSize.Width / Columns;
            double y = 0.0;
            double lineHeight = 0.0;
            int inLine = 0;
            foreach (UIElement child in InternalChildren)
            {
                ValueControl control = child as ValueControl;
                if (control != null && control.IsCompact)
                {
                    if (inLine == Columns)
                    {
                        y += lineHeight;
                        lineHeight = 0.0;
                        inLine = 0;
                    }
                    child.Arrange(new Rect(inLine * cellWidth, y, cellWidth, child.DesiredSize.Height));
                    lineHeight = Math.Max(lineHeight, child.DesiredSize.Height);
                    inLine++;
                }
                else
                {
                    y += lineHeight;
                    lineHeight = 0.0;
                    inLine = 0;
                    child.Arrange(new Rect(0.0, y, finalSize.Width, child.DesiredSize.Height));
                    y += child.DesiredSize.Height;
                }
            }
            return finalSize;
        }
    }
}
