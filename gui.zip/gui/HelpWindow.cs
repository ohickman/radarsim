// HelpWindow.cs - the help window (F1): a paragraph for each control group, then the hotkey table.
// Both come from HelpText, which writes the table out from HotkeyTable. Built in code. F1 or Esc closes it.
// Called by: MainWindow.

using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace RadarSim
{
    public class HelpWindow : Window
    {
        public HelpWindow()
        {
            Title = "Radar Sim help";
            Theme.Register(this);
            Width = 720;
            Height = 640;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;

            StackPanel panel = new StackPanel();
            panel.Margin = new Thickness(14);

            TextBlock title = new TextBlock();
            title.Text = "RADAR SIM HELP";
            title.FontWeight = FontWeights.Bold;
            title.FontSize = 16;
            panel.Children.Add(title);

            foreach (string[] group in HelpText.Groups)
            {
                TextBlock header = new TextBlock();
                header.Text = group[0];
                header.FontWeight = FontWeights.Bold;
                header.Margin = new Thickness(0, 12, 0, 2);
                panel.Children.Add(header);

                TextBlock paragraph = new TextBlock();
                paragraph.Text = group[1];
                paragraph.TextWrapping = TextWrapping.Wrap;
                panel.Children.Add(paragraph);
            }

            TextBlock hotkeys = new TextBlock();
            hotkeys.Text = "HOTKEYS";
            hotkeys.FontWeight = FontWeights.Bold;
            hotkeys.Margin = new Thickness(0, 14, 0, 4);
            panel.Children.Add(hotkeys);

            Grid table = new Grid();
            table.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(210) });
            table.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.0, GridUnitType.Star) });
            int row = 0;
            foreach (HotkeyRow hotkey in HotkeyTable.Rows)
            {
                table.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                TextBlock keys = new TextBlock();
                keys.Text = hotkey.KeysText;
                keys.FontFamily = new FontFamily("Consolas");
                keys.Margin = new Thickness(0, 1, 8, 1);
                Grid.SetRow(keys, row);
                Grid.SetColumn(keys, 0);
                table.Children.Add(keys);
                TextBlock action = new TextBlock();
                action.Text = hotkey.ActionText;
                action.TextWrapping = TextWrapping.Wrap;
                action.Margin = new Thickness(0, 1, 0, 1);
                Grid.SetRow(action, row);
                Grid.SetColumn(action, 1);
                table.Children.Add(action);
                row++;
            }
            panel.Children.Add(table);

            ScrollViewer scroll = new ScrollViewer();
            scroll.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            scroll.Content = panel;
            Content = scroll;

            PreviewKeyDown += HelpKeyDown;
        }

        private void HelpKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.F1 || e.Key == Key.Escape)
            {
                e.Handled = true;
                Close();
            }
        }
    }
}
