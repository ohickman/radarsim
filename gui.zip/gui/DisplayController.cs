// DisplayController.cs - the display's settings and what changes them: range, orientation,
// offset, colour mode, receiver controls, EBL and VRM, and the hotkey dispatch. It holds
// no WPF windows or controls, so the self-tests can drive it with simulated keys and read
// back the messages it sends. MainWindow and ControlPanel show its state and call its methods.
// Every change goes to the sim as a "set" message (BRIEF.md Section 7); the sim's "setting"
// answer is applied with ConfirmSetting.
// Motion (relative or true), trails (off, true, relative; 0.5 to 30 MIN) and stabilisation
// (sea or ground) are here too (M7). True motion needs north-up: asking for it in another
// orientation switches to north-up, and choosing another orientation switches back to relative
// motion; each says so through the Notice event (the window shows it in the message pane).
// Units: ranges NM, bearings deg, offsets as a fraction of the PPI radius, gain/STC/FTC %,
// trail time MIN, sim speed x (sim seconds per real second).
// ARPA (M9) lives in ArpaController, which this class owns: the hotkeys V, [, ], A, Delete,
// Ctrl+Delete and Space call it, and on/off and word settings go through SetRuntimeFlag and SetRuntimeWord.
// Called by: MainWindow, ControlPanel, ArpaPanel, SelfTest.

using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Windows.Input;

namespace RadarSim
{
    // Limits of one runtime control, as hello.controls gives them.
    public class ControlLimits
    {
        public string Path = "";
        public string Unit = "";
        public double Min;
        public double Max = 100.0;
        public double Step = 1.0;
        public double[] NumberChoices;      // a list of numbers (range scales), or null
        public string[] WordChoices;        // a list of words (orientation, colour mode), or null

        public double Limit(double requested)
        {
            if (NumberChoices != null && NumberChoices.Length > 0)
            {
                int best = 0;
                for (int i = 1; i < NumberChoices.Length; i++)
                {
                    if (Math.Abs(NumberChoices[i] - requested) < Math.Abs(NumberChoices[best] - requested))
                    {
                        best = i;
                    }
                }
                return NumberChoices[best];
            }
            return ControlMath.Clamp(requested, Min, Max);
        }
    }

    public class DisplayController
    {
        public const string SpeedPath = "general.sim_speed_multiplier";
        public const string GainPath = "radar_controls.gain_percent";
        public const string StcPath = "radar_controls.stc_percent";
        public const string FtcPath = "radar_controls.ftc_percent";
        public const string VideoRangePath = "radar.video_range_nm";
        public const string RangeScalePath = "display.range_scale_nm";
        public const string OrientationPath = "display.orientation";
        public const string ColourPath = "display.color_mode";
        public const string StylePath = "display.control_style";
        public const string DarkPath = "display.dark_mode";
        public const string OffsetEnabledPath = "display.offset_enabled";
        public const string OffsetXPath = "display.offset_x_fraction";
        public const string OffsetYPath = "display.offset_y_fraction";
        public const string MotionPath = "display.motion_mode";
        public const string TrailsModePath = "display.trails_mode";
        public const string TrailTimePath = "display.trail_time_min";
        public const string StabilisationPath = "arpa.stabilization";
        public const string InstructorPath = "display.instructor_overlay";

        private static readonly double[] SimSpeedSteps = new double[] { 1.0, 2.0, 3.0, 5.0, 10.0 };
        private static readonly string[] OrientationNames = new string[] { "north_up", "head_up", "course_up" };
        private static readonly string[] ColourNames = new string[] { "mono_green", "mono_amber", "color" };

        public readonly PpiGeometry Geometry = new PpiGeometry();        // the UI thread's copy
        public readonly EblVrmSet EblVrm = new EblVrmSet();
        public readonly Dictionary<string, ControlLimits> Limits = new Dictionary<string, ControlLimits>();
        public readonly Dictionary<string, double> Numbers = new Dictionary<string, double>();
        public readonly Dictionary<string, string> Words = new Dictionary<string, string>();
        public readonly Dictionary<string, bool> Flags = new Dictionary<string, bool>();    // on/off runtime settings
        public readonly ArpaController Arpa;                             // targets, alarms, guard zones, trial (M9)
        public readonly InstructorLayer Instructor = new InstructorLayer();    // true positions of the contacts (M10)
        public double OwnGroundXNm, OwnGroundYNm;    // own ship's position in the sim's ground frame, from the state message
        public int RunSeed;                          // the seed and scenario of the run, from hello
        public string RunScenario = "random";
        public string EventText = "";                // the last game event (collision, grounding) until the sim runs again

        public double[] RangeScalesNm = new double[0];
        public double[] RingIntervalsNm = new double[0];
        public int RangeIndex;
        public bool OffsetOn = true;
        public double OffsetXFraction;
        public double OffsetYFraction;
        public string ColourModeName = "mono_green";
        public bool Paused;
        public double SimSpeedRequested = 1.0;
        public bool HeadingLineHeld;                 // H is down
        public bool MotionTrue;                      // true motion (north-up only)
        public string TrailsModeName = "off";        // "off", "true", "relative"
        public double TrailTimeMin = 6.0;            // MIN
        public int TrailVideoThreshold = 60;         // video 0..255, from display.trail_video_threshold
        public bool ViewResetPending;                // the window puts own ship back at the offset position (true motion) at the next geometry change

        public event Action Changed;                 // anything the panel shows has changed
        public event Action<bool> GeometryChanged;   // range, orientation, offset or colour mode changed; true = clear the picture
        public event Action ColourModeChanged;
        public event Action<string> SettingApplied;  // a runtime setting (path) took a new value
        public event Action<bool> OrderFocusRequested;   // true = focus the order box, false = leave it
        public event Action TrailsChanged;           // trail mode or time changed (a new mode clears the trails)
        public event Action<string> Notice;          // a line for the message pane
        public event Action HelpRequested;           // F1
        public event Action<string, string> EventReceived;   // a game event: kind (collision, grounding) and text

        private readonly Action<Dictionary<string, object>> send;
        private bool eventStopSeen;                  // the sim was paused after the event
        private long eventStartMs;

        public DisplayController(Action<Dictionary<string, object>> send)
        {
            this.send = send;
            Arpa = new ArpaController(this);
        }

        // For ArpaController and the panels: send a message to the sim.
        public void SendMessage(Dictionary<string, object> message)
        {
            Send(message);
        }

        public void RaiseChangedFromArpa()
        {
            RaiseChanged();
        }

        private void Send(Dictionary<string, object> message)
        {
            if (send != null)
            {
                send(message);
            }
        }

        private void RaiseChanged()
        {
            if (Changed != null)
            {
                Changed();
            }
        }

        private void RaiseNotice(string text)
        {
            if (Notice != null)
            {
                Notice(text);
            }
        }

        private void RaiseTrailsChanged()
        {
            if (TrailsChanged != null)
            {
                TrailsChanged();
            }
        }

        private void RaiseSetting(string path)
        {
            if (SettingApplied != null)
            {
                SettingApplied(path);
            }
        }

        // ---- hello ----

        public static double[] ReadNumbers(JsonElement array)
        {
            double[] values = new double[array.GetArrayLength()];
            int index = 0;
            foreach (JsonElement item in array.EnumerateArray())
            {
                values[index] = item.GetDouble();
                index++;
            }
            return values;
        }

        private static string[] ReadWords(JsonElement array)
        {
            string[] words = new string[array.GetArrayLength()];
            int index = 0;
            foreach (JsonElement item in array.EnumerateArray())
            {
                words[index] = item.GetString();
                index++;
            }
            return words;
        }

        // Takes the display defaults and the limits of every runtime control from "hello",
        // also after the sim restarts. Does not send anything.
        public void ApplyHello(JsonElement hello)
        {
            JsonElement radar = hello.GetProperty("radar");
            JsonElement display = hello.GetProperty("display");

            RangeScalesNm = ReadNumbers(radar.GetProperty("range_scales_nm"));
            RingIntervalsNm = ReadNumbers(display.GetProperty("range_ring_interval_nm"));
            Geometry.OffsetMaxFraction = radar.GetProperty("offset_max_fraction").GetDouble();
            Geometry.Orientation = ParseOrientation(display.GetProperty("orientation").GetString());
            Geometry.LatchedCourseDegTrue = Geometry.HeadingDegTrue;
            OffsetOn = display.GetProperty("offset_enabled").GetBoolean();
            OffsetXFraction = display.GetProperty("offset_x_fraction").GetDouble();
            OffsetYFraction = display.GetProperty("offset_y_fraction").GetDouble();
            RangeIndex = NearestIndex(RangeScalesNm, display.GetProperty("range_scale_nm").GetDouble());
            ColourModeName = display.GetProperty("color_mode").GetString();
            JsonElement optional;
            if (hello.TryGetProperty("seed", out optional) && optional.ValueKind == JsonValueKind.Number)
            {
                RunSeed = (int)optional.GetInt64();
            }
            if (hello.TryGetProperty("scenario", out optional) && optional.ValueKind == JsonValueKind.String)
            {
                RunScenario = optional.GetString();
            }
            double resetFraction = 0.75;
            if (display.TryGetProperty("true_motion_reset_fraction", out optional) && optional.ValueKind == JsonValueKind.Number)
            {
                resetFraction = optional.GetDouble();
            }
            TrailVideoThreshold = 60;
            if (display.TryGetProperty("trail_video_threshold", out optional) && optional.ValueKind == JsonValueKind.Number)
            {
                TrailVideoThreshold = (int)Math.Round(optional.GetDouble());
            }
            MotionTrue = false;
            if (display.TryGetProperty("motion_mode", out optional) && optional.ValueKind == JsonValueKind.String)
            {
                MotionTrue = optional.GetString() == "true" && Geometry.Orientation == PpiOrientation.NorthUp;
            }
            TrailsModeName = "off";
            if (display.TryGetProperty("trails_mode", out optional) && optional.ValueKind == JsonValueKind.String)
            {
                TrailsModeName = optional.GetString();
            }
            TrailTimeMin = 6.0;
            if (display.TryGetProperty("trail_time_min", out optional) && optional.ValueKind == JsonValueKind.Number)
            {
                TrailTimeMin = optional.GetDouble();
            }
            Geometry.TrueMotion = MotionTrue;
            Geometry.TrueMotionResetFraction = resetFraction;
            ViewResetPending = true;

            Limits.Clear();
            Numbers.Clear();
            Words.Clear();
            Flags.Clear();
            Arpa.Reset();
            Instructor.Clear();
            EventText = "";
            foreach (JsonElement control in hello.GetProperty("controls").EnumerateArray())
            {
                ReadControl(control);
            }
            Words[OrientationPath] = OrientationName(Geometry.Orientation);
            Words[ColourPath] = ColourModeName;
            Words[MotionPath] = MotionTrue ? "true" : "relative";
            Words[TrailsModePath] = TrailsModeName;
            Numbers[TrailTimePath] = TrailTimeMin;
            if (!Words.ContainsKey(StylePath))
            {
                Words[StylePath] = display.GetProperty("control_style").GetString();
            }
            if (!Words.ContainsKey(DarkPath))
            {
                JsonElement darkWord;
                Words[DarkPath] = display.TryGetProperty("dark_mode", out darkWord) ? darkWord.GetString() : "off";
            }
            if (Numbers.ContainsKey(SpeedPath))
            {
                SimSpeedRequested = Numbers[SpeedPath];
            }

            EblVrm.Reset();
            if (RangeScalesNm.Length > 0)
            {
                Geometry.RangeScaleNm = RangeScalesNm[RangeIndex];
            }
            Geometry.OffsetXFraction = OffsetOn ? OffsetXFraction : 0.0;
            Geometry.OffsetYFraction = OffsetOn ? OffsetYFraction : 0.0;

            // The sim starts with the overlay data off; tell it if the display wants it.
            if (InstructorOn)
            {
                Send(Protocol.Truth(true));
            }
        }

        // ---- instructor overlay and game events (M10) ----

        // TRAFFIC NOW from the setup window: the sim adds or removes contacts at once to match the density setting.
        public void TrafficNow()
        {
            Send(Protocol.TrafficNow());
        }

        // NEW RUN from the setup window. The seed is a whole number, 0 or more (0 = the sim picks one);
        // the scenario is one the sim knows. Returns false, with the reason, when nothing was sent.
        public bool StartNewRun(string seedText, string scenario, out string problem)
        {
            int seed;
            if (!int.TryParse(seedText == null ? "" : seedText.Trim(), System.Globalization.NumberStyles.None,
                              System.Globalization.CultureInfo.InvariantCulture, out seed))
            {
                problem = "The seed must be a whole number, 0 or more (0 = random): \"" + seedText + "\" was not used.";
                return false;
            }
            if (scenario != "random" && scenario != "calibration")
            {
                problem = "The scenario must be random or calibration: \"" + scenario + "\" was not used.";
                return false;
            }
            problem = null;
            Send(Protocol.NewRun(seed, scenario));
            return true;
        }

        public bool InstructorOn
        {
            get
            {
                bool on;
                return Flags.TryGetValue(InstructorPath, out on) && on;
            }
        }

        // Ctrl+Shift+T and the setup window's check box: the setting goes to the sim, and so does the
        // request for "truth" messages.
        public void SetInstructor(bool on)
        {
            if (!on)
            {
                Instructor.Clear();
            }
            SetRuntimeFlag(InstructorPath, on);
            Send(Protocol.Truth(on));
        }

        public void ToggleInstructor()
        {
            SetInstructor(!InstructorOn);
        }

        // A "truth" message: kept only while the overlay is on, so a late message cannot bring it back.
        public void ApplyTruth(JsonElement message)
        {
            if (InstructorOn)
            {
                Instructor.SetMessage(message);
                RaiseChanged();
            }
        }

        // An "event" message (collision, grounding): the text goes to the message pane and stays in the
        // status line until the sim runs again. No pop-up.
        public void ApplyEvent(JsonElement message)
        {
            JsonElement text;
            if (message.TryGetProperty("text", out text) && text.ValueKind == JsonValueKind.String)
            {
                EventText = text.GetString();
                eventStopSeen = false;
                eventStartMs = Environment.TickCount64;
                JsonElement kind;
                string kindName = message.TryGetProperty("kind", out kind) && kind.ValueKind == JsonValueKind.String ? kind.GetString() : "";
                if (EventReceived != null)
                {
                    EventReceived(kindName, EventText);
                }
                RaiseChanged();
            }
        }

        // From each state message: own ship's position, and the end of a game event's text in the status
        // line: when the sim runs again after the stop, or EventShownMs after the event when it never stopped.
        public const long EventShownMs = 15000;

        public void ApplyOwnState(double xNm, double yNm, bool paused, long nowMs)
        {
            OwnGroundXNm = xNm;
            OwnGroundYNm = yNm;
            if (EventText == "")
            {
                return;
            }
            if (paused)
            {
                eventStopSeen = true;
            }
            else if (eventStopSeen || nowMs - eventStartMs > EventShownMs)
            {
                EventText = "";
                eventStopSeen = false;
                RaiseChanged();
            }
        }

        private void ReadControl(JsonElement control)
        {
            ControlLimits limits = new ControlLimits();
            limits.Path = control.GetProperty("path").GetString();
            JsonElement unit;
            if (control.TryGetProperty("unit", out unit) && unit.ValueKind == JsonValueKind.String)
            {
                limits.Unit = unit.GetString();
            }
            JsonElement choices;
            if (control.TryGetProperty("choices", out choices) && choices.ValueKind == JsonValueKind.Array
                && choices.GetArrayLength() > 0)
            {
                if (choices[0].ValueKind == JsonValueKind.Number)
                {
                    limits.NumberChoices = ReadNumbers(choices);
                }
                else if (choices[0].ValueKind == JsonValueKind.String)
                {
                    limits.WordChoices = ReadWords(choices);
                }
            }
            JsonElement minimum, maximum, step;
            if (control.TryGetProperty("min", out minimum) && minimum.ValueKind == JsonValueKind.Number)
            {
                limits.Min = minimum.GetDouble();
            }
            if (control.TryGetProperty("max", out maximum) && maximum.ValueKind == JsonValueKind.Number)
            {
                limits.Max = maximum.GetDouble();
            }
            if (control.TryGetProperty("step", out step) && step.ValueKind == JsonValueKind.Number)
            {
                limits.Step = step.GetDouble();
            }
            Limits[limits.Path] = limits;

            JsonElement value;
            if (control.TryGetProperty("value", out value))
            {
                if (value.ValueKind == JsonValueKind.Number)
                {
                    Numbers[limits.Path] = value.GetDouble();
                }
                else if (value.ValueKind == JsonValueKind.String)
                {
                    Words[limits.Path] = value.GetString();
                }
                else if (value.ValueKind == JsonValueKind.True || value.ValueKind == JsonValueKind.False)
                {
                    Flags[limits.Path] = value.ValueKind == JsonValueKind.True;
                }
            }
        }

        public static PpiOrientation ParseOrientation(string name)
        {
            if (name == "head_up")
            {
                return PpiOrientation.HeadUp;
            }
            if (name == "course_up")
            {
                return PpiOrientation.CourseUp;
            }
            return PpiOrientation.NorthUp;
        }

        public static string OrientationName(PpiOrientation orientation)
        {
            if (orientation == PpiOrientation.HeadUp)
            {
                return "head_up";
            }
            if (orientation == PpiOrientation.CourseUp)
            {
                return "course_up";
            }
            return "north_up";
        }

        public static int NearestIndex(double[] values, double wanted)
        {
            int best = 0;
            for (int i = 1; i < values.Length; i++)
            {
                if (Math.Abs(values[i] - wanted) < Math.Abs(values[best] - wanted))
                {
                    best = i;
                }
            }
            return best;
        }

        // ---- the sim's answers ----

        // A "setting" message. Range, orientation, offset and colour mode belong to the display:
        // it already shows what it asked for, so the answer is not applied again.
        public void ConfirmSetting(string path, JsonElement value)
        {
            if (path == RangeScalePath || path == OrientationPath || path == ColourPath || path == OffsetEnabledPath
                || path == MotionPath || path == TrailsModePath)
            {
                return;
            }
            if (value.ValueKind == JsonValueKind.Number)
            {
                Numbers[path] = value.GetDouble();
                if (path == SpeedPath)
                {
                    SimSpeedRequested = value.GetDouble();
                }
            }
            else if (value.ValueKind == JsonValueKind.String)
            {
                Words[path] = value.GetString();
            }
            else if (value.ValueKind == JsonValueKind.True || value.ValueKind == JsonValueKind.False)
            {
                Flags[path] = value.ValueKind == JsonValueKind.True;
            }
            if (path == TrailTimePath && value.ValueKind == JsonValueKind.Number && value.GetDouble() != TrailTimeMin)
            {
                TrailTimeMin = value.GetDouble();           // the sim snapped it to its list
                RaiseTrailsChanged();
            }
            RaiseSetting(path);
            RaiseChanged();
        }

        // ---- runtime numbers: gain, STC, FTC, brilliance, afterglow ----

        public double LimitedNumber(string path, double requested)
        {
            ControlLimits limits;
            if (Limits.TryGetValue(path, out limits))
            {
                return limits.Limit(requested);
            }
            return requested;
        }

        public void SetRuntimeNumber(string path, double requested)
        {
            double value = LimitedNumber(path, requested);
            Numbers[path] = value;
            Send(Protocol.Set(path, value));
            RaiseSetting(path);
            RaiseChanged();
        }

        // A word setting from a list (vector mode) and an on/off setting (history dots).
        public void SetRuntimeWord(string path, string word)
        {
            Words[path] = word;
            Send(Protocol.Set(path, word));
            RaiseSetting(path);
            RaiseChanged();
        }

        public void SetRuntimeFlag(string path, bool on)
        {
            Flags[path] = on;
            Send(Protocol.Set(path, on));
            RaiseSetting(path);
            RaiseChanged();
        }

        // A hotkey step. At a limit nothing is sent.
        public void StepRuntimeNumber(string path, double amount)
        {
            double current = 0.0;
            Numbers.TryGetValue(path, out current);
            double next = LimitedNumber(path, Math.Round(current + amount, 6));
            if (next == current)
            {
                return;
            }
            SetRuntimeNumber(path, next);
        }

        // ---- range, orientation, colour mode, control style ----

        public double RingIntervalNm
        {
            get { return RangeIndex < RingIntervalsNm.Length ? RingIntervalsNm[RangeIndex] : 0.0; }
        }

        // Pushes range and offset into the geometry, tells the sim the video range in use
        // when asked, and tells the window. A change of range, orientation, offset or colour
        // mode clears the picture (BRIEF.md Section 11).
        public void ApplyGeometry(bool clear, bool sendRange)
        {
            if (RangeScalesNm.Length == 0)
            {
                return;
            }
            Geometry.RangeScaleNm = RangeScalesNm[RangeIndex];
            Geometry.OffsetXFraction = OffsetOn ? OffsetXFraction : 0.0;
            Geometry.OffsetYFraction = OffsetOn ? OffsetYFraction : 0.0;
            if (sendRange)
            {
                SendRange();
            }
            if (GeometryChanged != null)
            {
                GeometryChanged(clear);
            }
            RaiseChanged();
        }

        // The sim covers the range scale plus the offset, so the far side of the picture is not empty.
        public void SendRange()
        {
            // In true motion own ship may be anywhere inside the reset circle, so that is the longest offset.
            double offsetFraction = Geometry.OffsetMagnitude;
            if (MotionTrue && Geometry.TrueMotionResetFraction > offsetFraction)
            {
                offsetFraction = Geometry.TrueMotionResetFraction;
            }
            double videoRangeNm = Geometry.RangeScaleNm * (1.0 + offsetFraction);
            videoRangeNm = Math.Ceiling(videoRangeNm * 100.0) / 100.0;
            ControlLimits limits;
            if (Limits.TryGetValue(VideoRangePath, out limits))
            {
                videoRangeNm = ControlMath.Clamp(videoRangeNm, limits.Min, limits.Max);
            }
            Send(Protocol.Set(RangeScalePath, Geometry.RangeScaleNm));
            Send(Protocol.Set(VideoRangePath, videoRangeNm));
        }

        public void StepRange(int direction)
        {
            int next = RangeIndex + direction;
            if (next < 0 || next >= RangeScalesNm.Length)
            {
                return;
            }
            RangeIndex = next;
            ViewResetPending = true;
            ApplyGeometry(true, true);
        }

        public void SetRangeNm(double rangeNm)
        {
            if (RangeScalesNm.Length == 0)
            {
                return;
            }
            int next = NearestIndex(RangeScalesNm, rangeNm);
            if (next == RangeIndex)
            {
                return;
            }
            RangeIndex = next;
            ViewResetPending = true;
            ApplyGeometry(true, true);
        }

        public void SetOrientation(string name)
        {
            if (MotionTrue && ParseOrientation(name) != PpiOrientation.NorthUp)
            {
                MotionTrue = false;
                Geometry.TrueMotion = false;
                Words[MotionPath] = "relative";
                Send(Protocol.Set(MotionPath, "relative"));
                RaiseNotice("Motion is RELATIVE again: true motion needs NORTH UP.");
            }
            Geometry.Orientation = ParseOrientation(name);
            Words[OrientationPath] = name;
            if (Geometry.Orientation == PpiOrientation.CourseUp)
            {
                Geometry.LatchedCourseDegTrue = Geometry.HeadingDegTrue;      // course-up latches the heading when selected
            }
            ApplyGeometry(true, false);
            Send(Protocol.Set(OrientationPath, name));
        }

        public void CycleOrientation()
        {
            int index = Array.IndexOf(OrientationNames, OrientationName(Geometry.Orientation));
            SetOrientation(OrientationNames[(index + 1) % OrientationNames.Length]);
        }

        public void ResetCourse()
        {
            Geometry.LatchedCourseDegTrue = Geometry.HeadingDegTrue;
            ApplyGeometry(Geometry.Orientation == PpiOrientation.CourseUp, false);
        }

        public void SetColourMode(string name)
        {
            ColourModeName = name;
            Words[ColourPath] = name;
            if (ColourModeChanged != null)
            {
                ColourModeChanged();
            }
            ApplyGeometry(true, false);
            Send(Protocol.Set(ColourPath, name));
        }

        public void CycleColourMode()
        {
            int index = Array.IndexOf(ColourNames, ColourModeName);
            SetColourMode(ColourNames[(index + 1) % ColourNames.Length]);
        }

        public void SetControlStyle(string name)
        {
            Words[StylePath] = name;
            Send(Protocol.Set(StylePath, name));
            RaiseSetting(StylePath);
            RaiseChanged();
        }

        public void SetDarkMode(bool on)
        {
            string word = on ? "on" : "off";
            Words[DarkPath] = word;
            Send(Protocol.Set(DarkPath, word));
            RaiseSetting(DarkPath);
            RaiseChanged();
        }

        public bool DarkMode
        {
            get
            {
                string word;
                return Words.TryGetValue(DarkPath, out word) && word == "on";
            }
        }

        // The control style the student chose: knobs, sliders, or hybrid (levels and bearings knobs, the rest sliders).
        public ControlStyle Style
        {
            get
            {
                string name;
                if (Words.TryGetValue(StylePath, out name))
                {
                    if (name == "slider")
                    {
                        return ControlStyle.Slider;
                    }
                    if (name == "hybrid")
                    {
                        return ControlStyle.Hybrid;
                    }
                }
                return ControlStyle.Knob;
            }
        }

        // ---- offset ----

        private void SetOffsetFraction(double x, double y)
        {
            double length = Math.Sqrt(x * x + y * y);
            if (length > Geometry.OffsetMaxFraction && length > 0.0)
            {
                x = x * Geometry.OffsetMaxFraction / length;           // longer than allowed: used clamped
                y = y * Geometry.OffsetMaxFraction / length;
            }
            OffsetXFraction = x;
            OffsetYFraction = y;
            OffsetOn = true;
            ViewResetPending = true;
            ApplyGeometry(true, true);
            SendOffset();
        }

        // Typed offset, percent of the radius, + right and + up.
        public void SetOffsetPercent(double xPercent, double yPercent)
        {
            SetOffsetFraction(xPercent / 100.0, yPercent / 100.0);
        }

        // Ctrl+O: own ship goes to the cursor. The position is in bitmap pixels.
        public void SetOffsetFromPixel(double xPx, double yPx)
        {
            SetOffsetFraction((xPx - Geometry.CentreXPx) / Geometry.RadiusPx,
                              (Geometry.CentreYPx - yPx) / Geometry.RadiusPx);
        }

        public void CentreOffset()
        {
            OffsetPlaceArmed = false;
            SetOffsetFraction(0.0, 0.0);
        }

        // OFFSET button: the next click inside the PPI circle puts own ship there.
        public bool OffsetPlaceArmed;

        public void ToggleOffsetPlace()
        {
            OffsetPlaceArmed = !OffsetPlaceArmed;
            RaiseChanged();
        }

        public void PlaceOffsetAtPixel(double xPx, double yPx)
        {
            OffsetPlaceArmed = false;
            SetOffsetFromPixel(xPx, yPx);
        }

        private void SendOffset()
        {
            Send(Protocol.Set(OffsetEnabledPath, OffsetOn));
            Send(Protocol.Set(OffsetXPath, OffsetXFraction));
            Send(Protocol.Set(OffsetYPath, OffsetYFraction));
        }

        // ---- motion, trails, stabilisation (M7) ----

        public void SetMotion(bool trueMotion)
        {
            if (trueMotion == MotionTrue)
            {
                return;
            }
            if (trueMotion && Geometry.Orientation != PpiOrientation.NorthUp)
            {
                RaiseNotice("True motion needs NORTH UP: orientation set to NORTH UP.");
                SetOrientation("north_up");
            }
            MotionTrue = trueMotion;
            Geometry.TrueMotion = trueMotion;
            string name = trueMotion ? "true" : "relative";
            Words[MotionPath] = name;
            ViewResetPending = true;
            ApplyGeometry(true, true);              // the video range depends on the motion
            Send(Protocol.Set(MotionPath, name));
        }

        public void ToggleMotion()
        {
            SetMotion(!MotionTrue);
        }

        // The RESET button: own ship goes back to the offset position (or the centre) and the picture is cleared.
        public void ResetTrueMotion()
        {
            if (!MotionTrue)
            {
                return;
            }
            ViewResetPending = true;
            ApplyGeometry(true, false);
        }

        public void SetTrailsMode(string name)
        {
            if (name == TrailsModeName)
            {
                return;
            }
            TrailsModeName = name;
            Words[TrailsModePath] = name;
            Send(Protocol.Set(TrailsModePath, name));
            RaiseTrailsChanged();
            RaiseChanged();
        }

        // T: off, true, relative, off...
        public void CycleTrails()
        {
            if (TrailsModeName == "off")
            {
                SetTrailsMode("true");
            }
            else if (TrailsModeName == "true")
            {
                SetTrailsMode("relative");
            }
            else
            {
                SetTrailsMode("off");
            }
        }

        public void SetTrailTimeMin(double minutes)
        {
            double value = LimitedNumber(TrailTimePath, minutes);
            if (value == TrailTimeMin)
            {
                return;
            }
            TrailTimeMin = value;
            Numbers[TrailTimePath] = value;
            Send(Protocol.Set(TrailTimePath, value));
            RaiseTrailsChanged();
            RaiseChanged();
        }

        // SEA or GROUND stabilisation. The reference position changes meaning, so the picture
        // and the trails are cleared and, in true motion, own ship goes back to its start position.
        public void SetStabilisation(string name)
        {
            string old;
            Words.TryGetValue(StabilisationPath, out old);
            if (name == old)
            {
                return;
            }
            Words[StabilisationPath] = name;
            Send(Protocol.Set(StabilisationPath, name));
            ViewResetPending = true;
            ApplyGeometry(true, false);
        }

        // ---- pause and sim speed ----

        public void TogglePause()
        {
            Send(Protocol.Pause(!Paused));
        }

        // F5 and F6: the next lower or higher of 1, 2, 3, 5, 10.
        public void StepSimSpeed(int direction)
        {
            double next = SimSpeedRequested;
            if (direction > 0)
            {
                for (int i = 0; i < SimSpeedSteps.Length; i++)
                {
                    if (SimSpeedSteps[i] > SimSpeedRequested + 1e-9)
                    {
                        next = SimSpeedSteps[i];
                        break;
                    }
                }
            }
            else
            {
                for (int i = SimSpeedSteps.Length - 1; i >= 0; i--)
                {
                    if (SimSpeedSteps[i] < SimSpeedRequested - 1e-9)
                    {
                        next = SimSpeedSteps[i];
                        break;
                    }
                }
            }
            if (next != SimSpeedRequested)
            {
                SimSpeedRequested = next;
                Send(Protocol.Set(SpeedPath, next));
                RaiseChanged();
            }
        }

        // ---- EBL and VRM ----

        public void ToggleEbl(int index)
        {
            EblVrm.ToggleEbl(index);
            RaiseChanged();
        }

        public void ToggleVrm(int index)
        {
            EblVrm.ToggleVrm(index, Geometry);
            RaiseChanged();
        }

        public void ToggleEblRelative()
        {
            EblVrm.SetRelativeMode(!EblVrm.EblRelative, Geometry.HeadingDegTrue);
            RaiseChanged();
        }

        public void SetEblReading(int index, double bearingDeg)
        {
            EblVrm.SetEblReading(index, bearingDeg);
            EblVrm.EblOn[index] = true;
            EblVrm.SelectedEbl = index;
            RaiseChanged();
        }

        public void SetVrmNm(int index, double rangeNm)
        {
            if (!EblVrm.VrmOn[index])
            {
                EblVrm.ToggleVrm(index, Geometry);
            }
            EblVrm.SetVrmNm(index, rangeNm, Geometry);
            EblVrm.SelectedVrm = index;
            RaiseChanged();
        }

        public void TogglePi(int index)
        {
            EblVrm.PiOn[index] = !EblVrm.PiOn[index];
            RaiseChanged();
        }

        public void SetPiBearing(int index, double bearingDeg)
        {
            EblVrm.SetPiBearing(index, bearingDeg);
            EblVrm.PiOn[index] = true;
            RaiseChanged();
        }

        public void SetPiNm(int index, double distanceNm)
        {
            EblVrm.SetPiNm(index, distanceNm, Geometry);
            EblVrm.PiOn[index] = true;
            RaiseChanged();
        }

        // The PPI moved an EBL or VRM with the mouse.
        public void EblVrmDragged()
        {
            RaiseChanged();
        }

        // ---- hotkeys ----

        // Returns true when the key was a hotkey with a function. The cursor position is in
        // bitmap pixels; cursorValid is false when the pointer is not on the PPI.
        public bool HandleKeyDown(Key key, ModifierKeys modifiers, bool cursorValid, double cursorXPx, double cursorYPx)
        {
            HotkeyBinding binding = HotkeyTable.Find(key, modifiers);
            if (binding == null || binding.Action == null)
            {
                return false;
            }
            int amount = (int)Math.Round(binding.Amount);
            switch (binding.Action)
            {
                case "range_step":
                    StepRange(amount);
                    return true;
                case "gain_step":
                    StepRuntimeNumber(GainPath, binding.Amount);
                    return true;
                case "stc_step":
                    StepRuntimeNumber(StcPath, binding.Amount);
                    return true;
                case "ftc_step":
                    StepRuntimeNumber(FtcPath, binding.Amount);
                    return true;
                case "orientation_cycle":
                    CycleOrientation();
                    return true;
                case "colour_cycle":
                    CycleColourMode();
                    return true;
                case "ebl_toggle":
                    ToggleEbl(amount);
                    return true;
                case "vrm_toggle":
                    ToggleVrm(amount);
                    return true;
                case "ebl_step":
                    if (EblVrm.EblOn[EblVrm.SelectedEbl])
                    {
                        EblVrm.AdjustSelectedEbl(binding.Amount);
                        RaiseChanged();
                    }
                    return true;
                case "vrm_step":
                    if (EblVrm.VrmOn[EblVrm.SelectedVrm])
                    {
                        EblVrm.AdjustSelectedVrm(binding.Amount, Geometry);
                        RaiseChanged();
                    }
                    return true;
                case "motion_toggle":
                    ToggleMotion();
                    return true;
                case "trails_cycle":
                    CycleTrails();
                    return true;
                case "heading_line_off":
                    HeadingLineHeld = true;
                    RaiseChanged();
                    return true;
                case "pause_toggle":
                    TogglePause();
                    return true;
                case "sim_speed_step":
                    StepSimSpeed(amount);
                    return true;
                case "order_focus":
                    if (OrderFocusRequested != null)
                    {
                        OrderFocusRequested(binding.Amount > 0.5);
                    }
                    return true;
                case "offset_cursor":
                    if (cursorValid)
                    {
                        SetOffsetFromPixel(cursorXPx, cursorYPx);
                    }
                    return true;
                case "offset_centre":
                    CentreOffset();
                    return true;
                case "vector_mode_toggle":
                    Arpa.ToggleVectorMode();
                    return true;
                case "vector_time_step":
                    Arpa.StepVectorTime(amount);
                    return true;
                case "acquire":
                    if (cursorValid)
                    {
                        Arpa.AcquireAtPixel(Geometry, cursorXPx, cursorYPx);
                    }
                    return true;
                case "cancel_target":
                    Arpa.CancelSelected();
                    return true;
                case "cancel_all":
                    Arpa.CancelAll();
                    return true;
                case "alarm_ack":
                    Arpa.AcknowledgeAll();
                    return true;
                case "instructor_toggle":
                    ToggleInstructor();
                    return true;
                case "help_open":
                    if (HelpRequested != null)
                    {
                        HelpRequested();
                    }
                    return true;
            }
            return false;
        }

        public void HandleKeyUp(Key key)
        {
            if (key == Key.H && HeadingLineHeld)
            {
                HeadingLineHeld = false;
                RaiseChanged();
            }
        }
    }
}
