// TargetLayer.cs - the ARPA targets as the display sees them: the latest "targets" message
// parsed into records, and the layout of boxes, vectors and history dots in PPI bitmap pixels
// for the current geometry (BRIEF.md Section 11, Symbols and vectors). No WPF types, so the
// self-tests can run it anywhere; PpiView does the drawing from the shapes this class returns.
// Boxes are laid out once per message at the position in the message (no extrapolation, as on
// a real unit); the layout is recomputed when the geometry changes, which moves a box with
// orientation, offset and true or relative motion but not in time.
// Also here: the hit test for a click on a box, and the guard-zone sector in pixels.
// Units: positions and ranges NM, courses and bearings deg T, speeds KN, vector time MIN,
// times s, pixels of the PPI bitmap (x right, y down).
// Called by: ArpaController (state), PpiView (drawing), SelfTest.

using System;
using System.Collections.Generic;
using System.Text.Json;

namespace RadarSim
{
    public enum TargetState { Acq, Trend, Track, Lost }

    // One entry of a target's history: where it was then (stabilisation frame) and where own ship was then.
    public class HistoryPoint
    {
        public double TimeS;
        public double TrueXNm;
        public double TrueYNm;
        public double OwnXNm;
        public double OwnYNm;
    }

    // One target of the "targets" message. A number the sim sent as null is null here.
    public class TargetRecord
    {
        public int Id;
        public TargetState State;
        public double XNm;                  // stabilisation frame
        public double YNm;
        public double RangeNm;
        public double BearingDegTrue;
        public double? CourseDegTrue;
        public double? SpeedKn;
        public double? RelCourseDegTrue;
        public double? RelSpeedKn;
        public double? CpaNm;
        public double? TcpaMin;             // negative = opening
        public double? BcrNm;
        public double? BctMin;
        public double? TrialCpaNm;
        public double? TrialTcpaMin;
        public List<HistoryPoint> History = new List<HistoryPoint>();
    }

    public struct PointPx
    {
        public double X;
        public double Y;

        public PointPx(double x, double y)
        {
            X = x;
            Y = y;
        }
    }

    // What PpiView draws for one target.
    public class TargetShape
    {
        public int Id;
        public TargetState State;
        public bool Selected;
        public double BoxXPx;
        public double BoxYPx;
        public string Label = "";           // the ID, beside the box; empty in ACQ
        public bool Crossed;                // LOST
        public bool Flashing;               // LOST and not yet acknowledged
        public bool HasVector;
        public bool VectorDashed;           // TREND; TRACK is solid
        public double VectorEndXPx;
        public double VectorEndYPx;
        public List<PointPx> HistoryPx = new List<PointPx>();
    }

    // A guard zone in pixels: the ring sector from the inner to the outer radius, swept clockwise
    // from StartScreenDeg by SweepDeg (360 = a full ring), about own ship's pixel.
    public class GuardZoneShape
    {
        public double CentreXPx;
        public double CentreYPx;
        public double InnerPx;
        public double OuterPx;
        public double StartScreenDeg;       // deg clockwise from the top of the picture
        public double SweepDeg;
        public PointPx StartInner;
        public PointPx StartOuter;
        public PointPx EndInner;
        public PointPx EndOuter;
    }

    public class TargetLayer
    {
        public double SimTimeS;
        public double RefXNm;               // own-ship reference position in the message
        public double RefYNm;
        public List<TargetRecord> Targets = new List<TargetRecord>();

        // Display options, set by ArpaController before each layout.
        public bool VectorTrue = true;
        public double VectorTimeMin = 6.0;
        public bool TrialOn;                // trial maneuver: relative vectors show the trial
        public double TrialCourseDegTrue;   // own ship's trial course, deg T
        public double TrialSpeedKn;         // own ship's trial speed, KN
        public bool HistoryOn = true;
        public int SelectedId = -1;
        public HashSet<int> UnacknowledgedLostIds = new HashSet<int>();

        // ---- the message ----

        private static double? NumberOrNull(JsonElement owner, string name)
        {
            JsonElement value;
            if (owner.TryGetProperty(name, out value) && value.ValueKind == JsonValueKind.Number)
            {
                return value.GetDouble();
            }
            return null;
        }

        private static double NumberOrZero(JsonElement owner, string name)
        {
            double? value = NumberOrNull(owner, name);
            return value.HasValue ? value.Value : 0.0;
        }

        public static TargetState ParseState(string name)
        {
            if (name == "TREND")
            {
                return TargetState.Trend;
            }
            if (name == "TRACK")
            {
                return TargetState.Track;
            }
            if (name == "LOST")
            {
                return TargetState.Lost;
            }
            return TargetState.Acq;
        }

        public static string StateName(TargetState state)
        {
            if (state == TargetState.Trend)
            {
                return "TREND";
            }
            if (state == TargetState.Track)
            {
                return "TRACK";
            }
            if (state == TargetState.Lost)
            {
                return "LOST";
            }
            return "ACQ";
        }

        // Replaces the targets with those of a "targets" message.
        public void SetMessage(JsonElement message)
        {
            SimTimeS = NumberOrZero(message, "sim_time_s");
            RefXNm = NumberOrZero(message, "ref_x_nm");
            RefYNm = NumberOrZero(message, "ref_y_nm");
            Targets.Clear();
            JsonElement list;
            if (!message.TryGetProperty("targets", out list) || list.ValueKind != JsonValueKind.Array)
            {
                return;
            }
            foreach (JsonElement item in list.EnumerateArray())
            {
                TargetRecord target = new TargetRecord();
                target.Id = (int)Math.Round(NumberOrZero(item, "id"));
                JsonElement state;
                if (item.TryGetProperty("state", out state) && state.ValueKind == JsonValueKind.String)
                {
                    target.State = ParseState(state.GetString());
                }
                target.XNm = NumberOrZero(item, "x_nm");
                target.YNm = NumberOrZero(item, "y_nm");
                target.RangeNm = NumberOrZero(item, "range_nm");
                target.BearingDegTrue = NumberOrZero(item, "bearing_deg_true");
                target.CourseDegTrue = NumberOrNull(item, "course_deg_true");
                target.SpeedKn = NumberOrNull(item, "speed_kn");
                target.RelCourseDegTrue = NumberOrNull(item, "rel_course_deg_true");
                target.RelSpeedKn = NumberOrNull(item, "rel_speed_kn");
                target.CpaNm = NumberOrNull(item, "cpa_nm");
                target.TcpaMin = NumberOrNull(item, "tcpa_min");
                target.BcrNm = NumberOrNull(item, "bcr_nm");
                target.BctMin = NumberOrNull(item, "bct_min");
                target.TrialCpaNm = NumberOrNull(item, "trial_cpa_nm");
                target.TrialTcpaMin = NumberOrNull(item, "trial_tcpa_min");
                JsonElement history;
                if (item.TryGetProperty("history", out history) && history.ValueKind == JsonValueKind.Array)
                {
                    foreach (JsonElement entry in history.EnumerateArray())
                    {
                        if (entry.ValueKind != JsonValueKind.Array || entry.GetArrayLength() < 5)
                        {
                            continue;
                        }
                        HistoryPoint point = new HistoryPoint();
                        point.TimeS = entry[0].GetDouble();
                        point.TrueXNm = entry[1].GetDouble();
                        point.TrueYNm = entry[2].GetDouble();
                        point.OwnXNm = entry[3].GetDouble();
                        point.OwnYNm = entry[4].GetDouble();
                        target.History.Add(point);
                    }
                }
                Targets.Add(target);
            }
        }

        public TargetRecord Find(int id)
        {
            foreach (TargetRecord target in Targets)
            {
                if (target.Id == id)
                {
                    return target;
                }
            }
            return null;
        }

        // ---- layout ----

        // A displacement in NM (east, north) as pixels on the screen: turned to suit the orientation.
        public static void OffsetPx(PpiGeometry geometry, double eastNm, double northNm, out double dxPx, out double dyPx)
        {
            double lengthNm = Math.Sqrt(eastNm * eastNm + northNm * northNm);
            if (lengthNm == 0.0)
            {
                dxPx = 0.0;
                dyPx = 0.0;
                return;
            }
            double bearingDegTrue = Math.Atan2(eastNm, northNm) * 180.0 / Math.PI;      // rad -> deg
            double screenAngleRad = geometry.ScreenAngleDeg(bearingDegTrue) * Math.PI / 180.0;   // deg -> rad
            double lengthPx = lengthNm / geometry.RangeScaleNm * geometry.RadiusPx;     // NM -> px
            dxPx = lengthPx * Math.Sin(screenAngleRad);
            dyPx = -lengthPx * Math.Cos(screenAngleRad);
        }

        // The target's motion relative to own ship if own ship steered the trial course at the trial speed:
        // the target's true velocity minus own ship's trial velocity. Both are in the stabilisation frame.
        public static void TrialRelative(double targetCourseDegTrue, double targetSpeedKn,
                                         double trialCourseDegTrue, double trialSpeedKn,
                                         out double relCourseDegTrue, out double relSpeedKn)
        {
            double targetRad = targetCourseDegTrue * Math.PI / 180.0;                   // deg -> rad
            double ownRad = trialCourseDegTrue * Math.PI / 180.0;
            double eastKn = targetSpeedKn * Math.Sin(targetRad) - trialSpeedKn * Math.Sin(ownRad);
            double northKn = targetSpeedKn * Math.Cos(targetRad) - trialSpeedKn * Math.Cos(ownRad);
            relSpeedKn = Math.Sqrt(eastKn * eastKn + northKn * northKn);
            double course = Math.Atan2(eastKn, northKn) * 180.0 / Math.PI;              // rad -> deg
            relCourseDegTrue = relSpeedKn < 1e-9 ? 0.0 : (course % 360.0 + 360.0) % 360.0;
        }

        // A vector of this course and speed, over this time, as a displacement in pixels.
        private void VectorOffsetPx(PpiGeometry geometry, double courseDegTrue, double speedKn, out double dxPx, out double dyPx)
        {
            double lengthNm = speedKn * VectorTimeMin / 60.0;                           // KN x MIN -> NM
            double courseRad = courseDegTrue * Math.PI / 180.0;                         // deg -> rad
            OffsetPx(geometry, lengthNm * Math.Sin(courseRad), lengthNm * Math.Cos(courseRad), out dxPx, out dyPx);
        }

        // The shapes for the current geometry. A box sits at own ship's pixel for the message's
        // reference position plus the target's displacement from that position: in relative motion
        // own ship is at the offset position, in true motion the box is fixed in the picture.
        public List<TargetShape> Layout(PpiGeometry geometry)
        {
            List<TargetShape> shapes = new List<TargetShape>();
            double ownXPx, ownYPx;
            geometry.OwnPixelFor(RefXNm, RefYNm, out ownXPx, out ownYPx);

            foreach (TargetRecord target in Targets)
            {
                TargetShape shape = new TargetShape();
                shape.Id = target.Id;
                shape.State = target.State;
                shape.Selected = target.Id == SelectedId;
                double dx, dy;
                OffsetPx(geometry, target.XNm - RefXNm, target.YNm - RefYNm, out dx, out dy);
                shape.BoxXPx = ownXPx + dx;
                shape.BoxYPx = ownYPx + dy;
                shape.Label = target.State == TargetState.Acq ? "" : target.Id.ToString();
                shape.Crossed = target.State == TargetState.Lost;
                shape.Flashing = shape.Crossed && UnacknowledgedLostIds.Contains(target.Id);

                // No vector in ACQ (no data yet) or LOST (the last one is no longer true).
                if (target.State == TargetState.Trend || target.State == TargetState.Track)
                {
                    double? course = VectorTrue ? target.CourseDegTrue : target.RelCourseDegTrue;
                    double? speed = VectorTrue ? target.SpeedKn : target.RelSpeedKn;
                    if (!VectorTrue && TrialOn && target.CourseDegTrue.HasValue && target.SpeedKn.HasValue)
                    {
                        // Under trial the relative vector is the one own ship's trial course and speed would give.
                        double relCourse, relSpeed;
                        TrialRelative(target.CourseDegTrue.Value, target.SpeedKn.Value, TrialCourseDegTrue, TrialSpeedKn, out relCourse, out relSpeed);
                        course = relCourse;
                        speed = relSpeed;
                    }
                    if (course.HasValue && speed.HasValue)
                    {
                        double vx, vy;
                        VectorOffsetPx(geometry, course.Value, speed.Value, out vx, out vy);
                        shape.HasVector = true;
                        shape.VectorDashed = target.State == TargetState.Trend;
                        shape.VectorEndXPx = shape.BoxXPx + vx;
                        shape.VectorEndYPx = shape.BoxYPx + vy;
                    }
                }

                // History dots: true past positions, or past positions relative to own ship at the time;
                // both are drawn from own ship's pixel now.
                if (HistoryOn)
                {
                    foreach (HistoryPoint point in target.History)
                    {
                        double eastNm = VectorTrue ? point.TrueXNm - RefXNm : point.TrueXNm - point.OwnXNm;
                        double northNm = VectorTrue ? point.TrueYNm - RefYNm : point.TrueYNm - point.OwnYNm;
                        double hx, hy;
                        OffsetPx(geometry, eastNm, northNm, out hx, out hy);
                        shape.HistoryPx.Add(new PointPx(ownXPx + hx, ownYPx + hy));
                    }
                }
                shapes.Add(shape);
            }
            return shapes;
        }

        // The ID of the box nearest to the point, if it is within the radius; otherwise -1.
        public static int HitTest(List<TargetShape> shapes, double xPx, double yPx, double radiusPx)
        {
            int bestId = -1;
            double bestDistance = radiusPx;
            foreach (TargetShape shape in shapes)
            {
                double dx = shape.BoxXPx - xPx;
                double dy = shape.BoxYPx - yPx;
                double distance = Math.Sqrt(dx * dx + dy * dy);
                if (distance <= bestDistance)
                {
                    bestDistance = distance;
                    bestId = shape.Id;
                }
            }
            return bestId;
        }

        // ---- guard zone ----

        // A zone's bearings are relative to own ship's heading or true, as arpa.guard_zone_reference says.
        // Start and end are swept clockwise; equal bearings give a full ring.
        public static GuardZoneShape ZoneShape(PpiGeometry geometry, double innerNm, double outerNm,
                                               double startDeg, double endDeg, bool referenceRelative)
        {
            GuardZoneShape zone = new GuardZoneShape();
            zone.CentreXPx = geometry.OwnXPx;
            zone.CentreYPx = geometry.OwnYPx;
            zone.InnerPx = innerNm / geometry.RangeScaleNm * geometry.RadiusPx;         // NM -> px
            zone.OuterPx = outerNm / geometry.RangeScaleNm * geometry.RadiusPx;
            double startTrue = referenceRelative ? startDeg + geometry.HeadingDegTrue : startDeg;
            double endTrue = referenceRelative ? endDeg + geometry.HeadingDegTrue : endDeg;
            zone.StartScreenDeg = geometry.ScreenAngleDeg(startTrue);
            double sweep = PpiGeometry.Normalise360(endDeg - startDeg);
            zone.SweepDeg = sweep == 0.0 ? 360.0 : sweep;
            double endScreenDeg = geometry.ScreenAngleDeg(endTrue);
            zone.StartInner = OnRing(zone, zone.InnerPx, zone.StartScreenDeg);
            zone.StartOuter = OnRing(zone, zone.OuterPx, zone.StartScreenDeg);
            zone.EndInner = OnRing(zone, zone.InnerPx, endScreenDeg);
            zone.EndOuter = OnRing(zone, zone.OuterPx, endScreenDeg);
            return zone;
        }

        private static PointPx OnRing(GuardZoneShape zone, double radiusPx, double screenAngleDeg)
        {
            double angleRad = screenAngleDeg * Math.PI / 180.0;                         // deg -> rad
            return new PointPx(zone.CentreXPx + radiusPx * Math.Sin(angleRad), zone.CentreYPx - radiusPx * Math.Cos(angleRad));
        }
    }
}
