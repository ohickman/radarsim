// ContactListLogic.cs - the lines of the contact list next to the PPI: one per target (ID, range, bearing,
// CPA, TCPA, state), in ID order, the selected one flagged; a dangerous one (positive TCPA under the limit
// with a CPA under the limit) flagged too. No WPF types.
// Units: RNG and CPA NM, BRG deg T, TCPA MIN (negative = opening). A value the sim sent as null shows "--".
// Called by: ContactList.cs (the view), SelfTest.

using System.Collections.Generic;
using System.Globalization;

namespace RadarSim
{
    public class ContactLine
    {
        public int Id;
        public string Text;
        public bool Selected;
        public bool Dangerous;              // a CPA inside the limit with a positive TCPA
    }

    public static class ContactListLogic
    {
        // The header is laid out with the same column widths as a line, so the columns line up.
        public static readonly string Header = "ID".PadRight(5) + "RNG NM".PadLeft(7) + "  " + "BRG T".PadLeft(7) + "  "
            + "CPA NM".PadLeft(7) + "  " + "TCPA MIN".PadLeft(8) + "  " + "STATE";

        private static string Num(double? value, string pattern)
        {
            return value.HasValue ? value.Value.ToString(pattern, CultureInfo.InvariantCulture) : "--";
        }

        private static string StateName(TargetState state)
        {
            switch (state)
            {
                case TargetState.Acq: return "ACQ";
                case TargetState.Trend: return "TREND";
                case TargetState.Track: return "TRACK";
                default: return "LOST";
            }
        }

        // One line per target, sorted by ID. cpaLimitNm and tcpaLimitMin mark the dangerous ones.
        public static List<ContactLine> Lines(IList<TargetRecord> targets, int selectedId, double cpaLimitNm, double tcpaLimitMin)
        {
            List<TargetRecord> sorted = new List<TargetRecord>(targets);
            sorted.Sort((a, b) => a.Id.CompareTo(b.Id));
            List<ContactLine> lines = new List<ContactLine>();
            foreach (TargetRecord t in sorted)
            {
                ContactLine line = new ContactLine();
                line.Id = t.Id;
                line.Selected = t.Id == selectedId;
                line.Dangerous = t.CpaNm.HasValue && t.TcpaMin.HasValue && t.TcpaMin.Value > 0.0
                                 && t.CpaNm.Value < cpaLimitNm && t.TcpaMin.Value < tcpaLimitMin;
                line.Text = t.Id.ToString(CultureInfo.InvariantCulture).PadRight(4) + " "
                    + t.RangeNm.ToString("0.00", CultureInfo.InvariantCulture).PadLeft(7) + "  "
                    + t.BearingDegTrue.ToString("000.0", CultureInfo.InvariantCulture).PadLeft(7) + "  "
                    + Num(t.CpaNm, "0.00").PadLeft(7) + "  "
                    + Num(t.TcpaMin, "0.0").PadLeft(8) + "  "
                    + StateName(t.State);
                lines.Add(line);
            }
            return lines;
        }
    }
}
