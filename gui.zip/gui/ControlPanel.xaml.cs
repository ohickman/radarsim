// ControlPanel.xaml.cs - the receiver and display controls, built from hello.controls so the
// panel holds no limits of its own (BRIEF.md Section 15, M6): GAIN, STC, FTC, RANGE,
// ORIENTATION, MOTION (with RESET), STABILISATION, TRAILS (mode and time), the three BRILLIANCE controls, AFTERGLOW, OFFSET,
// and EBL 1, EBL 2, VRM 1, VRM 2 and PI 1, PI 2 (parallel index lines) with their readouts. It only shows the
// DisplayController's state and calls its methods; every number shows its unit. Knobs sit side by side in
// ControlRows (GAIN, STC, FTC; the four display knobs; the EBLs; the VRMs; the PI directions and distances);
// in slider style, and for a slider in HYBRID style, each control takes a line.
// Units: gain, STC, FTC, brilliance %; range NM; afterglow s; trail time MIN; offset % of the PPI radius;
// EBL deg T or deg R; VRM NM.
// Called by: MainWindow (Build after each hello), SelfTest.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace RadarSim
{
    public partial class ControlPanel : UserControl
    {
        private const string VideoBrilliancePath = "display.video_brilliance_percent";
        private const string RingsBrilliancePath = "display.rings_brilliance_percent";
        private const string SymbolsBrilliancePath = "display.symbols_brilliance_percent";
        private const string AfterglowPath = "display.afterglow_sim_s";

        private DisplayController controller;
        private readonly List<ValueControl> valueControls = new List<ValueControl>();
        private ComboBox rangeBox;
        private ComboBox orientationBox;
        private ComboBox motionBox;
        private ComboBox stabilisationBox;
        private ComboBox trailsBox;
        private ComboBox trailTimeBox;
        private Button offsetPlaceButton;
        private Button eblModeButton;
        private readonly Button[] piButtons = new Button[EblVrmSet.PiCount];
        private readonly ValueControl[] piBearingControls = new ValueControl[EblVrmSet.PiCount];
        private readonly ValueControl[] piDistanceControls = new ValueControl[EblVrmSet.PiCount];
        private readonly Button[] eblButtons = new Button[EblVrmSet.Count];
        private readonly ValueControl[] eblControls = new ValueControl[EblVrmSet.Count];
        private readonly Button[] vrmButtons = new Button[EblVrmSet.Count];
        private readonly ValueControl[] vrmControls = new ValueControl[EblVrmSet.Count];
        private bool refreshing;                    // true while the widgets are set from the controller

        public ControlPanel()
        {
            InitializeComponent();
        }

        public List<ValueControl> ValueControls
        {
            get { return valueControls; }
        }

        // Builds every control from the controller's limits. Called after each "hello".
        public void Build(DisplayController newController)
        {
            if (controller != null)
            {
                controller.Changed -= Refresh;
            }
            controller = newController;
            controller.Changed += Refresh;

            Root.Children.Clear();
            valueControls.Clear();

            AddHeader("RECEIVER");
            ControlRow receiverRow = NewControlRow(3);
            AddValue("GAIN", DisplayController.GainPath, receiverRow);
            AddValue("STC", DisplayController.StcPath, receiverRow);
            AddValue("FTC", DisplayController.FtcPath, receiverRow);

            AddHeader("DISPLAY");
            BuildRangeRow();
            orientationBox = BuildChoiceRow("ORIENTATION", DisplayController.OrientationPath, OrientationChanged, true);
            BuildMotionRows();
            AddSubHeader("BRILLIANCE");
            ControlRow brillianceRow = NewControlRow(4);
            AddValue("VIDEO", VideoBrilliancePath, brillianceRow);
            AddValue("RINGS", RingsBrilliancePath, brillianceRow);
            AddValue("SYMBOLS", SymbolsBrilliancePath, brillianceRow);
            AddValue("AFTERGLOW", AfterglowPath, brillianceRow);
            BuildOffsetRow();

            AddHeader("EBL / VRM");
            BuildEblVrmRows();

            Refresh();
        }

        // ---- building blocks ----

        private void AddHeader(string text)
        {
            TextBlock header = new TextBlock();
            header.Text = text;
            header.FontWeight = FontWeights.Bold;
            header.Margin = new Thickness(0, 8, 0, 4);
            Root.Children.Add(header);
        }

        private void AddSubHeader(string text)
        {
            TextBlock header = new TextBlock();
            header.Text = text;
            header.Margin = new Thickness(0, 4, 0, 2);
            Root.Children.Add(header);
        }

        // A row for knobs: columns knobs to a line, a slider on a line of its own.
        private ControlRow NewControlRow(int columns)
        {
            ControlRow row = new ControlRow();
            row.Columns = columns;
            row.Margin = new Thickness(0, 0, 0, 2);
            Root.Children.Add(row);
            return row;
        }

        // Two buttons side by side, one per line (EBL 1 and EBL 2, VRM 1 and VRM 2, PI 1 and PI 2).
        private void AddButtonPair(Button first, Button second)
        {
            Grid pair = new Grid();
            pair.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            pair.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            pair.Margin = new Thickness(0, 4, 0, 2);
            first.Margin = new Thickness(0, 0, 2, 0);
            second.Margin = new Thickness(2, 0, 0, 0);
            Grid.SetColumn(first, 0);
            Grid.SetColumn(second, 1);
            pair.Children.Add(first);
            pair.Children.Add(second);
            Root.Children.Add(pair);
        }

        // The receiver and display levels are knobs in HYBRID style.
        private void AddValue(string label, string path, ControlRow row)
        {
            ControlLimits limits;
            if (!controller.Limits.TryGetValue(path, out limits))
            {
                return;
            }
            double value = 0.0;
            controller.Numbers.TryGetValue(path, out value);
            ValueControl control = new ValueControl();
            control.Configure(path, label, limits.Unit, limits.Min, limits.Max, limits.Step, limits.NumberChoices, value);
            control.HybridKnob = true;
            control.SetStyle(controller.Style);
            control.ValueSent += ValueSentFromControl;
            row.AddControl(control);
            valueControls.Add(control);
        }

        private void ValueSentFromControl(ValueControl control, double value)
        {
            controller.SetRuntimeNumber(control.Path, value);
        }

        private DockPanel NewRow(string label)
        {
            DockPanel row = new DockPanel();
            row.Margin = new Thickness(0, 0, 0, 4);
            TextBlock text = new TextBlock();
            text.Text = label;
            text.Width = 100;
            text.VerticalAlignment = VerticalAlignment.Center;
            DockPanel.SetDock(text, Dock.Left);
            row.Children.Add(text);
            Root.Children.Add(row);
            return row;
        }

        private static string Pretty(string word)
        {
            return word.Replace("_", " ").ToUpperInvariant().Replace("COLOR", "COLOUR");
        }

        private static string Plain(double value)
        {
            return value.ToString("0.##", CultureInfo.InvariantCulture);
        }

        private static string Fixed(double value, string pattern)
        {
            return value.ToString(pattern, CultureInfo.InvariantCulture);
        }

        private static void SelectByTag(ComboBox box, object tag)
        {
            foreach (object item in box.Items)
            {
                ComboBoxItem entry = item as ComboBoxItem;
                if (entry == null)
                {
                    continue;
                }
                bool same = entry.Tag is double && tag is double
                    ? Math.Abs((double)entry.Tag - (double)tag) < 1e-9
                    : object.Equals(entry.Tag, tag);
                if (same)
                {
                    box.SelectedItem = entry;
                    return;
                }
            }
        }

        // ---- range ----

        private void BuildRangeRow()
        {
            DockPanel row = NewRow("RANGE");
            Button down = new Button();
            down.Content = "DOWN";
            down.Width = 50;
            down.Click += RangeDown_Click;
            DockPanel.SetDock(down, Dock.Left);
            row.Children.Add(down);
            Button up = new Button();
            up.Content = "UP";
            up.Width = 50;
            up.Margin = new Thickness(4, 0, 4, 0);
            up.Click += RangeUp_Click;
            DockPanel.SetDock(up, Dock.Left);
            row.Children.Add(up);

            rangeBox = new ComboBox();
            foreach (double rangeNm in controller.RangeScalesNm)
            {
                ComboBoxItem item = new ComboBoxItem();
                item.Content = Plain(rangeNm) + " NM";
                item.Tag = rangeNm;
                rangeBox.Items.Add(item);
            }
            rangeBox.SelectionChanged += RangeBox_SelectionChanged;
            row.Children.Add(rangeBox);
        }

        private void RangeDown_Click(object sender, RoutedEventArgs e)
        {
            controller.StepRange(-1);
        }

        private void RangeUp_Click(object sender, RoutedEventArgs e)
        {
            controller.StepRange(1);
        }

        private void RangeBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem item = rangeBox.SelectedItem as ComboBoxItem;
            if (refreshing || item == null)
            {
                return;
            }
            controller.SetRangeNm((double)item.Tag);
        }

        // ---- orientation, colour mode, control style ----

        private ComboBox BuildChoiceRow(string label, string path, SelectionChangedEventHandler handler, bool withResetCourse)
        {
            DockPanel row = NewRow(label);
            if (withResetCourse)
            {
                Button reset = new Button();
                reset.Content = "RESET COURSE";
                reset.Margin = new Thickness(4, 0, 0, 0);
                reset.Click += ResetCourse_Click;
                DockPanel.SetDock(reset, Dock.Right);
                row.Children.Add(reset);
            }
            ComboBox box = new ComboBox();
            ControlLimits limits;
            if (controller.Limits.TryGetValue(path, out limits) && limits.WordChoices != null)
            {
                foreach (string word in limits.WordChoices)
                {
                    ComboBoxItem item = new ComboBoxItem();
                    item.Content = Pretty(word);
                    item.Tag = word;
                    box.Items.Add(item);
                }
            }
            box.SelectionChanged += handler;
            row.Children.Add(box);
            return box;
        }

        private static string TagOf(ComboBox box)
        {
            ComboBoxItem item = box.SelectedItem as ComboBoxItem;
            return item == null ? null : (string)item.Tag;
        }

        private void OrientationChanged(object sender, SelectionChangedEventArgs e)
        {
            string name = TagOf(orientationBox);
            if (!refreshing && name != null)
            {
                controller.SetOrientation(name);
            }
        }

        private void ResetCourse_Click(object sender, RoutedEventArgs e)
        {
            controller.ResetCourse();
        }

        // ---- motion, stabilisation, trails ----

        private void BuildMotionRows()
        {
            DockPanel motionRow = NewRow("MOTION");
            Button reset = new Button();
            reset.Content = "RESET";
            reset.Margin = new Thickness(4, 0, 0, 0);
            reset.Click += ResetMotion_Click;
            DockPanel.SetDock(reset, Dock.Right);
            motionRow.Children.Add(reset);
            motionBox = NewWordBox(DisplayController.MotionPath, MotionChanged);
            motionRow.Children.Add(motionBox);

            DockPanel stabilisationRow = NewRow("STABILISATION");
            stabilisationBox = NewWordBox(DisplayController.StabilisationPath, StabilisationChanged);
            stabilisationRow.Children.Add(stabilisationBox);

            DockPanel trailsRow = NewRow("TRAILS");
            trailTimeBox = new ComboBox();
            trailTimeBox.Width = 90;
            trailTimeBox.Margin = new Thickness(4, 0, 0, 0);
            ControlLimits timeLimits;
            if (controller.Limits.TryGetValue(DisplayController.TrailTimePath, out timeLimits) && timeLimits.NumberChoices != null)
            {
                foreach (double minutes in timeLimits.NumberChoices)
                {
                    ComboBoxItem item = new ComboBoxItem();
                    item.Content = Plain(minutes) + " MIN";
                    item.Tag = minutes;
                    trailTimeBox.Items.Add(item);
                }
            }
            trailTimeBox.SelectionChanged += TrailTimeChanged;
            DockPanel.SetDock(trailTimeBox, Dock.Right);
            trailsRow.Children.Add(trailTimeBox);
            trailsBox = NewWordBox(DisplayController.TrailsModePath, TrailsModeChanged);
            trailsRow.Children.Add(trailsBox);
        }

        // A list of the words that hello gives for a control.
        private ComboBox NewWordBox(string path, SelectionChangedEventHandler handler)
        {
            ComboBox box = new ComboBox();
            ControlLimits limits;
            if (controller.Limits.TryGetValue(path, out limits) && limits.WordChoices != null)
            {
                foreach (string word in limits.WordChoices)
                {
                    ComboBoxItem item = new ComboBoxItem();
                    item.Content = Pretty(word);
                    item.Tag = word;
                    box.Items.Add(item);
                }
            }
            box.SelectionChanged += handler;
            return box;
        }

        private void MotionChanged(object sender, SelectionChangedEventArgs e)
        {
            string name = TagOf(motionBox);
            if (!refreshing && name != null)
            {
                controller.SetMotion(name == "true");
            }
        }

        private void StabilisationChanged(object sender, SelectionChangedEventArgs e)
        {
            string name = TagOf(stabilisationBox);
            if (!refreshing && name != null)
            {
                controller.SetStabilisation(name);
            }
        }

        private void TrailsModeChanged(object sender, SelectionChangedEventArgs e)
        {
            string name = TagOf(trailsBox);
            if (!refreshing && name != null)
            {
                controller.SetTrailsMode(name);
            }
        }

        private void TrailTimeChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem item = trailTimeBox.SelectedItem as ComboBoxItem;
            if (!refreshing && item != null)
            {
                controller.SetTrailTimeMin((double)item.Tag);
            }
        }

        private void ResetMotion_Click(object sender, RoutedEventArgs e)
        {
            controller.ResetTrueMotion();
        }

        // ---- offset ----

        private void BuildOffsetRow()
        {
            StackPanel row = new StackPanel();
            row.Orientation = Orientation.Horizontal;
            row.Margin = new Thickness(0, 0, 0, 4);
            TextBlock label = new TextBlock();
            label.Text = "OFFSET";
            label.Width = 100;
            label.VerticalAlignment = VerticalAlignment.Center;
            row.Children.Add(label);

            offsetPlaceButton = new Button();
            offsetPlaceButton.Content = "OFFSET";
            offsetPlaceButton.Width = 90;
            offsetPlaceButton.ToolTip = "Then click where own ship should be (or Ctrl+O at the cursor)";
            offsetPlaceButton.Click += OffsetPlace_Click;
            row.Children.Add(offsetPlaceButton);

            Button centre = new Button();
            centre.Content = "CENTRE";
            centre.Width = 90;
            centre.Margin = new Thickness(6, 0, 0, 0);
            centre.Click += OffsetCentre_Click;
            row.Children.Add(centre);
            Root.Children.Add(row);
        }

        private static TextBlock SmallText(string text)
        {
            TextBlock block = new TextBlock();
            block.Text = text;
            block.VerticalAlignment = VerticalAlignment.Center;
            return block;
        }

        private void OffsetCentre_Click(object sender, RoutedEventArgs e)
        {
            controller.CentreOffset();
        }

        private void OffsetPlace_Click(object sender, RoutedEventArgs e)
        {
            controller.ToggleOffsetPlace();
        }

        // ---- EBL and VRM ----

        private void BuildEblVrmRows()
        {
            eblModeButton = new Button();
            eblModeButton.Margin = new Thickness(0, 0, 0, 4);
            eblModeButton.Click += EblMode_Click;
            Root.Children.Add(eblModeButton);

            for (int i = 0; i < EblVrmSet.Count; i++)
            {
                eblButtons[i] = new Button();
                eblButtons[i].Tag = i;
                eblButtons[i].Click += EblButton_Click;
            }
            AddButtonPair(eblButtons[0], eblButtons[1]);
            ControlRow eblRow = NewControlRow(2);
            for (int i = 0; i < EblVrmSet.Count; i++)
            {
                eblControls[i] = NewEblVrmControl("EBL " + (i + 1), "ebl" + i, "deg T", 360.0, 0.5, i, eblRow);
                eblControls[i].ValueSent += EblValueSent;
            }

            double scale = controller.RangeScalesNm.Length > 0 ? controller.RangeScalesNm[controller.RangeIndex] : 6.0;
            for (int i = 0; i < EblVrmSet.Count; i++)
            {
                vrmButtons[i] = new Button();
                vrmButtons[i].Tag = i;
                vrmButtons[i].Click += VrmButton_Click;
            }
            AddButtonPair(vrmButtons[0], vrmButtons[1]);
            ControlRow vrmRow = NewControlRow(2);
            for (int i = 0; i < EblVrmSet.Count; i++)
            {
                vrmControls[i] = NewEblVrmControl("VRM " + (i + 1), "vrm" + i, "NM", scale, 0.01, i, vrmRow);
                vrmControls[i].ValueSent += VrmValueSent;
            }

            // Two parallel index lines, often used as a pair. A line is on when its button is on or a value is typed.
            for (int i = 0; i < EblVrmSet.PiCount; i++)
            {
                piButtons[i] = new Button();
                piButtons[i].Tag = i;
                piButtons[i].Click += PiButton_Click;
            }
            AddButtonPair(piButtons[0], piButtons[1]);
            AddSubHeader("PI DIST: + RIGHT, - LEFT OF THE LINE'S DIRECTION");
            ControlRow piDirectionRow = NewControlRow(2);
            for (int i = 0; i < EblVrmSet.PiCount; i++)
            {
                piBearingControls[i] = NewEblVrmControl("PI " + (i + 1) + " DIR", "pibearing" + i, "deg T", 360.0, 0.5, i, piDirectionRow);
                piBearingControls[i].ValueSent += PiBearingSent;
            }
            ControlRow piDistanceRow = NewControlRow(2);
            for (int i = 0; i < EblVrmSet.PiCount; i++)
            {
                piDistanceControls[i] = NewEblVrmControl("PI " + (i + 1) + " DIST", "pidistance" + i, "NM", scale, 0.01, i, piDistanceRow);
                piDistanceControls[i].SetRange(-scale, scale);
                piDistanceControls[i].ValueSent += PiDistanceSent;
            }
        }

        private void PiBearingSent(ValueControl control, double value)
        {
            controller.SetPiBearing((int)control.Tag, value);
        }

        private void PiDistanceSent(ValueControl control, double value)
        {
            controller.SetPiNm((int)control.Tag, value);
        }

        private void PiButton_Click(object sender, RoutedEventArgs e)
        {
            controller.TogglePi((int)((Button)sender).Tag);
        }

        // A knob or slider with its own typed value, like the receiver controls. The path is a
        // name for the control only; it never goes to the sim.
        private ValueControl NewEblVrmControl(string label, string path, string unit, double maximum, double step, int index, ControlRow row)
        {
            ValueControl control = new ValueControl();
            control.Configure(path, label, unit, 0.0, maximum, step, null, 0.0);
            control.SetStyle(controller.Style);
            control.Tag = index;
            row.AddControl(control);
            return control;
        }

        private void EblValueSent(ValueControl control, double value)
        {
            controller.SetEblReading((int)control.Tag, value);
        }

        private void VrmValueSent(ValueControl control, double value)
        {
            controller.SetVrmNm((int)control.Tag, value);
        }

        private void EblMode_Click(object sender, RoutedEventArgs e)
        {
            controller.ToggleEblRelative();
        }

        private void EblButton_Click(object sender, RoutedEventArgs e)
        {
            controller.ToggleEbl((int)((Button)sender).Tag);
        }

        private void VrmButton_Click(object sender, RoutedEventArgs e)
        {
            controller.ToggleVrm((int)((Button)sender).Tag);
        }

        // ---- showing the controller's state ----

        public void Refresh()
        {
            if (controller == null || refreshing)
            {
                return;
            }
            refreshing = true;

            ControlStyle style = controller.Style;
            foreach (ValueControl control in valueControls)
            {
                double value;
                if (controller.Numbers.TryGetValue(control.Path, out value))
                {
                    control.ConfirmFromSim(value);
                }
                control.SetStyle(style);
            }

            if (rangeBox != null && controller.RangeScalesNm.Length > 0)
            {
                SelectByTag(rangeBox, controller.RangeScalesNm[controller.RangeIndex]);
            }
            SelectWord(orientationBox, DisplayController.OrientationPath);
            SelectWord(stabilisationBox, DisplayController.StabilisationPath);
            if (motionBox != null)
            {
                SelectByTag(motionBox, controller.MotionTrue ? "true" : "relative");
            }
            if (trailsBox != null)
            {
                SelectByTag(trailsBox, controller.TrailsModeName);
            }
            if (trailTimeBox != null)
            {
                SelectByTag(trailTimeBox, controller.TrailTimeMin);
            }

            offsetPlaceButton.FontWeight = controller.OffsetPlaceArmed ? FontWeights.Bold : FontWeights.Normal;
            offsetPlaceButton.Content = controller.OffsetPlaceArmed ? "CLICK PPI" : "OFFSET";

            EblVrmSet set = controller.EblVrm;
            eblModeButton.Content = set.EblRelative ? "EBL READS RELATIVE (deg R)  - click for TRUE" : "EBL READS TRUE (deg T)  - click for RELATIVE";
            for (int i = 0; i < EblVrmSet.Count; i++)
            {
                eblButtons[i].Content = "EBL " + (i + 1) + (set.EblOn[i] ? " ON" : " OFF");
                eblButtons[i].FontWeight = set.EblOn[i] && set.SelectedEbl == i ? FontWeights.Bold : FontWeights.Normal;
                eblControls[i].ShowUnit(set.EblUnit);
                eblControls[i].ConfirmFromSim(set.EblBearingDeg[i]);
                eblControls[i].SetStyle(style);
                vrmButtons[i].Content = "VRM " + (i + 1) + (set.VrmOn[i] ? " ON" : " OFF");
                vrmButtons[i].FontWeight = set.VrmOn[i] && set.SelectedVrm == i ? FontWeights.Bold : FontWeights.Normal;
                if (controller.RangeScalesNm.Length > 0)
                {
                    vrmControls[i].SetMaximum(controller.RangeScalesNm[controller.RangeIndex]);
                }
                vrmControls[i].ConfirmFromSim(set.VrmNm[i] < 0.0 ? 0.0 : set.VrmNm[i]);
                vrmControls[i].SetStyle(style);
            }

            for (int i = 0; i < EblVrmSet.PiCount; i++)
            {
                piButtons[i].Content = "PI " + (i + 1) + (set.PiOn[i] ? " ON" : " OFF");
                piButtons[i].FontWeight = set.PiOn[i] ? FontWeights.Bold : FontWeights.Normal;
                piBearingControls[i].ShowUnit(set.EblUnit);
                piBearingControls[i].ConfirmFromSim(set.PiBearingDeg[i]);
                if (controller.RangeScalesNm.Length > 0)
                {
                    double piScale = controller.RangeScalesNm[controller.RangeIndex];
                    piDistanceControls[i].SetRange(-piScale, piScale);
                }
                piDistanceControls[i].ConfirmFromSim(set.PiNm[i]);
                piBearingControls[i].SetStyle(style);
                piDistanceControls[i].SetStyle(style);
            }

            refreshing = false;
        }

        private void SelectWord(ComboBox box, string path)
        {
            string word;
            if (box != null && controller.Words.TryGetValue(path, out word))
            {
                SelectByTag(box, word);
            }
        }
    }
}
