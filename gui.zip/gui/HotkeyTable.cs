// HotkeyTable.cs - the hotkey table of BRIEF.md Section 11 as data: for each row the
// keys as shown to the student, the action as shown, and the key bindings with the
// action each one runs. DisplayController dispatches from it and M10's Help window is
// built from it, so the two cannot differ.
// A binding whose Action is null does nothing yet. Every row has a function from M10 on.
// Amount is the step or index that the action uses. Angles use ° for the degree sign.
// Called by: DisplayController, SelfTest, HelpText.

using System.Windows.Input;

namespace RadarSim
{
    public class HotkeyBinding
    {
        public Key Key;
        public ModifierKeys Modifiers;
        public string Action;               // null = no function yet
        public double Amount;

        public HotkeyBinding(Key key, ModifierKeys modifiers, string action, double amount)
        {
            Key = key;
            Modifiers = modifiers;
            Action = action;
            Amount = amount;
        }
    }

    public class HotkeyRow
    {
        public string KeysText;
        public string ActionText;
        public HotkeyBinding[] Bindings;

        public HotkeyRow(string keysText, string actionText, params HotkeyBinding[] bindings)
        {
            KeysText = keysText;
            ActionText = actionText;
            Bindings = bindings;
        }
    }

    public static class HotkeyTable
    {
        private const ModifierKeys None = ModifierKeys.None;
        private const ModifierKeys Shift = ModifierKeys.Shift;
        private const ModifierKeys Ctrl = ModifierKeys.Control;
        private const ModifierKeys CtrlShift = ModifierKeys.Control | ModifierKeys.Shift;

        // Receiver steps for G, S and F, in percent.
        public const double ReceiverStepPercent = 5.0;

        public static readonly HotkeyRow[] Rows = new HotkeyRow[]
        {
            new HotkeyRow("PageUp, PageDown", "range scale up, down",
                new HotkeyBinding(Key.PageUp, None, "range_step", 1.0),
                new HotkeyBinding(Key.PageDown, None, "range_step", -1.0)),
            new HotkeyRow("G, Shift+G", "gain up, down (5 % steps)",
                new HotkeyBinding(Key.G, None, "gain_step", ReceiverStepPercent),
                new HotkeyBinding(Key.G, Shift, "gain_step", -ReceiverStepPercent)),
            new HotkeyRow("S, Shift+S", "STC up, down",
                new HotkeyBinding(Key.S, None, "stc_step", ReceiverStepPercent),
                new HotkeyBinding(Key.S, Shift, "stc_step", -ReceiverStepPercent)),
            new HotkeyRow("F, Shift+F", "FTC up, down",
                new HotkeyBinding(Key.F, None, "ftc_step", ReceiverStepPercent),
                new HotkeyBinding(Key.F, Shift, "ftc_step", -ReceiverStepPercent)),
            new HotkeyRow("O", "cycle orientation",
                new HotkeyBinding(Key.O, None, "orientation_cycle", 0.0)),
            new HotkeyRow("M", "relative or true motion",
                new HotkeyBinding(Key.M, None, "motion_toggle", 0.0)),
            new HotkeyRow("C", "cycle colour mode",
                new HotkeyBinding(Key.C, None, "colour_cycle", 0.0)),
            new HotkeyRow("V", "true or relative vectors",
                new HotkeyBinding(Key.V, None, "vector_mode_toggle", 0.0)),
            new HotkeyRow("[ and ]", "vector time shorter, longer",
                new HotkeyBinding(Key.OemOpenBrackets, None, "vector_time_step", -1.0),
                new HotkeyBinding(Key.OemCloseBrackets, None, "vector_time_step", 1.0)),
            new HotkeyRow("T", "cycle trails: off, true, relative",
                new HotkeyBinding(Key.T, None, "trails_cycle", 0.0)),
            new HotkeyRow("1, 2, 3, 4", "toggle and select EBL 1, EBL 2, VRM 1, VRM 2",
                new HotkeyBinding(Key.D1, None, "ebl_toggle", 0.0),
                new HotkeyBinding(Key.D2, None, "ebl_toggle", 1.0),
                new HotkeyBinding(Key.D3, None, "vrm_toggle", 0.0),
                new HotkeyBinding(Key.D4, None, "vrm_toggle", 1.0),
                new HotkeyBinding(Key.NumPad1, None, "ebl_toggle", 0.0),
                new HotkeyBinding(Key.NumPad2, None, "ebl_toggle", 1.0),
                new HotkeyBinding(Key.NumPad3, None, "vrm_toggle", 0.0),
                new HotkeyBinding(Key.NumPad4, None, "vrm_toggle", 1.0)),
            new HotkeyRow("Left, Right", "adjust the selected EBL by 1° (Shift 0.1°, Ctrl 10°)",
                new HotkeyBinding(Key.Left, None, "ebl_step", -1.0),
                new HotkeyBinding(Key.Left, Shift, "ebl_step", -0.1),
                new HotkeyBinding(Key.Left, Ctrl, "ebl_step", -10.0),
                new HotkeyBinding(Key.Right, None, "ebl_step", 1.0),
                new HotkeyBinding(Key.Right, Shift, "ebl_step", 0.1),
                new HotkeyBinding(Key.Right, Ctrl, "ebl_step", 10.0)),
            new HotkeyRow("Up, Down", "adjust the selected VRM by 1 % of the range scale (Shift 0.1 %, Ctrl 10 %)",
                new HotkeyBinding(Key.Up, None, "vrm_step", 1.0),
                new HotkeyBinding(Key.Up, Shift, "vrm_step", 0.1),
                new HotkeyBinding(Key.Up, Ctrl, "vrm_step", 10.0),
                new HotkeyBinding(Key.Down, None, "vrm_step", -1.0),
                new HotkeyBinding(Key.Down, Shift, "vrm_step", -0.1),
                new HotkeyBinding(Key.Down, Ctrl, "vrm_step", -10.0)),
            new HotkeyRow("A", "acquire the echo under the cursor",
                new HotkeyBinding(Key.A, None, "acquire", 0.0)),
            new HotkeyRow("Delete, Ctrl+Delete", "cancel the selected target, cancel all",
                new HotkeyBinding(Key.Delete, None, "cancel_target", 0.0),
                new HotkeyBinding(Key.Delete, Ctrl, "cancel_all", 0.0)),
            new HotkeyRow("Space", "acknowledge alarms",
                new HotkeyBinding(Key.Space, None, "alarm_ack", 0.0)),
            new HotkeyRow("H (held)", "heading line off",
                new HotkeyBinding(Key.H, None, "heading_line_off", 0.0)),
            new HotkeyRow("P", "pause",
                new HotkeyBinding(Key.P, None, "pause_toggle", 0.0)),
            new HotkeyRow("F5, F6", "sim speed down, up (1, 2, 3, 5, 10)",
                new HotkeyBinding(Key.F5, None, "sim_speed_step", -1.0),
                new HotkeyBinding(Key.F6, None, "sim_speed_step", 1.0)),
            new HotkeyRow("Enter, Esc", "focus the course box, leave it",
                new HotkeyBinding(Key.Enter, None, "order_focus", 1.0),
                new HotkeyBinding(Key.Escape, None, "order_focus", 0.0)),
            new HotkeyRow("Ctrl+O, Ctrl+Shift+O", "offset to the cursor, centre",
                new HotkeyBinding(Key.O, Ctrl, "offset_cursor", 0.0),
                new HotkeyBinding(Key.O, CtrlShift, "offset_centre", 0.0)),
            new HotkeyRow("Ctrl+Shift+T", "instructor overlay on or off",
                new HotkeyBinding(Key.T, CtrlShift, "instructor_toggle", 0.0)),
            new HotkeyRow("F1", "help",
                new HotkeyBinding(Key.F1, None, "help_open", 0.0)),
        };

        // The binding for a key with exactly these modifiers, or null.
        public static HotkeyBinding Find(Key key, ModifierKeys modifiers)
        {
            foreach (HotkeyRow row in Rows)
            {
                foreach (HotkeyBinding binding in row.Bindings)
                {
                    if (binding.Key == key && binding.Modifiers == modifiers)
                    {
                        return binding;
                    }
                }
            }
            return null;
        }
    }
}
