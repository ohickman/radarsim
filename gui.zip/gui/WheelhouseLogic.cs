// WheelhouseLogic.cs - the data and the arithmetic of the wheelhouse view (BRIEF.md Section 7, "view" and
// "land_view" messages). No WPF types, so the self-tests can run it.
// The view is a panorama seen from own ship's bridge. A point at a bearing and a distance is drawn at
// x = (bearing - view centre) x pixels per degree and y = horizon - elevation angle x pixels per degree,
// so a 180 degree field of view fits on the screen. The elevation angle allows for the curve of the
// Earth (with the usual refraction), so a distant ship or hill rises over the horizon as it comes nearer.
// The view shows bearings only; it never shows a range, a speed or an aspect as a number.
// Units: positions NM (the sim's ground frame, x east, y north), bearings and courses deg true,
// heights and lengths m, elevation angles rad, light levels 0 (night) to 1 (full day), time of day h.
// Called by: WheelhouseWindow (drawing), MainWindow (messages), SelfTest.

using System;
using System.Globalization;
using System.Collections.Generic;
using System.Text.Json;

namespace RadarSim
{
    public class WheelhouseContact
    {
        public int Id;
        public string Kind = "";
        public double XNm, YNm;
        public double CourseDegTrue;
        public double SpeedKn;
        public double LengthM;
        public bool Sail;                       // a sailing vessel (pleasure craft)
        public bool HasTow;                     // a tug with a barge astern
        public double TowXNm, TowYNm, TowLengthM;
        public bool HasMark;                    // a lane buoy: it has a colour, a shape and a flashing light
        public string MarkColour = "";          // "red", "green" or "yellow"
        public string MarkShape = "";           // "nun" (cone), "can" (cylinder) or "pillar"
        public string LightColour = "";         // "red", "green" or "yellow"
        public double LightPeriodS;             // s from the start of one flash to the start of the next
        public double LightFlashS;              // s the light is on in each period (the first flash)
        public double[][] LightFlashes;         // each flash as { start s, duration s } within the period; null = one flash at the start
        public string LightCode = "";           // the chart's text for the light, "Fl(2) G 6s"
    }

    // The land as one byte per cell, row 0 = south, column 0 = west.
    public class WheelhouseLand
    {
        public int Size;                        // cells a side; 0 = open sea
        public double CellNm;
        public double WestNm, SouthNm;
        public double HeightStepM = 2.0;
        public byte[] Heights = new byte[0];

        public double HeightM(double xNm, double yNm)
        {
            if (Size == 0)
            {
                return 0.0;
            }
            int column = (int)Math.Floor((xNm - WestNm) / CellNm);
            int row = (int)Math.Floor((yNm - SouthNm) / CellNm);
            if (column < 0 || row < 0 || column >= Size || row >= Size)
            {
                return 0.0;
            }
            return Heights[row * Size + column] * HeightStepM;
        }
    }

    public class ShoreLight
    {
        public double XNm, YNm;
        public double HeightM;
    }

    public class WheelhouseData
    {
        public const int MaxShoreLights = 600;

        public WheelhouseLand Land = new WheelhouseLand();
        public readonly List<ShoreLight> ShoreLights = new List<ShoreLight>();
        public readonly List<WheelhouseContact> Contacts = new List<WheelhouseContact>();
        public bool HasOwn;
        public double OwnXNm, OwnYNm;
        public double HeadingDegTrue;           // true heading
        public double GyroHeadingDeg;           // what the gyro repeater reads; the bow and the bearings use it

        // The environment of the picture. The time of day and the visibility are set in the Setup window (display only);
        // the wind and the sea state come from the sim in every "view" message.
        public double Hour = 12.0;                              // time of day, h
        public double VisibilitySetNm = WheelhouseMath.ClearVisibilityNm;
        public double VisibilityVariability;                    // 0 = constant, 1 = varies up to clear
        public double WindFromDeg, WindSpeedKn;
        public int SeaState;                                    // Douglas 0 to 9
        public double RainPeakMmH;                              // the rate at the centre of a rain cell, from the sim's "rain" part of the view message
        public double RainRadiusNm = 4.0;                       // radius of a cell
        public readonly List<double[]> RainCells = new List<double[]>();      // centres { x NM, y NM }

        // The rain rate (mm/h) at a place: the sim's cell shape, a raised cosine from the peak at the centre to 0 at the radius; cells do not add.
        public double RainRateAt(double xNm, double yNm)
        {
            double rate = 0.0;
            if (RainPeakMmH <= 0.0 || RainRadiusNm <= 0.0)
            {
                return rate;
            }
            foreach (double[] cell in RainCells)
            {
                double distance = Math.Sqrt((xNm - cell[0]) * (xNm - cell[0]) + (yNm - cell[1]) * (yNm - cell[1]));
                rate = Math.Max(rate, RainPeakMmH * 0.5 * (1.0 + Math.Cos(Math.PI * Math.Min(distance / RainRadiusNm, 1.0))));
            }
            return rate;
        }

        // How much rain between own ship and a contact hides it (0 = none, 1 = lost in it), from the rate along the line of sight.
        public double RainFogFraction(WheelhouseContact contact)
        {
            if (RainPeakMmH <= 0.0 || RainCells.Count == 0)
            {
                return 0.0;
            }
            const int Samples = 16;
            double length = Math.Sqrt((contact.XNm - OwnXNm) * (contact.XNm - OwnXNm) + (contact.YNm - OwnYNm) * (contact.YNm - OwnYNm));   // NM
            double sum = 0.0;                                   // mm/h
            for (int i = 0; i < Samples; i++)
            {
                double along = (i + 0.5) / Samples;
                sum += RainRateAt(OwnXNm + along * (contact.XNm - OwnXNm), OwnYNm + along * (contact.YNm - OwnYNm));
            }
            double optical = WheelhouseMath.RainExtinctionPerNmPerMmH * (sum / Samples) * length;       // optical depth along the path
            return 1.0 - Math.Exp(-optical);
        }

        public double VisibilityNowNm(double seconds)
        {
            return WheelhouseMath.VisibilityNowNm(VisibilitySetNm, VisibilityVariability, seconds);
        }

        public void Clear()
        {
            Land = new WheelhouseLand();
            ShoreLights.Clear();
            Contacts.Clear();
            RainCells.Clear();
            RainPeakMmH = 0.0;
            HasOwn = false;
        }

        // The "land_view" message, sent after every hello.
        public void SetLand(JsonElement message)
        {
            WheelhouseLand land = new WheelhouseLand();
            land.Size = message.GetProperty("size").GetInt32();
            land.CellNm = message.GetProperty("cell_nm").GetDouble();
            land.WestNm = message.GetProperty("west_nm").GetDouble();
            land.SouthNm = message.GetProperty("south_nm").GetDouble();
            land.HeightStepM = message.GetProperty("height_step_m").GetDouble();
            if (land.Size > 0)
            {
                land.Heights = Convert.FromBase64String(message.GetProperty("data").GetString());
                if (land.Heights.Length != land.Size * land.Size)
                {
                    land = new WheelhouseLand();
                }
            }
            Land = land;
            MakeShoreLights();
        }

        // The "view" message, 5 times a second while the window is open.
        public void SetView(JsonElement message)
        {
            JsonElement own = message.GetProperty("own");
            OwnXNm = own.GetProperty("x_nm").GetDouble();
            OwnYNm = own.GetProperty("y_nm").GetDouble();
            HeadingDegTrue = own.GetProperty("heading_deg_true").GetDouble();
            GyroHeadingDeg = own.GetProperty("gyro_heading_deg").GetDouble();
            HasOwn = true;
            JsonElement env;
            if (message.TryGetProperty("env", out env))
            {
                WindFromDeg = env.GetProperty("wind_from_deg_true").GetDouble();
                WindSpeedKn = env.GetProperty("wind_speed_kn").GetDouble();
                SeaState = Math.Max(0, Math.Min(9, env.GetProperty("sea_state_douglas").GetInt32()));
            }
            RainCells.Clear();
            RainPeakMmH = 0.0;
            JsonElement rain;
            if (message.TryGetProperty("rain", out rain))
            {
                RainPeakMmH = rain.GetProperty("peak_mm_per_h").GetDouble();
                RainRadiusNm = rain.GetProperty("radius_nm").GetDouble();
                foreach (JsonElement cell in rain.GetProperty("cells").EnumerateArray())
                {
                    RainCells.Add(new double[] { cell[0].GetDouble(), cell[1].GetDouble() });
                }
            }
            Contacts.Clear();
            foreach (JsonElement item in message.GetProperty("contacts").EnumerateArray())
            {
                WheelhouseContact contact = new WheelhouseContact();
                contact.Id = item.GetProperty("id").GetInt32();
                contact.Kind = item.GetProperty("kind").GetString();
                contact.XNm = item.GetProperty("x_nm").GetDouble();
                contact.YNm = item.GetProperty("y_nm").GetDouble();
                contact.CourseDegTrue = item.GetProperty("course_deg_true").GetDouble();
                contact.SpeedKn = item.GetProperty("speed_kn").GetDouble();
                contact.LengthM = item.GetProperty("length_m").GetDouble();
                JsonElement extra;
                if (item.TryGetProperty("sail", out extra))
                {
                    contact.Sail = extra.GetBoolean();
                }
                if (item.TryGetProperty("tow", out extra))
                {
                    contact.HasTow = true;
                    contact.TowXNm = extra.GetProperty("x_nm").GetDouble();
                    contact.TowYNm = extra.GetProperty("y_nm").GetDouble();
                    contact.TowLengthM = extra.GetProperty("length_m").GetDouble();
                }
                if (item.TryGetProperty("mark", out extra))
                {
                    contact.HasMark = true;
                    contact.MarkColour = extra.GetProperty("colour").GetString();
                    contact.MarkShape = extra.GetProperty("shape").GetString();
                    JsonElement lightItem = extra.GetProperty("light");
                    contact.LightColour = lightItem.GetProperty("colour").GetString();
                    contact.LightPeriodS = lightItem.GetProperty("period_s").GetDouble();
                    contact.LightFlashS = lightItem.GetProperty("flash_s").GetDouble();
                    JsonElement flashList;
                    if (lightItem.TryGetProperty("flashes", out flashList))
                    {
                        List<double[]> flashes = new List<double[]>();
                        foreach (JsonElement flash in flashList.EnumerateArray())
                        {
                            flashes.Add(new double[] { flash[0].GetDouble(), flash[1].GetDouble() });
                        }
                        contact.LightFlashes = flashes.ToArray();
                    }
                    JsonElement code;
                    if (lightItem.TryGetProperty("code", out code))
                    {
                        contact.LightCode = code.GetString();
                    }
                }
                Contacts.Add(contact);
            }
        }

        // Lights ashore for the night view: a few cells of the coast, picked the same way every time.
        private void MakeShoreLights()
        {
            ShoreLights.Clear();
            WheelhouseLand land = Land;
            for (int row = 1; row < land.Size - 1; row++)
            {
                for (int column = 1; column < land.Size - 1; column++)
                {
                    if (land.Heights[row * land.Size + column] == 0 || land.Heights[row * land.Size + column] > 30)
                    {
                        continue;
                    }
                    bool coast = land.Heights[row * land.Size + column - 1] == 0 || land.Heights[row * land.Size + column + 1] == 0
                        || land.Heights[(row - 1) * land.Size + column] == 0 || land.Heights[(row + 1) * land.Size + column] == 0;
                    if (!coast)
                    {
                        continue;
                    }
                    uint hash = (uint)(row * 73856093) ^ (uint)(column * 19349663);
                    hash ^= hash >> 13;
                    hash *= 0x5bd1e995u;
                    hash ^= hash >> 15;
                    uint pick = hash % 100u;
                    if (pick >= 6u)
                    {
                        continue;
                    }
                    int copies = pick == 0u ? 3 : 1;           // now and then a small town
                    for (int copy = 0; copy < copies && ShoreLights.Count < MaxShoreLights; copy++)
                    {
                        ShoreLight light = new ShoreLight();
                        light.XNm = land.WestNm + (column + 0.5 + 0.5 * copy) * land.CellNm;
                        light.YNm = land.SouthNm + (row + 0.5 - 0.3 * copy) * land.CellNm;
                        light.HeightM = 6.0 + (hash >> 8) % 12u;
                        ShoreLights.Add(light);
                    }
                }
            }
        }
    }

    public struct LightSet
    {
        public bool Masthead, Green, Red, Stern;
    }

    // One ship as seen from here: where on the screen and how big, in metres across the line of sight.
    public struct ShipView
    {
        public double BearingDeg;               // from own ship to the ship
        public double RangeM;
        public double AlphaDeg;                 // the ship's course minus the bearing, -180..180
        public double WidthM;                   // across the line of sight
        public int BowSide;                     // +1 the bow points to the right on the screen, -1 to the left
        public double SinAlpha;
    }

    public static class WheelhouseMath
    {
        public const double MPerNm = 1852.0;
        public const double EffectiveEarthRadiusM = 7432000.0;      // 6,371 km x 7/6: standard refraction
        public const double EyeHeightM = 22.0;                      // the bridge, above the water
        public const double MaxSkylineRangeNm = 30.0;
        public static readonly double[] FieldsOfViewDeg = { 180.0, 120.0, 90.0, 60.0, 30.0, 15.0, 8.0, 4.0 };
        public const double SideOverlapDeg = 3.0;
        public const double CrosshairBelowDeg = 31.0;               // the crosshair shows when the view is this narrow or narrower

        public static double Wrap360(double angleDeg)
        {
            double wrapped = angleDeg % 360.0;
            return wrapped < 0.0 ? wrapped + 360.0 : wrapped;
        }

        // The direction of view as a person on the ship would call it: "AHEAD", "ASTERN", or degrees off the bow
        // to starboard or port ("090 STBD"); relDeg is degrees clockwise from the bow.
        public static string RelativeViewText(double relDeg)
        {
            double signed = Wrap180(relDeg);
            double size = Math.Round(Math.Abs(signed));
            if (size < 1.0)
            {
                return "AHEAD";
            }
            if (size > 179.0)
            {
                return "ASTERN";
            }
            return size.ToString("000", CultureInfo.InvariantCulture) + (signed > 0.0 ? " STBD" : " PORT");
        }

        public static double Wrap180(double angleDeg)
        {
            double wrapped = Wrap360(angleDeg);
            return wrapped > 180.0 ? wrapped - 360.0 : wrapped;
        }

        public static double BearingDeg(double eastNm, double northNm)
        {
            return Wrap360(Math.Atan2(eastNm, northNm) * 180.0 / Math.PI);          // rad -> deg
        }

        // Angle above the eye's horizontal (rad) of a point heightAboveEyeM above the eye, distanceM away.
        public static double Elevation(double heightAboveEyeM, double distanceM)
        {
            return heightAboveEyeM / distanceM - distanceM / (2.0 * EffectiveEarthRadiusM);
        }

        public static double HorizonDistanceM(double eyeM)
        {
            return Math.Sqrt(2.0 * eyeM * EffectiveEarthRadiusM);
        }

        // How far below the horizontal the sea horizon is (rad).
        public static double HorizonDipRad(double eyeM)
        {
            return Math.Sqrt(2.0 * eyeM / EffectiveEarthRadiusM);
        }

        // 0 at night, 1 in full day, with dawn and dusk between. Sunrise is at 06:00 and sunset at 18:00.
        public static double Daylight(double hour)
        {
            double sunAltitude = Math.Sin(2.0 * Math.PI * (hour - 6.0) / 24.0);
            double level = (sunAltitude + 0.1) / 0.35;
            return level < 0.0 ? 0.0 : (level > 1.0 ? 1.0 : level);
        }

        public static double ScreenX(double bearingDeg, double centreDeg, double pixelsPerDeg, double widthPx)
        {
            return widthPx / 2.0 + Wrap180(bearingDeg - centreDeg) * pixelsPerDeg;
        }

        public static double ScreenY(double elevationRad, double horizonYPx, double pixelsPerDeg)
        {
            return horizonYPx - elevationRad * 180.0 / Math.PI * pixelsPerDeg;
        }

        // ---- visibility and the reach of lights ----

        public const double ClearVisibilityNm = 30.0;
        // Rain hides things: extinction per NM per mm/h of rain along the line of sight (chosen, not from a source: 10 mm/h gives about 2 NM).
        public const double RainExtinctionPerNmPerMmH = 0.13;
        // The visibility in a rain of a given rate (mm/h) where the watcher stands: 30 NM in none, 12 NM at 1 mm/h, 2.4 NM at 12, 0.6 NM at 50.
        public static double RainVisibilityNm(double rateMmH)
        {
            return rateMmH <= 0.0 ? ClearVisibilityNm : Math.Min(ClearVisibilityNm, 20.0 / (1.0 + 0.6 * rateMmH));
        }

        // The most the visibility reaches while it varies. Variability 0.5 doubles the set value, 1 reaches clear.
        public static double VisibilityUpperNm(double setNm, double variability)
        {
            double v = Math.Max(0.0, Math.Min(1.0, variability));
            double set = Math.Max(0.05, Math.Min(ClearVisibilityNm, setNm));
            double upper = v <= 0.5 ? set * (1.0 + 2.0 * v) : Math.Min(ClearVisibilityNm, 2.0 * set) + (v - 0.5) * 2.0 * (ClearVisibilityNm - Math.Min(ClearVisibilityNm, 2.0 * set));
            return Math.Min(ClearVisibilityNm, upper);
        }

        // The visibility now, wandering slowly between the set value and its upper limit (three sines, periods 41 s to 5 min).
        public static double VisibilityNowNm(double setNm, double variability, double seconds)
        {
            double set = Math.Max(0.05, Math.Min(ClearVisibilityNm, setNm));
            double upper = VisibilityUpperNm(setNm, variability);
            double wander = 0.5 + 0.5 * (0.5 * Math.Sin(2.0 * Math.PI * seconds / 310.0 + 1.3)
                                         + 0.3 * Math.Sin(2.0 * Math.PI * seconds / 97.0 + 0.4)
                                         + 0.2 * Math.Sin(2.0 * Math.PI * seconds / 41.0 + 2.1));
            return set + (upper - set) * Math.Max(0.0, Math.Min(1.0, wander));
        }

        // How much of the fog's colour replaces the colour of something rangeM away (0 = clear). The usual rule is that
        // contrast falls to 2 % at the visibility; the haze of an ordinary clear day is taken out, so a clear day has none.
        public static double FogFraction(double rangeM, double visibilityNm)
        {
            if (visibilityNm >= ClearVisibilityNm)
            {
                return 0.0;
            }
            double raw = 1.0 - Math.Exp(-3.912 * rangeM / (visibilityNm * MPerNm));
            double clear = 1.0 - Math.Exp(-3.912 * rangeM / (ClearVisibilityNm * MPerNm));
            return Math.Max(0.0, Math.Min(1.0, (raw - clear) / (1.0 - clear + 1e-9)));
        }

        // Whether a buoy's light is on at a wall-clock time (ms): on for LightFlashS at the start of each period.
        // Each buoy has its own start, taken from its id, so a row of buoys does not flash together.
        public static bool LightIsOn(WheelhouseContact buoy, long clockMs)
        {
            if (buoy.LightPeriodS <= 0.0)
            {
                return true;
            }
            double periodMs = buoy.LightPeriodS * 1000.0;
            double phaseMs = (Math.Abs((long)buoy.Id) * 997L % 1000L) / 1000.0 * periodMs;
            double into = (clockMs + phaseMs) % periodMs;
            if (buoy.LightFlashes == null)
            {
                return into < buoy.LightFlashS * 1000.0;
            }
            foreach (double[] flash in buoy.LightFlashes)
            {
                if (into >= flash[0] * 1000.0 && into < (flash[0] + flash[1]) * 1000.0)
                {
                    return true;
                }
            }
            return false;
        }

        // Lights are seen farther through binoculars: the reach of a light grows as the field of view narrows (1 at 90 deg, 8 at 11 deg or less).
        public static double LightRangeZoom(double fovDeg)
        {
            return Math.Max(1.0, Math.Min(8.0, 90.0 / Math.Max(1.0, fovDeg)));
        }

        // The farthest a light at heightM can be seen over the curve of the sea from eyeM.
        public static double LightReachM(double heightM, double eyeM)
        {
            return HorizonDistanceM(eyeM) + HorizonDistanceM(Math.Max(0.0, heightM));
        }

        // The next field of view when zooming (direction +1 narrower, -1 wider), staying in the list.
        public static int ZoomIndex(int index, int direction)
        {
            int next = index + direction;
            return next < 0 ? 0 : (next >= FieldsOfViewDeg.Length ? FieldsOfViewDeg.Length - 1 : next);
        }

        // ---- ships and their lights ----

        // theta is the bearing from the ship to the watcher, measured from the ship's bow (+ to starboard).
        // A masthead light shows over 225 degrees ahead, each sidelight over 112.5 degrees on its own side
        // (from right ahead to 22.5 degrees abaft the beam), the stern light over 135 degrees astern.
        // The two sidelights overlap by SideOverlapDeg across the bow, so both are seen from right ahead.
        public static LightSet LightsSeenFrom(double thetaDeg)
        {
            double theta = Wrap180(thetaDeg);
            LightSet set;
            set.Masthead = Math.Abs(theta) <= 112.5;
            set.Green = theta >= -SideOverlapDeg && theta <= 112.5;
            set.Red = theta <= SideOverlapDeg && theta >= -112.5;
            set.Stern = Math.Abs(theta) >= 112.5;
            return set;
        }

        public static ShipView ViewOfShip(double ownXNm, double ownYNm, WheelhouseContact ship, double beamM)
        {
            double east = ship.XNm - ownXNm;
            double north = ship.YNm - ownYNm;
            ShipView view;
            view.BearingDeg = BearingDeg(east, north);
            view.RangeM = Math.Max(1.0, Math.Sqrt(east * east + north * north) * MPerNm);
            view.AlphaDeg = Wrap180(ship.CourseDegTrue - view.BearingDeg);
            double alpha = view.AlphaDeg * Math.PI / 180.0;             // deg -> rad
            view.SinAlpha = Math.Sin(alpha);
            view.WidthM = ship.LengthM * Math.Abs(Math.Sin(alpha)) + beamM * Math.Abs(Math.Cos(alpha));
            view.BowSide = view.SinAlpha >= 0.0 ? 1 : -1;
            return view;
        }

        // Where a point of the ship appears, sideways from the middle of the ship (m, + to the right on the
        // screen): alongShipM is its distance from the middle toward the bow, lateralM its distance to starboard.
        public static double SidewaysM(ShipView view, double alongShipM, double lateralM)
        {
            return alongShipM * view.SinAlpha + lateralM * Math.Cos(view.AlphaDeg * Math.PI / 180.0);     // deg -> rad
        }

        // The watcher's angle from the ship's bow, for LightsSeenFrom.
        public static double ThetaFromBowDeg(ShipView view)
        {
            return Wrap180(180.0 - view.AlphaDeg);
        }

        public static double BeamM(double lengthM)
        {
            return Math.Max(2.0, lengthM * 0.15);
        }

        // ---- land ----

        // For each of `columns` screen columns across fovDeg centred on centreDeg: the elevation angle and the
        // distance of the highest land seen along that bearing (NaN when there is none), and the elevation angle
        // and distance of the first land met (the shore's foot). One step per land cell out to maxRangeNm.
        public static void Skyline(WheelhouseLand land, double ownXNm, double ownYNm, double eyeM, double centreDeg,
                                   double fovDeg, int columns, double maxRangeNm,
                                   double[] topElevation, double[] topDistanceM, double[] footElevation, double[] footDistanceM)
        {
            double step = land.Size > 0 ? Math.Max(land.CellNm, 0.01) : 1.0;
            double dip = HorizonDipRad(eyeM);
            double horizonM = HorizonDistanceM(eyeM);
            for (int column = 0; column < columns; column++)
            {
                double bearing = (centreDeg - fovDeg / 2.0 + (column + 0.5) * fovDeg / columns) * Math.PI / 180.0;   // deg -> rad
                double east = Math.Sin(bearing);
                double north = Math.Cos(bearing);
                double top = double.NaN, topDistance = 0.0, footDistance = 0.0;
                bool seen = false;
                if (land.Size > 0)
                {
                    for (double range = step; range <= maxRangeNm; range += step)
                    {
                        double height = land.HeightM(ownXNm + range * east, ownYNm + range * north);
                        if (height <= 0.0)
                        {
                            continue;
                        }
                        double distanceM = range * MPerNm;
                        if (!seen)
                        {
                            seen = true;
                            footDistance = distanceM;
                        }
                        double elevation = Elevation(height - eyeM, distanceM);
                        if (double.IsNaN(top) || elevation > top)
                        {
                            top = elevation;
                            topDistance = distanceM;
                        }
                    }
                }
                topElevation[column] = top;
                topDistanceM[column] = topDistance;
                footDistanceM[column] = footDistance;
                if (seen)
                {
                    double foot = Elevation(-eyeM, footDistance);
                    if (footDistance > horizonM && foot < -dip)
                    {
                        foot = -dip;                        // the foot is below the horizon: hidden by the curve of the sea
                    }
                    footElevation[column] = foot;
                    if (top < foot)
                    {
                        topElevation[column] = foot;
                    }
                }
                else
                {
                    footElevation[column] = double.NaN;
                }
            }
        }
    }
}
