// TrailLayer.cs - echo trails (BRIEF.md Section 11, M7). The painter calls AddSpoke for every
// spoke; cells with video at or above the threshold are kept as sparse points, grouped by
// antenna revolution, for the last trail_time_min of sim time. Redraw puts the kept points on
// a layer of its own (one alpha byte per pixel) whose intensity falls linearly with age; the
// view draws that layer over the video and under the symbols about 4 times a second.
// Each point keeps two positions: where it was in the stabilisation frame, and where it was
// relative to own ship when it was taken (stabilisation position minus the reference position
// then). True trails draw the first minus the reference position now, so a stationary echo
// stays put. Relative trails draw the second, so a stationary echo leaves a track opposite to
// own ship's motion.
// Units: positions NM (x east, y north), bearings deg T, sim time s, trail time min,
// video 0..255, layer positions in pixels of the PPI bitmap (see PpiGeometry).
// Head-up with relative trails: the points turn with the picture (accepted, logged in BRIEF.md).
// Called by: PpiBitmap (AddSpoke, painter thread), PpiView (Redraw, UI thread), MainWindow, SelfTest.

using System;
using System.Collections.Generic;

namespace RadarSim
{
    public enum TrailMode { Off, True, Relative }

    public class TrailLayer
    {
        public const int MaxPointsPerRevolution = 4000;     // above this a revolution keeps every 2nd, 4th... cell (chosen: bounds memory at 30 MIN)
        public const double OldestLevel = 0.1;              // intensity of a point that is trail_time_min old (chosen)
        private const int FloatsPerPoint = 4;               // x, y, relative x, relative y

        private class Revolution
        {
            public double StartSimTimeS;
            public List<float> Points = new List<float>();  // FloatsPerPoint per point
            public int Stride = 1;                          // keep one candidate in this many
            public long Seen;                               // candidates offered so far
        }

        public readonly int SizePx;
        public readonly object Sync = new object();
        public readonly byte[] Alpha;                       // 0..255 per pixel, rebuilt by Redraw
        public bool Dirty;                                  // Alpha has changed since the view last copied it
        public TrailMode Mode = TrailMode.Off;
        public double TimeMin = 6.0;                        // trail length, MIN of sim time
        public int VideoThreshold = 60;                     // cells at or above this video value are kept

        private readonly List<Revolution> revolutions = new List<Revolution>();
        private Revolution current;
        private int lastAzimuthIndex = -1;
        private readonly bool[] inside;

        public TrailLayer(int sizePx)
        {
            SizePx = sizePx;
            Alpha = new byte[sizePx * sizePx];
            inside = new bool[sizePx * sizePx];
            double radius = sizePx / 2.0;
            for (int y = 0; y < sizePx; y++)
            {
                for (int x = 0; x < sizePx; x++)
                {
                    double dx = x + 0.5 - radius;
                    double dy = y + 0.5 - radius;
                    inside[y * sizePx + x] = dx * dx + dy * dy <= radius * radius;
                }
            }
        }

        public int RevolutionCount
        {
            get
            {
                lock (Sync)
                {
                    return revolutions.Count;
                }
            }
        }

        public int PointCount
        {
            get
            {
                lock (Sync)
                {
                    int total = 0;
                    foreach (Revolution revolution in revolutions)
                    {
                        total += revolution.Points.Count / FloatsPerPoint;
                    }
                    return total;
                }
            }
        }

        // Age in s of the oldest revolution still kept, or 0 when there are none.
        public double OldestAgeS(double nowSimS)
        {
            lock (Sync)
            {
                if (revolutions.Count == 0)
                {
                    return 0.0;
                }
                return nowSimS - revolutions[0].StartSimTimeS;
            }
        }

        public void Clear()
        {
            lock (Sync)
            {
                revolutions.Clear();
                current = null;
                lastAzimuthIndex = -1;
                Array.Clear(Alpha, 0, Alpha.Length);
                Dirty = true;
            }
        }

        // A change of mode throws the trails away (BRIEF.md Section 11).
        public void SetMode(TrailMode mode)
        {
            lock (Sync)
            {
                if (mode == Mode)
                {
                    return;
                }
                Mode = mode;
            }
            Clear();
        }

        public static TrailMode ParseMode(string name)
        {
            if (name == "true")
            {
                return TrailMode.True;
            }
            if (name == "relative")
            {
                return TrailMode.Relative;
            }
            return TrailMode.Off;
        }

        public static string ModeName(TrailMode mode)
        {
            if (mode == TrailMode.True)
            {
                return "true";
            }
            if (mode == TrailMode.Relative)
            {
                return "relative";
            }
            return "off";
        }

        // ---- collecting ----

        // Painter thread. The spoke's video starts at videoStart in video; the bins cover
        // 0..videoRangeNm. A new revolution starts when the antenna angle goes backwards.
        public void AddSpoke(int azimuthIndex, double simTimeS, double trueBearingDeg, double refXNm, double refYNm,
                             byte[] video, int videoStart, int binCount, double videoRangeNm)
        {
            lock (Sync)
            {
                if (Mode == TrailMode.Off)
                {
                    return;
                }
                if (current == null || azimuthIndex < lastAzimuthIndex || simTimeS < current.StartSimTimeS)
                {
                    StartRevolution(simTimeS);
                }
                lastAzimuthIndex = azimuthIndex;

                double bearingRad = trueBearingDeg * Math.PI / 180.0;       // deg -> rad
                double sine = Math.Sin(bearingRad);
                double cosine = Math.Cos(bearingRad);
                double binNm = videoRangeNm / binCount;                      // NM per bin
                for (int bin = 0; bin < binCount; bin++)
                {
                    if (video[videoStart + bin] < VideoThreshold)
                    {
                        continue;
                    }
                    double rangeNm = (bin + 0.5) * binNm;
                    float relativeX = (float)(rangeNm * sine);
                    float relativeY = (float)(rangeNm * cosine);
                    Offer(current, (float)(refXNm + relativeX), (float)(refYNm + relativeY), relativeX, relativeY);
                }
            }
        }

        private void StartRevolution(double simTimeS)
        {
            double windowS = TimeMin * 60.0;                                // MIN -> s
            while (revolutions.Count > 0 && simTimeS - revolutions[0].StartSimTimeS > windowS)
            {
                revolutions.RemoveAt(0);
            }
            current = new Revolution();
            current.StartSimTimeS = simTimeS;
            revolutions.Add(current);
        }

        private static void Offer(Revolution revolution, float x, float y, float relativeX, float relativeY)
        {
            revolution.Seen++;
            if ((revolution.Seen - 1) % revolution.Stride != 0)
            {
                return;
            }
            revolution.Points.Add(x);
            revolution.Points.Add(y);
            revolution.Points.Add(relativeX);
            revolution.Points.Add(relativeY);
            if (revolution.Points.Count >= MaxPointsPerRevolution * FloatsPerPoint)
            {
                List<float> thinned = new List<float>();                    // keep every second point, and keep fewer from now on
                for (int point = 0; point < revolution.Points.Count / FloatsPerPoint; point += 2)
                {
                    for (int part = 0; part < FloatsPerPoint; part++)
                    {
                        thinned.Add(revolution.Points[point * FloatsPerPoint + part]);
                    }
                }
                revolution.Points = thinned;
                revolution.Stride *= 2;
            }
        }

        // ---- drawing ----

        // UI thread, about 4 times a second. The geometry is the UI copy, with OwnRef set to the
        // reference position now; nowSimS is the sim time of the latest spoke.
        public void Redraw(PpiGeometry geometry, double nowSimS)
        {
            lock (Sync)
            {
                Array.Clear(Alpha, 0, Alpha.Length);
                if (Mode != TrailMode.Off && revolutions.Count > 0)
                {
                    DrawPoints(geometry, nowSimS);
                }
                Dirty = true;
            }
        }

        private void DrawPoints(PpiGeometry geometry, double nowSimS)
        {
            double windowS = TimeMin * 60.0;                                // MIN -> s
            double pxPerNm = geometry.RadiusPx / geometry.RangeScaleNm;     // px per NM
            double topRad = geometry.TopBearingDegTrue * Math.PI / 180.0;   // deg -> rad
            double sinTop = Math.Sin(topRad);
            double cosTop = Math.Cos(topRad);
            double ownX = geometry.OwnXPx;
            double ownY = geometry.OwnYPx;
            double refX = geometry.OwnRefXNm;
            double refY = geometry.OwnRefYNm;
            bool trueTrails = Mode == TrailMode.True;

            foreach (Revolution revolution in revolutions)
            {
                double ageS = Math.Max(0.0, nowSimS - revolution.StartSimTimeS);
                if (ageS > windowS)
                {
                    continue;
                }
                double level = 1.0 - (1.0 - OldestLevel) * ageS / windowS;
                byte alpha = (byte)Math.Round(level * 255.0);
                List<float> points = revolution.Points;
                for (int i = 0; i + FloatsPerPoint <= points.Count; i += FloatsPerPoint)
                {
                    double dx = trueTrails ? points[i] - refX : points[i + 2];      // NM east of own ship
                    double dy = trueTrails ? points[i + 1] - refY : points[i + 3];  // NM north of own ship
                    double xPx = ownX + (dx * cosTop - dy * sinTop) * pxPerNm;
                    double yPx = ownY - (dy * cosTop + dx * sinTop) * pxPerNm;
                    if (xPx < 0.0 || yPx < 0.0 || xPx >= SizePx || yPx >= SizePx)
                    {
                        continue;
                    }
                    int index = (int)yPx * SizePx + (int)xPx;
                    if (inside[index] && alpha > Alpha[index])
                    {
                        Alpha[index] = alpha;
                    }
                }
            }
        }
    }
}
