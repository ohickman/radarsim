// PpiBitmap.cs - the scan converter: paints spokes into a persistent square
// intensity layer, fades it with sim time, and turns it into BGRA pixels.
// No WPF types (the view copies Pixels into a WriteableBitmap).
// Units: video 0..255 (stored times 257 so 255 fills 16 bits), sim time in s,
// geometry in bitmap pixels and NM (see PpiGeometry).
// Mono: a new echo never makes a pixel dimmer (max), and the layer fades with
// afterglow_sim_s. Colour: a new echo replaces the pixel, and the layer fades over
// one antenna revolution.
// True motion (M7): every spoke is painted from own ship's pixel for that spoke's reference
// position, so the picture stays fixed in the stabilisation frame. When own ship passes
// true_motion_reset_fraction of the radius the view origin is reset, and the picture and the
// trails are cleared. The painter also feeds every spoke to the trail layer.
// Called by: SpokeSource (painting thread), PpiView (UI thread, colourise), SelfTest.
// Everything that touches Intensity or Pixels must hold Sync.

using System;
using System.Threading;

namespace RadarSim
{
    public class PpiBitmap
    {
        private const double RayStepPx = 0.5;           // spacing of samples along a ray
        private const double RaySpacingPx = 0.5;        // widest gap between neighbouring rays, at the longest range
        private const int MaxSubRays = 16;
        private const double DecayQuantumS = 0.1;       // fade is applied at most this often, sim s (chosen)

        public readonly int SizePx;
        public readonly ushort[] Intensity;             // 0..65535 per pixel
        public readonly uint[] Pixels;                  // 0xAARRGGBB per pixel, alpha always 0xFF
        public readonly object Sync = new object();

        public int AzimuthBins = 2048;                  // spokes per revolution
        public bool ColourMode = false;                 // false = mono
        public uint MonoHue = 0xFF33FF33;
        public uint MonoBackground = 0xFF000000;
        public uint[] ColourStops = { 0xFF0000FF, 0xFF00FFFF, 0xFFFFFF00 };    // weakest to strongest
        public uint ColourBackground = 0xFF050814;
        public double VideoBrilliance = 0.8;            // 0..1
        public double AfterglowSimS = 6.0;              // mono: sim s for an echo to fall to 10 %
        public double RevolutionSimS = 2.5;             // colour: sim s for an echo to fall to 10 %
        public bool Dirty = true;                       // Pixels is out of date
        public long SpokesPainted;
        public readonly TrailLayer Trails;              // fed by PaintFrame; drawn by the view

        // What the painter knows, for the UI thread to read while holding Sync.
        public bool HaveRef;                            // a spoke has been painted
        public double LatestRefXNm;                     // reference position of the latest spoke
        public double LatestRefYNm;
        public double LatestSimTimeS;                   // sim time of the latest spoke
        public double ViewOriginXNm;                    // true motion: the view origin the painter uses
        public double ViewOriginYNm;
        public long ResetCount;                         // true-motion resets the painter has made

        private readonly bool[] inside;                 // pixel centre inside the PPI circle
        private readonly uint[] lut = new uint[256];    // video level -> pixel colour
        private bool lutStale = true;
        private double lastDecaySimS = double.NaN;

        public PpiBitmap(int sizePx)
        {
            SizePx = sizePx;
            Intensity = new ushort[sizePx * sizePx];
            Pixels = new uint[sizePx * sizePx];
            inside = new bool[sizePx * sizePx];
            Trails = new TrailLayer(sizePx);
            double radius = sizePx / 2.0;
            for (int y = 0; y < sizePx; y++)
            {
                for (int x = 0; x < sizePx; x++)
                {
                    double dx = x + 0.5 - radius;
                    double dy = y + 0.5 - radius;
                    inside[y * sizePx + x] = dx * dx + dy * dy <= radius * radius;
                }
            }
        }

        // Call after changing a colour, brilliance or the mode (while holding Sync).
        public void SettingsChanged()
        {
            lutStale = true;
            Dirty = true;
        }

        public void Clear()
        {
            Array.Clear(Intensity, 0, Intensity.Length);
            lastDecaySimS = double.NaN;
            Dirty = true;
        }

        // ---- colours ----

        // Each colour channel moves from one colour to the other by fraction 0..1.
        public static uint Blend(uint startColour, uint endColour, double fraction)
        {
            uint result = 0xFF000000;
            for (int shift = 0; shift <= 16; shift += 8)
            {
                double a = (startColour >> shift) & 0xFF;
                double b = (endColour >> shift) & 0xFF;
                uint channel = (uint)Math.Round(a + (b - a) * fraction);
                result |= channel << shift;
            }
            return result;
        }

        public static uint ParseHex(string hex, uint fallback)
        {
            if (hex == null || hex.Length != 7 || hex[0] != '#')
            {
                return fallback;
            }
            uint rgb;
            if (!uint.TryParse(hex.Substring(1), System.Globalization.NumberStyles.HexNumber,
                               System.Globalization.CultureInfo.InvariantCulture, out rgb))
            {
                return fallback;
            }
            return 0xFF000000 | rgb;
        }

        private uint ColourFor(int level)
        {
            if (!ColourMode)
            {
                return Blend(MonoBackground, MonoHue, level / 255.0 * VideoBrilliance);
            }
            if (level == 0)
            {
                return ColourBackground;
            }
            // Video 1 is the first stop, 128 the middle stop, 255 the last stop.
            double position = (level - 1) / 254.0;
            uint colour;
            if (position <= 0.5)
            {
                colour = Blend(ColourStops[0], ColourStops[1], position * 2.0);
            }
            else
            {
                colour = Blend(ColourStops[1], ColourStops[2], (position - 0.5) * 2.0);
            }
            return Blend(ColourBackground, colour, VideoBrilliance);
        }

        private void BuildLut()
        {
            for (int level = 0; level < 256; level++)
            {
                lut[level] = ColourFor(level);
            }
            lutStale = false;
        }

        // The pixel colour that a video value (0..255) is drawn with right now.
        public uint ColourOfVideo(int video)
        {
            if (lutStale)
            {
                BuildLut();
            }
            return lut[video];
        }

        public void Colourise()
        {
            if (lutStale)
            {
                BuildLut();
            }
            uint background = ColourMode ? ColourBackground : MonoBackground;
            for (int i = 0; i < Pixels.Length; i++)
            {
                Pixels[i] = inside[i] ? lut[Intensity[i] >> 8] : background;
            }
            Dirty = false;
        }

        // ---- fading, in sim time ----

        // Fades the layer by the sim time that has passed since the last fade. Sim time
        // comes from the spokes, so a paused sim (no spokes) does not fade the picture.
        public void Advance(double simTimeS)
        {
            if (double.IsNaN(lastDecaySimS) || simTimeS < lastDecaySimS)
            {
                lastDecaySimS = simTimeS;               // first spoke, or a new run
                return;
            }
            double elapsedS = simTimeS - lastDecaySimS;
            if (elapsedS < DecayQuantumS)
            {
                return;
            }
            double tenPercentS = ColourMode ? RevolutionSimS : AfterglowSimS;
            double timeConstantS = tenPercentS / Math.Log(10.0);       // exp(-t / tau) = 0.1 at t = tenPercentS
            uint multiplier = (uint)Math.Round(Math.Exp(-elapsedS / timeConstantS) * 65536.0);
            for (int i = 0; i < Intensity.Length; i++)
            {
                Intensity[i] = (ushort)(((uint)Intensity[i] * multiplier + 32768u) >> 16);
            }
            lastDecaySimS = simTimeS;
            Dirty = true;
        }

        // ---- painting ----

        // Paints every spoke of a frame as a fan of rays from own ship. Rays are
        // closer together than a pixel, so a long range with 2048 spokes leaves no holes.
        public void PaintFrame(SpokeFrame frame, PpiGeometry geometry)
        {
            if (frame.SpokeCount == 0)
            {
                return;
            }
            Advance(frame.SimTimeS[0]);

            double spokeWidthDeg = 360.0 / AzimuthBins;
            double radiusPx = geometry.RadiusPx;
            double pxPerNm = radiusPx / geometry.RangeScaleNm;
            double limitPx = frame.VideoRangeNm * pxPerNm + 2.0;         // two pixels past the video, so the rim has no gap
            if (limitPx > 2.0 * SizePx)
            {
                limitPx = 2.0 * SizePx;
            }
            double binsPerPx = frame.BinsPerSpoke / (frame.VideoRangeNm * pxPerNm);
            double spokeWidthRad = spokeWidthDeg * Math.PI / 180.0;
            int subRays = (int)Math.Ceiling(limitPx * spokeWidthRad / RaySpacingPx);
            if (subRays < 1)
            {
                subRays = 1;
            }
            if (subRays > MaxSubRays)
            {
                subRays = MaxSubRays;
            }

            for (int spoke = 0; spoke < frame.SpokeCount; spoke++)
            {
                double refXNm = frame.RefXNm[spoke];
                double refYNm = frame.RefYNm[spoke];
                if (geometry.TrueMotionActive)
                {
                    CheckViewOrigin(geometry, refXNm, refYNm);
                }
                double ownXPx, ownYPx;
                geometry.OwnPixelFor(refXNm, refYNm, out ownXPx, out ownYPx);
                double relativeDeg = (frame.AzimuthIndex[spoke] + 0.5) * spokeWidthDeg;
                double gyroDeg = frame.GyroHeadingCdeg[spoke] / 100.0;
                Trails.AddSpoke(frame.AzimuthIndex[spoke], frame.SimTimeS[spoke], relativeDeg + gyroDeg, refXNm, refYNm,
                                frame.Video, spoke * frame.BinsPerSpoke, frame.BinsPerSpoke, frame.VideoRangeNm);
                double centreAngleDeg = geometry.SpokeScreenAngleDeg(relativeDeg, gyroDeg);
                for (int ray = 0; ray < subRays; ray++)
                {
                    double angleDeg = centreAngleDeg + spokeWidthDeg * ((ray + 0.5) / subRays - 0.5);
                    PaintRay(frame.Video, spoke * frame.BinsPerSpoke, frame.BinsPerSpoke,
                             ownXPx, ownYPx, angleDeg * Math.PI / 180.0, limitPx, binsPerPx);
                }
            }
            int last = frame.SpokeCount - 1;
            HaveRef = true;
            LatestRefXNm = frame.RefXNm[last];
            LatestRefYNm = frame.RefYNm[last];
            LatestSimTimeS = frame.SimTimeS[last];
            Interlocked.Add(ref SpokesPainted, frame.SpokeCount);
            Dirty = true;
        }

        // True motion. A pending origin (set when no reference position was known) is taken
        // from this spoke. Otherwise, own ship past the reset circle puts the origin back so
        // own ship is at the offset position, and clears the picture and the trails.
        private void CheckViewOrigin(PpiGeometry geometry, double refXNm, double refYNm)
        {
            if (geometry.OriginPending)
            {
                geometry.ResetViewOrigin(refXNm, refYNm);
                geometry.OriginPending = false;
                PublishOrigin(geometry);
            }
            else if (geometry.BeyondResetLimit(refXNm, refYNm))
            {
                geometry.ResetViewOrigin(refXNm, refYNm);
                PublishOrigin(geometry);
                Clear();
                Trails.Clear();
                ResetCount++;
            }
        }

        // UI thread. True motion: puts own ship back at the offset position (or the centre) as of
        // the latest spoke, in the UI's geometry; the next SetGeometry hands that to the painter.
        // With no spoke yet the first one decides.
        public void ApplyViewReset(PpiGeometry geometry)
        {
            lock (Sync)
            {
                if (HaveRef)
                {
                    geometry.OwnRefXNm = LatestRefXNm;
                    geometry.OwnRefYNm = LatestRefYNm;
                    geometry.ResetViewOrigin(LatestRefXNm, LatestRefYNm);
                }
                else
                {
                    geometry.OriginPending = true;
                }
            }
        }

        // Records the painter's view origin for the UI thread, and marks the geometry's change as taken.
        public void PublishOrigin(PpiGeometry geometry)
        {
            ViewOriginXNm = geometry.ViewOriginXNm;
            ViewOriginYNm = geometry.ViewOriginYNm;
            geometry.OriginChanged = false;
        }

        private void PaintRay(byte[] video, int videoStart, int binCount, double ownXPx, double ownYPx,
                              double angleRad, double limitPx, double binsPerPx)
        {
            double stepX = Math.Sin(angleRad) * RayStepPx;
            double stepY = -Math.Cos(angleRad) * RayStepPx;
            double x = ownXPx + stepX * 0.5;
            double y = ownYPx + stepY * 0.5;
            double distancePx = RayStepPx * 0.5;
            for (; distancePx < limitPx; distancePx += RayStepPx, x += stepX, y += stepY)
            {
                if (x < 0.0 || y < 0.0 || x >= SizePx || y >= SizePx)
                {
                    break;                              // the bitmap is convex, so the ray has left it for good
                }
                int bin = (int)(distancePx * binsPerPx);
                if (bin >= binCount)
                {
                    break;
                }
                byte level = video[videoStart + bin];
                int index = (int)y * SizePx + (int)x;
                if (ColourMode)
                {
                    Intensity[index] = (ushort)(level * 257);
                }
                else if (level != 0)
                {
                    ushort stored = (ushort)(level * 257);
                    if (stored > Intensity[index])
                    {
                        Intensity[index] = stored;
                    }
                }
            }
        }
    }
}
