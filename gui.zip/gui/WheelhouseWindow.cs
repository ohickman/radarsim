// WheelhouseWindow.cs - the view from the wheelhouse: sea, land and sky with the ships and boats painted on
// them, and the foredeck of own ship. A second window opened by the WHEELHOUSE button. It draws what the sim
// sends in "view" (own ship, every contact, the wind and sea state, 5 a second) and "land_view" (the land, once
// per run); the arithmetic is in WheelhouseLogic.cs. Flat colours, no shadows, about 5 frames a second.
// The window shows bearings only, as a watchkeeper reading a gyro repeater's azimuth circle would: the
// bearing of the centre line of the view, and a scale of bearings along the top. It never shows a range,
// a speed or an aspect as a number. A centre line and, at the sides, a horizon tick with elevation ticks appear when the view is 30 degrees wide or less.
// The time of day and the visibility are set in the Setup window (ENVIRONMENT); they live in WheelhouseData.
// Keys: Left and Right look round (Shift 1 deg, Ctrl 30 deg), Up and Down or the wheel zoom, Home looks
// ahead, End looks astern; the mouse drags the view round.
// Units: bearings deg (the gyro repeater, true), heights and lengths m, time of day h, pixels of the window.
// Called by: MainWindow.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace RadarSim
{
    public class WheelhouseWindow : Window
    {
        private readonly Action<Dictionary<string, object>> send;
        private readonly WheelhouseView view;
        private readonly DispatcherTimer timer;
        private readonly TextBlock fovText = new TextBlock();
        private readonly ComboBox deckBox = new ComboBox();

        public WheelhouseWindow(WheelhouseData data, Action<Dictionary<string, object>> send)
        {
            this.send = send;
            Title = "Wheelhouse view";
            Theme.Register(this);
            Width = 1200;
            Height = 600;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;

            view = new WheelhouseView(data);
            DockPanel dock = new DockPanel();
            dock.LastChildFill = true;

            StackPanel bar = new StackPanel();
            bar.Orientation = Orientation.Horizontal;
            bar.Margin = new Thickness(6);
            DockPanel.SetDock(bar, Dock.Top);
            AddButton(bar, "◄", 40, delegate { view.Pan(-5.0); });
            AddButton(bar, "►", 40, delegate { view.Pan(5.0); });
            AddButton(bar, "AHEAD", 70, delegate { view.LookAt(0.0); });
            AddButton(bar, "ASTERN", 70, delegate { view.LookAt(180.0); });
            AddButton(bar, "ZOOM IN", 80, delegate { view.Zoom(1); });
            AddButton(bar, "ZOOM OUT", 80, delegate { view.Zoom(-1); });
            fovText.Margin = new Thickness(4, 4, 18, 0);
            fovText.Width = 110;
            bar.Children.Add(fovText);
            TextBlock deckLabel = new TextBlock();
            deckLabel.Text = "OWN SHIP";
            deckLabel.Margin = new Thickness(4, 4, 6, 0);
            bar.Children.Add(deckLabel);
            foreach (string name in WheelhouseView.DeckNames)
            {
                deckBox.Items.Add(name);
            }
            deckBox.SelectedIndex = 0;
            deckBox.Width = 150;
            deckBox.Focusable = false;
            deckBox.SelectionChanged += delegate { view.DeckType = Math.Max(0, deckBox.SelectedIndex); view.InvalidateVisual(); };
            bar.Children.Add(deckBox);
            dock.Children.Add(bar);
            dock.Children.Add(view);
            Content = dock;

            ShowLabels();
            PreviewKeyDown += Window_PreviewKeyDown;
            Loaded += delegate { send(Protocol.ViewEnable(true)); };
            Closed += delegate { timer.Stop(); send(Protocol.ViewEnable(false)); };
            // 5 frames a second. The sim forgets that the view is wanted when the display reconnects, so ask again each second.
            int ticks = 0;
            timer = new DispatcherTimer(TimeSpan.FromMilliseconds(200), DispatcherPriority.Normal, delegate
            {
                ticks++;
                if (ticks % 5 == 0)
                {
                    send(Protocol.ViewEnable(true));
                }
                view.InvalidateVisual();
                ShowLabels();
            }, Dispatcher);
        }

        private static void AddButton(StackPanel bar, string text, double width, RoutedEventHandler handler)
        {
            Button button = new Button();
            button.Content = text;
            button.Width = width;
            button.Margin = new Thickness(0, 0, 6, 0);
            button.Focusable = false;
            button.Click += handler;
            bar.Children.Add(button);
        }

        private void ShowLabels()
        {
            fovText.Text = "FIELD " + WheelhouseMath.FieldsOfViewDeg[view.ZoomIndex].ToString("0", CultureInfo.InvariantCulture) + " deg";
        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            double step = 5.0;
            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
            {
                step = 1.0;
            }
            else if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
            {
                step = 30.0;
            }
            switch (e.Key)
            {
                case Key.Left: view.Pan(-step); break;
                case Key.Right: view.Pan(step); break;
                case Key.Up: case Key.PageUp: view.Zoom(1); break;
                case Key.Down: case Key.PageDown: view.Zoom(-1); break;
                case Key.Home: view.LookAt(0.0); break;
                case Key.End: view.LookAt(180.0); break;
                default: return;
            }
            e.Handled = true;
            ShowLabels();
            view.InvalidateVisual();
        }
    }

    // What the foredeck of own ship looks like, seen from the bridge. Lengths in m, measured from the eye.
    public class DeckSpec
    {
        public string Name = "";
        public double EyeM;                 // the bridge eye above the water
        public double DeckM;                // the deck above the water
        public double BeamM;
        public double StartZ;               // the deck starts this far ahead of the eye
        public double TaperZ;               // the bow starts to narrow here
        public double EndZ;                 // the stem
        public int Kind;                    // 0 containers, 1 tanker, 2 bulk carrier
    }

    // The picture. It is drawn from the WheelhouseData it was given, on a timer, never on the sim's schedule.
    public class WheelhouseView : FrameworkElement
    {
        public static readonly string[] DeckNames = { "CONTAINER SHIP", "TANKER", "BULK CARRIER" };
        private static readonly DeckSpec[] Decks =
        {
            new DeckSpec { Name = "CONTAINER SHIP", EyeM = 34.0, DeckM = 14.0, BeamM = 32.0, StartZ = 25.0, TaperZ = 150.0, EndZ = 190.0, Kind = 0 },
            new DeckSpec { Name = "TANKER", EyeM = 24.0, DeckM = 11.0, BeamM = 42.0, StartZ = 14.0, TaperZ = 215.0, EndZ = 250.0, Kind = 1 },
            new DeckSpec { Name = "BULK CARRIER", EyeM = 26.0, DeckM = 12.0, BeamM = 36.0, StartZ = 20.0, TaperZ = 170.0, EndZ = 200.0, Kind = 2 },
        };

        private const double HorizonFraction = 0.56;                // the horizon is this far down the window
        private const double MaxShipRangeNm = 24.0;
        private const double LandNearNm = 1.0;
        private const double LandFarNm = 25.0;
        private const double LightBoost = 1.8;                      // lights reach farther than the Rules' minimum, as they do in practice
        private const double BargeLengthM = 70.0;
        private const int BargeIdOffset = 100000;

        private readonly WheelhouseData data;
        private readonly Typeface typeface = new Typeface(new FontFamily("Consolas"), FontStyles.Normal, FontWeights.Bold, FontStretches.Normal);
        private double[] topElevation = new double[0];
        private double[] topDistanceM = new double[0];
        private double[] footElevation = new double[0];
        private double[] footDistanceM = new double[0];
        private bool dragging;
        private double dragStartX;
        private double dragStartRelDeg;

        // set at the start of every frame
        private double eyeM = 22.0;
        private double visibilityNm = WheelhouseMath.ClearVisibilityNm;
        private Color fogColour = Colors.Gray;

        public double ViewRelDeg;                                   // the centre of the view, from the bow (+ to starboard)
        public int ZoomIndex;                                       // into WheelhouseMath.FieldsOfViewDeg; 0 = 180 deg
        public int DeckType;                                        // into Decks

        public WheelhouseView(WheelhouseData data)
        {
            this.data = data;
            ClipToBounds = true;
            Focusable = false;
        }

        public void Pan(double deltaDeg)
        {
            ViewRelDeg = WheelhouseMath.Wrap180(ViewRelDeg + deltaDeg);
        }

        public void LookAt(double relativeDeg)
        {
            ViewRelDeg = WheelhouseMath.Wrap180(relativeDeg);
        }

        public void Zoom(int direction)
        {
            ZoomIndex = WheelhouseMath.ZoomIndex(ZoomIndex, direction);
        }

        // ---- the mouse ----

        protected override void OnMouseWheel(MouseWheelEventArgs e)
        {
            base.OnMouseWheel(e);
            Zoom(e.Delta > 0 ? 1 : -1);
            InvalidateVisual();
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            dragging = true;
            dragStartX = e.GetPosition(this).X;
            dragStartRelDeg = ViewRelDeg;
            CaptureMouse();
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (dragging && ActualWidth > 10.0)
            {
                double pixelsPerDeg = ActualWidth / WheelhouseMath.FieldsOfViewDeg[ZoomIndex];
                ViewRelDeg = WheelhouseMath.Wrap180(dragStartRelDeg - (e.GetPosition(this).X - dragStartX) / pixelsPerDeg);
                InvalidateVisual();
            }
        }

        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonUp(e);
            dragging = false;
            ReleaseMouseCapture();
        }

        // ---- colours and small tools ----

        private static Color Mix(Color a, Color b, double t)
        {
            t = t < 0.0 ? 0.0 : (t > 1.0 ? 1.0 : t);
            return Color.FromRgb((byte)(a.R + (b.R - a.R) * t), (byte)(a.G + (b.G - a.G) * t), (byte)(a.B + (b.B - a.B) * t));
        }

        // night, dusk and day colours, for a light level 0 to 1.
        private static Color Palette(Color night, Color dusk, Color day, double light)
        {
            return light < 0.5 ? Mix(night, dusk, light * 2.0) : Mix(dusk, day, (light - 0.5) * 2.0);
        }

        private static Brush Solid(Color color)
        {
            SolidColorBrush brush = new SolidColorBrush(color);
            brush.Freeze();
            return brush;
        }

        private static Brush Solid(Color color, double alpha)
        {
            SolidColorBrush brush = new SolidColorBrush(Color.FromArgb((byte)(255.0 * Math.Max(0.0, Math.Min(1.0, alpha))), color.R, color.G, color.B));
            brush.Freeze();
            return brush;
        }

        private static Color Shade(Color color, double factor)
        {
            return Color.FromRgb((byte)Math.Min(255.0, color.R * factor), (byte)Math.Min(255.0, color.G * factor), (byte)Math.Min(255.0, color.B * factor));
        }

        // A colour in flat daylight (factor 0.1 to 1), then the fog's colour mixed in for the distance.
        private Color Tint(Color color, double day, double fog)
        {
            return Mix(Shade(color, day), fogColour, fog);
        }

        // A repeatable number from 0 to 1 for two whole numbers.
        private static double Hash(int a, int b)
        {
            unchecked
            {
                uint h = (uint)(a * 374761393 + b * 668265263);
                h = (h ^ (h >> 13)) * 1274126177u;
                h ^= h >> 16;
                return (h & 0xFFFFFF) / (double)0x1000000;
            }
        }

        private static void Polygon(DrawingContext dc, Brush fill, Pen pen, params Point[] points)
        {
            StreamGeometry geometry = new StreamGeometry();
            using (StreamGeometryContext context = geometry.Open())
            {
                context.BeginFigure(points[0], fill != null, true);
                for (int i = 1; i < points.Length; i++)
                {
                    context.LineTo(points[i], pen != null, false);
                }
            }
            geometry.Freeze();
            dc.DrawGeometry(fill, pen, geometry);
        }

        private void Text(DrawingContext dc, string text, double size, Brush brush, double x, double y, bool centred)
        {
            FormattedText formatted = new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
                                                        typeface, size, brush, VisualTreeHelper.GetDpi(this).PixelsPerDip);
            dc.DrawText(formatted, new Point(centred ? x - formatted.Width / 2.0 : x, y));
        }

        // ---- the picture ----

        protected override void OnRender(DrawingContext dc)
        {
            double width = ActualWidth;
            double height = ActualHeight;
            if (width < 100.0 || height < 100.0)
            {
                return;
            }
            double fov = WheelhouseMath.FieldsOfViewDeg[ZoomIndex];
            double pixelsPerDeg = width / fov;
            double pixelsPerRad = pixelsPerDeg * 180.0 / Math.PI;       // deg -> rad
            double horizonY = height * HorizonFraction;
            eyeM = Decks[Math.Max(0, Math.Min(Decks.Length - 1, DeckType))].EyeM;
            double eye = eyeM;
            double seaY = horizonY + WheelhouseMath.HorizonDipRad(eye) * pixelsPerRad;          // the sea horizon is a little below eye level
            double light = WheelhouseMath.Daylight(data.Hour);
            double night = 1.0 - light;
            double heading = data.HasOwn ? data.GyroHeadingDeg : 0.0;
            double centre = WheelhouseMath.Wrap360(heading + ViewRelDeg);
            visibilityNm = data.VisibilityNowNm(Environment.TickCount64 / 1000.0);
            double ownRain = data.HasOwn ? data.RainRateAt(data.OwnXNm, data.OwnYNm) : 0.0;
            visibilityNm = Math.Min(visibilityNm, WheelhouseMath.RainVisibilityNm(ownRain));
            fogColour = Palette(Color.FromRgb(22, 24, 30), Color.FromRgb(120, 112, 116), Color.FromRgb(200, 206, 210), light);
            double horizonM = WheelhouseMath.HorizonDistanceM(eye);
            double fogHorizon = WheelhouseMath.FogFraction(horizonM * 1.5, visibilityNm);

            // Sky.
            Color skyTop = Palette(Color.FromRgb(4, 6, 18), Color.FromRgb(70, 80, 130), Color.FromRgb(96, 150, 214), light);
            Color skyLow = Palette(Color.FromRgb(14, 20, 44), Color.FromRgb(225, 150, 110), Color.FromRgb(196, 220, 238), light);
            skyTop = Mix(skyTop, fogColour, fogHorizon * 0.75);
            skyLow = Mix(skyLow, fogColour, fogHorizon);
            LinearGradientBrush sky = new LinearGradientBrush(skyTop, skyLow, 90.0);
            sky.Freeze();
            dc.DrawRectangle(sky, null, new Rect(0.0, 0.0, width, seaY));
            if (night > 0.7 && fogHorizon < 0.5)
            {
                Brush star = Solid(Color.FromRgb(230, 230, 255), (night - 0.7) * 3.0 * (1.0 - 2.0 * fogHorizon));
                for (int i = 0; i < 90; i++)
                {
                    double bearing = (i * 137.5) % 360.0;
                    double elevationDeg = 4.0 + (i * 29) % 60;
                    double x = WheelhouseMath.ScreenX(bearing, centre, pixelsPerDeg, width);
                    double y = seaY - elevationDeg * pixelsPerDeg;
                    if (x >= 0.0 && x < width && y > 34.0 && y < seaY)
                    {
                        dc.DrawRectangle(star, null, new Rect(x, y, 1.5, 1.5));
                    }
                }
            }

            // Sea: strips, each mixed with the fog by its distance.
            Color seaFar = Palette(Color.FromRgb(10, 18, 36), Color.FromRgb(80, 90, 120), Color.FromRgb(96, 140, 170), light);
            Color seaNear = Palette(Color.FromRgb(4, 8, 18), Color.FromRgb(30, 44, 70), Color.FromRgb(30, 78, 116), light);
            int strips = 36;
            double stripHeight = (height - seaY) / strips;
            for (int strip = 0; strip < strips; strip++)
            {
                double yMid = seaY + (strip + 0.5) * stripHeight;
                double depression = Math.Max(1e-4, (yMid - horizonY) / pixelsPerRad);
                double distanceM = eye / depression;
                Color colour = Mix(Mix(seaFar, seaNear, (strip + 0.5) / strips), fogColour, WheelhouseMath.FogFraction(distanceM, visibilityNm));
                dc.DrawRectangle(Solid(colour), null, new Rect(0.0, seaY + strip * stripHeight, width, stripHeight + 1.0));
            }
            DrawWaves(dc, width, height, horizonY, seaY, pixelsPerDeg, pixelsPerRad, centre, fov, light);

            // Land: one bar for each column of pixels, from the skyline down to the shore.
            int columns = Math.Max(10, (int)(width / 3.0));
            if (topElevation.Length != columns)
            {
                topElevation = new double[columns];
                topDistanceM = new double[columns];
                footElevation = new double[columns];
                footDistanceM = new double[columns];
            }
            for (int column = 0; column < columns; column++)
            {
                topElevation[column] = double.NaN;
            }
            if (data.HasOwn)
            {
                WheelhouseMath.Skyline(data.Land, data.OwnXNm, data.OwnYNm, eye, centre, fov, columns, WheelhouseMath.MaxSkylineRangeNm,
                                       topElevation, topDistanceM, footElevation, footDistanceM);
                Color landNear = Palette(Color.FromRgb(10, 14, 10), Color.FromRgb(60, 60, 50), Color.FromRgb(88, 104, 64), light);
                Color landFar = Palette(Color.FromRgb(12, 16, 28), Color.FromRgb(110, 100, 120), Color.FromRgb(140, 160, 184), light);
                double barWidth = width / columns;
                for (int column = 0; column < columns; column++)
                {
                    if (double.IsNaN(topElevation[column]))
                    {
                        continue;
                    }
                    double rangeNm = topDistanceM[column] / WheelhouseMath.MPerNm;
                    double haze = (rangeNm - LandNearNm) / (LandFarNm - LandNearNm);
                    Color colour = Mix(Mix(landNear, landFar, haze), fogColour, WheelhouseMath.FogFraction(topDistanceM[column], visibilityNm));
                    double y1 = WheelhouseMath.ScreenY(topElevation[column], horizonY, pixelsPerDeg);
                    double y2 = WheelhouseMath.ScreenY(footElevation[column], horizonY, pixelsPerDeg);
                    if (y2 < y1 + 1.0)
                    {
                        y2 = y1 + 1.0;
                    }
                    dc.DrawRectangle(Solid(colour), null, new Rect(column * barWidth, y1, barWidth + 0.8, y2 - y1));
                }
            }

            if (data.HasOwn)
            {
                DrawShoreLights(dc, width, horizonY, pixelsPerDeg, centre, fov, columns, night);
                DrawRainCurtains(dc, width, horizonY, pixelsPerDeg, centre, fov, light);
                DrawContacts(dc, width, horizonY, seaY, pixelsPerDeg, pixelsPerRad, centre, fov, columns, light);
            }

            DrawBowDeck(dc, width, height, horizonY, pixelsPerDeg, centre, heading, fov, light);
            DrawRainStreaks(dc, width, height, ownRain, light);
            DrawScaleAndReadout(dc, width, height, pixelsPerDeg, centre, fov);
            DrawHeadingIndicator(dc, width, centre - heading, fov);
        }

        // A small plan view of own ship in the top right corner, bow up, with a wedge showing where the window is looking and
        // its angle off the bow written under it.
        private void DrawHeadingIndicator(DrawingContext dc, double width, double viewRelDeg, double fov)
        {
            const double Radius = 46.0;                 // px, the wedge's reach
            Point middle = new Point(width - Radius - 14.0, 40.0 + Radius + 4.0);
            dc.DrawEllipse(Solid(Color.FromRgb(0, 0, 0), 0.45), new Pen(Solid(Color.FromRgb(200, 200, 200), 0.6), 1.0), middle, Radius + 6.0, Radius + 6.0);
            Point bridge = new Point(middle.X, middle.Y + 8.0);         // the wedge starts at the wheelhouse, a little aft of the middle
            double halfDeg = Math.Min(fov / 2.0, 90.0);
            List<Point> points = new List<Point>();
            points.Add(bridge);
            int steps = Math.Max(2, (int)Math.Ceiling(halfDeg * 2.0 / 5.0));
            for (int i = 0; i <= steps; i++)
            {
                double angleRad = (viewRelDeg - halfDeg + 2.0 * halfDeg * i / steps) * Math.PI / 180.0;       // deg -> rad, clockwise from the bow
                points.Add(new Point(bridge.X + Radius * Math.Sin(angleRad), bridge.Y - Radius * Math.Cos(angleRad)));
            }
            StreamGeometry wedge = new StreamGeometry();
            using (StreamGeometryContext context = wedge.Open())
            {
                context.BeginFigure(points[0], true, true);
                context.PolyLineTo(points.GetRange(1, points.Count - 1), true, false);
            }
            wedge.Freeze();
            dc.DrawGeometry(Solid(Color.FromRgb(255, 214, 90), 0.45), new Pen(Solid(Color.FromRgb(255, 214, 90)), 1.0), wedge);
            // The hull: a pointed bow, parallel sides, a square stern, 14 px wide and 52 px long.
            StreamGeometry hull = new StreamGeometry();
            using (StreamGeometryContext context = hull.Open())
            {
                context.BeginFigure(new Point(middle.X, middle.Y - 26.0), true, true);
                context.LineTo(new Point(middle.X + 7.0, middle.Y - 10.0), true, false);
                context.LineTo(new Point(middle.X + 7.0, middle.Y + 26.0), true, false);
                context.LineTo(new Point(middle.X - 7.0, middle.Y + 26.0), true, false);
                context.LineTo(new Point(middle.X - 7.0, middle.Y - 10.0), true, false);
            }
            hull.Freeze();
            dc.DrawGeometry(Solid(Color.FromRgb(90, 100, 115)), new Pen(Solid(Color.FromRgb(235, 235, 235)), 1.2), hull);
            dc.DrawRectangle(Solid(Color.FromRgb(235, 235, 235)), null, new Rect(bridge.X - 5.0, bridge.Y - 3.0, 10.0, 6.0));
            Text(dc, WheelhouseMath.RelativeViewText(viewRelDeg), 12.0, Solid(Color.FromRgb(240, 240, 240)), middle.X, middle.Y + Radius + 8.0, true);
        }

        // ---- rain ----

        private const double CloudBaseM = 700.0;                    // height of the base of a rain cloud, m (chosen)

        // Each rain cell seen from outside as a grey curtain hanging from a dark cloud base to the sea, strip by strip across the view:
        // a strip is as opaque as the rain rate where its line of sight passes closest to the cell's centre, so a cell is thick in the
        // middle and soft at its edges. The cell is the same blob the radar shows.
        private void DrawRainCurtains(DrawingContext dc, double width, double horizonY, double pixelsPerDeg, double centre, double fov, double light)
        {
            if (data.RainPeakMmH <= 0.0 || data.RainCells.Count == 0)
            {
                return;
            }
            double eye = eyeM;
            Color curtain = Palette(Color.FromRgb(34, 38, 48), Color.FromRgb(118, 120, 128), Color.FromRgb(150, 158, 168), light);
            Color cap = Palette(Color.FromRgb(18, 20, 26), Color.FromRgb(76, 78, 86), Color.FromRgb(100, 106, 116), light);
            double stripDeg = 6.0 / pixelsPerDeg;
            int first = (int)Math.Floor((centre - fov / 2.0 - 1.0) / stripDeg);
            int last = (int)Math.Ceiling((centre + fov / 2.0 + 1.0) / stripDeg);
            double radius = data.RainRadiusNm;
            for (int strip = first; strip <= last; strip++)
            {
                double bearing = (strip + 0.5) * stripDeg;
                double dx = Math.Sin(bearing * Math.PI / 180.0);
                double dy = Math.Cos(bearing * Math.PI / 180.0);
                double x = WheelhouseMath.ScreenX(bearing, centre, pixelsPerDeg, width) - 3.0;
                foreach (double[] cell in data.RainCells)
                {
                    double relX = cell[0] - data.OwnXNm;
                    double relY = cell[1] - data.OwnYNm;
                    double along = relX * dx + relY * dy;                       // NM along the line of sight to the closest approach
                    double across = Math.Abs(relX * dy - relY * dx);            // NM from the cell's centre to the line of sight
                    if (along <= 0.0 || across >= radius)
                    {
                        continue;
                    }
                    double nearNm = Math.Max(0.05, along - Math.Sqrt(radius * radius - across * across));
                    double rate = data.RainPeakMmH * 0.5 * (1.0 + Math.Cos(Math.PI * across / radius));
                    double opacity = 0.85 * (1.0 - Math.Exp(-rate / 8.0));
                    double range = nearNm * WheelhouseMath.MPerNm;
                    double bottom = WheelhouseMath.ScreenY(WheelhouseMath.Elevation(-eye, range), horizonY, pixelsPerDeg);
                    double top = Math.Max(-20.0, WheelhouseMath.ScreenY(WheelhouseMath.Elevation(CloudBaseM - eye, range), horizonY, pixelsPerDeg));
                    if (bottom <= top)
                    {
                        continue;
                    }
                    double capHeight = Math.Min(bottom - top, Math.Max(8.0, 0.18 * (bottom - top)));
                    dc.DrawRectangle(Solid(curtain, opacity), null, new Rect(x, top, 6.5, bottom - top));
                    dc.DrawRectangle(Solid(cap, Math.Min(0.9, opacity * 1.1)), null, new Rect(x, top, 6.5, capHeight));
                }
            }
        }

        // Streaks of rain across the whole view while own ship is in a cell.
        private void DrawRainStreaks(DrawingContext dc, double width, double height, double rate, double light)
        {
            if (rate < 0.5)
            {
                return;
            }
            int count = (int)Math.Min(220.0, 30.0 + 8.0 * rate);
            double seconds = Environment.TickCount64 / 1000.0;
            double length = Math.Min(26.0, 8.0 + 0.5 * rate);
            Pen pen = new Pen(Solid(Palette(Color.FromRgb(120, 130, 150), Color.FromRgb(190, 192, 200), Color.FromRgb(220, 226, 232), light), 0.35), 1.0);
            for (int i = 0; i < count; i++)
            {
                double x = ((i * 7919L) % 10007L) / 10007.0 * (width + 40.0) - 20.0;
                double y = (((i * 104729L) % 10009L) / 10009.0 * height + seconds * 600.0) % (height + length) - length;
                dc.DrawLine(pen, new Point(x, y), new Point(x - 3.0, y + length));
            }
        }

        // ---- the sea's surface ----

        // Short crests in rows from near to far. Their size and number follow the Douglas sea state the wind makes;
        // from state 3 up some of them break white.
        private void DrawWaves(DrawingContext dc, double width, double height, double horizonY, double seaY, double pixelsPerDeg,
                               double pixelsPerRad, double centre, double fov, double light)
        {
            int state = data.SeaState;
            double eye = eyeM;
            double amplitude = 0.35 + 0.65 * state / 9.0;
            double crestM = 3.0 + 2.2 * state;                      // the length of a crest, m
            double spacingM = crestM * 2.6;
            Color crestColour = Palette(Color.FromRgb(30, 40, 60), Color.FromRgb(120, 130, 160), Color.FromRgb(170, 200, 220), light);
            Color whiteColour = Palette(Color.FromRgb(60, 66, 80), Color.FromRgb(200, 200, 205), Color.FromRgb(246, 248, 250), light);
            double distanceM = 60.0;
            int row = 0;
            while (distanceM < 4000.0)
            {
                double y = horizonY + eye / distanceM * pixelsPerRad;
                if (y > height)
                {
                    distanceM *= 1.3;
                    row++;
                    continue;
                }
                double fog = WheelhouseMath.FogFraction(distanceM, visibilityNm);
                if (fog < 0.95)
                {
                    double scale = (y - horizonY) / eye;              // pixels in a metre of the sea's surface at this distance
                    double dashWidth = Math.Max(1.5, crestM * scale);
                    double dashHeight = Math.Max(1.0, 0.1 * dashWidth);
                    double stepDeg = spacingM / distanceM * 180.0 / Math.PI;      // deg
                    while (fov / stepDeg > 110.0)
                    {
                        stepDeg *= 2.0;
                    }
                    int first = (int)Math.Floor((centre - fov / 2.0 - 2.0) / stepDeg);
                    int last = (int)Math.Ceiling((centre + fov / 2.0 + 2.0) / stepDeg);
                    for (int k = first; k <= last; k++)
                    {
                        double h1 = Hash(row, k);
                        double h2 = Hash(k, row + 77);
                        double bearing = (k + h1) * stepDeg;
                        double x = WheelhouseMath.ScreenX(bearing, centre, pixelsPerDeg, width);
                        if (x < -dashWidth || x > width + dashWidth)
                        {
                            continue;
                        }
                        // White caps are short flecks (a quarter to a half of a crest) that get more numerous as the sea builds:
                        // few at state 3, most crests by state 8 or 9, and then a second fleck beside the first.
                        bool breaking = state >= 3 && h2 < Math.Min(0.9, 0.02 + 0.012 * state * state);
                        double alpha = (breaking ? 0.85 : 0.35 * amplitude) * (1.0 - fog);
                        if (breaking)
                        {
                            double fleck = Math.Max(1.2, dashWidth * (0.25 + 0.25 * h1));
                            double fleckHeight = Math.Max(1.0, 0.1 * fleck);
                            dc.DrawRectangle(Solid(whiteColour, alpha), null, new Rect(x - fleck / 2.0, y, fleck, fleckHeight));
                            if (state >= 6 && h1 > 0.4)
                            {
                                double second = fleck * (0.5 + 0.5 * h2);
                                dc.DrawRectangle(Solid(whiteColour, alpha), null, new Rect(x + dashWidth * 0.45, y, second, fleckHeight));
                            }
                        }
                        else
                        {
                            dc.DrawRectangle(Solid(crestColour, alpha), null, new Rect(x - dashWidth / 2.0, y, dashWidth * (0.6 + 0.8 * h2), dashHeight));
                        }
                    }
                }
                distanceM *= 1.3;
                row++;
            }
        }

        // ---- lights ashore ----

        private void DrawShoreLights(DrawingContext dc, double width, double horizonY, double pixelsPerDeg, double centre, double fov,
                                     int columns, double night)
        {
            if (night < 0.3)
            {
                return;
            }
            double eye = eyeM;
            double dip = WheelhouseMath.HorizonDipRad(eye);
            foreach (ShoreLight shore in data.ShoreLights)
            {
                double east = shore.XNm - data.OwnXNm;
                double north = shore.YNm - data.OwnYNm;
                double rangeM = Math.Sqrt(east * east + north * north) * WheelhouseMath.MPerNm;
                if (rangeM < 200.0 || rangeM > 22.0 * WheelhouseMath.MPerNm || rangeM > 2.0 * visibilityNm * WheelhouseMath.MPerNm)
                {
                    continue;
                }
                double bearing = WheelhouseMath.BearingDeg(east, north);
                double relative = WheelhouseMath.Wrap180(bearing - centre);
                if (Math.Abs(relative) > fov / 2.0)
                {
                    continue;
                }
                double elevation = WheelhouseMath.Elevation(shore.HeightM - eye, rangeM);
                if (elevation < -dip)
                {
                    continue;                                       // below the sea horizon
                }
                int column = Math.Min(columns - 1, Math.Max(0, (int)((relative + fov / 2.0) / fov * columns)));
                if (!double.IsNaN(topElevation[column]) && topDistanceM[column] < rangeM - 100.0 && topElevation[column] > elevation + 0.0005)
                {
                    continue;                                       // behind nearer, higher land
                }
                double fade = 1.0 - Math.Min(1.0, rangeM / (2.0 * visibilityNm * WheelhouseMath.MPerNm));
                double strength = (night - 0.3) * fade;
                double x = width / 2.0 + relative * pixelsPerDeg;
                double y = WheelhouseMath.ScreenY(elevation, horizonY, pixelsPerDeg);
                dc.DrawEllipse(Solid(Color.FromRgb(255, 214, 140), strength * 0.5), null, new Point(x, y), 3.0, 3.0);
                dc.DrawEllipse(Solid(Color.FromRgb(255, 236, 190), strength * 1.4), null, new Point(x, y), 1.1, 1.1);
            }
        }

        // ---- ships, boats and buoys ----

        private void DrawContacts(DrawingContext dc, double width, double horizonY, double seaY, double pixelsPerDeg, double pixelsPerRad,
                                  double centre, double fov, int columns, double light)
        {
            double eye = eyeM;
            double horizonM = WheelhouseMath.HorizonDistanceM(eye);
            List<WheelhouseContact> all = new List<WheelhouseContact>();
            foreach (WheelhouseContact contact in data.Contacts)
            {
                all.Add(contact);
                if (contact.HasTow)
                {
                    // The barge behind a tug: a low hull with side and stern lights, heading the way the tug is.
                    WheelhouseContact barge = new WheelhouseContact();
                    barge.Id = contact.Id + BargeIdOffset;
                    barge.Kind = "barge";
                    barge.XNm = contact.TowXNm;
                    barge.YNm = contact.TowYNm;
                    barge.CourseDegTrue = WheelhouseMath.BearingDeg(contact.XNm - contact.TowXNm, contact.YNm - contact.TowYNm);
                    barge.SpeedKn = contact.SpeedKn;
                    barge.LengthM = BargeLengthM;
                    all.Add(barge);
                }
            }
            List<ShipView> views = new List<ShipView>();
            List<WheelhouseContact> ships = new List<WheelhouseContact>();
            foreach (WheelhouseContact contact in all)
            {
                ShipView sv = WheelhouseMath.ViewOfShip(data.OwnXNm, data.OwnYNm, contact, WheelhouseMath.BeamM(contact.LengthM));
                if (sv.RangeM > MaxShipRangeNm * WheelhouseMath.MPerNm || Math.Abs(WheelhouseMath.Wrap180(sv.BearingDeg - centre)) > fov / 2.0 + 12.0)
                {
                    continue;
                }
                int index = 0;
                while (index < views.Count && views[index].RangeM > sv.RangeM)
                {
                    index++;
                }
                views.Insert(index, sv);                            // far ships first, so near ones paint over them
                ships.Insert(index, contact);
            }
            for (int i = 0; i < views.Count; i++)
            {
                ShipView sv = views[i];
                WheelhouseContact ship = ships[i];
                double relative = WheelhouseMath.Wrap180(sv.BearingDeg - centre);
                double length = Math.Max(1.0, ship.LengthM);
                double fog = Math.Max(WheelhouseMath.FogFraction(sv.RangeM, visibilityNm), data.RainFogFraction(ship));
                // Hidden behind higher, nearer land?
                int column = Math.Min(columns - 1, Math.Max(0, (int)((relative + fov / 2.0) / fov * columns)));
                double mastTop = WheelhouseMath.Elevation(Math.Max(6.0, 0.12 * length) - eye, sv.RangeM);
                if (!double.IsNaN(topElevation[column]) && topDistanceM[column] < sv.RangeM && topElevation[column] > mastTop)
                {
                    continue;
                }
                bool clip = sv.RangeM > horizonM;                   // beyond the sea horizon the hull is hidden by the curve of the sea
                if (clip)
                {
                    dc.PushClip(new RectangleGeometry(new Rect(0.0, 0.0, width, seaY)));
                }
                if (ship.Kind == "buoy")
                {
                    DrawBuoy(dc, ship, sv, width, horizonY, pixelsPerDeg, pixelsPerRad, centre, light, fog, fov);
                }
                else
                {
                    DrawShip(dc, ship, sv, width, horizonY, pixelsPerDeg, pixelsPerRad, centre, light, fog, fov);
                }
                if (clip)
                {
                    dc.Pop();
                }
            }
        }

        // What a vessel looks like: its colours and the sizes of its parts.
        private class ShipLook
        {
            public double FreeboardM, HouseHeightM, HouseLengthM, HouseAlongM, MastM;
            public Color Hull, Boot, House;
            public int Cargo;                   // 0 none, 1 containers, 2 tanker, 3 bulk carrier
            public bool Funnel;
            public double BootFraction = 0.25;  // the height of the waterline band as a fraction of the freeboard
            public double BowRiseM;             // how much higher the bow stands than the middle of the deck, m (the flare and sheer)
            public int Masts;                   // sailing vessels: 1 gaff cutter, 2 schooner, 3 three-masted schooner
            public bool Fenders;                // tugs: a row of tyres along the side
        }

        private static ShipLook LookOf(WheelhouseContact ship)
        {
            double length = Math.Max(1.0, ship.LengthM);
            ShipLook look = new ShipLook();
            Color[] shipHulls = { Color.FromRgb(36, 40, 50), Color.FromRgb(120, 40, 36), Color.FromRgb(30, 44, 80), Color.FromRgb(34, 34, 36) };
            look.Hull = shipHulls[Math.Abs(ship.Id) % shipHulls.Length];
            look.Boot = Color.FromRgb(140, 44, 40);
            look.House = Color.FromRgb(236, 236, 232);
            look.MastM = 0.0;
            if (ship.Kind == "tug_tow")
            {
                look.FreeboardM = Math.Max(1.8, 0.07 * length);
                look.HouseHeightM = Math.Max(3.0, 0.22 * length);
                look.HouseLengthM = 0.35 * length;
                look.HouseAlongM = 0.1 * length;
                look.MastM = 0.2 * length;
                // Harbour tugs: a dark hull with a high flared bow, a cream, white or red house well forward and a funnel behind it.
                int tugStyle = Math.Abs(ship.Id) % 3;
                look.Hull = tugStyle == 2 ? Color.FromRgb(36, 34, 34) : Color.FromRgb(28, 30, 38);
                look.Boot = Color.FromRgb(150, 44, 38);
                look.House = tugStyle == 0 ? Color.FromRgb(232, 224, 196) : (tugStyle == 1 ? Color.FromRgb(238, 238, 234) : Color.FromRgb(214, 78, 44));
                look.BowRiseM = Math.Max(0.8, 0.045 * length);
                look.HouseAlongM = 0.12 * length;
                look.HouseLengthM = 0.32 * length;
                look.Fenders = true;
                look.Funnel = true;
            }
            else if (ship.Kind == "fishing")
            {
                look.FreeboardM = Math.Max(1.2, 0.08 * length);
                look.HouseHeightM = Math.Max(2.5, 0.28 * length);
                look.HouseLengthM = 0.25 * length;
                look.HouseAlongM = 0.2 * length;
                look.MastM = 0.35 * length;
                Color[] fishHulls = { Color.FromRgb(44, 84, 140), Color.FromRgb(236, 236, 232), Color.FromRgb(34, 38, 52), Color.FromRgb(120, 44, 40) };
                look.Hull = fishHulls[Math.Abs(ship.Id) % fishHulls.Length];
                look.House = Color.FromRgb(238, 238, 232);
                look.Boot = Color.FromRgb(150, 40, 36);
                look.BowRiseM = Math.Max(0.6, 0.05 * length);
                look.BootFraction = 0.3;
            }
            else if (ship.Kind == "pleasure")
            {
                look.FreeboardM = Math.Max(0.6, 0.07 * length);
                look.HouseHeightM = ship.Sail ? Math.Max(0.5, 0.08 * length) : Math.Max(1.0, 0.2 * length);
                look.HouseLengthM = 0.3 * length;
                look.HouseAlongM = ship.Sail ? 0.0 : -0.05 * length;
                look.Masts = !ship.Sail ? 0 : (length < 18.0 ? 1 : (length < 36.0 ? 2 : 3));
                look.MastM = ship.Sail ? (look.Masts == 1 ? 1.25 : 0.95) * length : 0.3 * length;
                look.Hull = Color.FromRgb(238, 238, 238);
                look.Boot = Color.FromRgb(40, 60, 120);
                look.House = Color.FromRgb(196, 208, 222);
                if (ship.Sail)
                {
                    // Gaff-rigged classics: varnished wood, white or black topsides.
                    Color[] woods = { Color.FromRgb(150, 98, 44), Color.FromRgb(236, 236, 230), Color.FromRgb(28, 32, 40), Color.FromRgb(236, 236, 230) };
                    look.Hull = woods[Math.Abs(ship.Id) % woods.Length];
                    look.Boot = look.Hull.R > 200 ? Color.FromRgb(40, 60, 120) : Color.FromRgb(120, 40, 36);
                    look.BowRiseM = 0.04 * length;
                    look.BootFraction = 0.2;
                }
            }
            else if (ship.Kind == "barge")
            {
                look.FreeboardM = 2.0;
                look.HouseHeightM = 0.0;
                look.Hull = Color.FromRgb(70, 64, 58);
                look.Boot = Color.FromRgb(40, 34, 30);
                look.Cargo = 0;
            }
            else
            {
                look.FreeboardM = Math.Max(4.0, 0.06 * length);
                look.HouseHeightM = Math.Max(8.0, 0.1 * length);
                look.HouseLengthM = 0.1 * length;
                look.HouseAlongM = -0.36 * length;
                look.MastM = 0.05 * length;
                look.Funnel = true;
                look.BootFraction = 0.38;                              // the red anti-fouling shows high on a big ship in ballast
                look.Boot = Color.FromRgb(150, 52, 42);
                look.BowRiseM = Math.Max(2.0, 0.025 * length);
                int type = Math.Abs(ship.Id) % 3;
                look.Cargo = type == 0 ? 1 : (type == 1 ? 2 : 3);
                if (look.Cargo == 1)
                {
                    // Container ships: the bridge about two thirds of the way aft with the funnel behind it, stacks before and abaft it.
                    look.FreeboardM = Math.Max(4.0, 0.042 * length);
                    look.HouseAlongM = -0.2 * length;
                    look.HouseHeightM = Math.Max(20.0, 0.15 * length);
                    look.HouseLengthM = 0.07 * length;
                }
                else if (look.Cargo == 2)
                {
                    // Tankers: a tall accommodation block right aft, a long flat deck of pipes, a low freeboard.
                    look.Hull = Color.FromRgb(46, 50, 56);
                    look.FreeboardM = Math.Max(3.0, 0.045 * length);
                    look.HouseAlongM = -0.4 * length;
                    look.HouseHeightM = Math.Max(14.0, 0.09 * length);
                    look.HouseLengthM = 0.07 * length;
                    look.BowRiseM = Math.Max(1.0, 0.012 * length);
                }
            }
            return look;
        }

        private void DrawShip(DrawingContext dc, WheelhouseContact ship, ShipView sv, double width, double horizonY,
                              double pixelsPerDeg, double pixelsPerRad, double centre, double light, double fog, double fov)
        {
            double eye = eyeM;
            double length = Math.Max(1.0, ship.LengthM);
            double beam = WheelhouseMath.BeamM(length);
            double perMetre = pixelsPerRad / sv.RangeM;             // pixels in a metre of the ship
            double xc = WheelhouseMath.ScreenX(sv.BearingDeg, centre, pixelsPerDeg, width);
            double waterY = WheelhouseMath.ScreenY(WheelhouseMath.Elevation(-eye, sv.RangeM), horizonY, pixelsPerDeg);
            double cosAlpha = Math.Cos(sv.AlphaDeg * Math.PI / 180.0);          // deg -> rad
            ShipLook look = LookOf(ship);
            double day = 0.1 + 0.9 * light;                         // flat lighting: the colours just darken toward night

            // Where a point of the ship is on the screen: along the ship from its middle (+ toward the bow), across it (+ to starboard), up from the water.
            Func<double, double, double> sx = (along, lateral) => xc + WheelhouseMath.SidewaysM(sv, along, lateral) * perMetre;
            Func<double, double> sy = (up) => waterY - up * perMetre;

            bool solidShip = ship.Kind == "ship" || ship.Kind == "tug_tow" || ship.Kind == "fishing" || (ship.Kind == "pleasure" && ship.Sail);
            if (solidShip && day > 0.14 && fog < 0.985)
            {
                DrawSolidShip(dc, ship, look, sv, xc, waterY, perMetre, day, fog);
            }
            if (!solidShip && day > 0.14 && fog < 0.985)
            {
                double halfWidth = Math.Max(1.2, sv.WidthM * perMetre / 2.0);
                double side = sv.BowSide;
                double deckY = sy(look.FreeboardM);
                double rake = Math.Min(halfWidth * 0.5, 0.05 * length * perMetre) * Math.Abs(sv.SinAlpha);
                double sternRake = Math.Min(halfWidth * 0.3, 0.02 * length * perMetre) * Math.Abs(sv.SinAlpha);
                double sheer = (ship.Kind == "barge" ? 0.0 : 0.15 * look.FreeboardM) * perMetre;
                double xStern = xc - side * halfWidth;
                double xBow = xc + side * halfWidth;
                // The deck line sags a little amidships and rises to the bow (sheer and flare).
                double bowRisePx = look.BowRiseM * perMetre;
                List<Point> outline = new List<Point>();
                outline.Add(new Point(xStern + side * sternRake, waterY));
                outline.Add(new Point(xBow - side * rake, waterY));
                outline.Add(new Point(xBow, deckY - bowRisePx - sheer));
                for (int n = 4; n >= 0; n--)
                {
                    double u = (n - 2.0) / 2.5 * 0.8;                                   // 0.64 ... -0.64 of the half length, bow to stern
                    double rise = bowRisePx * Math.Pow(Math.Max(0.0, (u - 0.2) / 0.8), 2.0) + 0.1 * look.FreeboardM * perMetre * (1.0 - u * u);
                    outline.Add(new Point(xc + side * halfWidth * u, deckY - rise));
                }
                outline.Add(new Point(xStern, deckY));
                Polygon(dc, Solid(Tint(look.Hull, day, fog)), null, outline.ToArray());
                double bootTop = waterY - look.BootFraction * look.FreeboardM * perMetre;       // the red band at the waterline
                double bootLeft = Math.Min(xStern + side * sternRake, xBow - side * rake);
                double bootRight = Math.Max(xStern + side * sternRake, xBow - side * rake);
                dc.DrawRectangle(Solid(Tint(look.Boot, day, fog)), null, new Rect(bootLeft, bootTop, Math.Max(0.5, bootRight - bootLeft), Math.Max(0.5, waterY - bootTop)));

                if (look.Fenders && halfWidth > 6.0)
                {
                    // a row of tyres along the side at deck level, round the bow too
                    double tyre = Math.Max(1.5, 0.045 * length * perMetre * Math.Abs(sv.SinAlpha) + 0.01 * length * perMetre);
                    int tyres = (int)Math.Max(3.0, Math.Min(14.0, 0.9 * length / 3.5));
                    for (int n = 0; n < tyres; n++)
                    {
                        double u = -0.45 + 0.9 * n / (tyres - 1.0);
                        dc.DrawEllipse(Solid(Tint(Color.FromRgb(18, 18, 18), day, fog)), null,
                                       new Point(sx(u * length, 0.0), sy(look.FreeboardM - 0.6)), tyre / 2.0, Math.Max(1.0, 0.7 * look.FreeboardM * perMetre / 2.0));
                    }
                }

                if (ship.Kind == "ship")
                {
                    DrawHullDetail(dc, ship, look, sv, sx, sy, perMetre, day, fog, outline, bootLeft, bootRight, side, halfWidth, rake, sternRake, xStern, xBow, waterY);
                }

                // From a viewer abaft the beam the stern end is nearer: then the house is drawn last, otherwise the cargo is.
                double theta = WheelhouseMath.ThetaFromBowDeg(sv) * Math.PI / 180.0;       // deg -> rad
                bool houseNearer = Math.Cos(theta) < 0.0;
                if (!houseNearer)
                {
                    DrawHouse(dc, ship, look, sv, sx, sy, perMetre, beam, cosAlpha, day, fog);
                }
                DrawCargo(dc, ship, look, sv, sx, sy, perMetre, beam, cosAlpha, day, fog, Math.Cos(theta));
                if (look.Cargo == 2)
                {
                    DrawTankerDetails(dc, ship, look, sx, sy, perMetre, length, day, fog);
                }
                if (houseNearer)
                {
                    DrawHouse(dc, ship, look, sv, sx, sy, perMetre, beam, cosAlpha, day, fog);
                }
                if (ship.Kind == "pleasure" && ship.Sail)
                {
                    DrawGaffRig(dc, ship, look, sx, sy, perMetre, length, day, fog);
                }
                if (fov <= 30.0 && light > 0.3)
                {
                    DrawDayShapes(dc, ship, look, sx, sy, perMetre, length, day, fog);
                }
            }

            double nightFactor = (1.0 - light) * (1.0 - fog);
            if (nightFactor > 0.25 && ship.Kind != "buoy")
            {
                DrawNavigationLights(dc, ship, look, sv, perMetre, xc, horizonY, pixelsPerDeg, (nightFactor - 0.25) / 0.75, fov);
            }
        }

        // The deckhouse, windows, funnel and mast.
        private void DrawHouse(DrawingContext dc, WheelhouseContact ship, ShipLook look, ShipView sv, Func<double, double, double> sx, Func<double, double> sy,
                               double perMetre, double beam, double cosAlpha, double day, double fog)
        {
            if (look.HouseHeightM <= 0.0)
            {
                return;
            }
            double length = Math.Max(1.0, ship.LengthM);
            double houseX = sx(look.HouseAlongM, 0.0);
            double houseHalf = Math.Max(0.8, (look.HouseLengthM * Math.Abs(sv.SinAlpha) + 0.8 * beam * Math.Abs(cosAlpha)) * perMetre / 2.0);
            double deckY = sy(look.FreeboardM);
            double houseTop = sy(look.FreeboardM + look.HouseHeightM);
            double houseTall = Math.Max(1.0, deckY - houseTop);
            dc.DrawRectangle(Solid(Tint(look.House, day, fog)), null, new Rect(houseX - houseHalf, houseTop, houseHalf * 2.0, houseTall));
            if (houseTall > 7.0 && ship.Kind != "pleasure")
            {
                // a row of windows along the top, and for a big ship two more rows below
                Brush window = Solid(Tint(Color.FromRgb(30, 40, 52), day, fog));
                dc.DrawRectangle(window, null, new Rect(houseX - houseHalf * 0.9, houseTop + houseTall * 0.12, houseHalf * 1.8, Math.Max(1.0, houseTall * 0.14)));
                if (houseTall > 16.0)
                {
                    dc.DrawRectangle(window, null, new Rect(houseX - houseHalf * 0.9, houseTop + houseTall * 0.42, houseHalf * 1.8, Math.Max(1.0, houseTall * 0.10)));
                    dc.DrawRectangle(window, null, new Rect(houseX - houseHalf * 0.9, houseTop + houseTall * 0.64, houseHalf * 1.8, Math.Max(1.0, houseTall * 0.10)));
                }
            }
            if (look.Funnel)
            {
                double funnelHeight = (ship.Kind == "tug_tow" ? 0.12 : 0.05) * length;
                double funnelHalf = Math.Max(0.5, (ship.Kind == "tug_tow" ? 0.05 : 0.03) * length * perMetre);
                double funnelX = sx(look.HouseAlongM - (ship.Kind == "tug_tow" ? 0.08 : 0.07) * length, 0.0);
                dc.DrawRectangle(Solid(Tint(ship.Kind == "tug_tow" ? Color.FromRgb(30, 30, 30) : Color.FromRgb(150, 40, 34), day, fog)), null,
                                 new Rect(funnelX - funnelHalf, houseTop - funnelHeight * perMetre, funnelHalf * 2.0, funnelHeight * perMetre + 1.0));
            }
            if (look.MastM > 0.0 && ship.Kind != "pleasure")
            {
                double mastX = sx(look.HouseAlongM + 0.05 * length, 0.0);
                dc.DrawRectangle(Solid(Tint(Color.FromRgb(210, 210, 205), day, fog)), null,
                                 new Rect(mastX - 0.5, houseTop - look.MastM * perMetre, 1.0, look.MastM * perMetre + 1.0));
            }
        }

        // ---- big ships: hull detail, container stacks and the container ship's house ----

        private static readonly Color[] ContainerColours =
        {
            Color.FromRgb(176, 62, 50), Color.FromRgb(52, 92, 150), Color.FromRgb(196, 160, 56), Color.FromRgb(70, 130, 96),
            Color.FromRgb(200, 200, 196), Color.FromRgb(120, 80, 50), Color.FromRgb(220, 110, 40), Color.FromRgb(60, 60, 66)
        };

        private void Block(DrawingContext dc, Color colour, double day, double fog, double x, double y, double w, double h)
        {
            dc.DrawRectangle(Solid(Tint(colour, day, fog)), null, new Rect(x, y, Math.Max(0.5, w), Math.Max(0.5, h)));
        }

        // What a big ship's hull shows besides its colour: the deck rail, a seam, the company's lettering, a hawse pipe at the bow, the
        // bow wave and the wake, and a low raised deck at each end with the foremast. Only drawn when the ship is big enough on the screen.
        private void DrawHullDetail(DrawingContext dc, WheelhouseContact ship, ShipLook look, ShipView sv, Func<double, double, double> sx, Func<double, double> sy,
                                    double perMetre, double day, double fog, List<Point> outline, double bootLeft, double bootRight, double side, double halfWidth,
                                    double rake, double sternRake, double xStern, double xBow, double waterY)
        {
            double length = Math.Max(1.0, ship.LengthM);
            double absSin = Math.Abs(sv.SinAlpha);
            double fb = look.FreeboardM;
            double bowRiseM = look.BowRiseM;
            if (halfWidth > 12.0)
            {
                // the bow wave and the wake along the waterline, bigger with speed
                double speed = Math.Min(1.0, ship.SpeedKn / 18.0);
                if (ship.SpeedKn > 3.0)
                {
                    double bowWave = 0.07 * length * absSin * perMetre * speed + 2.0;
                    Polygon(dc, Solid(Tint(Color.FromRgb(244, 248, 250), day, fog), 0.9), null,
                            new Point(xBow - side * rake, waterY), new Point(xBow - side * rake - side * bowWave * 1.6, waterY + 0.01 * length * perMetre),
                            new Point(xBow - side * rake + side * bowWave * 0.5, waterY - 0.07 * fb * perMetre * speed - 1.0));
                    double wake = 0.12 * length * absSin * perMetre * speed;
                    Polygon(dc, Solid(Tint(Color.FromRgb(236, 242, 246), day, fog), 0.8), null,
                            new Point(xStern + side * sternRake, waterY), new Point(xStern + side * sternRake - side * wake, waterY + 1.5),
                            new Point(xStern + side * sternRake - side * wake * 0.8, waterY - 1.0));
                }
            }
            if (halfWidth > 25.0)
            {
                Pen rail = new Pen(Solid(Tint(Color.FromRgb(200, 200, 196), day, fog)), 1.0);
                for (int n = 2; n < outline.Count - 1; n++)
                {
                    dc.DrawLine(rail, new Point(outline[n].X, outline[n].Y + 1.0), new Point(outline[n + 1].X, outline[n + 1].Y + 1.0));
                }
                if (absSin > 0.3)
                {
                    // the company's name as a row of white blocks amidships, and the hawse pipe with its anchor at the bow
                    for (int k = 0; k < 4; k++)
                    {
                        double letterX = sx((-0.06 + 0.016 * k) * length, 0.0);
                        double letterWidth = Math.Max(1.0, 0.011 * length * absSin * perMetre);
                        Block(dc, Color.FromRgb(238, 238, 234), day, fog, letterX - letterWidth / 2.0, sy(fb * 0.72), letterWidth, fb * 0.34 * perMetre);
                    }
                    double hawse = Math.Max(1.0, 0.012 * length * perMetre * absSin);
                    dc.DrawEllipse(Solid(Tint(Shade(look.Hull, 0.5), day, fog)), null, new Point(sx(0.45 * length, 0.0), sy(fb * 0.62)), hawse, hawse);
                }
                dc.DrawLine(new Pen(Solid(Tint(Shade(look.Hull, 1.25), day, fog)), 1.0), new Point(bootLeft, waterY - 0.7 * fb * perMetre),
                            new Point(bootRight, waterY - 0.7 * fb * perMetre));
            }
            // the forecastle at the bow with its mast, and the poop at the stern
            double beam = WheelhouseMath.BeamM(length);
            double absCos = Math.Abs(Math.Cos(sv.AlphaDeg * Math.PI / 180.0));       // deg -> rad
            double forecastleLength = 0.06 * length;
            double forecastleX = sx(0.5 * length - forecastleLength / 2.0 - 0.01 * length, 0.0);
            double forecastleHalf = Math.Max(1.0, (forecastleLength * absSin + 0.5 * beam * absCos) * perMetre / 2.0);
            double forecastleTop = fb + bowRiseM + 3.0;
            Block(dc, Shade(look.Hull, 1.2), day, fog, forecastleX - forecastleHalf, sy(forecastleTop), forecastleHalf * 2.0, 3.0 * perMetre);
            Block(dc, Color.FromRgb(214, 214, 208), day, fog, forecastleX - 1.0, sy(forecastleTop + 0.04 * length), 2.0, 0.04 * length * perMetre);
            double poopX = sx(-0.5 * length + 0.02 * length, 0.0);
            double poopHalf = Math.Max(1.0, (0.03 * length * absSin + 0.6 * beam * absCos) * perMetre / 2.0);
            Block(dc, Shade(look.Hull, 1.2), day, fog, poopX - poopHalf, sy(fb + 3.0), poopHalf * 2.0, 3.0 * perMetre);
        }

        // The hull as a prism: `plan` is its outline seen from above ({along, lateral} corners, convex), each wall that faces the viewer is
        // drawn from the waterline to the deck, lit by how squarely it faces them, with the anti-fouling band along its foot.
        // The foot is drawn `footScale` as wide as the deck, as a hull narrows toward the keel.
        private void DrawPrismHull(DrawingContext dc, ShipView sv, Func<double, double, double> sx, Func<double, double> sy, double[,] plan,
                                   Func<double, double> deckHeight, ShipLook look, double waterY, double footScale, double day, double fog)
        {
            double cosAlpha = Math.Cos(sv.AlphaDeg * Math.PI / 180.0);          // deg -> rad
            double sinAlpha = sv.SinAlpha;
            int corners = plan.GetLength(0);
            double[] order = new double[corners];
            for (int i = 0; i < corners; i++)
            {
                int j = (i + 1) % corners;
                order[i] = (plan[i, 0] + plan[j, 0]) / 2.0 * cosAlpha - (plan[i, 1] + plan[j, 1]) / 2.0 * sinAlpha;        // how far away the wall is
            }
            List<int> walls = new List<int>();
            for (int i = 0; i < corners; i++)
            {
                walls.Add(i);
            }
            walls.Sort((p, q) => order[q].CompareTo(order[p]));                                     // far walls first
            Pen rail = new Pen(Solid(Tint(Color.FromRgb(205, 205, 200), day, fog)), 1.0);
            double bootHeight = look.BootFraction * look.FreeboardM;
            foreach (int i in walls)
            {
                int j = (i + 1) % corners;
                double dAlong = plan[j, 0] - plan[i, 0];
                double dLat = plan[j, 1] - plan[i, 1];
                double wallLength = Math.Sqrt(dAlong * dAlong + dLat * dLat);
                double normalAlong = dLat / wallLength;
                double normalLat = -dAlong / wallLength;
                if (normalAlong * (plan[i, 0] + plan[j, 0]) + normalLat * (plan[i, 1] + plan[j, 1]) < 0.0)
                {
                    normalAlong = -normalAlong;                                                       // make it point out of the hull
                    normalLat = -normalLat;
                }
                double toward = normalAlong * cosAlpha - normalLat * sinAlpha;               // + is away from the viewer
                if (toward >= -1e-6)
                {
                    continue;
                }
                double light = 0.74 + 0.26 * (-toward);
                Point topFrom = new Point(sx(plan[i, 0], plan[i, 1]), sy(deckHeight(plan[i, 0])));
                Point topTo = new Point(sx(plan[j, 0], plan[j, 1]), sy(deckHeight(plan[j, 0])));
                Point footFrom = new Point(sx(plan[i, 0], plan[i, 1] * footScale), waterY);
                Point footTo = new Point(sx(plan[j, 0], plan[j, 1] * footScale), waterY);
                Polygon(dc, Solid(Tint(Shade(look.Hull, light), day, fog)), null, footFrom, footTo, topTo, topFrom);
                Polygon(dc, Solid(Tint(Shade(look.Boot, light), day, fog)), null, footFrom, footTo,
                        new Point(sx(plan[j, 0], plan[j, 1] * (footScale + 0.08)), sy(bootHeight)), new Point(sx(plan[i, 0], plan[i, 1] * (footScale + 0.08)), sy(bootHeight)));
                dc.DrawLine(rail, new Point(topFrom.X, topFrom.Y + 1.0), new Point(topTo.X, topTo.Y + 1.0));
            }
        }

        private void Line3(DrawingContext dc, Func<double, double, double> sx, Func<double, double> sy, double along1, double lateral1, double up1,
                           double along2, double lateral2, double up2, Color colour, double thickness, double day, double fog)
        {
            dc.DrawLine(new Pen(Solid(Tint(colour, day, fog)), Math.Max(1.0, thickness)), new Point(sx(along1, lateral1), sy(up1)), new Point(sx(along2, lateral2), sy(up2)));
        }

        // Rows of windows on a face: `rows` bands, each `bandFraction` of its row high.
        private void WindowRows(DrawingContext dc, Face face, int rows, double bandFraction, double firstFraction, bool dividers, double day, double fog)
        {
            if (!face.Visible)
            {
                return;
            }
            double height = face.Bottom - face.Top;
            double width = face.X1 - face.X0;
            for (int row = 0; row < rows; row++)
            {
                double y = face.Top + height * (row + firstFraction) / rows;
                double bandHeight = Math.Max(1.0, height / rows * bandFraction * 0.6);
                Block(dc, Color.FromRgb(32, 42, 56), day, fog, face.X0 + width * 0.06, y, width * 0.88, bandHeight);
                if (false && dividers && width > 40.0)
                {
                    int count = (int)(width * 0.88 / 6.0);
                    for (int m = 1; m < count; m++)
                    {
                        Block(dc, Color.FromRgb(240, 240, 235), day, fog, face.X0 + width * 0.06 + m * 6.0, y, 1.0, bandHeight);
                    }
                }
            }
        }

        // One dispatcher for every vessel drawn as a solid: container ships, tankers, bulk carriers, tugs, fishing boats and sailing vessels.
        private void DrawSolidShip(DrawingContext dc, WheelhouseContact ship, ShipLook look, ShipView sv, double xc, double waterY, double perMetre, double day, double fog)
        {
            if (ship.Kind == "ship" && look.Cargo == 1)
            {
                DrawContainerShip(dc, ship, look, sv, xc, waterY, perMetre, day, fog);
            }
            else if (ship.Kind == "ship")
            {
                DrawTankerOrBulk(dc, ship, look, sv, xc, waterY, perMetre, day, fog);
            }
            else if (ship.Kind == "tug_tow")
            {
                DrawTug(dc, ship, look, sv, xc, waterY, perMetre, day, fog);
            }
            else if (ship.Kind == "fishing")
            {
                DrawFishingBoat(dc, ship, look, sv, xc, waterY, perMetre, day, fog);
            }
            else
            {
                DrawSailingVessel(dc, ship, look, sv, xc, waterY, perMetre, day, fog);
            }
        }

        private void BowWave(DrawingContext dc, ShipView sv, double bowX, double waterY, double speedFraction, double size, double day, double fog)
        {
            Polygon(dc, Solid(Tint(Color.FromRgb(244, 248, 250), day, fog), 0.9), null, new Point(bowX, waterY),
                    new Point(bowX - size * 0.4 * speedFraction - size * 1.1 * speedFraction * sv.SinAlpha, waterY + 3.0), new Point(bowX + size * 0.7 * speedFraction, waterY - 3.0 - size * 0.2));
        }

        // Tankers and bulk carriers: the house and funnel right aft, a long flat deck with the cargo gear (a tanker's pipeline, platforms and
        // manifold with a crane; a bulk carrier's hatch covers with a crane between each pair), and the forecastle with its mast.
        private void DrawTankerOrBulk(DrawingContext dc, WheelhouseContact ship, ShipLook look, ShipView sv, double xc, double waterY, double perMetre, double day, double fog)
        {
            double length = Math.Max(1.0, ship.LengthM);
            double halfBeam = WheelhouseMath.BeamM(length) / 2.0;
            double cosAlpha = Math.Cos(sv.AlphaDeg * Math.PI / 180.0);          // deg -> rad
            double sinAlpha = sv.SinAlpha;
            double fb = look.FreeboardM;
            double rise = look.BowRiseM;
            Func<double, double, double> sx = (along, lateral) => xc + (along * sinAlpha + lateral * cosAlpha) * perMetre;
            Func<double, double> sy = (up) => waterY - up * perMetre;
            Func<double, double> deckHeight = (along) =>
            {
                double u = along / (0.5 * length);
                return fb - 0.05 * fb * (1.0 - u * u) + rise * Math.Pow(Math.Max(0.0, (u / 1.0 - 0.3) / 0.7), 2.0);
            };
            double[,] plan = { { -0.5 * length, -halfBeam }, { -0.5 * length, halfBeam }, { 0.38 * length, halfBeam }, { 0.5 * length, 0.0 }, { 0.38 * length, -halfBeam } };
            DrawPrismHull(dc, sv, sx, sy, plan, deckHeight, look, waterY, 0.82, day, fog);
            bool tanker = look.Cargo == 2;
            List<DeckItem> items = new List<DeckItem>();
            if (tanker)
            {
                for (int k = 0; k < 18; k++)
                {
                    items.Add(new DeckItem { Kind = 0, Along = -0.30 * length + (k + 0.5) * (0.70 * length / 18.0), Bay = k });
                }
                items.Add(new DeckItem { Kind = 5, Along = 0.04 * length });
                items.Add(new DeckItem { Kind = 6, Along = 0.04 * length });
            }
            else
            {
                for (int k = 0; k < 5; k++)
                {
                    items.Add(new DeckItem { Kind = 7, Along = -0.28 * length + k * 0.15 * length, Bay = k });
                    items.Add(new DeckItem { Kind = 8, Along = -0.28 * length + k * 0.15 * length + 0.075 * length, Bay = k });
                }
            }
            items.Add(new DeckItem { Kind = 1, Along = look.HouseAlongM });
            items.Add(new DeckItem { Kind = 3, Along = 0.45 * length });
            foreach (DeckItem item in items)
            {
                item.Away = item.Along * cosAlpha;
            }
            items.Sort((p, q) => q.Away.CompareTo(p.Away));
            Face side, end;
            double houseHeight = look.HouseHeightM;
            foreach (DeckItem item in items)
            {
                if (item.Kind == 0)
                {
                    DrawBox(dc, sv, sx, sy, item.Along, 0.70 * length / 36.0 * 0.96, 0.05 * halfBeam, fb, fb + 1.3, Color.FromRgb(120, 126, 130), day, fog, out side, out end);     // the pipeline
                    if (item.Bay % 3 == 1)
                    {
                        DrawBox(dc, sv, sx, sy, item.Along, 0.012 * length, 0.16 * halfBeam, fb, fb + 0.7, Color.FromRgb(150, 156, 160), day, fog, out side, out end);
                    }
                    if (item.Bay % 6 == 2)
                    {
                        DrawBox(dc, sv, sx, sy, item.Along, 0.5 * 0.70 * length / 36.0, 0.5 * halfBeam, fb, fb + 0.7, Color.FromRgb(60, 86, 70), day, fog, out side, out end);
                    }
                }
                else if (item.Kind == 5)
                {
                    DrawBox(dc, sv, sx, sy, item.Along, 0.012 * length, 0.7 * halfBeam, fb + 1.0, fb + 1.9, Color.FromRgb(130, 136, 140), day, fog, out side, out end);     // the manifold
                }
                else if (item.Kind == 6)
                {
                    double postHeight = 0.05 * length;
                    DrawBox(dc, sv, sx, sy, item.Along, 0.006 * length, 0.012 * length, fb, fb + postHeight, Color.FromRgb(226, 226, 220), day, fog, out side, out end);
                    Line3(dc, sx, sy, item.Along, 0.5 * halfBeam, fb + postHeight, item.Along + 0.07 * length, 0.5 * halfBeam, fb + 0.03 * length,
                          Color.FromRgb(226, 226, 220), 2.0, day, fog);
                }
                else if (item.Kind == 7)
                {
                    DrawBox(dc, sv, sx, sy, item.Along, 0.06 * length, 0.62 * halfBeam, fb, fb + 1.6, Color.FromRgb(96, 108, 96), day, fog, out side, out end);
                    DrawBox(dc, sv, sx, sy, item.Along, 0.058 * length, 0.62 * halfBeam, fb + 1.6, fb + 2.1, Color.FromRgb(80, 92, 82), day, fog, out side, out end);
                }
                else if (item.Kind == 8)
                {
                    double post = 0.055 * length;
                    Color crane = Color.FromRgb(214, 204, 130);
                    DrawBox(dc, sv, sx, sy, item.Along, 0.006 * length, 0.018 * length, fb, fb + post, crane, day, fog, out side, out end);
                    Line3(dc, sx, sy, item.Along, 0.0, fb + post, item.Along + 0.09 * length, 0.0, fb + 0.05 * length, crane, 2.0, day, fog);
                    Line3(dc, sx, sy, item.Along, 0.0, fb + post, item.Along - 0.03 * length, 0.0, fb + post + 0.015 * length, crane, 1.0, day, fog);
                }
                else if (item.Kind == 1)
                {
                    Color funnelColour = tanker ? new Color[] { Color.FromRgb(30, 60, 130), Color.FromRgb(200, 40, 40), Color.FromRgb(240, 200, 40), Color.FromRgb(30, 30, 34) }[Math.Abs(ship.Id) % 4]
                                                : new Color[] { Color.FromRgb(200, 40, 40), Color.FromRgb(30, 60, 130), Color.FromRgb(240, 200, 40), Color.FromRgb(30, 30, 34) }[Math.Abs(ship.Id) % 4];
                    DrawBox(dc, sv, sx, sy, item.Along, 0.035 * length, halfBeam * 0.92, fb, fb + 0.82 * houseHeight, Color.FromRgb(238, 238, 232), day, fog, out side, out end);
                    WindowRows(dc, side, 3, 0.35, 0.3, true, day, fog);
                    WindowRows(dc, end, 3, 0.35, 0.3, false, day, fog);
                    Face wheelSide, wheelEnd;
                    DrawBox(dc, sv, sx, sy, item.Along, 0.026 * length, halfBeam * 0.98, fb + 0.82 * houseHeight, fb + houseHeight, Color.FromRgb(236, 236, 230), day, fog, out wheelSide, out wheelEnd);
                    WindowRows(dc, wheelSide, 1, 0.5, 0.3, true, day, fog);
                    WindowRows(dc, wheelEnd, 1, 0.5, 0.3, false, day, fog);
                    Face funnelSide, funnelEnd;
                    DrawBox(dc, sv, sx, sy, item.Along - 0.012 * length, 0.012 * length, 0.05 * length, fb + houseHeight, fb + houseHeight + 0.03 * length, funnelColour, day, fog, out funnelSide, out funnelEnd);
                    foreach (Face face in new Face[] { funnelSide, funnelEnd })
                    {
                        if (face.Visible)
                        {
                            Block(dc, Color.FromRgb(24, 24, 26), day, fog, face.X0, face.Top, face.X1 - face.X0, Math.Max(1.0, 0.008 * length * perMetre));
                        }
                    }
                    Block(dc, Color.FromRgb(214, 214, 208), day, fog, sx(item.Along + 0.01 * length, 0.0) - 1.0, sy(fb + houseHeight + 0.05 * length), 2.0, 0.05 * length * perMetre);
                }
                else
                {
                    DrawBox(dc, sv, sx, sy, item.Along, 0.02 * length, 0.4 * halfBeam, fb + rise, fb + rise + 2.5, Shade(look.Hull, 1.25), day, fog, out side, out end);
                    Block(dc, Color.FromRgb(214, 214, 208), day, fog, sx(item.Along, 0.0) - 1.0, sy(fb + rise + 2.5 + 0.035 * length), 2.0, 0.035 * length * perMetre);
                }
            }
            if (ship.SpeedKn > 3.0)
            {
                BowWave(dc, sv, sx(0.5 * length, 0.0), waterY, Math.Min(1.0, ship.SpeedKn / 18.0), 14.0, day, fog);
            }
        }

        // A harbour tug: a short, beamy hull with a high flared bow and a rounded stern, a row of tyres along the side, a two-storey house forward
        // with the wheelhouse overhanging, the funnel abaft it, a radar mast, the towing winch aft and a bitt on the bow.
        private void DrawTug(DrawingContext dc, WheelhouseContact ship, ShipLook look, ShipView sv, double xc, double waterY, double perMetre, double day, double fog)
        {
            double length = Math.Max(1.0, ship.LengthM);
            double halfBeam = 0.15 * length;                                        // a tug is much beamier than a ship
            double cosAlpha = Math.Cos(sv.AlphaDeg * Math.PI / 180.0);          // deg -> rad
            double sinAlpha = sv.SinAlpha;
            double fb = look.FreeboardM;
            double rise = 0.06 * length;
            Func<double, double, double> sx = (along, lateral) => xc + (along * sinAlpha + lateral * cosAlpha) * perMetre;
            Func<double, double> sy = (up) => waterY - up * perMetre;
            Func<double, double> deckHeight = (along) =>
            {
                double u = along / (0.5 * length);
                return fb - 0.12 * fb * (1.0 - u * u) + rise * Math.Pow(Math.Max(0.0, (u - 0.25) / 0.75), 2.0);
            };
            double[,] plan = { { -0.5 * length, -0.7 * halfBeam }, { -0.5 * length, 0.7 * halfBeam }, { -0.36 * length, halfBeam }, { 0.2 * length, halfBeam },
                               { 0.5 * length, 0.25 * halfBeam }, { 0.5 * length, -0.25 * halfBeam }, { 0.2 * length, -halfBeam }, { -0.36 * length, -halfBeam } };
            DrawPrismHull(dc, sv, sx, sy, plan, deckHeight, look, waterY, 0.88, day, fog);
            if (Math.Abs(sinAlpha) > 0.3 && length * perMetre > 40.0)
            {
                int sideSign = sinAlpha > 0.0 ? 1 : -1;
                int tyres = (int)Math.Max(3.0, Math.Min(14.0, 0.9 * length / 3.5));
                double radius = Math.Max(1.5, 0.02 * length * perMetre);
                for (int n = 0; n < tyres; n++)
                {
                    double u = -0.4 + 0.8 * n / (tyres - 1.0);
                    dc.DrawEllipse(Solid(Tint(Color.FromRgb(18, 18, 18), day, fog)), null, new Point(sx(u * length, sideSign * halfBeam), sy(fb - 0.6)), radius, radius * 1.2);
                }
            }
            int variant = (Math.Abs(ship.Id) / 3) % 3;          // 0 harbour tug, 1 ocean tug with a towing gantry, 2 old steam tug
            double houseHeight = look.HouseHeightM * (variant == 2 ? 0.7 : 1.0);
            double hs = variant == 1 ? 0.8 : 1.0;
            double houseAlong = look.HouseAlongM;
            List<DeckItem> items = new List<DeckItem>();
            items.Add(new DeckItem { Kind = 1, Along = houseAlong });
            items.Add(new DeckItem { Kind = 2, Along = houseAlong - 0.2 * length });
            items.Add(new DeckItem { Kind = 3, Along = -0.3 * length });
            items.Add(new DeckItem { Kind = 4, Along = 0.38 * length });
            foreach (DeckItem item in items)
            {
                item.Away = item.Along * cosAlpha;
            }
            items.Sort((p, q) => q.Away.CompareTo(p.Away));
            Face side, end;
            foreach (DeckItem item in items)
            {
                if (item.Kind == 1)
                {
                    DrawBox(dc, sv, sx, sy, item.Along, 0.15 * length * hs, 0.62 * halfBeam, fb, fb + 0.55 * houseHeight, look.House, day, fog, out side, out end);
                    WindowRows(dc, side, 1, 0.4, 0.3, true, day, fog);
                    WindowRows(dc, end, 1, 0.4, 0.3, false, day, fog);
                    Face wheelSide, wheelEnd;
                    DrawBox(dc, sv, sx, sy, item.Along + 0.01 * length, 0.11 * length * hs, 0.72 * halfBeam, fb + 0.55 * houseHeight, fb + houseHeight, look.House, day, fog, out wheelSide, out wheelEnd);
                    foreach (Face face in new Face[] { wheelSide, wheelEnd })
                    {
                        if (face.Visible)
                        {
                            double faceWidth = face.X1 - face.X0;
                            Block(dc, Color.FromRgb(32, 42, 56), day, fog, face.X0 + faceWidth * 0.05, face.Top + (face.Bottom - face.Top) * 0.25, faceWidth * 0.9, (face.Bottom - face.Top) * 0.45);
                            for (int m = 1; m < 1; m++)
                            {
                                Block(dc, look.House, day, fog, face.X0 + faceWidth * 0.05 + m * faceWidth * 0.9 / 5.0, face.Top + (face.Bottom - face.Top) * 0.25, 1.0, (face.Bottom - face.Top) * 0.45);
                            }
                        }
                    }
                    DrawBox(dc, sv, sx, sy, item.Along + 0.01 * length, 0.115 * length * hs, 0.76 * halfBeam, fb + houseHeight, fb + houseHeight + 0.015 * length, Shade(look.House, 0.8), day, fog, out side, out end);
                    double mastX = sx(item.Along + 0.05 * length, 0.0);
                    double mastTop = sy(fb + houseHeight + look.MastM);
                    Block(dc, Color.FromRgb(214, 214, 208), day, fog, mastX - 1.0, mastTop, 2.0, look.MastM * perMetre);
                    Block(dc, Color.FromRgb(70, 70, 74), day, fog, mastX - 5.0, mastTop - 2.0, 10.0, 2.0);
                }
                else if (item.Kind == 2)
                {
                    double stackLength = variant == 1 ? 0.07 * length : (variant == 2 ? 0.025 * length : 0.05 * length);
                    double stackWidth = variant == 1 ? 0.35 * halfBeam : (variant == 2 ? 0.14 * halfBeam : 0.2 * halfBeam);
                    double stackTop = variant == 1 ? 1.6 : (variant == 2 ? 2.2 : 1.35);
                    DrawBox(dc, sv, sx, sy, item.Along, stackLength, stackWidth, fb + 0.55 * houseHeight, fb + houseHeight * stackTop, Color.FromRgb(30, 30, 34), day, fog, out side, out end);
                    foreach (Face face in new Face[] { side, end })
                    {
                        if (face.Visible)
                        {
                            Block(dc, Color.FromRgb(200, 40, 40), day, fog, face.X0, face.Top, face.X1 - face.X0, Math.Max(1.0, 0.012 * length * perMetre));
                        }
                    }
                }
                else if (item.Kind == 3)
                {
                    DrawBox(dc, sv, sx, sy, item.Along, 0.06 * length, 0.35 * halfBeam, fb, fb + 0.05 * length, Color.FromRgb(70, 74, 70), day, fog, out side, out end);
                }
                else
                {
                    DrawBox(dc, sv, sx, sy, item.Along, 0.012 * length, 0.06 * halfBeam, fb + rise, fb + rise + 0.03 * length, Color.FromRgb(80, 80, 80), day, fog, out side, out end);
                }
            }
            if (variant == 1)
            {
                // the towing gantry: an arch over the afterdeck
                double postUp = fb + 0.2 * length;
                Line3(dc, sx, sy, -0.33 * length, -0.7 * halfBeam, fb, -0.33 * length, -0.7 * halfBeam, postUp, Color.FromRgb(70, 74, 70), 2.0, day, fog);
                Line3(dc, sx, sy, -0.33 * length, 0.7 * halfBeam, fb, -0.33 * length, 0.7 * halfBeam, postUp, Color.FromRgb(70, 74, 70), 2.0, day, fog);
                Line3(dc, sx, sy, -0.33 * length, -0.7 * halfBeam, postUp, -0.33 * length, 0.7 * halfBeam, postUp, Color.FromRgb(70, 74, 70), 2.0, day, fog);
            }
            if (ship.SpeedKn > 2.0)
            {
                BowWave(dc, sv, sx(0.5 * length, 0.0), waterY, Math.Min(1.0, ship.SpeedKn / 8.0), 14.0, day, fog);
            }
        }

        // A fishing boat: a pointed bow with a high stem, the house and wheelhouse forward, a mast with a derrick boom and the stays to bow and stern,
        // an A-frame gantry at the stern, and a pile of net and floats on the after deck.
        private void DrawFishingBoat(DrawingContext dc, WheelhouseContact ship, ShipLook look, ShipView sv, double xc, double waterY, double perMetre, double day, double fog)
        {
            double length = Math.Max(1.0, ship.LengthM);
            double halfBeam = 0.125 * length;
            double cosAlpha = Math.Cos(sv.AlphaDeg * Math.PI / 180.0);          // deg -> rad
            double sinAlpha = sv.SinAlpha;
            double fb = look.FreeboardM;
            double rise = 0.07 * length;
            Func<double, double, double> sx = (along, lateral) => xc + (along * sinAlpha + lateral * cosAlpha) * perMetre;
            Func<double, double> sy = (up) => waterY - up * perMetre;
            Func<double, double> deckHeight = (along) =>
            {
                double u = along / (0.5 * length);
                return fb - 0.12 * fb * (1.0 - u * u) + rise * Math.Pow(Math.Max(0.0, (u - 0.2) / 0.8), 2.0);
            };
            double[,] plan = { { -0.5 * length, -0.6 * halfBeam }, { -0.5 * length, 0.6 * halfBeam }, { -0.3 * length, halfBeam }, { 0.15 * length, halfBeam },
                               { 0.5 * length, 0.0 }, { 0.15 * length, -halfBeam }, { -0.3 * length, -halfBeam } };
            DrawPrismHull(dc, sv, sx, sy, plan, deckHeight, look, waterY, 0.86, day, fog);
            int variant = (Math.Abs(ship.Id) / 3) % 3;          // 0 stern trawler, 1 small cabin boat, 2 shrimper with outriggers
            double houseHeight = look.HouseHeightM * (variant == 1 ? 0.8 : 1.0);
            double houseAlong = look.HouseAlongM;
            List<DeckItem> items = new List<DeckItem>();
            items.Add(new DeckItem { Kind = 1, Along = houseAlong });
            items.Add(new DeckItem { Kind = 2, Along = -0.25 * length });
            items.Add(new DeckItem { Kind = 3, Along = 0.05 * length });
            foreach (DeckItem item in items)
            {
                item.Away = item.Along * cosAlpha;
            }
            items.Sort((p, q) => q.Away.CompareTo(p.Away));
            Face side, end;
            foreach (DeckItem item in items)
            {
                if (item.Kind == 1)
                {
                    DrawBox(dc, sv, sx, sy, item.Along, 0.11 * length, 0.6 * halfBeam, fb, fb + 0.6 * houseHeight, look.House, day, fog, out side, out end);
                    WindowRows(dc, side, 1, 0.5, 0.25, true, day, fog);
                    WindowRows(dc, end, 1, 0.5, 0.25, false, day, fog);
                    Face wheelSide, wheelEnd;
                    DrawBox(dc, sv, sx, sy, item.Along + 0.01 * length, 0.08 * length, 0.5 * halfBeam, fb + 0.6 * houseHeight, fb + houseHeight, look.House, day, fog, out wheelSide, out wheelEnd);
                    foreach (Face face in new Face[] { wheelSide, wheelEnd })
                    {
                        if (face.Visible)
                        {
                            Block(dc, Color.FromRgb(32, 42, 56), day, fog, face.X0 + (face.X1 - face.X0) * 0.06, face.Top + (face.Bottom - face.Top) * 0.25, (face.X1 - face.X0) * 0.88, (face.Bottom - face.Top) * 0.45);
                        }
                    }
                    DrawBox(dc, sv, sx, sy, item.Along + 0.01 * length, 0.085 * length, 0.55 * halfBeam, fb + houseHeight, fb + houseHeight + 0.012 * length, Shade(look.House, 0.8), day, fog, out side, out end);
                }
                else if (item.Kind == 2 && variant == 1)
                {
                    DrawBox(dc, sv, sx, sy, item.Along, 0.05 * length, 0.4 * halfBeam, fb, fb + 0.04 * length, Color.FromRgb(150, 150, 146), day, fog, out side, out end);      // fish boxes
                }
                else if (item.Kind == 2)
                {
                    DrawBox(dc, sv, sx, sy, item.Along, 0.08 * length, 0.5 * halfBeam, fb, fb + 0.07 * length, Color.FromRgb(210, 130, 40), day, fog, out side, out end);
                    DrawBox(dc, sv, sx, sy, item.Along + 0.04 * length, 0.03 * length, 0.4 * halfBeam, fb + 0.07 * length, fb + 0.1 * length, Color.FromRgb(60, 110, 70), day, fog, out side, out end);
                }
                else
                {
                    DrawBox(dc, sv, sx, sy, item.Along, 0.03 * length, 0.3 * halfBeam, fb, fb + 0.05 * length, Color.FromRgb(110, 110, 106), day, fog, out side, out end);
                }
            }
            // the mast on the house, the derrick boom, the stays and the A-frame
            double mastAlong = houseAlong + 0.05 * length;
            double mastTopUp = fb + houseHeight + look.MastM;
            Color gear = Color.FromRgb(70, 70, 72);
            Line3(dc, sx, sy, mastAlong, 0.0, fb + houseHeight, mastAlong, 0.0, mastTopUp, Color.FromRgb(214, 214, 208), 2.0, day, fog);
            if (variant == 0)
            {
                Line3(dc, sx, sy, mastAlong, 0.0, fb + houseHeight * 0.7, mastAlong - 0.2 * length, 0.5 * halfBeam, fb + 0.13 * length, Color.FromRgb(60, 60, 60), 2.0, day, fog);
            }
            Line3(dc, sx, sy, mastAlong, 0.0, mastTopUp, 0.5 * length, 0.0, fb + rise, gear, 1.0, day, fog);
            Line3(dc, sx, sy, mastAlong, 0.0, mastTopUp, -0.5 * length, 0.0, fb, gear, 1.0, day, fog);
            if (variant == 0)
            {
                Line3(dc, sx, sy, -0.42 * length, -0.7 * halfBeam, fb, -0.40 * length, 0.0, fb + 0.28 * length, Color.FromRgb(60, 60, 60), 2.0, day, fog);
                Line3(dc, sx, sy, -0.42 * length, 0.7 * halfBeam, fb, -0.40 * length, 0.0, fb + 0.28 * length, Color.FromRgb(60, 60, 60), 2.0, day, fog);
            }
            else if (variant == 2)
            {
                // outriggers: a long boom out to each side from the mast, held up by a line from the masthead
                for (int s = -1; s <= 1; s += 2)
                {
                    Line3(dc, sx, sy, mastAlong, 0.0, fb + houseHeight * 0.8, mastAlong - 0.04 * length, s * 0.38 * length, fb + 0.22 * length, Color.FromRgb(60, 60, 60), 2.0, day, fog);
                    Line3(dc, sx, sy, mastAlong, 0.0, mastTopUp, mastAlong - 0.04 * length, s * 0.38 * length, fb + 0.22 * length, gear, 1.0, day, fog);
                }
            }
            if (ship.SpeedKn > 2.0)
            {
                BowWave(dc, sv, sx(0.5 * length, 0.0), waterY, Math.Min(1.0, ship.SpeedKn / 8.0), 10.0, day, fog);
            }
        }

        // A sailing vessel: a long narrow hull with a pointed bow, a low cabin trunk, and a gaff rig: one, two or three masts, each with a gaff mainsail
        // and topsail, with headsails from the foremast to the bowsprit. The sails stand in the ship's centre plane, so they thin out end-on.
        private void DrawSailingVessel(DrawingContext dc, WheelhouseContact ship, ShipLook look, ShipView sv, double xc, double waterY, double perMetre, double day, double fog)
        {
            double length = Math.Max(1.0, ship.LengthM);
            double halfBeam = 0.1 * length;
            double cosAlpha = Math.Cos(sv.AlphaDeg * Math.PI / 180.0);          // deg -> rad
            double sinAlpha = sv.SinAlpha;
            double fb = look.FreeboardM;
            double rise = look.BowRiseM;
            Func<double, double, double> sx = (along, lateral) => xc + (along * sinAlpha + lateral * cosAlpha) * perMetre;
            Func<double, double> sy = (up) => waterY - up * perMetre;
            Func<double, double> deckHeight = (along) =>
            {
                double u = along / (0.5 * length);
                return fb - 0.18 * fb * (1.0 - u * u) + rise * Math.Pow(Math.Max(0.0, (u - 0.1) / 0.9), 2.0);
            };
            double[,] plan = { { -0.5 * length, -0.35 * halfBeam }, { -0.5 * length, 0.35 * halfBeam }, { -0.15 * length, halfBeam }, { 0.25 * length, halfBeam },
                               { 0.5 * length, 0.0 }, { 0.25 * length, -halfBeam }, { -0.15 * length, -halfBeam } };
            DrawPrismHull(dc, sv, sx, sy, plan, deckHeight, look, waterY, 0.8, day, fog);
            Face side, end;
            DrawBox(dc, sv, sx, sy, -0.08 * length, 0.1 * length, 0.45 * halfBeam, fb, fb + 0.05 * length, look.Hull.R > 200 ? Color.FromRgb(210, 206, 190) : Shade(look.Hull, 1.1), day, fog, out side, out end);
            int rig = (Math.Abs(ship.Id) / 3) % 3;                     // 0 gaff schooner/cutter, 1 Bermudan sloop, 2 Bermudan ketch
            if (rig != 0)
            {
                double[] bermudaAlong = rig == 1 ? new double[] { 0.05 } : new double[] { 0.1, -0.24 };
                double[] bermudaHeight = rig == 1 ? new double[] { 1.15 * length } : new double[] { 1.0 * length, 0.6 * length };
                double[] bermudaBoom = rig == 1 ? new double[] { 0.3 * length } : new double[] { 0.26 * length, 0.13 * length };
                Color mainColour = Color.FromRgb(244, 242, 232);
                Color headColour = Color.FromRgb(226, 224, 212);
                Color mastColour = Color.FromRgb(190, 190, 186);
                double mainMast = bermudaAlong[0] * length;
                Polygon(dc, Solid(Tint(headColour, day, fog)), null, new Point(sx(mainMast + 0.01 * length, 0.0), sy(fb + 0.93 * bermudaHeight[0])),
                        new Point(sx(0.47 * length, 0.0), sy(fb + 0.8)), new Point(sx(mainMast + 0.01 * length, 0.0), sy(fb + 0.8)));
                for (int n = 0; n < bermudaAlong.Length; n++)
                {
                    double m = bermudaAlong[n] * length;
                    double h = bermudaHeight[n];
                    Polygon(dc, Solid(Tint(mainColour, day, fog)), null, new Point(sx(m, 0.0), sy(fb + 1.0)), new Point(sx(m, 0.0), sy(fb + 0.97 * h)),
                            new Point(sx(m - bermudaBoom[n], 0.0), sy(fb + 1.0)));
                    dc.DrawLine(new Pen(Solid(Tint(mastColour, day, fog)), 2.0), new Point(sx(m, 0.0), sy(fb)), new Point(sx(m, 0.0), sy(fb + h)));
                    dc.DrawLine(new Pen(Solid(Tint(mastColour, day, fog)), 1.0), new Point(sx(m, 0.0), sy(fb + 1.0)), new Point(sx(m - bermudaBoom[n], 0.0), sy(fb + 1.0)));
                    dc.DrawLine(new Pen(Solid(Tint(Color.FromRgb(90, 90, 90), day, fog)), 1.0), new Point(sx(m, 0.0), sy(fb + h)), new Point(sx(-0.5 * length, 0.0), sy(fb + 0.4)));
                }
                dc.DrawLine(new Pen(Solid(Tint(Color.FromRgb(90, 90, 90), day, fog)), 1.0), new Point(sx(mainMast, 0.0), sy(fb + bermudaHeight[0])), new Point(sx(0.5 * length, 0.0), sy(fb + rise)));
                if (ship.SpeedKn > 1.0)
                {
                    BowWave(dc, sv, sx(0.5 * length, 0.0), waterY, Math.Min(1.0, ship.SpeedKn / 8.0), 8.0, day, fog);
                }
                return;
            }
            int masts = Math.Max(1, look.Masts);
            double[] mastAlong = masts == 1 ? new double[] { 0.04 } : (masts == 2 ? new double[] { 0.14, -0.14 } : new double[] { 0.24, 0.0, -0.24 });
            double mastHeight = (masts == 1 ? 1.0 : 0.8) * length;
            double boomLength = (masts == 1 ? 0.3 : 0.2) * length;
            Color sailColour = Color.FromRgb(240, 236, 220);
            Color sailShade = Color.FromRgb(224, 220, 204);
            Color spar = Color.FromRgb(120, 84, 44);
            double foreAlong = mastAlong[0] * length;
            Polygon(dc, Solid(Tint(sailShade, day, fog)), null, new Point(sx(foreAlong + 0.01 * length, 0.0), sy(fb + 0.9 * mastHeight)),
                    new Point(sx(foreAlong + 0.01 * length, 0.0), sy(fb + 0.5)), new Point(sx(0.55 * length, 0.0), sy(fb + 0.6)));
            Polygon(dc, Solid(Tint(sailShade, day, fog)), null, new Point(sx(foreAlong + 0.01 * length, 0.0), sy(fb + 0.62 * mastHeight)),
                    new Point(sx(foreAlong + 0.01 * length, 0.0), sy(fb + 0.5)), new Point(sx(0.4 * length, 0.0), sy(fb + 0.5)));
            for (int n = 0; n < masts; n++)
            {
                double m = mastAlong[n] * length;
                double h = mastHeight * (n == 0 && masts > 1 ? 0.92 : 1.0);
                Point tack = new Point(sx(m, 0.0), sy(fb + 0.9));
                Point throat = new Point(sx(m, 0.0), sy(fb + 0.6 * h));
                Point peak = new Point(sx(m - 0.65 * boomLength, 0.0), sy(fb + 0.74 * h));
                Point clew = new Point(sx(m - boomLength, 0.0), sy(fb + 0.9));
                Polygon(dc, Solid(Tint(sailColour, day, fog)), null, tack, throat, peak, clew);
                Polygon(dc, Solid(Tint(sailShade, day, fog)), null, throat, new Point(sx(m, 0.0), sy(fb + h)), peak);
                Pen sparPen = new Pen(Solid(Tint(spar, day, fog)), 1.0);
                dc.DrawLine(new Pen(Solid(Tint(spar, day, fog)), 2.0), new Point(sx(m, 0.0), sy(fb)), new Point(sx(m, 0.0), sy(fb + h)));
                dc.DrawLine(sparPen, tack, clew);
                dc.DrawLine(sparPen, throat, peak);
            }
            if (ship.SpeedKn > 1.0)
            {
                BowWave(dc, sv, sx(0.5 * length, 0.0), waterY, Math.Min(1.0, ship.SpeedKn / 8.0), 8.0, day, fog);
            }
        }

        // ---- the container ship, drawn as a solid: every box shows the faces that face the viewer ----

        private class Face
        {
            public bool Visible;
            public double X0, X1, Top, Bottom;
        }

        // A box (hull, stack, house) centred `along` the ship and `halfLength` and `halfWidth` big, from heightBottom to heightTop above the
        // water. The side that faces the viewer and the end that faces the viewer are drawn side by side, the end a little darker, so the
        // ship's heading reads at any angle. 'side' is the starboard side when the ship is seen from the starboard, else the port side.
        private void DrawBox(DrawingContext dc, ShipView sv, Func<double, double, double> sx, Func<double, double> sy, double along, double halfLength,
                             double halfWidth, double heightBottom, double heightTop, Color colour, double day, double fog, out Face side, out Face end)
        {
            double cosAlpha = Math.Cos(sv.AlphaDeg * Math.PI / 180.0);          // deg -> rad
            side = new Face();
            end = new Face();
            if (Math.Abs(sv.SinAlpha) > 1e-6)
            {
                int sideSign = sv.SinAlpha > 0.0 ? 1 : -1;
                double x0 = sx(along - halfLength, sideSign * halfWidth);
                double x1 = sx(along + halfLength, sideSign * halfWidth);
                side.Visible = true;
                side.X0 = Math.Min(x0, x1);
                side.X1 = Math.Max(x0, x1);
                side.Top = sy(heightTop);
                side.Bottom = sy(heightBottom);
                Block(dc, Shade(colour, 0.74 + 0.26 * Math.Abs(sv.SinAlpha)), day, fog, side.X0, side.Top, side.X1 - side.X0, side.Bottom - side.Top);
            }
            if (Math.Abs(cosAlpha) > 1e-6)
            {
                int endSign = cosAlpha < 0.0 ? 1 : -1;                          // the bow end faces the viewer when the ship comes toward them
                double x0 = sx(along + endSign * halfLength, -halfWidth);
                double x1 = sx(along + endSign * halfLength, halfWidth);
                end.Visible = true;
                end.X0 = Math.Min(x0, x1);
                end.X1 = Math.Max(x0, x1);
                end.Top = sy(heightTop);
                end.Bottom = sy(heightBottom);
                Block(dc, Shade(colour, 0.74 + 0.26 * Math.Abs(cosAlpha)), day, fog, end.X0, end.Top, end.X1 - end.X0, end.Bottom - end.Top);
            }
        }

        private class DeckItem
        {
            public int Kind;                // 0 container bay, 1 house, 2 funnel, 3 forecastle, 4 poop
            public double Along, Away;
            public int Bay, Tiers;
        }

        private void DrawContainerShip(DrawingContext dc, WheelhouseContact ship, ShipLook look, ShipView sv, double xc, double waterY, double perMetre, double day, double fog)
        {
            double length = Math.Max(1.0, ship.LengthM);
            double beam = WheelhouseMath.BeamM(length);
            double halfBeam = beam / 2.0;
            double cosAlpha = Math.Cos(sv.AlphaDeg * Math.PI / 180.0);          // deg -> rad
            double sinAlpha = sv.SinAlpha;
            double fb = look.FreeboardM;
            double bowRise = look.BowRiseM;
            Func<double, double, double> sx = (along, lateral) => xc + (along * sinAlpha + lateral * cosAlpha) * perMetre;
            Func<double, double> sy = (up) => waterY - up * perMetre;
            Func<double, double> deckHeight = (along) =>
            {
                double u = along / (0.5 * length);
                return fb - 0.1 * fb * (1.0 - u * u) + bowRise * Math.Pow(Math.Max(0.0, (u - 0.2) / 0.8), 2.0);        // sags amidships, rises to the bow
            };

            double[,] plan = { { -0.5 * length, -halfBeam }, { -0.5 * length, halfBeam }, { 0.36 * length, halfBeam }, { 0.5 * length, 0.0 }, { 0.36 * length, -halfBeam } };
            DrawPrismHull(dc, sv, sx, sy, plan, deckHeight, look, waterY, 0.82, day, fog);
            // the company's name along the side that faces the viewer
            if (Math.Abs(sinAlpha) > 0.3 && length * Math.Abs(sinAlpha) * perMetre > 60.0)
            {
                int sideSign = sinAlpha > 0.0 ? 1 : -1;
                for (int k = 0; k < 4; k++)
                {
                    double x0 = sx((-0.06 + 0.016 * k) * length, sideSign * halfBeam);
                    double x1 = sx((-0.06 + 0.016 * k + 0.011) * length, sideSign * halfBeam);
                    Block(dc, Color.FromRgb(238, 238, 234), day, fog, Math.Min(x0, x1), sy(fb * 0.72), Math.Abs(x1 - x0), fb * 0.34 * perMetre);
                }
            }
            if (ship.SpeedKn > 3.0 && length * perMetre > 60.0)
            {
                double speed = Math.Min(1.0, ship.SpeedKn / 18.0);
                double bowX = sx(0.5 * length, 0.0);
                Polygon(dc, Solid(Tint(Color.FromRgb(244, 248, 250), day, fog), 0.9), null, new Point(bowX, waterY),
                        new Point(bowX - 6.0 * speed - 18.0 * speed * sinAlpha, waterY + 3.0), new Point(bowX + 12.0 * speed, waterY - 0.07 * fb * perMetre * speed - 1.0));
            }

            // Things on deck, from the farthest to the nearest: the container bays, the house, the funnel, the forecastle and the poop.
            List<DeckItem> items = new List<DeckItem>();
            double houseAlong = look.HouseAlongM;
            double bayLength = 12.2;                                    // a 40 foot container, m
            double spanStart = -0.46 * length;
            double spanLength = 0.86 * length;
            int count = (int)Math.Max(3.0, Math.Min(40.0, spanLength / bayLength));
            double step = spanLength / count;
            for (int k = 0; k < count; k++)
            {
                double along = spanStart + (k + 0.5) * step;
                if (Math.Abs(along - houseAlong) < 0.055 * length)
                {
                    continue;                                           // the bridge stands here
                }
                int tiers;
                if (along > houseAlong)
                {
                    double ahead = (along - houseAlong) / (0.5 * length - houseAlong);
                    tiers = (int)Math.Round(8.0 - 4.0 * Math.Pow(ahead, 1.4));       // falling away toward the bow, so the bridge can see over them
                }
                else
                {
                    double abaft = (houseAlong - along) / (houseAlong + 0.5 * length);
                    tiers = (int)Math.Round(8.0 - 2.2 * abaft);
                }
                tiers -= (int)(Hash(ship.Id, k) * 2.0);
                tiers = Math.Max(2, Math.Min(tiers, 9));
                items.Add(new DeckItem { Kind = 0, Along = along, Bay = k, Tiers = tiers });
            }
            items.Add(new DeckItem { Kind = 1, Along = houseAlong });
            items.Add(new DeckItem { Kind = 2, Along = houseAlong - 0.062 * length });
            items.Add(new DeckItem { Kind = 3, Along = 0.45 * length });
            items.Add(new DeckItem { Kind = 4, Along = -0.47 * length });
            foreach (DeckItem item in items)
            {
                item.Away = item.Along * cosAlpha;
            }
            items.Sort((a, b) => b.Away.CompareTo(a.Away));

            double deck = fb + 1.4;
            Face side, end;
            foreach (DeckItem item in items)
            {
                if (item.Kind == 0)
                {
                    for (int tier = 0; tier < item.Tiers; tier++)
                    {
                        Color box = ContainerColours[(int)(Hash(ship.Id * 7 + item.Bay, tier) * ContainerColours.Length) % ContainerColours.Length];
                        DrawBox(dc, sv, sx, sy, item.Along, bayLength * 0.47, halfBeam * 0.82, deck + tier * 2.6, deck + (tier + 1) * 2.6, box, day, fog, out side, out end);
                        foreach (Face face in new Face[] { side, end })
                        {
                            if (face.Visible && face.Bottom - face.Top > 6.0 && face.X1 - face.X0 > 5.0)
                            {
                                Color dark = Shade(box, 0.6);
                                Block(dc, dark, day, fog, face.X0, face.Top, face.X1 - face.X0, 1.0);
                                Block(dc, dark, day, fog, face.X0, face.Top, 1.0, face.Bottom - face.Top);
                                if (face == side)
                                {
                                    Color rib = Shade(box, 0.82);
                                    for (int q = 1; q < 5; q++)
                                    {
                                        Block(dc, rib, day, fog, face.X0 + q * (face.X1 - face.X0) / 5.0, face.Top + 1.0, 0.7, face.Bottom - face.Top - 2.0);
                                    }
                                }
                            }
                        }
                    }
                }
                else if (item.Kind == 1)
                {
                    DrawContainerHouse(dc, ship, look, sv, sx, sy, perMetre, length, item.Along, day, fog);
                }
                else if (item.Kind == 2)
                {
                    double houseHeight = look.HouseHeightM;
                    Color[] funnelColours = { Color.FromRgb(30, 60, 130), Color.FromRgb(200, 40, 40), Color.FromRgb(240, 200, 40), Color.FromRgb(30, 30, 34) };
                    DrawBox(dc, sv, sx, sy, item.Along, 0.018 * length, 0.034 * length, fb + 0.35 * houseHeight, fb + 0.93 * houseHeight,
                            funnelColours[Math.Abs(ship.Id) % 4], day, fog, out side, out end);
                    foreach (Face face in new Face[] { side, end })
                    {
                        if (face.Visible)
                        {
                            Block(dc, Color.FromRgb(24, 24, 26), day, fog, face.X0, face.Top, face.X1 - face.X0, Math.Max(1.0, 0.012 * length * perMetre));
                        }
                    }
                    Block(dc, Color.FromRgb(70, 70, 74), day, fog, sx(item.Along, 0.0) - 3.0, sy(fb + 0.93 * houseHeight) - 0.012 * length * perMetre, 6.0, 0.012 * length * perMetre);
                }
                else if (item.Kind == 3)
                {
                    DrawBox(dc, sv, sx, sy, item.Along, 0.03 * length, halfBeam * 0.5, fb + bowRise, fb + bowRise + 3.0, Shade(look.Hull, 1.25), day, fog, out side, out end);
                    Block(dc, Color.FromRgb(214, 214, 208), day, fog, sx(item.Along, 0.0) - 1.0, sy(fb + bowRise + 3.0 + 0.04 * length), 2.0, 0.04 * length * perMetre);
                }
                else
                {
                    DrawBox(dc, sv, sx, sy, item.Along, 0.03 * length, halfBeam * 0.6, fb, fb + 3.0, Shade(look.Hull, 1.25), day, fog, out side, out end);
                }
            }
        }

        // The house: five decks of cabins with rows of windows, a wheelhouse on top that is wider across than the decks below, lifeboats,
        // and a radar mast with its scanner. The windows are drawn on whichever faces the viewer sees.
        private void DrawContainerHouse(DrawingContext dc, WheelhouseContact ship, ShipLook look, ShipView sv, Func<double, double, double> sx, Func<double, double> sy,
                                        double perMetre, double length, double along, double day, double fog)
        {
            double halfBeam = WheelhouseMath.BeamM(length) / 2.0;
            double fb = look.FreeboardM;
            double houseHeight = look.HouseHeightM;
            Color window = Color.FromRgb(32, 42, 56);
            Face side, end;
            DrawBox(dc, sv, sx, sy, along, 0.035 * length, halfBeam * 0.92, fb, fb + 0.84 * houseHeight, Color.FromRgb(238, 238, 232), day, fog, out side, out end);
            foreach (Face face in new Face[] { side, end })
            {
                if (!face.Visible)
                {
                    continue;
                }
                double height = face.Bottom - face.Top;
                double width = face.X1 - face.X0;
                for (int deckNumber = 0; deckNumber < 5; deckNumber++)
                {
                    double y = face.Top + height * (deckNumber + 0.25) / 5.0;
                    double windowHeight = Math.Max(1.0, height / 5.0 * 0.35);
                    Block(dc, window, day, fog, face.X0 + width * 0.06, y, width * 0.88, windowHeight);
                    if (face == side && width > 40.0)
                    {
                        int dividers = (int)(width * 0.88 / 6.0);
                        for (int m = 1; m < dividers; m++)
                        {
                            Block(dc, Color.FromRgb(238, 238, 232), day, fog, face.X0 + width * 0.06 + m * 6.0, y, 1.0, windowHeight);
                        }
                    }
                    if (deckNumber > 0)
                    {
                        Block(dc, Color.FromRgb(185, 185, 180), day, fog, face.X0, face.Top + height * deckNumber / 5.0, width, 1.0);
                    }
                }
            }
            Face wheelSide, wheelEnd;
            DrawBox(dc, sv, sx, sy, along, 0.028 * length, halfBeam, fb + 0.84 * houseHeight, fb + houseHeight, Color.FromRgb(236, 236, 230), day, fog, out wheelSide, out wheelEnd);
            foreach (Face face in new Face[] { wheelSide, wheelEnd })
            {
                if (face.Visible)
                {
                    Block(dc, window, day, fog, face.X0 + (face.X1 - face.X0) * 0.04, face.Top + (face.Bottom - face.Top) * 0.3, (face.X1 - face.X0) * 0.92, (face.Bottom - face.Top) * 0.4);
                }
            }
            if (side.Visible)
            {
                Color orange = Color.FromRgb(226, 110, 36);
                foreach (double fraction in new double[] { 0.25, 0.75 })
                {
                    Block(dc, orange, day, fog, side.X0 + (side.X1 - side.X0) * fraction - 5.0, side.Top + (side.Bottom - side.Top) * 0.45, 10.0, 6.0);
                }
            }
            double mastX = sx(along, 0.0);
            double mastTop = sy(fb + houseHeight + 0.11 * length);
            Block(dc, Color.FromRgb(214, 214, 208), day, fog, mastX - 1.0, mastTop, 2.0, 0.11 * length * perMetre);
            double scanner = 8.0 * (0.4 + 0.6 * Math.Abs(sv.SinAlpha));
            Block(dc, Color.FromRgb(70, 70, 74), day, fog, mastX - scanner / 2.0, mastTop - 2.0, scanner, 2.0);
        }

        // Cargo on deck: stacks of containers, a tanker's pipes and kingposts, a bulk carrier's hatches and cranes.
        private void DrawCargo(DrawingContext dc, WheelhouseContact ship, ShipLook look, ShipView sv, Func<double, double, double> sx, Func<double, double> sy,
                               double perMetre, double beam, double cosAlpha, double day, double fog, double cosTheta)
        {
            double length = Math.Max(1.0, ship.LengthM);
            double deck = look.FreeboardM;
            if (ship.Kind == "fishing")
            {
                // an A-frame gantry at the stern, and the gear stowed on deck forward of the house
                dc.DrawLine(new Pen(Solid(Tint(Color.FromRgb(60, 60, 60), day, fog)), Math.Max(1.0, 0.012 * length * perMetre)),
                            new Point(sx(-0.45 * length, 0.0), sy(deck)), new Point(sx(-0.38 * length, 0.0), sy(deck + 0.28 * length)));
                dc.DrawRectangle(Solid(Tint(Color.FromRgb(210, 130, 40), day, fog)), null,
                                 new Rect(sx(0.0, 0.0) - 0.06 * length * perMetre * Math.Abs(sv.SinAlpha) - 1.0, sy(deck + 0.07 * length),
                                          0.12 * length * perMetre * Math.Abs(sv.SinAlpha) + 2.0, 0.07 * length * perMetre + 1.0));
                // a derrick boom from the foot of the mast out over the side, and the stays that hold the mast: to the bow and to the stern
                Pen gear = new Pen(Solid(Tint(Color.FromRgb(70, 70, 72), day, fog)), 1.0);
                double mastAlong = look.HouseAlongM + 0.05 * length;
                Point mastHead = new Point(sx(mastAlong, 0.0), sy(deck + look.HouseHeightM + look.MastM));
                Point boomFoot = new Point(sx(mastAlong, 0.0), sy(deck + 0.12 * length));
                dc.DrawLine(new Pen(Solid(Tint(Color.FromRgb(60, 60, 60), day, fog)), Math.Max(1.0, 0.01 * length * perMetre)),
                            boomFoot, new Point(sx(mastAlong - 0.1 * length, 0.0), sy(deck + 0.2 * length)));
                dc.DrawLine(gear, mastHead, new Point(sx(0.5 * length, 0.0), sy(deck)));
                dc.DrawLine(gear, mastHead, new Point(sx(-0.5 * length, 0.0), sy(deck)));
                return;
            }
            if (look.Cargo == 0)
            {
                if (ship.Kind == "barge")
                {
                    // a deck cargo of blocks
                    double blockWidth = (0.3 * length * Math.Abs(sv.SinAlpha) + 0.7 * beam * Math.Abs(cosAlpha)) * perMetre;
                    dc.DrawRectangle(Solid(Tint(Color.FromRgb(96, 86, 70), day, fog)), null,
                                     new Rect(sx(0.0, 0.0) - blockWidth / 2.0, sy(deck + 3.0), blockWidth, 3.0 * perMetre + 1.0));
                }
                return;
            }
            double blockLength = Math.Max(3.0, 0.045 * length);
            double spanStart = look.Cargo == 1 ? -0.46 : (look.Cargo == 2 ? -0.32 : -0.2);          // where the cargo starts abaft the bow, as a fraction of the length
            double spanLength = look.Cargo == 1 ? 0.86 : (look.Cargo == 2 ? 0.74 : 0.62);
            int count = (int)Math.Max(3.0, Math.Min(30.0, spanLength * length / blockLength));
            double firstAlong = spanStart * length;
            // draw the stacks nearest the viewer last
            for (int n = 0; n < count; n++)
            {
                int k = cosTheta >= 0.0 ? n : count - 1 - n;
                double along = firstAlong + (k + 0.5) * (spanLength * length / count);
                if (look.Cargo == 1 && Math.Abs(along - look.HouseAlongM) < 0.055 * length)
                {
                    continue;                               // the bridge stands here, with a gap before and abaft it
                }
                double bw = (blockLength * 0.92 * Math.Abs(sv.SinAlpha) + 0.8 * beam * Math.Abs(cosAlpha)) * perMetre;
                bw = Math.Max(1.0, bw);
                double cx = sx(along, 0.0);
                if (look.Cargo == 1)
                {
                    int tiers = 2 + (int)(Hash(ship.Id, k) * 3.99) + (along < look.HouseAlongM ? 1 : 0);        // a little higher abaft the bridge
                    Color[] palette = { Color.FromRgb(176, 62, 50), Color.FromRgb(52, 92, 150), Color.FromRgb(196, 160, 56), Color.FromRgb(70, 130, 96),
                                        Color.FromRgb(200, 200, 196), Color.FromRgb(120, 80, 50) };
                    Color box = palette[(Math.Abs(ship.Id) + k * 3) % palette.Length];
                    double stackTop = sy(deck + tiers * 2.6);
                    double stackHeight = Math.Max(1.0, sy(deck) - stackTop);
                    dc.DrawRectangle(Solid(Tint(box, day, fog)), null, new Rect(cx - bw / 2.0, stackTop, bw, stackHeight));
                    if (stackHeight > 12.0)
                    {
                        dc.DrawRectangle(Solid(Tint(Shade(box, 0.7), day, fog)), null, new Rect(cx - bw / 2.0, stackTop + stackHeight * 0.5, bw, Math.Max(1.0, stackHeight * 0.06)));
                    }
                }
                else if (look.Cargo == 3)
                {
                    if (k % 3 != 2)
                    {
                        dc.DrawRectangle(Solid(Tint(Color.FromRgb(110, 118, 112), day, fog)), null,
                                         new Rect(cx - bw / 2.0, sy(deck + 2.2), bw, 2.2 * perMetre + 1.0));
                    }
                    else
                    {
                        // a deck crane between the hatches: a post and a jib raised toward the bow
                        double postTop = sy(deck + 0.07 * length);
                        Pen pen = new Pen(Solid(Tint(Color.FromRgb(200, 190, 120), day, fog)), Math.Max(1.0, 0.008 * length * perMetre));
                        dc.DrawLine(pen, new Point(cx, sy(deck)), new Point(cx, postTop));
                        dc.DrawLine(pen, new Point(cx, postTop), new Point(sx(along + 0.08 * length, 0.0), sy(deck + 0.1 * length)));
                    }
                }
                else
                {
                    // a tanker: a long pipeline and a kingpost now and then
                    dc.DrawRectangle(Solid(Tint(Color.FromRgb(110, 120, 128), day, fog)), null,
                                     new Rect(cx - bw / 2.0 - 0.5, sy(deck + 1.2), bw + 1.0, 1.2 * perMetre + 1.0));
                    if (k % 4 == 1)
                    {
                        dc.DrawRectangle(Solid(Tint(Color.FromRgb(200, 200, 195), day, fog)), null,
                                         new Rect(cx - 0.6, sy(deck + 0.05 * length), 1.2, 0.05 * length * perMetre));
                    }
                }
            }
        }

        // A tanker's forecastle mast and the cargo crane abreast of the manifold: they stand clear of the pipes and make the deck read as a tanker's.
        private void DrawTankerDetails(DrawingContext dc, WheelhouseContact ship, ShipLook look, Func<double, double, double> sx, Func<double, double> sy,
                                       double perMetre, double length, double day, double fog)
        {
            double deck = look.FreeboardM;
            Pen pen = new Pen(Solid(Tint(Color.FromRgb(215, 215, 208), day, fog)), Math.Max(1.0, 0.006 * length * perMetre));
            dc.DrawLine(pen, new Point(sx(0.42 * length, 0.0), sy(deck)), new Point(sx(0.42 * length, 0.0), sy(deck + 0.06 * length)));          // forecastle mast
            Point foot = new Point(sx(0.05 * length, 0.0), sy(deck + 1.2));
            Point top = new Point(sx(0.05 * length, 0.0), sy(deck + 0.05 * length));
            dc.DrawLine(pen, foot, top);                                                                                                     // the crane's post
            dc.DrawLine(pen, top, new Point(sx(0.12 * length, 0.0), sy(deck + 0.03 * length)));                                              // and jib
        }

        // The sails of a sailing vessel: gaff-rigged masts, each with a mainsail (a quadrilateral held out by a gaff) and a topsail above it,
        // and headsails from the foremast to the bow.
        private void DrawGaffRig(DrawingContext dc, WheelhouseContact ship, ShipLook look, Func<double, double, double> sx, Func<double, double> sy,
                                 double perMetre, double length, double day, double fog)
        {
            double deck = look.FreeboardM;
            Brush sail = Solid(Tint(Color.FromRgb(240, 236, 220), day, fog));
            Brush sailShade = Solid(Tint(Color.FromRgb(224, 220, 204), day, fog));
            Pen spar = new Pen(Solid(Tint(Color.FromRgb(120, 84, 44), day, fog)), Math.Max(1.0, 0.004 * length * perMetre));
            double[] mastAlong = look.Masts == 1 ? new double[] { 0.04 } : (look.Masts == 2 ? new double[] { 0.14, -0.14 } : new double[] { 0.24, 0.0, -0.24 });
            double mastM = look.MastM;
            double boomLength = (look.Masts == 1 ? 0.3 : 0.2) * length;
            // headsails first (behind): from the foremast head to the bowsprit end
            double foreAlong = mastAlong[0] * length;
            Polygon(dc, sailShade, null, new Point(sx(foreAlong + 0.01 * length, 0.0), sy(deck + 0.9 * mastM)), new Point(sx(foreAlong + 0.01 * length, 0.0), sy(deck + 0.5)),
                    new Point(sx(0.55 * length, 0.0), sy(deck + 0.6)));
            Polygon(dc, sailShade, null, new Point(sx(foreAlong + 0.01 * length, 0.0), sy(deck + 0.62 * mastM)), new Point(sx(foreAlong + 0.01 * length, 0.0), sy(deck + 0.5)),
                    new Point(sx(0.4 * length, 0.0), sy(deck + 0.5)));
            for (int n = 0; n < mastAlong.Length; n++)
            {
                double m = mastAlong[n] * length;
                double h = mastM * (n == 0 && look.Masts > 1 ? 0.92 : 1.0);
                double gaffEnd = m - 0.65 * boomLength;
                Point tack = new Point(sx(m, 0.0), sy(deck + 0.9));
                Point throat = new Point(sx(m, 0.0), sy(deck + 0.6 * h));
                Point peak = new Point(sx(gaffEnd, 0.0), sy(deck + 0.74 * h));
                Point clew = new Point(sx(m - boomLength, 0.0), sy(deck + 0.9));
                Polygon(dc, sail, null, tack, throat, peak, clew);                                              // the gaff mainsail
                Polygon(dc, sailShade, null, throat, new Point(sx(m, 0.0), sy(deck + h)), peak);                 // the gaff topsail
                dc.DrawLine(spar, new Point(sx(m, 0.0), sy(deck)), new Point(sx(m, 0.0), sy(deck + h)));        // the mast
                dc.DrawLine(spar, tack, clew);                                                                  // the boom
                dc.DrawLine(spar, throat, peak);                                                                // the gaff
            }
        }

        // The sails of a sailing vessel: a mainsail between mast and boom, and a jib toward the bow.
        private void DrawSails(DrawingContext dc, WheelhouseContact ship, ShipLook look, Func<double, double, double> sx, Func<double, double> sy,
                               double perMetre, double length, double day, double fog)
        {
            double deck = look.FreeboardM;
            Brush sail = Solid(Tint(Color.FromRgb(246, 246, 240), day, fog));
            Point foot = new Point(sx(0.0, 0.0), sy(deck + 0.5));
            Point head = new Point(sx(0.0, 0.0), sy(deck + look.MastM));
            Polygon(dc, sail, null, foot, head, new Point(sx(-0.3 * length, 0.0), sy(deck + 0.5)));
            Polygon(dc, Solid(Tint(Color.FromRgb(236, 236, 230), day, fog)), null,
                    new Point(sx(0.02 * length, 0.0), sy(deck + 0.4)), new Point(sx(0.02 * length, 0.0), sy(deck + 0.9 * look.MastM)),
                    new Point(sx(0.42 * length, 0.0), sy(deck + 0.4)));
        }

        // Day shapes, left up day and night: fishing vessels show two cones, points together; a tug with a long tow shows a diamond.
        // They are only drawn in a narrow view, as they are only seen through binoculars.
        private void DrawDayShapes(DrawingContext dc, WheelhouseContact ship, ShipLook look, Func<double, double, double> sx, Func<double, double> sy,
                                   double perMetre, double length, double day, double fog)
        {
            bool fishing = ship.Kind == "fishing";
            bool diamond = ship.Kind == "tug_tow" && ship.HasTow && ship.TowLengthM > 200.0;
            if (!fishing && !diamond)
            {
                return;
            }
            double mastX = sx(look.HouseAlongM + 0.05 * length, 0.0);
            double mastTopY = sy(look.FreeboardM + look.HouseHeightM + look.MastM);
            double size = Math.Max(2.5, 1.2 * perMetre);                   // a cone is 0.6 m; drawn a little large so that it can be seen
            Brush ink = Solid(Tint(Color.FromRgb(10, 10, 10), day, fog));
            double y = mastTopY + size * 0.2;
            if (fishing)
            {
                // two cones, apexes together: the upper one points down, the lower one points up
                Polygon(dc, ink, null, new Point(mastX - size / 2.0, y), new Point(mastX + size / 2.0, y), new Point(mastX, y + size));
                Polygon(dc, ink, null, new Point(mastX, y + size), new Point(mastX - size / 2.0, y + 2.0 * size), new Point(mastX + size / 2.0, y + 2.0 * size));
            }
            else
            {
                // a diamond: two cones base to base
                Polygon(dc, ink, null, new Point(mastX, y - size), new Point(mastX + size / 2.0, y), new Point(mastX, y + size), new Point(mastX - size / 2.0, y));
            }
        }

        // Masthead, side, stern and special lights, each shown only from the directions it shines in (COLREGS Rules 21 to 26).
        private void DrawNavigationLights(DrawingContext dc, WheelhouseContact ship, ShipLook look, ShipView sv, double perMetre, double xc,
                                          double horizonY, double pixelsPerDeg, double strength, double fov)
        {
            double length = Math.Max(1.0, ship.LengthM);
            double beam = WheelhouseMath.BeamM(length);
            double rangeNm = sv.RangeM / WheelhouseMath.MPerNm;
            bool large = length > 50.0;
            bool medium = length > 12.0;
            LightSet seen = WheelhouseMath.LightsSeenFrom(WheelhouseMath.ThetaFromBowDeg(sv));
            // The Rules' minimum ranges in NM, made longer for practice and longer again through binoculars.
            double boost = LightBoost * WheelhouseMath.LightRangeZoom(fov);
            double mastRange = (large ? 6.0 : (medium ? 5.0 : 3.0)) * boost;
            double sideRange = (large ? 3.0 : (medium ? 2.0 : 1.0)) * boost;
            double allRoundRange = 2.0 * boost;
            double masthead = large ? Math.Max(8.0, 0.07 * length + 4.0) : Math.Max(2.5, 0.3 * length);
            double sideHeight = large ? Math.Max(4.0, 0.05 * length + 2.0) : Math.Max(1.5, 0.2 * length);
            Color white = Color.FromRgb(255, 255, 240);
            Color red = Color.FromRgb(255, 40, 30);
            Color green = Color.FromRgb(40, 255, 90);
            Color yellow = Color.FromRgb(255, 220, 60);
            bool underway = ship.SpeedKn > 0.3;

            if (ship.Kind == "fishing")
            {
                // Trawling (even ids here): green over white; other fishing: red over white. All round lights.
                double mast = look.FreeboardM + look.HouseHeightM + look.MastM;
                Color upper = Math.Abs(ship.Id) % 2 == 0 ? green : red;
                double gap = Math.Max(1.2, 0.06 * length);
                DrawLight(dc, xc, sv, look.HouseAlongM, 0.0, mast, upper, allRoundRange, rangeNm, strength, horizonY, pixelsPerDeg, perMetre);
                DrawLight(dc, xc, sv, look.HouseAlongM, 0.0, mast - gap, white, allRoundRange, rangeNm, strength, horizonY, pixelsPerDeg, perMetre);
                if (underway)
                {
                    // making way: sidelights and a stern light as well
                    if (seen.Green)
                    {
                        DrawLight(dc, xc, sv, 0.3 * length, beam / 2.0, sideHeight, green, sideRange, rangeNm, strength, horizonY, pixelsPerDeg, perMetre);
                    }
                    if (seen.Red)
                    {
                        DrawLight(dc, xc, sv, 0.3 * length, -beam / 2.0, sideHeight, red, sideRange, rangeNm, strength, horizonY, pixelsPerDeg, perMetre);
                    }
                    if (seen.Stern)
                    {
                        DrawLight(dc, xc, sv, -0.5 * length, 0.0, sideHeight, white, mastRange * 0.5, rangeNm, strength, horizonY, pixelsPerDeg, perMetre);
                    }
                }
                return;
            }

            bool power = !(ship.Kind == "pleasure" && ship.Sail) && ship.Kind != "barge";
            if (seen.Masthead && power)
            {
                DrawLight(dc, xc, sv, 0.3 * length, 0.0, masthead, white, mastRange, rangeNm, strength, horizonY, pixelsPerDeg, perMetre);
                if (large)
                {
                    DrawLight(dc, xc, sv, -0.25 * length, 0.0, masthead + Math.Max(4.0, 0.03 * length), white, mastRange, rangeNm, strength,
                              horizonY, pixelsPerDeg, perMetre);
                }
                if (ship.Kind == "tug_tow")
                {
                    // two masthead lights in a line, three if the tow is longer than 200 m
                    DrawLight(dc, xc, sv, 0.3 * length, 0.0, masthead + 0.15 * length, white, mastRange, rangeNm, strength, horizonY, pixelsPerDeg, perMetre);
                    if (ship.HasTow && ship.TowLengthM > 200.0)
                    {
                        DrawLight(dc, xc, sv, 0.3 * length, 0.0, masthead + 0.3 * length, white, mastRange, rangeNm, strength, horizonY, pixelsPerDeg, perMetre);
                    }
                }
            }
            double sideBeam = ship.Kind == "barge" ? 5.0 : beam / 2.0;
            double sideAt = ship.Kind == "barge" ? 0.45 * length : 0.3 * length;
            double sideUp = ship.Kind == "barge" ? 3.0 : sideHeight;
            if (seen.Green)
            {
                DrawLight(dc, xc, sv, sideAt, sideBeam, sideUp, green, sideRange, rangeNm, strength, horizonY, pixelsPerDeg, perMetre);
            }
            if (seen.Red)
            {
                DrawLight(dc, xc, sv, sideAt, -sideBeam, sideUp, red, sideRange, rangeNm, strength, horizonY, pixelsPerDeg, perMetre);
            }
            if (seen.Stern)
            {
                double sternAt = -0.5 * length;
                DrawLight(dc, xc, sv, sternAt, 0.0, sideUp, white, sideRange * 1.5, rangeNm, strength, horizonY, pixelsPerDeg, perMetre);
                if (ship.Kind == "tug_tow")
                {
                    // the towing light: yellow, above the stern light, same arc (Rule 24)
                    DrawLight(dc, xc, sv, sternAt, 0.0, sideUp + Math.Max(2.0, 0.08 * length), yellow, sideRange * 1.5, rangeNm, strength,
                              horizonY, pixelsPerDeg, perMetre);
                }
            }
        }

        private void DrawLight(DrawingContext dc, double xc, ShipView sv, double alongM, double lateralM, double heightM, Color colour,
                               double limitNm, double rangeNm, double strength, double horizonY, double pixelsPerDeg, double perMetre)
        {
            // Not farther than the light is seen over the curve of the sea, and not farther than the visibility lets a light be seen.
            limitNm = Math.Min(limitNm, 1.5 * visibilityNm);
            if (rangeNm > limitNm || sv.RangeM > WheelhouseMath.LightReachM(heightM, eyeM))
            {
                return;
            }
            double fade = Math.Max(0.3, Math.Min(1.0, 2.0 * (1.0 - rangeNm / limitNm)));
            double x = xc + WheelhouseMath.SidewaysM(sv, alongM, lateralM) * perMetre;
            double y = WheelhouseMath.ScreenY(WheelhouseMath.Elevation(heightM - eyeM, sv.RangeM), horizonY, pixelsPerDeg);
            double alpha = strength * fade;
            dc.DrawEllipse(Solid(colour, alpha * 0.3), null, new Point(x, y), 4.5, 4.5);
            dc.DrawEllipse(Solid(colour, alpha), null, new Point(x, y), 1.6, 1.6);
            DrawReflection(dc, x, sv, colour, rangeNm, alpha, horizonY, pixelsPerDeg);
        }

        // The sea state at which a light's reflection has gone altogether (Douglas).
        private const double ReflectionGoneAtState = 6.0;

        // A light's reflection hangs under it on the water: in a calm a long, bright, narrow streak; as the sea rises it breaks into
        // shorter dashes, spreads sideways and dims, until it is gone at ReflectionGoneAtState.
        private void DrawReflection(DrawingContext dc, double x, ShipView sv, Color colour, double rangeNm, double alpha, double horizonY, double pixelsPerDeg)
        {
            double state = data.SeaState;
            if (state >= ReflectionGoneAtState)
            {
                return;
            }
            double calm = 1.0 - state / ReflectionGoneAtState;                  // 1 flat calm, 0 gone
            double waterY = WheelhouseMath.ScreenY(WheelhouseMath.Elevation(-eyeM, sv.RangeM), horizonY, pixelsPerDeg);
            double length = Math.Min(80.0, 90.0 / (rangeNm + 0.7));             // px; nearer lights have longer reflections
            int dashes = 2 + (int)(state * 2.0);
            double dashLength = length / dashes;
            long slice = Environment.TickCount64 / 250;                          // the sparkle changes four times a second
            for (int k = 0; k < dashes; k++)
            {
                double jitter = (((k * 37L + slice * 11L + (long)sv.RangeM) % 7L) - 3.0) / 3.0;
                double across = jitter * state * 2.2;                           // px
                double thickness = Math.Max(1.0, 2.2 * calm + 0.8);
                double y = waterY + k * dashLength;
                double visible = dashLength * (state < 0.5 ? 1.0 : 0.75 - 0.08 * state);
                dc.DrawRectangle(Solid(colour, alpha * 0.55 * calm * (1.0 - 0.6 * k / dashes)), null,
                                 new Rect(x + across - thickness / 2.0, y, thickness, Math.Max(1.0, visible)));
            }
        }

        // A lane buoy in its colour and shape (a green can, a red nun, a yellow pillar with an X topmark), with its flashing
        // light at night. A buoy without a mark (the calibration scene) is a plain cone with a white light.
        private void DrawBuoy(DrawingContext dc, WheelhouseContact buoy, ShipView sv, double width, double horizonY,
                              double pixelsPerDeg, double pixelsPerRad, double centre, double light, double fog, double fov)
        {
            double eye = eyeM;
            double perMetre = pixelsPerRad / sv.RangeM;
            double x = WheelhouseMath.ScreenX(sv.BearingDeg, centre, pixelsPerDeg, width);
            double waterY = WheelhouseMath.ScreenY(WheelhouseMath.Elevation(-eye, sv.RangeM), horizonY, pixelsPerDeg);
            string shape = buoy.HasMark ? buoy.MarkShape : "nun";
            Color colour;
            if (!buoy.HasMark)
            {
                colour = buoy.Id % 2 == 0 ? Color.FromRgb(200, 40, 34) : Color.FromRgb(40, 140, 60);
            }
            else if (buoy.MarkColour == "red")
            {
                colour = Color.FromRgb(200, 40, 34);
            }
            else if (buoy.MarkColour == "green")
            {
                colour = Color.FromRgb(40, 140, 60);
            }
            else
            {
                colour = Color.FromRgb(228, 190, 40);
            }
            // Sizes in metres: the float (a drum), then the tower on it and the lantern on that. The light is drawn at lanternTopM.
            double floatRadiusM = shape == "pillar" ? 0.8 : 1.3;
            double floatTopM = shape == "pillar" ? 0.8 : 0.9;
            double lanternTopM = shape == "can" ? floatTopM + 3.7 : (shape == "nun" ? floatTopM + 3.9 : floatTopM + 4.0);
            double tallM = lanternTopM;
            double day = 0.1 + 0.9 * light;
            if (day > 0.14)
            {
                double rp = Math.Max(1.5, floatRadiusM * perMetre);
                double floatTop = waterY - Math.Max(1.5, floatTopM * perMetre);
                double stroke = Math.Max(1.0, 0.12 * perMetre);
                Pen legPen = new Pen(Solid(Tint(colour, day, fog)), stroke);
                Pen bracePen = new Pen(Solid(Tint(Shade(colour, 0.8), day, fog)), Math.Max(1.0, 0.07 * perMetre));
                Func<double, double> up = (m) => waterY - m * perMetre;
                // the tower first, so the float's top edge overlaps its feet
                if (shape == "can")
                {
                    double legHalf = 0.62 * floatRadiusM * perMetre;
                    double boxHalf = 0.72 * perMetre;
                    double boxBottom = up(floatTopM + 1.4);
                    double boxTop = up(floatTopM + 3.0);
                    dc.DrawLine(legPen, new Point(x - legHalf, floatTop), new Point(x - boxHalf * 0.8, boxBottom));
                    dc.DrawLine(legPen, new Point(x + legHalf, floatTop), new Point(x + boxHalf * 0.8, boxBottom));
                    dc.DrawLine(bracePen, new Point(x - legHalf, floatTop), new Point(x + boxHalf * 0.8, boxBottom));
                    dc.DrawLine(bracePen, new Point(x + legHalf, floatTop), new Point(x - boxHalf * 0.8, boxBottom));
                    Block(dc, colour, day, fog, x - boxHalf, boxTop, 2.0 * boxHalf, boxBottom - boxTop);
                    Block(dc, Shade(colour, 0.7), day, fog, x + boxHalf * 0.35, boxTop, boxHalf * 0.65, boxBottom - boxTop);                // the shaded side
                    Block(dc, Shade(colour, 0.6), day, fog, x - boxHalf, boxTop, 2.0 * boxHalf, Math.Max(1.0, 0.1 * perMetre));              // the rim
                    Block(dc, Shade(colour, 0.6), day, fog, x - boxHalf, boxBottom - Math.Max(1.0, 0.1 * perMetre), 2.0 * boxHalf, Math.Max(1.0, 0.1 * perMetre));
                    if (boxHalf > 7.0)
                    {
                        Text(dc, (Math.Abs(buoy.Id) % 20 * 2 + (colour.G > colour.R ? 1 : 2)).ToString(CultureInfo.InvariantCulture), boxHalf * 1.1,
                             Solid(Tint(Color.FromRgb(245, 245, 240), day, fog)), x - boxHalf * 0.15, (boxTop + boxBottom) / 2.0 - boxHalf * 0.55, true);
                    }
                    Block(dc, Color.FromRgb(200, 205, 205), day, fog, x - 0.2 * perMetre, up(lanternTopM - 0.1), 0.4 * perMetre, 0.6 * perMetre);
                }
                else if (shape == "nun")
                {
                    double topM = floatTopM + 2.3;
                    double footHalf = 0.7 * floatRadiusM * perMetre;
                    double neckHalf = 0.3 * perMetre;
                    double neck = up(topM);
                    double mid = up(floatTopM + 1.15);
                    dc.DrawLine(legPen, new Point(x - footHalf, floatTop), new Point(x - neckHalf, neck));
                    dc.DrawLine(legPen, new Point(x + footHalf, floatTop), new Point(x + neckHalf, neck));
                    double midHalf = (footHalf + neckHalf) / 2.0;
                    dc.DrawLine(bracePen, new Point(x - footHalf, floatTop), new Point(x + midHalf, mid));
                    dc.DrawLine(bracePen, new Point(x + footHalf, floatTop), new Point(x - midHalf, mid));
                    dc.DrawLine(bracePen, new Point(x - midHalf, mid), new Point(x + neckHalf, neck));
                    dc.DrawLine(bracePen, new Point(x + midHalf, mid), new Point(x - neckHalf, neck));
                    // the cone daymark that makes it a nun
                    double coneHalf = 0.62 * perMetre;
                    Polygon(dc, Solid(Tint(colour, day, fog)), null, new Point(x - coneHalf, neck), new Point(x + coneHalf, neck), new Point(x, up(topM + 1.3)));
                    Polygon(dc, Solid(Tint(Shade(colour, 0.7), day, fog)), null, new Point(x + 0.1 * coneHalf, neck), new Point(x + coneHalf, neck), new Point(x, up(topM + 1.3)));
                    Block(dc, Color.FromRgb(200, 205, 205), day, fog, x - 0.2 * perMetre, up(lanternTopM - 0.05), 0.4 * perMetre, 0.5 * perMetre);
                }
                else
                {
                    // a pillar: a slim column with the lantern on it and an X topmark above that
                    double colHalf = Math.Max(1.0, 0.25 * perMetre);
                    Block(dc, colour, day, fog, x - colHalf, up(floatTopM + 3.0), 2.0 * colHalf, floatTop - up(floatTopM + 3.0));
                    Block(dc, Shade(colour, 0.7), day, fog, x, up(floatTopM + 3.0), colHalf, floatTop - up(floatTopM + 3.0));
                    Block(dc, Color.FromRgb(200, 205, 205), day, fog, x - 0.2 * perMetre, up(floatTopM + 3.5), 0.4 * perMetre, 0.5 * perMetre);
                    Pen cross = new Pen(Solid(Tint(colour, day, fog)), Math.Max(1.0, 0.15 * perMetre));
                    double arm = Math.Max(2.0, 0.55 * perMetre);
                    double crossY = up(floatTopM + 3.5 + 0.9);
                    dc.DrawLine(cross, new Point(x - arm, crossY - arm), new Point(x + arm, crossY + arm));
                    dc.DrawLine(cross, new Point(x - arm, crossY + arm), new Point(x + arm, crossY - arm));
                }
                // the float: a drum with its right side in shade, a darker foot of marine growth and a flat top seen at a slant
                double slant = Math.Max(0.8, rp * Math.Min(0.5, (eye - floatTopM) / sv.RangeM * 60.0));
                Block(dc, colour, day, fog, x - rp, floatTop, 2.0 * rp, waterY - floatTop);
                Block(dc, Shade(colour, 0.68), day, fog, x + rp * 0.35, floatTop, rp * 0.65, waterY - floatTop);
                Block(dc, Shade(colour, 0.38), day, fog, x - rp, waterY - (waterY - floatTop) * 0.28, 2.0 * rp, (waterY - floatTop) * 0.28);
                dc.DrawEllipse(Solid(Tint(Shade(colour, 1.12), day, fog)), null, new Point(x, floatTop), rp, slant);
                // eyes for the mooring and the lantern's foot on the deck
                Block(dc, Shade(colour, 0.5), day, fog, x - rp, floatTop - 0.3 * perMetre, Math.Max(1.5, 0.3 * perMetre), 0.3 * perMetre);
                Block(dc, Shade(colour, 0.5), day, fog, x + rp - Math.Max(1.5, 0.3 * perMetre), floatTop - 0.3 * perMetre, Math.Max(1.5, 0.3 * perMetre), 0.3 * perMetre);
                dc.DrawEllipse(Solid(Tint(Color.FromRgb(236, 240, 242), day, fog), 0.5), null, new Point(x, waterY), rp * 1.15, Math.Max(0.8, rp * 0.12));          // the ripple round the foot
            }
            // The light: a flash at night, reaching farther through binoculars, not beyond the curve of the sea or the visibility.
            double night = (1.0 - light) * (1.0 - fog);
            if (night > 0.25 && WheelhouseMath.LightIsOn(buoy, Environment.TickCount64))
            {
                Color lightColour = Color.FromRgb(255, 255, 240);
                if (buoy.HasMark)
                {
                    lightColour = buoy.LightColour == "red" ? Color.FromRgb(255, 40, 30)
                                : buoy.LightColour == "green" ? Color.FromRgb(40, 255, 90) : Color.FromRgb(255, 220, 60);
                }
                double rangeNm = sv.RangeM / WheelhouseMath.MPerNm;
                double reachNm = 3.0 * LightBoost * WheelhouseMath.LightRangeZoom(fov);
                DrawLight(dc, x, sv, 0.0, 0.0, tallM - 0.2, lightColour, reachNm, rangeNm, (night - 0.25) / 0.75, horizonY, pixelsPerDeg, perMetre);
            }
        }

        // ---- own ship's foredeck ----

        // The deck of own ship seen from the bridge, in the direction of the bow, drawn in perspective from points measured in
        // metres from the eye: x to starboard, z ahead, up from the deck. A container ship's stacks, a tanker's pipes, a bulk carrier's
        // hatches and cranes. Only drawn in a wide view; a zoomed view is a look through binoculars.
        private void DrawBowDeck(DrawingContext dc, double width, double height, double horizonY, double pixelsPerDeg, double centre, double heading,
                                 double fov, double light)
        {
            if (fov < 45.0 || Math.Abs(WheelhouseMath.Wrap180(centre - heading)) > fov / 2.0 + 60.0)
            {
                return;
            }
            DeckSpec spec = Decks[Math.Max(0, Math.Min(Decks.Length - 1, DeckType))];
            double day = 0.2 + 0.8 * light;
            double deckRel = spec.DeckM - spec.EyeM;                  // the deck is this far below the eye (negative)
            double half = spec.BeamM / 2.0;

            Func<double, double, double, Point> P = (x, z, up) =>
            {
                double ground = Math.Sqrt(x * x + z * z);
                double bearing = heading + Math.Atan2(x, z) * 180.0 / Math.PI;          // rad -> deg
                double elevation = Math.Atan2(deckRel + up, ground);                    // rad
                return new Point(WheelhouseMath.ScreenX(bearing, centre, pixelsPerDeg, width), WheelhouseMath.ScreenY(elevation, horizonY, pixelsPerDeg));
            };
            Func<double, double> halfAt = (z) =>
            {
                if (z <= spec.TaperZ)
                {
                    return half;
                }
                double t = Math.Min(1.0, (z - spec.TaperZ) / (spec.EndZ - spec.TaperZ));
                return Math.Max(0.2, half * Math.Sqrt(1.0 - t * t));
            };
            // the steps along the deck: at most 25 m apart, finer in the bow
            List<double> zs = new List<double>();
            for (double z = spec.StartZ; z < spec.TaperZ; z += 25.0)
            {
                zs.Add(z);
            }
            for (int i = 0; i <= 8; i++)
            {
                zs.Add(spec.TaperZ + (spec.EndZ - spec.TaperZ) * i / 8.0);
            }

            Color deckColour = spec.Kind == 0 ? Color.FromRgb(96, 100, 96) : (spec.Kind == 1 ? Color.FromRgb(96, 108, 96) : Color.FromRgb(112, 72, 62));
            List<Point> outline = new List<Point>();
            for (int i = 0; i < zs.Count; i++)
            {
                outline.Add(P(-halfAt(zs[i]), zs[i], 0.0));
            }
            for (int i = zs.Count - 1; i >= 0; i--)
            {
                outline.Add(P(halfAt(zs[i]), zs[i], 0.0));
            }
            Polygon(dc, Solid(Shade(deckColour, day)), null, outline.ToArray());

            // the bulwark along both sides: its inner face, and the rail on top
            Brush bulwark = Solid(Shade(Color.FromRgb(150, 70, 56), day));
            Pen rail = new Pen(Solid(Shade(Color.FromRgb(225, 225, 215), day)), 2.0);
            for (int i = zs.Count - 1; i > 0; i--)
            {
                for (int s = -1; s <= 1; s += 2)
                {
                    double x0 = s * halfAt(zs[i - 1]);
                    double x1 = s * halfAt(zs[i]);
                    Polygon(dc, bulwark, null, P(x0, zs[i - 1], 0.0), P(x1, zs[i], 0.0), P(x1, zs[i], 1.4), P(x0, zs[i - 1], 1.4));
                    dc.DrawLine(rail, P(x0, zs[i - 1], 1.4), P(x1, zs[i], 1.4));
                }
            }

            if (spec.Kind == 0)
            {
                DrawContainers(dc, spec, P, day);
            }
            else if (spec.Kind == 1)
            {
                DrawTankerDeck(dc, spec, P, day);
            }
            else
            {
                DrawBulkDeck(dc, spec, P, day);
            }
            // the jackstaff at the stem
            Pen staff = new Pen(Solid(Shade(Color.FromRgb(235, 235, 235), day)), 2.0);
            dc.DrawLine(staff, P(0.0, spec.EndZ - 6.0, 0.0), P(0.0, spec.EndZ - 6.0, 7.0));
        }

        // Rows of container stacks, 11 across, drawn far to near and from the outside toward the centre so that each paints over what is behind it.
        private void DrawContainers(DrawingContext dc, DeckSpec spec, Func<double, double, double, Point> P, double day)
        {
            Color[] palette = { Color.FromRgb(176, 62, 50), Color.FromRgb(52, 92, 150), Color.FromRgb(196, 160, 56), Color.FromRgb(70, 130, 96),
                                Color.FromRgb(214, 214, 208), Color.FromRgb(124, 82, 52), Color.FromRgb(188, 100, 44), Color.FromRgb(40, 70, 70) };
            const int Columns = 11;
            const double ColumnWidthM = 2.5;
            const double RowLengthM = 12.2;
            const double TierM = 2.6;
            double firstZ = spec.StartZ + 4.0;
            int rows = (int)((spec.TaperZ - 10.0 - firstZ) / RowLengthM);
            double eyeAboveDeck = spec.EyeM - spec.DeckM;
            for (int row = rows - 1; row >= 0; row--)
            {
                double z0 = firstZ + row * RowLengthM;
                double z1 = z0 + RowLengthM - 0.3;
                double rowBase = 2.0 + Hash(row, 5) * 3.0;
                for (int n = 0; n < Columns; n++)
                {
                    // outside in on each side: columns 0,10,1,9,2,8 ...
                    int col = n % 2 == 0 ? n / 2 : Columns - 1 - n / 2;
                    double x0 = (col - Columns / 2.0) * ColumnWidthM;
                    double x1 = x0 + ColumnWidthM - 0.1;
                    int tiers = (int)Math.Max(1.0, Math.Min(6.0, Math.Floor(rowBase + Hash(row, col + 11) * 3.0 - 1.0)));
                    double top = tiers * TierM;
                    Color colour = palette[(row * 5 + col * 3) % palette.Length];
                    // the face toward the centre line, then the top, then the face toward the viewer
                    double inner = x0 + x1 < 0.0 ? x1 : x0;
                    Polygon(dc, Solid(Shade(colour, day * 0.72)), null, P(inner, z0, 0.0), P(inner, z1, 0.0), P(inner, z1, top), P(inner, z0, top));
                    if (top < eyeAboveDeck)
                    {
                        Polygon(dc, Solid(Shade(colour, day * 1.12)), null, P(x0, z0, top), P(x1, z0, top), P(x1, z1, top), P(x0, z1, top));
                    }
                    for (int tier = 0; tier < tiers; tier++)
                    {
                        Color face = Shade(colour, day * (tier % 2 == 0 ? 0.95 : 0.85));
                        Polygon(dc, Solid(face), null, P(x0, z0, tier * TierM), P(x1, z0, tier * TierM), P(x1, z0, (tier + 1) * TierM), P(x0, z0, (tier + 1) * TierM));
                    }
                }
            }
        }

        // A tanker's deck: a raised catwalk down the middle, pipes along and across, tank hatches and a white foremast.
        private void DrawTankerDeck(DrawingContext dc, DeckSpec spec, Func<double, double, double, Point> P, double day)
        {
            double endZ = spec.TaperZ - 10.0;
            Brush pipe = Solid(Shade(Color.FromRgb(130, 142, 150), day));
            Brush pipeDark = Solid(Shade(Color.FromRgb(88, 98, 108), day));
            foreach (double x in new double[] { -12.0, -7.0, -3.4, 3.4, 7.0, 12.0 })
            {
                for (double z = spec.StartZ + 6.0; z < endZ; z += 30.0)
                {
                    double z1 = Math.Min(endZ, z + 30.0);
                    Polygon(dc, pipeDark, null, P(x - 0.4, z, 0.8), P(x + 0.4, z, 0.8), P(x + 0.4, z1, 0.8), P(x - 0.4, z1, 0.8));
                }
            }
            for (double z = spec.StartZ + 20.0; z < endZ; z += 36.0)
            {
                Polygon(dc, pipe, null, P(-14.0, z, 1.3), P(14.0, z, 1.3), P(14.0, z + 0.8, 1.3), P(-14.0, z + 0.8, 1.3));
            }
            int boxes = 0;
            for (double z = spec.StartZ + 12.0; z < endZ; z += 20.0, boxes++)
            {
                foreach (double x in new double[] { -16.0, 16.0, -9.5, 9.5 })
                {
                    Color colour = Hash(boxes, (int)x) < 0.5 ? Color.FromRgb(70, 120, 84) : Color.FromRgb(150, 150, 140);
                    Polygon(dc, Solid(Shade(colour, day)), null, P(x - 1.3, z, 1.0), P(x + 1.3, z, 1.0), P(x + 1.3, z + 2.6, 1.0), P(x - 1.3, z + 2.6, 1.0));
                }
            }
            // the catwalk, raised over the pipes and wide enough to walk on
            Brush walk = Solid(Shade(Color.FromRgb(168, 168, 156), day));
            for (double z = spec.StartZ; z < endZ; z += 30.0)
            {
                double z1 = Math.Min(endZ, z + 30.0);
                Polygon(dc, walk, null, P(-1.2, z, 1.8), P(1.2, z, 1.8), P(1.2, z1, 1.8), P(-1.2, z1, 1.8));
            }
            // the foremast
            double mastZ = spec.EndZ - 45.0;
            Pen mast = new Pen(Solid(Shade(Color.FromRgb(240, 240, 236), day)), 5.0);
            dc.DrawLine(mast, P(0.0, mastZ, 0.0), P(0.0, mastZ, 11.0));
            dc.DrawLine(new Pen(Solid(Shade(Color.FromRgb(240, 240, 236), day)), 3.0), P(-2.5, mastZ, 9.0), P(2.5, mastZ, 9.0));
        }

        // A bulk carrier's deck: five hatch covers in a row, and a crane in the gap behind every second one.
        private void DrawBulkDeck(DrawingContext dc, DeckSpec spec, Func<double, double, double, Point> P, double day)
        {
            Brush top = Solid(Shade(Color.FromRgb(150, 160, 152), day));
            Brush front = Solid(Shade(Color.FromRgb(100, 110, 104), day));
            Brush side = Solid(Shade(Color.FromRgb(84, 92, 88), day));
            double eyeAboveDeck = spec.EyeM - spec.DeckM;
            Pen jib = new Pen(Solid(Shade(Color.FromRgb(214, 200, 120), day)), 3.0);
            for (int i = 4; i >= 0; i--)
            {
                double z0 = spec.StartZ + 10.0 + i * 30.0;
                double z1 = z0 + 22.0;
                if (z1 > spec.TaperZ - 5.0)
                {
                    continue;
                }
                double h = 2.4;
                Polygon(dc, side, null, P(-9.0, z0, 0.0), P(-9.0, z1, 0.0), P(-9.0, z1, h), P(-9.0, z0, h));
                Polygon(dc, side, null, P(9.0, z0, 0.0), P(9.0, z1, 0.0), P(9.0, z1, h), P(9.0, z0, h));
                if (h < eyeAboveDeck)
                {
                    Polygon(dc, top, null, P(-9.0, z0, h), P(9.0, z0, h), P(9.0, z1, h), P(-9.0, z1, h));
                }
                Polygon(dc, front, null, P(-9.0, z0, 0.0), P(9.0, z0, 0.0), P(9.0, z0, h), P(-9.0, z0, h));
                if (i % 2 == 1)
                {
                    double zc = z1 + 3.5;
                    dc.DrawLine(new Pen(Solid(Shade(Color.FromRgb(214, 200, 120), day)), 6.0), P(0.0, zc, 0.0), P(0.0, zc, 9.0));
                    dc.DrawLine(jib, P(0.0, zc, 9.0), P(0.0, zc + 20.0, 15.0));
                }
            }
        }

        // ---- the bearing scale, the bearing readout and the crosshair ----

        private void DrawScaleAndReadout(DrawingContext dc, double width, double height, double pixelsPerDeg, double centre, double fov)
        {
            double tick, labelEvery;
            if (fov >= 120.0) { tick = 10.0; labelEvery = 30.0; }
            else if (fov >= 60.0) { tick = 5.0; labelEvery = 10.0; }
            else if (fov >= 30.0) { tick = 2.0; labelEvery = 10.0; }
            else if (fov >= 15.0) { tick = 1.0; labelEvery = 5.0; }
            else if (fov >= 8.0) { tick = 0.5; labelEvery = 1.0; }
            else { tick = 0.25; labelEvery = 1.0; }
            Brush ink = Solid(Color.FromRgb(240, 240, 240));
            Pen inkPen = new Pen(ink, 1.0);
            dc.DrawRectangle(Solid(Color.FromRgb(0, 0, 0), 0.55), null, new Rect(0.0, 0.0, width, 32.0));
            double first = Math.Ceiling((centre - fov / 2.0) / tick) * tick;
            for (double bearing = first; bearing <= centre + fov / 2.0 + 1e-9; bearing += tick)
            {
                double x = width / 2.0 + (bearing - centre) * pixelsPerDeg;
                double normalised = WheelhouseMath.Wrap360(Math.Round(bearing / tick) * tick);
                bool labelled = Math.Abs(Math.IEEERemainder(Math.Round(bearing / tick) * tick, labelEvery)) < 1e-6;
                dc.DrawLine(inkPen, new Point(x, 32.0), new Point(x, labelled ? 22.0 : 27.0));
                if (labelled)
                {
                    string label = labelEvery < 1.5 && tick < 1.0 ? normalised.ToString("000.0", CultureInfo.InvariantCulture) : normalised.ToString("000", CultureInfo.InvariantCulture);
                    Text(dc, label, 11.0, ink, x, 4.0, true);
                }
            }

            // The bearing of the centre line, as read on a gyro repeater: the bearing a compass sight along it would give.
            string readout = "BEARING " + centre.ToString("000.0", CultureInfo.InvariantCulture) + " deg (gyro)";
            dc.DrawRectangle(Solid(Color.FromRgb(0, 0, 0), 0.65), null, new Rect(width / 2.0 - 130.0, 34.0, 260.0, 24.0));
            Text(dc, readout, 14.0, ink, width / 2.0, 38.0, true);

            if (fov <= WheelhouseMath.CrosshairBelowDeg)
            {
                Pen cross = new Pen(Solid(Color.FromRgb(255, 255, 255), 0.85), 1.0);
                dc.DrawLine(cross, new Point(width / 2.0, 60.0), new Point(width / 2.0, height));
                // No line across the picture (it hides contacts): ticks in from each side instead. The long one is the horizon (eye level);
                // the others are every step of elevation above and below it, so how far a ship's waterline is below the horizon shows
                // how near it is. The step is the smallest of the list that keeps the ticks 14 pixels apart.
                double horizonY = height * HorizonFraction;
                double[] steps = { 0.1, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0 };
                double step = steps[steps.Length - 1];
                foreach (double candidate in steps)
                {
                    if (candidate * pixelsPerDeg >= 14.0)
                    {
                        step = candidate;
                        break;
                    }
                }
                for (int i = -(int)Math.Ceiling(height / (step * pixelsPerDeg)); i <= (int)Math.Ceiling(height / (step * pixelsPerDeg)); i++)
                {
                    double y = WheelhouseMath.ScreenY(i * step * Math.PI / 180.0, horizonY, pixelsPerDeg);      // deg -> rad
                    if (y < 60.0 || y > height)
                    {
                        continue;
                    }
                    double longer = i == 0 ? 34.0 : (i % 5 == 0 ? 20.0 : 11.0);
                    dc.DrawLine(cross, new Point(0.0, y), new Point(longer, y));
                    dc.DrawLine(cross, new Point(width, y), new Point(width - longer, y));
                }
            }
        }
    }
}
