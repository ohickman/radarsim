// InstructorLayer.cs - the instructor overlay (BRIEF.md Sections 7 and 11, M10): the true position,
// true course and speed, kind and length of every contact, and own ship's ground track, from the
// sim's "truth" message. It holds no WPF types, so the self-tests can run it. Nothing else in the
// display shows truth.
// A contact's marker sits at own ship's pixel plus the displacement from own ship to the contact, the
// same way as the radar echo; the line is the contact's true motion over LineMinutes.
// Units: positions NM (the sim's ground frame), course deg true, speed KN, length m, line length MIN,
// pixels in bitmap pixels.
// Called by: DisplayController (data), PpiView (drawing), SelfTest.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.Json;

namespace RadarSim
{
    public class TruthContact
    {
        public int Id;
        public string Name;                 // "S4" in the calibration scenario, otherwise empty
        public string Kind = "";
        public double XNm, YNm;
        public double CourseDegTrue;
        public double SpeedKn;
        public double LengthM;
    }

    public class TruthShape
    {
        public double XPx, YPx;             // the contact's marker
        public double LineEndXPx, LineEndYPx;
        public string Label = "";
    }

    public class InstructorShapes
    {
        public readonly List<TruthShape> Contacts = new List<TruthShape>();
        public readonly List<PointPx> OwnTrackPx = new List<PointPx>();     // oldest first; the last point is own ship's position when the track was last extended
    }

    public class InstructorLayer
    {
        public const double LineMinutes = 6.0;          // chosen: the line shows 6 MIN of true motion

        public readonly List<TruthContact> Contacts = new List<TruthContact>();
        public readonly List<double[]> OwnTrackNm = new List<double[]>();       // [x, y] pairs
        public bool HasData;                // a truth message has arrived since the last Clear

        public void Clear()
        {
            Contacts.Clear();
            OwnTrackNm.Clear();
            HasData = false;
        }

        // The "truth" message: contacts (id, name, kind, x_nm, y_nm, course_deg_true, speed_kn, length_m)
        // and own_track (a list of [x_nm, y_nm]).
        public void SetMessage(JsonElement message)
        {
            Contacts.Clear();
            OwnTrackNm.Clear();
            JsonElement contacts;
            if (message.TryGetProperty("contacts", out contacts) && contacts.ValueKind == JsonValueKind.Array)
            {
                foreach (JsonElement item in contacts.EnumerateArray())
                {
                    TruthContact contact = new TruthContact();
                    contact.Id = (int)Number(item, "id", 0.0);
                    JsonElement name;
                    if (item.TryGetProperty("name", out name) && name.ValueKind == JsonValueKind.String)
                    {
                        contact.Name = name.GetString();
                    }
                    JsonElement kind;
                    if (item.TryGetProperty("kind", out kind) && kind.ValueKind == JsonValueKind.String)
                    {
                        contact.Kind = kind.GetString();
                    }
                    contact.XNm = Number(item, "x_nm", 0.0);
                    contact.YNm = Number(item, "y_nm", 0.0);
                    contact.CourseDegTrue = Number(item, "course_deg_true", 0.0);
                    contact.SpeedKn = Number(item, "speed_kn", 0.0);
                    contact.LengthM = Number(item, "length_m", 0.0);
                    Contacts.Add(contact);
                }
            }
            JsonElement track;
            if (message.TryGetProperty("own_track", out track) && track.ValueKind == JsonValueKind.Array)
            {
                foreach (JsonElement point in track.EnumerateArray())
                {
                    if (point.ValueKind == JsonValueKind.Array && point.GetArrayLength() >= 2)
                    {
                        OwnTrackNm.Add(new double[] { point[0].GetDouble(), point[1].GetDouble() });
                    }
                }
            }
            HasData = true;
        }

        private static double Number(JsonElement item, string name, double fallback)
        {
            JsonElement value;
            if (item.TryGetProperty(name, out value) && value.ValueKind == JsonValueKind.Number)
            {
                return value.GetDouble();
            }
            return fallback;
        }

        // "SHIP 225°T 12.0 KN 150 M", with the name first when there is one.
        public static string LabelOf(TruthContact contact)
        {
            string text = contact.Kind.Replace('_', ' ').ToUpperInvariant() + " "
                + ((int)Math.Round(PpiGeometry.Normalise360(contact.CourseDegTrue)) % 360).ToString("000", CultureInfo.InvariantCulture)
                + "°T " + contact.SpeedKn.ToString("0.0", CultureInfo.InvariantCulture) + " KN "
                + contact.LengthM.ToString("0", CultureInfo.InvariantCulture) + " M";
            if (!string.IsNullOrEmpty(contact.Name))
            {
                text = contact.Name + " " + text;
            }
            return text;
        }

        // The shapes for the geometry. ownGroundXNm and ownGroundYNm are own ship's position in the same
        // frame as the truth message (from the state message); ownRefXNm and ownRefYNm are own ship's
        // reference position now, which says where own ship is drawn in true motion.
        public InstructorShapes Layout(PpiGeometry geometry, double ownGroundXNm, double ownGroundYNm,
                                       double ownRefXNm, double ownRefYNm)
        {
            InstructorShapes shapes = new InstructorShapes();
            double ownXPx, ownYPx;
            geometry.OwnPixelFor(ownRefXNm, ownRefYNm, out ownXPx, out ownYPx);

            foreach (TruthContact contact in Contacts)
            {
                TruthShape shape = new TruthShape();
                double dx, dy;
                TargetLayer.OffsetPx(geometry, contact.XNm - ownGroundXNm, contact.YNm - ownGroundYNm, out dx, out dy);
                shape.XPx = ownXPx + dx;
                shape.YPx = ownYPx + dy;
                double lengthNm = contact.SpeedKn * LineMinutes / 60.0;                 // KN x MIN -> NM
                double courseRad = contact.CourseDegTrue * Math.PI / 180.0;             // deg -> rad
                double lx, ly;
                TargetLayer.OffsetPx(geometry, lengthNm * Math.Sin(courseRad), lengthNm * Math.Cos(courseRad), out lx, out ly);
                shape.LineEndXPx = shape.XPx + lx;
                shape.LineEndYPx = shape.YPx + ly;
                shape.Label = LabelOf(contact);
                shapes.Contacts.Add(shape);
            }
            foreach (double[] point in OwnTrackNm)
            {
                double tx, ty;
                TargetLayer.OffsetPx(geometry, point[0] - ownGroundXNm, point[1] - ownGroundYNm, out tx, out ty);
                shapes.OwnTrackPx.Add(new PointPx(ownXPx + tx, ownYPx + ty));
            }
            return shapes;
        }
    }
}
