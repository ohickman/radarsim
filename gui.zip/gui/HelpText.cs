// HelpText.cs - the text of the help window (F1): one short paragraph per control group, then the
// hotkey table written out from HotkeyTable, so the help and the keys cannot differ. No WPF types
// besides those HotkeyTable already uses, so the self-tests can check it.
// Called by: HelpWindow, SelfTest.

using System.Collections.Generic;
using System.Text;

namespace RadarSim
{
    public static class HelpText
    {
        // Group title, paragraph.
        public static readonly string[][] Groups = new string[][]
        {
            new[] { "RECEIVER", "GAIN sets how weak an echo can be and still show. STC (sea clutter) cuts the near-range returns from waves; raise it with sea state, no further than the clutter needs. FTC (fast time constant) flattens long, even returns such as heavy sea clutter and rain, so stronger contacts stand out in them; the first half of the knob does most of the work. It also shortens every echo, so use as little as works. Gain, STC and FTC are three knobs in a row. Each control is a knob or slider (SETUP, INTERFACE); type a value in its box and press Enter for an exact one." },
            new[] { "DISPLAY", "RANGE SCALE (PageUp, PageDown) is the radius of the picture in NM. ORIENTATION: NORTH UP, HEAD UP or COURSE UP (the heading at the moment you pick it). MOTION: RELATIVE keeps own ship fixed on the screen; TRUE keeps the land and moored echoes fixed and moves own ship, and needs NORTH UP. OFFSET then a click puts own ship where you click (or Ctrl+O at the cursor); CENTRE (or Ctrl+Shift+O) brings it back. The range rings and the picture extend to the far edge of the screen. STABILISATION chooses the frame for true motion, vectors and trails: SEA (speed through the water, so a current moves the picture) or GROUND (speed over the ground). TRAILS show where echoes have been, in true or relative form. BRILLIANCE and AFTERGLOW are display-only." },
            new[] { "EBL / VRM", "Two electronic bearing lines and two variable range markers. Press 1 or 2 to switch an EBL on and select it, 3 or 4 for a VRM. Drag a line or ring with the mouse, turn its knob or slider (the mouse wheel steps it, Ctrl for fine steps), type a value into the knob's number, or move the selected one with the arrow keys (steps in the hotkey table). The readout gives bearing in degrees and range in NM; the bearing can be relative or true. A bearing knob has no stops: turn it round and round, and a step or a typed value past 360 comes round to 000. Under the EBLs and VRMs are two PARALLEL INDEX lines, PI 1 and PI 2 (dash-dot and dotted): each has a direction (read like the EBLs) and a distance from own ship, + to the right of the line's direction and - to the left, so a pair can mark both edges of a channel." },
            new[] { "ARPA", "ACQUIRE arms the picture: each click puts a box down, until you press the button again or 8 s pass without one; A acquires at the cursor (a box can be dropped anywhere: with no echo under it, it looks every revolution and is lost after a few); a click on a box selects the target and shows its numbers at the top left of the screen, DELETE cancels it, Ctrl+Delete cancels all. A new target is ACQ (dashed box), becomes TREND (dashed vector) and then TRACK (solid vector). VECTOR MODE is TRUE or RELATIVE (V) and VECTOR TIME is 0.5 to 60 MIN ([ and ]). HISTORY shows past positions as dots. CPA LIMIT in NM and TCPA LIMIT in MIN set when a target raises an alarm." },
            new[] { "GUARD ZONES", "Two ring sectors, each with an inner and outer range in NM and a start and end bearing in degrees (relative or true, as the label says). An echo that stays inside an enabled zone for a few revolutions in a row raises GUARD ZONE 1 or 2, whether or not it is tracked." },
            new[] { "WHEELHOUSE", "The WHEELHOUSE button opens the view from the bridge: sea, land and sky with the ships painted on them and the bow of own ship in front. It shows bearings only: the scale along the top and the gyro bearing of the centre line, with a crosshair when the view is 30 deg wide or less. Left and Right look round (Shift 1 deg, Ctrl 30 deg), the wheel or Up and Down zoom from 180 deg to 4 deg, Home looks ahead, End looks astern, and dragging with the mouse turns the view. The TIME OF DAY slider changes the light; at night ships show their navigation lights. CHART writes the practice chart and opens it." },
            new[] { "TRIAL MANEUVER", "Set a course in deg T, a speed in KN and a delay in MIN (decimals allowed: 0.1 MIN is 6 s) with the knobs or by typing a value, and switch TRIAL on. Every target then also shows the CPA and TCPA it would have if own ship made that maneuver after the delay, and with RELATIVE vectors the vectors show that relative motion; TRUE vectors do not change. TRIAL is shown in the status line while it is on. It changes nothing in the sim's own ship." },
            new[] { "ALARMS", "Each alarm shows its text (CPA/TCPA 3, LOST TARGET 5, GUARD ZONE 1, TARGET CAPACITY) and flashes until acknowledged with Space or the ACK button. With the alarm sound on, a tone repeats every 2 s until then." },
            new[] { "OWN SHIP", "Own ship has a box of its own on the left. COURSE: type a course in degrees true and press Enter or STEER (Enter on the keyboard focuses the box, Esc leaves it); STEADY holds the heading. HELM: type the rudder angle in degrees, then PORT or STBD; MIDSHIPS centres the rudder. SPEED: knots, then SET. The telegraph buttons give engine orders such as HALF AHEAD. The log shows the sim's reply to every order. The panel shows heading, speed, rudder, rate of turn and the ordered values." },
            new[] { "SIM", "SIM SPEED runs the sim at 1 to 10 times real time (F5, F6). PAUSE (P) stops the clock; the picture stays. RESTART SIM starts the sim again. SETUP opens the window for a new run, the environment and the traffic. A collision or a grounding stops the sim and shows its text in the status line and the message pane; P resumes." },
            new[] { "SETUP", "NEW RUN starts a run with a seed (0 picks one at random) and a scenario, RANDOM or CALIBRATION, and clears the picture, the trails and the targets. The same seed and scenario give the same traffic. Wind, sea state, current, rain and traffic can be changed while the sim runs. INTERFACE holds the colour mode (the C key cycles it) and the control style, which is not part of the radar: KNOBS, SLIDERS, or HYBRID (levels such as gain, STC, FTC and brilliance, and bearings, are knobs; distances such as VRM and the PI distance, and the trial speed and delay, are sliders). With SEA STATE FROM WIND on, the sea state follows the wind speed; setting the sea state by hand turns it off." },
            new[] { "INSTRUCTOR OVERLAY", "Ctrl+Shift+T shows the truth: a diamond at the true position of every contact with a line of its true motion over 6 MIN and a label with its kind, true course, speed and length, and a dotted line for own ship's track over the ground. Nothing else in the display shows this." },
        };

        // The whole help text as lines: title, the groups, then the hotkey table.
        public static List<string> Lines()
        {
            List<string> lines = new List<string>();
            lines.Add("RADAR SIM HELP");
            lines.Add("");
            foreach (string[] group in Groups)
            {
                lines.Add(group[0]);
                lines.Add(group[1]);
                lines.Add("");
            }
            lines.Add("HOTKEYS");
            foreach (HotkeyRow row in HotkeyTable.Rows)
            {
                lines.Add(row.KeysText + "   " + row.ActionText);
            }
            return lines;
        }

        public static string Text()
        {
            StringBuilder text = new StringBuilder();
            foreach (string line in Lines())
            {
                text.Append(line).Append('\n');
            }
            return text.ToString();
        }
    }
}
