// PpiGeometry.cs - the PPI maths: range and bearing to pixel and back for every
// orientation and offset, range rings, heading line end, bearing-scale ticks.
// No WPF types, so the self-tests can run it anywhere.
// Units: ranges NM, bearings deg T (clockwise from north), screen angles deg
// (clockwise from the top of the picture), positions in pixels of the PPI bitmap.
// In pixel coordinates x grows to the right and y grows downward. The bitmap
// centre is (SizePx / 2, SizePx / 2) and the PPI radius is SizePx / 2 pixels,
// which is the range scale.
// Called by: PpiBitmap (painting), PpiView (drawing), MainWindow, SelfTest.

using System;
using System.Collections.Generic;

namespace RadarSim
{
    public enum PpiOrientation { NorthUp, HeadUp, CourseUp }

    public struct BearingTick
    {
        public double BearingDegTrue;
        public double ScreenAngleDeg;
        public bool IsLong;         // every 30 deg
        public bool HasLabel;       // every 30 deg
    }

    public class PpiGeometry
    {
        public int SizePx = 1024;
        public double RangeScaleNm = 6.0;
        public PpiOrientation Orientation = PpiOrientation.NorthUp;
        public double HeadingDegTrue = 0.0;             // current gyro heading
        public double LatchedCourseDegTrue = 0.0;       // course-up: the heading that was latched
        public double OffsetXFraction = 0.0;            // own ship right of the centre, fraction of the radius
        public double OffsetYFraction = 0.0;            // own ship above the centre, fraction of the radius
        public double OffsetMaxFraction = 0.66;         // longest offset allowed, fraction of the radius

        // True motion (north-up only). The picture is fixed in the stabilisation frame: the point
        // (ViewOriginXNm, ViewOriginYNm) of that frame is at the screen centre, and own ship is drawn
        // at its reference position minus that origin. OwnRef is the reference position now.
        public bool TrueMotion = false;
        public double ViewOriginXNm = 0.0;              // NM east, stabilisation frame
        public double ViewOriginYNm = 0.0;              // NM north, stabilisation frame
        public double OwnRefXNm = 0.0;                  // own-ship reference position now (the UI copy only)
        public double OwnRefYNm = 0.0;
        public double TrueMotionResetFraction = 0.75;   // own ship this far from the centre (fraction of the radius) resets the picture
        public bool OriginChanged = false;              // the UI set the view origin; the painter takes it once
        public bool OriginPending = false;              // true motion wants a reset but no reference position is known yet; the next spoke sets it

        public PpiGeometry Copy()
        {
            return (PpiGeometry)MemberwiseClone();
        }

        public double RadiusPx
        {
            get { return SizePx / 2.0; }
        }

        public double CentreXPx
        {
            get { return SizePx / 2.0; }
        }

        public double CentreYPx
        {
            get { return SizePx / 2.0; }
        }

        // ---- own-ship position on the screen ----

        // The offset with its length limited to OffsetMaxFraction.
        private void LimitedOffset(out double x, out double y)
        {
            x = OffsetXFraction;
            y = OffsetYFraction;
            double length = Math.Sqrt(x * x + y * y);
            if (length > OffsetMaxFraction && length > 0.0)
            {
                x = x * OffsetMaxFraction / length;
                y = y * OffsetMaxFraction / length;
            }
        }

        public double OffsetMagnitude
        {
            get
            {
                double x, y;
                LimitedOffset(out x, out y);
                return Math.Sqrt(x * x + y * y);
            }
        }

        // True motion in use: it only works with north-up.
        public bool TrueMotionActive
        {
            get { return TrueMotion && Orientation == PpiOrientation.NorthUp; }
        }

        // Own ship's pixel for a reference position. In relative motion it is the offset
        // position whatever the reference; in true motion it is the reference minus the view origin.
        public void OwnPixelFor(double refXNm, double refYNm, out double xPx, out double yPx)
        {
            if (TrueMotionActive)
            {
                double pxPerNm = RadiusPx / RangeScaleNm;                       // px per NM
                xPx = CentreXPx + (refXNm - ViewOriginXNm) * pxPerNm;
                yPx = CentreYPx - (refYNm - ViewOriginYNm) * pxPerNm;           // north is up, and up is smaller y
                return;
            }
            double x, y;
            LimitedOffset(out x, out y);
            xPx = CentreXPx + x * RadiusPx;
            yPx = CentreYPx - y * RadiusPx;                                     // + offset is up, and up is smaller y
        }

        // Puts own ship (at this reference position) at the offset position, or the centre when there is no offset.
        public void ResetViewOrigin(double refXNm, double refYNm)
        {
            double x, y;
            LimitedOffset(out x, out y);
            ViewOriginXNm = refXNm - x * RangeScaleNm;
            ViewOriginYNm = refYNm - y * RangeScaleNm;
            OriginChanged = true;
        }

        // True motion: own ship at this reference position is past the reset circle.
        public bool BeyondResetLimit(double refXNm, double refYNm)
        {
            double xPx, yPx;
            OwnPixelFor(refXNm, refYNm, out xPx, out yPx);
            double dx = xPx - CentreXPx;
            double dy = yPx - CentreYPx;
            double limitPx = TrueMotionResetFraction * RadiusPx;
            return dx * dx + dy * dy > limitPx * limitPx;
        }

        public double OwnXPx
        {
            get
            {
                double x, y;
                OwnPixelFor(OwnRefXNm, OwnRefYNm, out x, out y);
                return x;
            }
        }

        public double OwnYPx
        {
            get
            {
                double x, y;
                OwnPixelFor(OwnRefXNm, OwnRefYNm, out x, out y);
                return y;
            }
        }

        // ---- angles ----

        public static double Normalise360(double angleDeg)
        {
            double result = angleDeg % 360.0;
            if (result < 0.0)
            {
                result += 360.0;
            }
            if (result >= 360.0)
            {
                result = 0.0;
            }
            return result;
        }

        // The true bearing that points to the top of the screen.
        public double TopBearingDegTrue
        {
            get
            {
                if (Orientation == PpiOrientation.HeadUp)
                {
                    return Normalise360(HeadingDegTrue);
                }
                if (Orientation == PpiOrientation.CourseUp)
                {
                    return Normalise360(LatchedCourseDegTrue);
                }
                return 0.0;
            }
        }

        // Screen angle of a true bearing, deg clockwise from the top.
        public double ScreenAngleDeg(double bearingDegTrue)
        {
            return Normalise360(bearingDegTrue - TopBearingDegTrue);
        }

        // Screen angle of a spoke. The spoke's own gyro heading is used, as on a real
        // radar: in head-up the picture is the relative bearing, whatever the heading
        // does later.
        public double SpokeScreenAngleDeg(double relativeBearingDeg, double gyroHeadingDeg)
        {
            if (Orientation == PpiOrientation.HeadUp)
            {
                return Normalise360(relativeBearingDeg);
            }
            if (Orientation == PpiOrientation.CourseUp)
            {
                return Normalise360(relativeBearingDeg + gyroHeadingDeg - LatchedCourseDegTrue);
            }
            return Normalise360(relativeBearingDeg + gyroHeadingDeg);
        }

        // Relative bearing (deg R) of a true bearing, from the current heading.
        public double RelativeBearingDeg(double bearingDegTrue)
        {
            return Normalise360(bearingDegTrue - HeadingDegTrue);
        }

        // ---- range and bearing <-> pixel ----

        public void PixelOf(double rangeNm, double bearingDegTrue, out double xPx, out double yPx)
        {
            double radiusPx = rangeNm / RangeScaleNm * RadiusPx;                // NM -> px
            double angleRad = ScreenAngleDeg(bearingDegTrue) * Math.PI / 180.0; // deg -> rad
            xPx = OwnXPx + radiusPx * Math.Sin(angleRad);
            yPx = OwnYPx - radiusPx * Math.Cos(angleRad);
        }

        public void RangeBearingOf(double xPx, double yPx, out double rangeNm, out double bearingDegTrue)
        {
            double dx = xPx - OwnXPx;
            double dy = OwnYPx - yPx;                                           // up is positive
            double radiusPx = Math.Sqrt(dx * dx + dy * dy);
            rangeNm = radiusPx / RadiusPx * RangeScaleNm;                       // px -> NM
            double screenAngleDeg = Math.Atan2(dx, dy) * 180.0 / Math.PI;       // rad -> deg
            bearingDegTrue = Normalise360(screenAngleDeg + TopBearingDegTrue);
        }

        // ---- rings, heading line, bearing scale ----

        // Radii in pixels of the range rings, n x interval, out to the farthest point of the PPI
        // circle from own ship: the range scale when own ship is at the centre, more when it is offset.
        public List<double> RingRadiiPx(double ringIntervalNm)
        {
            List<double> radii = new List<double>();
            if (ringIntervalNm <= 0.0)
            {
                return radii;
            }
            double ownFromCentreX = OwnXPx - CentreXPx;
            double ownFromCentreY = OwnYPx - CentreYPx;
            double farthestNm = (Math.Sqrt(ownFromCentreX * ownFromCentreX + ownFromCentreY * ownFromCentreY) + RadiusPx) / RadiusPx * RangeScaleNm;
            for (int ring = 1; ring * ringIntervalNm <= farthestNm + 1e-6; ring++)
            {
                radii.Add(ring * ringIntervalNm / RangeScaleNm * RadiusPx);
            }
            return radii;
        }

        // Where a line from own ship at a screen angle meets the edge of the PPI circle.
        public void EdgePointPx(double screenAngleDeg, out double xPx, out double yPx)
        {
            double angleRad = screenAngleDeg * Math.PI / 180.0;
            double dx = Math.Sin(angleRad);
            double dy = -Math.Cos(angleRad);
            double ownFromCentreX = OwnXPx - CentreXPx;
            double ownFromCentreY = OwnYPx - CentreYPx;
            double along = ownFromCentreX * dx + ownFromCentreY * dy;
            double outside = ownFromCentreX * ownFromCentreX + ownFromCentreY * ownFromCentreY - RadiusPx * RadiusPx;
            double length = -along + Math.Sqrt(along * along - outside);
            xPx = OwnXPx + length * dx;
            yPx = OwnYPx + length * dy;
        }

        public void HeadingLineEndPx(out double xPx, out double yPx)
        {
            EdgePointPx(ScreenAngleDeg(HeadingDegTrue), out xPx, out yPx);
        }

        // Where the line from own ship at a screen angle (deg clockwise from straight up) meets the edge of
        // the display circle, in bitmap pixels, with the outward unit vector there (the bearing scale is
        // read from own ship, so with an offset its ticks are not evenly spaced round the edge).
        public void ScaleEdgePoint(double screenAngleDeg, out double xPx, out double yPx, out double outX, out double outY)
        {
            double angleRad = screenAngleDeg * Math.PI / 180.0;     // deg -> rad
            double dx = Math.Sin(angleRad);
            double dy = -Math.Cos(angleRad);
            double wx = OwnXPx - CentreXPx;
            double wy = OwnYPx - CentreYPx;
            double along = wx * dx + wy * dy;
            double discriminant = along * along - (wx * wx + wy * wy) + RadiusPx * RadiusPx;
            double t = discriminant >= 0.0 ? -along + Math.Sqrt(discriminant) : RadiusPx;      // px
            xPx = OwnXPx + t * dx;
            yPx = OwnYPx + t * dy;
            double ex = xPx - CentreXPx;
            double ey = yPx - CentreYPx;
            double length = Math.Sqrt(ex * ex + ey * ey);
            outX = length > 1e-9 ? ex / length : dx;
            outY = length > 1e-9 ? ey / length : dy;
        }

        // A tick every 10 deg of true bearing; long and labelled every 30 deg.
        // The scale shows true bearings, turned to suit the orientation.
        public List<BearingTick> BearingTicks()
        {
            List<BearingTick> ticks = new List<BearingTick>();
            for (int bearingDeg = 0; bearingDeg < 360; bearingDeg += 10)
            {
                BearingTick tick = new BearingTick();
                tick.BearingDegTrue = bearingDeg;
                tick.ScreenAngleDeg = ScreenAngleDeg(bearingDeg);
                tick.IsLong = bearingDeg % 30 == 0;
                tick.HasLabel = bearingDeg % 30 == 0;
                ticks.Add(tick);
            }
            return ticks;
        }
    }
}
