// ArpaPanel.xaml.cs - the ARPA controls, built from hello.controls
// so the panel holds no limits of its own: ACQUIRE (then click the echo), CANCEL, CANCEL ALL; VECTOR
// MODE (TRUE, REL) and VECTOR TIME; HISTORY; CPA LIMIT and TCPA LIMIT; two guard zones with enable, inner
// and outer range and start and end bearing typed in; the TRIAL group (enable, course, speed, delay in MIN as knobs or sliders);
// The selected target's readout is drawn on the PPI (PpiView). STABILISATION is in the ControlPanel (M7).
// It only shows the controller's state and calls its methods; every number shows its unit.
// Units: CPA limit NM, TCPA limit MIN, vector time MIN, guard-zone ranges NM and bearings deg (relative
// or true, as the label says), trial course deg T, speed KN, delay s.
// Called by: MainWindow (Build after each hello), SelfTest.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace RadarSim
{
    public partial class ArpaPanel : UserControl
    {
        private DisplayController controller;
        private readonly List<ValueControl> valueControls = new List<ValueControl>();
        private Button acquireButton;
        private Button vectorModeButton;
        private ComboBox vectorTimeBox;
        private Button historyButton;
        private TextBlock guardReferenceText;
        private readonly Button[] zoneButtons = new Button[ArpaController.ZoneCount];
        private readonly TextBox[][] zoneBoxes = new TextBox[ArpaController.ZoneCount][];     // inner, outer, start, end
        private Button trialButton;
        private readonly ValueControl[] trialControls = new ValueControl[3];                  // course, speed, delay
        private bool built;
        private bool zoneKeyHandled;                // Enter or Esc already dealt with the box that is losing focus
        private bool refreshing;                    // true while the widgets are set from the controller

        public ArpaPanel()
        {
            InitializeComponent();
        }

        public List<ValueControl> ValueControls
        {
            get { return valueControls; }
        }

        // Builds every control from the controller's limits. Called after each "hello".
        public void Build(DisplayController newController)
        {
            if (controller != null)
            {
                controller.Changed -= Refresh;
            }
            controller = newController;
            controller.Changed += Refresh;

            Root.Children.Clear();
            valueControls.Clear();

            AddHeader("ARPA");
            BuildTargetButtons();
            BuildVectorRows();
            AddValue("CPA LIMIT", ArpaController.CpaLimitPath);
            AddValue("TCPA LIMIT", ArpaController.TcpaLimitPath);

            AddHeader("GUARD ZONES");
            guardReferenceText = new TextBlock();
            guardReferenceText.FontSize = 10;
            guardReferenceText.Margin = new Thickness(0, 0, 0, 2);
            Root.Children.Add(guardReferenceText);
            for (int zone = 0; zone < ArpaController.ZoneCount; zone++)
            {
                BuildZoneRow(zone);
            }

            AddHeader("TRIAL MANEUVER");
            BuildTrialRow();

            built = true;
            Refresh();
        }

        // ---- building blocks ----

        private void AddHeader(string text)
        {
            TextBlock header = new TextBlock();
            header.Text = text;
            header.FontWeight = FontWeights.Bold;
            header.Margin = new Thickness(0, 8, 0, 4);
            Root.Children.Add(header);
        }

        private void AddValue(string label, string path)
        {
            ControlLimits limits;
            if (!controller.Limits.TryGetValue(path, out limits))
            {
                return;
            }
            double value = 0.0;
            controller.Numbers.TryGetValue(path, out value);
            ValueControl control = new ValueControl();
            control.Configure(path, label, limits.Unit, limits.Min, limits.Max, limits.Step, limits.NumberChoices, value);
            control.SetStyle(controller.Style);
            control.ValueSent += ValueSentFromControl;
            Root.Children.Add(control);
            valueControls.Add(control);
        }

        private void ValueSentFromControl(ValueControl control, double value)
        {
            controller.SetRuntimeNumber(control.Path, value);
        }

        private static TextBlock SmallText(string text)
        {
            TextBlock block = new TextBlock();
            block.Text = text;
            block.VerticalAlignment = VerticalAlignment.Center;
            return block;
        }

        private static string Fixed(double value, string pattern)
        {
            return value.ToString(pattern, CultureInfo.InvariantCulture);
        }

        private static TextBox NewBox(double width, KeyEventHandler handler)
        {
            TextBox box = new TextBox();
            box.Width = width;
            box.KeyDown += handler;
            return box;
        }

        // ---- acquire, cancel ----

        private void BuildTargetButtons()
        {
            StackPanel row = new StackPanel();
            row.Orientation = Orientation.Horizontal;
            row.Margin = new Thickness(0, 0, 0, 4);
            acquireButton = new Button();
            acquireButton.Width = 130;
            acquireButton.Click += Acquire_Click;
            row.Children.Add(acquireButton);
            Button cancel = new Button();
            cancel.Content = "CANCEL";
            cancel.Width = 70;
            cancel.Margin = new Thickness(4, 0, 0, 0);
            cancel.Click += Cancel_Click;
            row.Children.Add(cancel);
            Button cancelAll = new Button();
            cancelAll.Content = "CANCEL ALL";
            cancelAll.Width = 90;
            cancelAll.Margin = new Thickness(4, 0, 0, 0);
            cancelAll.Click += CancelAll_Click;
            row.Children.Add(cancelAll);
            Root.Children.Add(row);
        }

        private void Acquire_Click(object sender, RoutedEventArgs e)
        {
            controller.Arpa.ArmAcquire();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            controller.Arpa.CancelSelected();
        }

        private void CancelAll_Click(object sender, RoutedEventArgs e)
        {
            controller.Arpa.CancelAll();
        }

        // ---- vectors and history ----

        private void BuildVectorRows()
        {
            StackPanel modeRow = new StackPanel();
            modeRow.Orientation = Orientation.Horizontal;
            modeRow.Margin = new Thickness(0, 0, 0, 4);
            TextBlock modeLabel = SmallText("VECTOR MODE");
            modeLabel.Width = 100;
            modeRow.Children.Add(modeLabel);
            vectorModeButton = new Button();
            vectorModeButton.Width = 90;
            vectorModeButton.Click += VectorMode_Click;
            modeRow.Children.Add(vectorModeButton);
            historyButton = new Button();
            historyButton.Width = 100;
            historyButton.Margin = new Thickness(8, 0, 0, 0);
            historyButton.Click += History_Click;
            modeRow.Children.Add(historyButton);
            Root.Children.Add(modeRow);

            StackPanel timeRow = new StackPanel();
            timeRow.Orientation = Orientation.Horizontal;
            timeRow.Margin = new Thickness(0, 0, 0, 4);
            TextBlock timeLabel = SmallText("VECTOR TIME");
            timeLabel.Width = 100;
            timeRow.Children.Add(timeLabel);
            vectorTimeBox = new ComboBox();
            vectorTimeBox.Width = 80;
            foreach (double minutes in controller.Arpa.VectorTimesMin)
            {
                ComboBoxItem item = new ComboBoxItem();
                item.Content = minutes.ToString("0.#", CultureInfo.InvariantCulture) + " MIN";
                item.Tag = minutes;
                vectorTimeBox.Items.Add(item);
            }
            vectorTimeBox.SelectionChanged += VectorTime_Changed;
            timeRow.Children.Add(vectorTimeBox);
            Root.Children.Add(timeRow);
        }

        private static void AddChoice(ComboBox box, string text, object tag)
        {
            ComboBoxItem item = new ComboBoxItem();
            item.Content = text;
            item.Tag = tag;
            box.Items.Add(item);
        }

        private static void SelectByTag(ComboBox box, object tag)
        {
            foreach (object entry in box.Items)
            {
                ComboBoxItem item = entry as ComboBoxItem;
                if (item == null)
                {
                    continue;
                }
                bool same = item.Tag is double && tag is double
                    ? Math.Abs((double)item.Tag - (double)tag) < 1e-9
                    : object.Equals(item.Tag, tag);
                if (same)
                {
                    box.SelectedItem = item;
                    return;
                }
            }
        }

        private void VectorMode_Click(object sender, RoutedEventArgs e)
        {
            controller.Arpa.SetVectorMode(!controller.Arpa.VectorTrue);
        }

        private void VectorTime_Changed(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem item = vectorTimeBox.SelectedItem as ComboBoxItem;
            if (refreshing || item == null)
            {
                return;
            }
            controller.Arpa.SetVectorTimeMin((double)item.Tag);
        }

        private void History_Click(object sender, RoutedEventArgs e)
        {
            controller.Arpa.SetHistory(!controller.Arpa.HistoryOn);
        }

        // ---- guard zones ----

        private void BuildZoneRow(int zoneIndex)
        {
            StackPanel row = new StackPanel();
            row.Orientation = Orientation.Horizontal;
            row.Margin = new Thickness(0, 0, 0, 2);
            Button button = new Button();
            button.Width = 70;
            button.Tag = zoneIndex;
            button.Click += ZoneButton_Click;
            row.Children.Add(button);
            zoneButtons[zoneIndex] = button;

            TextBox[] boxes = new TextBox[4];
            string[] labels = new string[] { " IN ", " OUT ", " NM  FROM ", " TO " };
            string[] units = new string[] { "", " NM", "", " deg" };
            for (int i = 0; i < 4; i++)
            {
                row.Children.Add(SmallText(labels[i]));
                boxes[i] = NewBox(i < 2 ? 40 : 44, ZoneBox_KeyDown);
                boxes[i].Tag = zoneIndex;
                boxes[i].LostKeyboardFocus += ZoneBox_LostFocus;
                row.Children.Add(boxes[i]);
                if (units[i] != "")
                {
                    row.Children.Add(SmallText(units[i]));
                }
            }
            zoneBoxes[zoneIndex] = boxes;
            Root.Children.Add(row);
        }

        private void ZoneButton_Click(object sender, RoutedEventArgs e)
        {
            int zone = (int)((Button)sender).Tag;
            ApplyZone(zone, !controller.Arpa.Zones[zone].Enabled);
        }

        private void ZoneBox_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox box = (TextBox)sender;
            int zone = (int)box.Tag;
            if (e.Key == Key.Escape)
            {
                zoneKeyHandled = true;
                Keyboard.ClearFocus();
                zoneKeyHandled = false;
                Refresh();
                e.Handled = true;
            }
            else if (e.Key == Key.Enter)
            {
                ApplyZone(zone, controller.Arpa.Zones[zone].Enabled);
                zoneKeyHandled = true;
                Keyboard.ClearFocus();
                zoneKeyHandled = false;
                e.Handled = true;
            }
        }

        // Clicking away keeps what was typed, as Enter does (Esc cancels).
        private void ZoneBox_LostFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            if (zoneKeyHandled || controller == null || refreshing)
            {
                return;
            }
            int zone = (int)((TextBox)sender).Tag;
            ApplyZone(zone, controller.Arpa.Zones[zone].Enabled);
        }

        // Sends the typed values. A box that is not a number keeps the zone's last values.
        private void ApplyZone(int zone, bool enabled)
        {
            GuardZoneSettings now = controller.Arpa.Zones[zone];
            double[] values = new double[] { now.InnerNm, now.OuterNm, now.StartDeg, now.EndDeg };
            for (int i = 0; i < 4; i++)
            {
                double typed;
                if (ArpaController.TryParseNumber(zoneBoxes[zone][i].Text, out typed))
                {
                    values[i] = typed;
                }
            }
            controller.Arpa.SetGuardZone(zone + 1, enabled, values[0], values[1], values[2], values[3]);
        }

        // ---- trial ----

        private void BuildTrialRow()
        {
            trialButton = new Button();
            trialButton.Width = 90;
            trialButton.HorizontalAlignment = HorizontalAlignment.Left;
            trialButton.Margin = new Thickness(0, 0, 0, 2);
            trialButton.Click += TrialButton_Click;
            Root.Children.Add(trialButton);
            ControlRow trialRow = new ControlRow();
            trialRow.Columns = 3;
            Root.Children.Add(trialRow);
            trialControls[0] = NewTrialControl("COURSE", "deg T", 360.0, 1.0, trialRow);
            trialControls[1] = NewTrialControl("SPEED", "KN", 40.0, 0.5, trialRow);
            trialControls[2] = NewTrialControl("DELAY", "MIN", 30.0, 0.1, trialRow);
        }

        // A knob or slider with a typed value, like the others. The path is a name only; the trial goes to
        // the sim as one message. The delay is entered in minutes (0.1 = 6 s) and sent in seconds.
        private ValueControl NewTrialControl(string label, string unit, double maximum, double step, ControlRow row)
        {
            ValueControl control = new ValueControl();
            control.Configure("trial." + label, label, unit, 0.0, maximum, step, null, 0.0);
            control.SetStyle(controller.Style);
            control.ValueSent += TrialValueSent;
            row.AddControl(control);
            return control;
        }

        private void TrialValueSent(ValueControl control, double value)
        {
            ApplyTrial(controller.Arpa.Trial.Enabled);
        }

        private void TrialButton_Click(object sender, RoutedEventArgs e)
        {
            ApplyTrial(!controller.Arpa.Trial.Enabled);
        }

        // Sends the three values as they stand on the controls.
        private void ApplyTrial(bool enabled)
        {
            controller.Arpa.SetTrial(enabled, trialControls[0].Model.Value, trialControls[1].Model.Value,
                                     trialControls[2].Model.Value * ArpaController.SecondsPerMinute);
        }

        // ---- showing the controller's state ----

        public void Refresh()
        {
            if (controller == null || refreshing || !built)
            {
                return;
            }
            refreshing = true;
            ArpaController arpa = controller.Arpa;

            foreach (ValueControl control in valueControls)
            {
                double value;
                if (controller.Numbers.TryGetValue(control.Path, out value))
                {
                    control.ConfirmFromSim(value);
                }
                control.SetStyle(controller.Style);
            }

            acquireButton.Content = arpa.AcquireArmed ? "STOP ACQUIRING" : "ACQUIRE";
            acquireButton.FontWeight = arpa.AcquireArmed ? FontWeights.Bold : FontWeights.Normal;
            vectorModeButton.Content = arpa.VectorTrue ? "TRUE" : "RELATIVE";
            SelectByTag(vectorTimeBox, arpa.VectorTimeMin);
            historyButton.Content = arpa.HistoryOn ? "HISTORY ON" : "HISTORY OFF";
            guardReferenceText.Text = arpa.GuardReferenceRelative ? "(bearings relative to the bow, deg R; Enter applies)"
                                                                  : "(bearings true, deg T; Enter applies)";

            for (int zone = 0; zone < ArpaController.ZoneCount; zone++)
            {
                GuardZoneSettings settings = arpa.Zones[zone];
                zoneButtons[zone].Content = "ZONE " + (zone + 1) + (settings.Enabled ? " ON" : " OFF");
                zoneButtons[zone].FontWeight = settings.Enabled ? FontWeights.Bold : FontWeights.Normal;
                double[] values = new double[] { settings.InnerNm, settings.OuterNm, settings.StartDeg, settings.EndDeg };
                string[] patterns = new string[] { "0.00", "0.00", "000", "000" };
                for (int i = 0; i < 4; i++)
                {
                    if (!zoneBoxes[zone][i].IsKeyboardFocused)
                    {
                        zoneBoxes[zone][i].Text = Fixed(values[i], patterns[i]);
                    }
                }
            }

            trialButton.Content = arpa.Trial.Enabled ? "TRIAL ON" : "TRIAL OFF";
            trialButton.FontWeight = arpa.Trial.Enabled ? FontWeights.Bold : FontWeights.Normal;
            double[] trialValues = new double[] { arpa.Trial.CourseDegTrue, arpa.Trial.SpeedKn, arpa.Trial.DelayS / ArpaController.SecondsPerMinute };
            for (int i = 0; i < 3; i++)
            {
                trialControls[i].ConfirmFromSim(trialValues[i]);
                trialControls[i].SetStyle(controller.Style);
            }
            refreshing = false;
        }
    }
}
