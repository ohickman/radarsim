// TargetReadout.cs - the selected target's data as rows of text, every value with its unit:
// ID, BRG (deg T and deg R), RNG, CRS, SPD, CPA, TCPA, BCR, BCT, and while a trial is on also
// the trial CPA and TCPA. A value the sim sent as null shows "--". TCPA keeps the sign the sim
// sends (negative = the target is opening). No WPF types.
// Units: BRG and CRS deg T / deg R, RNG, CPA and BCR NM, SPD KN, TCPA and BCT MIN.
// Called by: ArpaPanel (shows the rows), SelfTest.

using System.Collections.Generic;
using System.Globalization;

namespace RadarSim
{
    public class ReadoutRow
    {
        public string Label;
        public string Text;

        public ReadoutRow(string label, string text)
        {
            Label = label;
            Text = text;
        }
    }

    public static class TargetReadout
    {
        public const string NoValue = "--";

        private static string Format(double? value, string pattern, string unit)
        {
            if (!value.HasValue)
            {
                return NoValue;
            }
            return value.Value.ToString(pattern, CultureInfo.InvariantCulture) + " " + unit;
        }

        // Rows for one target; headingDegTrue turns the true bearing into a relative one.
        public static List<ReadoutRow> Rows(TargetRecord target, double headingDegTrue, bool trialOn)
        {
            List<ReadoutRow> rows = new List<ReadoutRow>();
            if (target == null)
            {
                return rows;
            }
            double bearingRelative = PpiGeometry.Normalise360(target.BearingDegTrue - headingDegTrue);
            rows.Add(new ReadoutRow("ID", target.Id.ToString(CultureInfo.InvariantCulture)));
            rows.Add(new ReadoutRow("BRG", target.BearingDegTrue.ToString("000.0", CultureInfo.InvariantCulture) + " deg T   "
                + bearingRelative.ToString("000.0", CultureInfo.InvariantCulture) + " deg R"));
            rows.Add(new ReadoutRow("RNG", Format(target.RangeNm, "0.00", "NM")));
            rows.Add(new ReadoutRow("CRS", Format(target.CourseDegTrue, "000.0", "deg T")));
            rows.Add(new ReadoutRow("SPD", Format(target.SpeedKn, "0.0", "KN")));
            rows.Add(new ReadoutRow("CPA", Format(target.CpaNm, "0.00", "NM")));
            rows.Add(new ReadoutRow("TCPA", Format(target.TcpaMin, "0.0", "MIN")));
            rows.Add(new ReadoutRow("BCR", Format(target.BcrNm, "0.00", "NM")));
            rows.Add(new ReadoutRow("BCT", Format(target.BctMin, "0.0", "MIN")));
            if (trialOn)
            {
                rows.Add(new ReadoutRow("TRIAL CPA", Format(target.TrialCpaNm, "0.00", "NM")));
                rows.Add(new ReadoutRow("TRIAL TCPA", Format(target.TrialTcpaMin, "0.0", "MIN")));
            }
            return rows;
        }
    }
}
