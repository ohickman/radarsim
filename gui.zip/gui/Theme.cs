// Theme.cs - dark mode: dark gray background and controls, light text. The colours the program draws
// itself take their colour from the keys ThemeBack, ThemePanel, ThemeText, ThemeBorder and ThemeHover in
// the application's resources; the standard controls follow the system colours, which are replaced while
// dark mode is on, and the buttons and drop-downs get a dark template. The PPI, the knobs and the alarm
// colours do not change. Switching is live.
// Called by: MainWindow, SetupWindow, HelpWindow (Register), MainWindow (Apply).

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

namespace RadarSim
{
    public static class Theme
    {
        private static bool dark;
        private static bool started;
        private static ResourceDictionary darkStyles;

        private const string StylesXaml = @"
<ResourceDictionary xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                    xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>
  <Style TargetType='Button'>
    <Setter Property='Background' Value='{DynamicResource ThemePanel}'/>
    <Setter Property='Foreground' Value='{DynamicResource ThemeText}'/>
    <Setter Property='BorderBrush' Value='{DynamicResource ThemeBorder}'/>
    <Setter Property='BorderThickness' Value='1'/>
    <Setter Property='Padding' Value='6,2'/>
    <Setter Property='Template'>
      <Setter.Value>
        <ControlTemplate TargetType='Button'>
          <Border x:Name='Bd' Background='{TemplateBinding Background}' BorderBrush='{TemplateBinding BorderBrush}'
                  BorderThickness='{TemplateBinding BorderThickness}' CornerRadius='2' Padding='{TemplateBinding Padding}'>
            <ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Center' RecognizesAccessKey='True'/>
          </Border>
          <ControlTemplate.Triggers>
            <Trigger Property='IsMouseOver' Value='True'>
              <Setter TargetName='Bd' Property='Background' Value='{DynamicResource ThemeHover}'/>
            </Trigger>
            <Trigger Property='IsPressed' Value='True'>
              <Setter TargetName='Bd' Property='BorderBrush' Value='{DynamicResource ThemeText}'/>
            </Trigger>
            <Trigger Property='IsEnabled' Value='False'>
              <Setter Property='Foreground' Value='#FF8A8A8A'/>
            </Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>
  <Style TargetType='ComboBox'>
    <Setter Property='Background' Value='{DynamicResource ThemePanel}'/>
    <Setter Property='Foreground' Value='{DynamicResource ThemeText}'/>
    <Setter Property='BorderBrush' Value='{DynamicResource ThemeBorder}'/>
    <Setter Property='Template'>
      <Setter.Value>
        <ControlTemplate TargetType='ComboBox'>
          <Grid>
            <ToggleButton Focusable='False' ClickMode='Press'
                          IsChecked='{Binding IsDropDownOpen, Mode=TwoWay, RelativeSource={RelativeSource TemplatedParent}}'>
              <ToggleButton.Template>
                <ControlTemplate TargetType='ToggleButton'>
                  <Border Background='{DynamicResource ThemePanel}' BorderBrush='{DynamicResource ThemeBorder}'
                          BorderThickness='1' CornerRadius='2'>
                    <Path HorizontalAlignment='Right' VerticalAlignment='Center' Margin='0,0,6,0'
                          Data='M 0 0 L 4 4 L 8 0 Z' Fill='{DynamicResource ThemeText}'/>
                  </Border>
                </ControlTemplate>
              </ToggleButton.Template>
            </ToggleButton>
            <ContentPresenter IsHitTestVisible='False' Margin='6,2,22,2' VerticalAlignment='Center' HorizontalAlignment='Left'
                              Content='{TemplateBinding SelectionBoxItem}'
                              ContentTemplate='{TemplateBinding SelectionBoxItemTemplate}'
                              ContentStringFormat='{TemplateBinding SelectionBoxItemStringFormat}'/>
            <Popup Placement='Bottom' IsOpen='{TemplateBinding IsDropDownOpen}' AllowsTransparency='True' Focusable='False'>
              <Grid MinWidth='{Binding ActualWidth, RelativeSource={RelativeSource TemplatedParent}}'
                    MaxHeight='{TemplateBinding MaxDropDownHeight}'>
                <Border Background='{DynamicResource ThemePanel}' BorderBrush='{DynamicResource ThemeBorder}' BorderThickness='1'/>
                <ScrollViewer>
                  <ItemsPresenter KeyboardNavigation.DirectionalNavigation='Contained'/>
                </ScrollViewer>
              </Grid>
            </Popup>
          </Grid>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>
</ResourceDictionary>";

        public static bool Dark
        {
            get { return dark; }
        }

        private static void SetBrush(string key, byte red, byte green, byte blue)
        {
            SolidColorBrush brush = new SolidColorBrush(Color.FromRgb(red, green, blue));
            brush.Freeze();
            Application.Current.Resources[key] = brush;
        }

        private static void SetSystem(object key, byte red, byte green, byte blue)
        {
            SetBrushByKey(key, Color.FromRgb(red, green, blue));
        }

        private static void SetBrushByKey(object key, Color colour)
        {
            SolidColorBrush brush = new SolidColorBrush(colour);
            brush.Freeze();
            Application.Current.Resources[key] = brush;
        }

        private static readonly object[] SystemBrushKeys = new object[]
        {
            SystemColors.WindowBrushKey, SystemColors.WindowTextBrushKey, SystemColors.ControlBrushKey,
            SystemColors.ControlTextBrushKey, SystemColors.ControlLightBrushKey, SystemColors.ControlLightLightBrushKey,
            SystemColors.ControlDarkBrushKey, SystemColors.GrayTextBrushKey,
            SystemColors.InactiveSelectionHighlightBrushKey, SystemColors.InactiveSelectionHighlightTextBrushKey
        };

        // Dark mode on or off. Safe to call again with the same value.
        public static void Apply(bool wantDark)
        {
            if (Application.Current == null || (started && wantDark == dark))
            {
                return;
            }
            started = true;
            dark = wantDark;
            if (wantDark)
            {
                SetBrush("ThemeBack", 0x2D, 0x2D, 0x2D);
                SetBrush("ThemePanel", 0x3C, 0x3C, 0x3C);
                SetBrush("ThemeText", 0xE8, 0xE8, 0xE8);
                SetBrush("ThemeBorder", 0x70, 0x70, 0x70);
                SetBrush("ThemeHover", 0x55, 0x55, 0x55);
                SetSystem(SystemColors.WindowBrushKey, 0x3C, 0x3C, 0x3C);
                SetSystem(SystemColors.WindowTextBrushKey, 0xE8, 0xE8, 0xE8);
                SetSystem(SystemColors.ControlBrushKey, 0x3C, 0x3C, 0x3C);
                SetSystem(SystemColors.ControlTextBrushKey, 0xE8, 0xE8, 0xE8);
                SetSystem(SystemColors.ControlLightBrushKey, 0x4A, 0x4A, 0x4A);
                SetSystem(SystemColors.ControlLightLightBrushKey, 0x55, 0x55, 0x55);
                SetSystem(SystemColors.ControlDarkBrushKey, 0x70, 0x70, 0x70);
                SetSystem(SystemColors.GrayTextBrushKey, 0x9A, 0x9A, 0x9A);
                SetSystem(SystemColors.InactiveSelectionHighlightBrushKey, 0x55, 0x55, 0x55);
                SetSystem(SystemColors.InactiveSelectionHighlightTextBrushKey, 0xE8, 0xE8, 0xE8);
                if (darkStyles == null)
                {
                    try
                    {
                        darkStyles = (ResourceDictionary)XamlReader.Parse(StylesXaml);
                    }
                    catch (Exception problem)
                    {
                        Messages.Warn("Dark mode: the button and drop-down styles could not be made (" + problem.Message + "); the rest is dark.");
                        darkStyles = new ResourceDictionary();
                    }
                }
                if (!Application.Current.Resources.MergedDictionaries.Contains(darkStyles))
                {
                    Application.Current.Resources.MergedDictionaries.Add(darkStyles);
                }
            }
            else
            {
                SetBrush("ThemeBack", 0xFF, 0xFF, 0xFF);
                SetBrush("ThemePanel", 0xFF, 0xFF, 0xFF);
                SetBrush("ThemeText", 0x00, 0x00, 0x00);
                SetBrush("ThemeBorder", 0x80, 0x80, 0x80);
                SetBrush("ThemeHover", 0xE0, 0xE0, 0xE0);
                foreach (object key in SystemBrushKeys)
                {
                    Application.Current.Resources.Remove(key);
                }
                if (darkStyles != null)
                {
                    Application.Current.Resources.MergedDictionaries.Remove(darkStyles);
                }
            }
        }

        // A window takes its background and text colour from the theme, and follows it when it changes.
        public static void Register(Window window)
        {
            if (Application.Current != null && !started)
            {
                Apply(false);
            }
            window.SetResourceReference(Control.BackgroundProperty, "ThemeBack");
            window.SetResourceReference(Control.ForegroundProperty, "ThemeText");
        }
    }
}
