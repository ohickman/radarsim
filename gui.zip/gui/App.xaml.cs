// App.xaml.cs - program start: reads the command line, finds the project root,
// opens the main window.
// Options: --root <project folder>   (default: walk up from the .exe to radarsim.toml)
//          --no-launch               (connect to a sim that was started by hand)
//          --selftest                (run the self-tests, write selftest_results.txt, exit 0 or 1)
// Called by: WPF at start-up.

using System;
using System.IO;
using System.Windows;

namespace RadarSim
{
    public partial class App : Application
    {
        public const string ConfigFileName = "radarsim.toml";

        private void App_Startup(object sender, StartupEventArgs e)
        {
            string root = null;
            bool launchSim = true;
            bool selfTest = false;
            string problem = null;

            for (int i = 0; i < e.Args.Length; i++)
            {
                if (e.Args[i] == "--no-launch")
                {
                    launchSim = false;
                }
                else if (e.Args[i] == "--selftest")
                {
                    selfTest = true;
                }
                else if (e.Args[i] == "--root" && i + 1 < e.Args.Length)
                {
                    root = Path.GetFullPath(e.Args[i + 1]);
                    i++;
                }
                else
                {
                    problem = "Option not understood: " + e.Args[i] + ". Options: --root <project folder>, --no-launch, --selftest.";
                }
            }

            if (root == null)
            {
                root = FindProjectRoot(AppContext.BaseDirectory);
                if (root == null)
                {
                    problem = ConfigFileName + " not found in " + AppContext.BaseDirectory
                        + " or any folder above it. Start the display with --root <project folder>.";
                }
            }
            else if (!File.Exists(Path.Combine(root, ConfigFileName)))
            {
                problem = ConfigFileName + " not found in " + root + ". Check the --root option.";
                root = null;
            }

            if (selfTest)
            {
                Shutdown(SelfTest.Run(root));
                return;
            }

            Theme.Apply(false);
            MainWindow window = new MainWindow(root, launchSim, problem);
            window.Show();
        }

        // Walks up from a folder until radarsim.toml is found, so the display runs
        // from any working directory. Returns null when there is none.
        public static string FindProjectRoot(string startFolder)
        {
            DirectoryInfo folder = new DirectoryInfo(startFolder);
            while (folder != null)
            {
                if (File.Exists(Path.Combine(folder.FullName, ConfigFileName)))
                {
                    return folder.FullName;
                }
                folder = folder.Parent;
            }
            return null;
        }
    }
}
