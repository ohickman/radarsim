// BigReadoutText.cs - the text of the large own-ship heading and speed outside the PPI.
// Heading in deg T from the gyro, 000.0 to 359.9 (a heading that rounds to 360.0 shows 000.0);
// speed in KN with one decimal. No WPF types.
// Called by: BigReadout (the view), SelfTest.

using System;
using System.Globalization;

namespace RadarSim
{
    public static class BigReadoutText
    {
        public static string Heading(double headingDeg)
        {
            double wrapped = headingDeg % 360.0;                    // deg
            if (wrapped < 0.0)
            {
                wrapped += 360.0;
            }
            double rounded = Math.Round(wrapped, 1);
            if (rounded >= 360.0)
            {
                rounded = 0.0;
            }
            return rounded.ToString("000.0", CultureInfo.InvariantCulture);
        }

        public static string Speed(double speedKn)
        {
            return speedKn.ToString("0.0", CultureInfo.InvariantCulture);
        }
    }
}
