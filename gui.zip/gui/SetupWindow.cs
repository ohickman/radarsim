// SetupWindow.cs - the setup window (SETUP button): NEW RUN with a seed and a scenario; the environment
// (wind direction and speed, SEA STATE FROM WIND, sea state, current set and drift, rain rate); the
// traffic (maximum contacts, density); sim speed; the interface (colour mode, control style); the instructor overlay. Built in code from the
// controller's limits (hello.controls), so it holds no limits of its own. It only shows the controller's
// state and calls its methods; every number shows its unit.
// Units: wind and current direction deg T, speeds KN, rain mm/h, density contacts per 100 NM2, sim speed x.
// Called by: MainWindow.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace RadarSim
{
    public class SetupWindow : Window
    {
        public const string WindFromPath = "environment.wind_from_deg_true";
        public const string WindSpeedPath = "environment.wind_speed_kn";
        public const string SeaFromWindPath = "environment.sea_state_from_wind";
        public const string SeaStatePath = "environment.sea_state_douglas";
        public const string CurrentSetPath = "environment.current_set_deg_true";
        public const string CurrentDriftPath = "environment.current_drift_kn";
        public const string RainPath = "environment.rain_rate_mm_per_h";
        public const string RainCellsPath = "environment.rain_cell_count";
        public const string RainSizePath = "environment.rain_cell_radius_nm";
        public const string MaxContactsPath = "traffic.max_contacts";
        public const string DensityPath = "traffic.density_per_100_nm2";
        public const string MixShipPath = "traffic.mix_ship";
        public const string MixTugPath = "traffic.mix_tug_tow";
        public const string MixFishingPath = "traffic.mix_fishing";
        public const string MixPleasurePath = "traffic.mix_pleasure";
        public const string RoguePercentPath = "traffic.rogue_percent";
        public const string RogueNoGiveWayPath = "traffic.rogue_no_give_way";
        public const string RogueCrossBowPath = "traffic.rogue_cross_bow";
        public const string RogueLatePath = "traffic.rogue_late";

        private readonly DisplayController controller;
        private readonly WheelhouseData wheelhouse;
        private readonly List<ValueControl> localControls = new List<ValueControl>();       // display-only settings, not from the sim
        private readonly List<ValueControl> valueControls = new List<ValueControl>();
        private readonly StackPanel root = new StackPanel();
        private TextBox seedBox;
        private ComboBox scenarioBox;
        private ComboBox colourBox;
        private ComboBox styleBox;
        private ComboBox darkBox;
        private CheckBox seaFromWindBox;
        private CheckBox instructorBox;
        private readonly Dictionary<string, CheckBox> rogueBoxes = new Dictionary<string, CheckBox>();
        private bool refreshing;

        public SetupWindow(DisplayController controller, WheelhouseData wheelhouse)
        {
            this.controller = controller;
            this.wheelhouse = wheelhouse;
            Title = "Setup";
            Theme.Register(this);
            Width = 440;
            Height = 780;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;

            root.Margin = new Thickness(12);
            ScrollViewer scroll = new ScrollViewer();
            scroll.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            scroll.Content = root;
            Content = scroll;

            AddHeader("NEW RUN");
            BuildNewRunRow();
            AddHeader("ENVIRONMENT");
            AddValue("WIND FROM", WindFromPath);
            AddValue("WIND SPEED", WindSpeedPath);
            seaFromWindBox = AddCheckBox("SEA STATE FROM WIND", SeaFromWindChanged);
            AddValue("SEA STATE", SeaStatePath);
            AddValue("CURRENT SET", CurrentSetPath);
            AddValue("CURRENT DRIFT", CurrentDriftPath);
            AddValue("RAIN RATE", RainPath);
            AddValue("RAIN CELLS", RainCellsPath);
            AddValue("RAIN CELL RADIUS", RainSizePath);
            AddLocalValue("TIME OF DAY", "h", 0.0, 24.0, 0.25, wheelhouse.Hour, value => wheelhouse.Hour = value);
            AddLocalValue("VISIBILITY", "NM", 0.1, WheelhouseMath.ClearVisibilityNm, 0.1, wheelhouse.VisibilitySetNm, value => wheelhouse.VisibilitySetNm = value);
            AddLocalValue("VIS VARIABILITY", "", 0.0, 1.0, 0.05, wheelhouse.VisibilityVariability, value => wheelhouse.VisibilityVariability = value);
            AddHeader("TRAFFIC");
            AddValue("MAX CONTACTS", MaxContactsPath);
            AddValue("DENSITY", DensityPath);
            root.Children.Add(new TextBlock { Text = "MIX OF VESSELS (relative weights; TRAFFIC NOW builds the mix at once)", Margin = new Thickness(0, 6, 0, 2) });
            AddValue("MERCHANT SHIPS", MixShipPath);
            AddValue("TUGS WITH TOW", MixTugPath);
            AddValue("FISHING VESSELS", MixFishingPath);
            AddValue("PLEASURE CRAFT", MixPleasurePath);
            Button trafficNow = new Button();
            trafficNow.Content = "TRAFFIC NOW (add or remove contacts at once to match DENSITY)";
            trafficNow.HorizontalAlignment = HorizontalAlignment.Left;
            trafficNow.Padding = new Thickness(8, 2, 8, 2);
            trafficNow.Click += (sender, e) => controller.TrafficNow();
            root.Children.Add(trafficNow);
            AddHeader("MISBEHAVING SHIPS");
            AddValue("ROGUE SHIPS", RoguePercentPath);
            AddRogueBox("DOES NOT GIVE WAY", RogueNoGiveWayPath);
            AddRogueBox("GIVES WAY LATE", RogueLatePath);
            AddRogueBox("CROSSES AHEAD OF OWN SHIP", RogueCrossBowPath);
            AddHeader("SIM");
            AddValue("SIM SPEED", DisplayController.SpeedPath);
            AddHeader("INTERFACE (not part of the radar)");
            colourBox = AddChoice("COLOUR MODE", DisplayController.ColourPath, ColourChanged);
            styleBox = AddChoice("CONTROL STYLE", DisplayController.StylePath, StyleChanged);
            darkBox = AddChoice("DARK MODE", DisplayController.DarkPath, DarkChanged);
            AddHeader("INSTRUCTOR");
            instructorBox = AddCheckBox("INSTRUCTOR OVERLAY (Ctrl+Shift+T)", InstructorChanged);

            controller.Changed += Refresh;
            Closed += (sender, e) => controller.Changed -= Refresh;
            Refresh();
        }

        // ---- building blocks ----

        private void AddHeader(string text)
        {
            if (root.Children.Count > 0)
            {
                Separator line = new Separator();
                line.Margin = new Thickness(0, 10, 0, 0);
                root.Children.Add(line);
            }
            TextBlock header = new TextBlock();
            header.Text = text;
            header.FontWeight = FontWeights.Bold;
            header.Margin = new Thickness(0, 4, 0, 4);
            root.Children.Add(header);
        }

        private void AddValue(string label, string path)
        {
            ControlLimits limits;
            if (!controller.Limits.TryGetValue(path, out limits))
            {
                return;
            }
            double value = 0.0;
            controller.Numbers.TryGetValue(path, out value);
            ValueControl control = new ValueControl();
            control.Configure(path, label, limits.Unit, limits.Min, limits.Max, limits.Step, limits.NumberChoices, value);
            control.SetStyle(controller.Style);
            control.ValueSent += (sender, sent) => controller.SetRuntimeNumber(sender.Path, sent);
            root.Children.Add(control);
            valueControls.Add(control);
        }

        // A setting that only the wheelhouse view uses (time of day, visibility): it never goes to the sim.
        private void AddLocalValue(string label, string unit, double minimum, double maximum, double step, double value, Action<double> apply)
        {
            ValueControl control = new ValueControl();
            control.Configure("wheelhouse." + label, label, unit, minimum, maximum, step, null, value);
            control.SetStyle(controller.Style);
            control.ValueSent += (sender, sent) => apply(sent);
            root.Children.Add(control);
            localControls.Add(control);
        }

        // A row with a drop-down of the words the sim's control list allows.
        private ComboBox AddChoice(string label, string path, SelectionChangedEventHandler handler)
        {
            DockPanel row = new DockPanel();
            row.Margin = new Thickness(0, 0, 0, 4);
            TextBlock text = new TextBlock();
            text.Text = label;
            text.Width = 120;
            text.VerticalAlignment = VerticalAlignment.Center;
            DockPanel.SetDock(text, Dock.Left);
            row.Children.Add(text);
            ComboBox box = new ComboBox();
            ControlLimits limits;
            if (controller.Limits.TryGetValue(path, out limits) && limits.WordChoices != null)
            {
                foreach (string word in limits.WordChoices)
                {
                    ComboBoxItem item = new ComboBoxItem();
                    item.Content = word.Replace("_", " ").ToUpperInvariant().Replace("COLOR", "COLOUR");
                    item.Tag = word;
                    box.Items.Add(item);
                }
            }
            box.SelectionChanged += handler;
            row.Children.Add(box);
            root.Children.Add(row);
            return box;
        }

        private static string TagOf(ComboBox box)
        {
            ComboBoxItem item = box.SelectedItem as ComboBoxItem;
            return item == null ? null : item.Tag as string;
        }

        private static void Select(ComboBox box, string word)
        {
            foreach (object item in box.Items)
            {
                ComboBoxItem entry = item as ComboBoxItem;
                if (entry != null && (entry.Tag as string) == word && box.SelectedItem != item)
                {
                    box.SelectedItem = item;
                }
            }
        }

        private void ColourChanged(object sender, SelectionChangedEventArgs e)
        {
            string name = TagOf(colourBox);
            if (!refreshing && name != null)
            {
                controller.SetColourMode(name);
            }
        }

        private void DarkChanged(object sender, SelectionChangedEventArgs e)
        {
            string name = TagOf(darkBox);
            if (!refreshing && name != null)
            {
                controller.SetDarkMode(name == "on");
            }
        }

        private void StyleChanged(object sender, SelectionChangedEventArgs e)
        {
            string name = TagOf(styleBox);
            if (!refreshing && name != null)
            {
                controller.SetControlStyle(name);
            }
        }

        private void AddRogueBox(string text, string path)
        {
            CheckBox box = AddCheckBox(text, (sender, e) =>
            {
                if (!refreshing)
                {
                    controller.SetRuntimeFlag(path, ((CheckBox)sender).IsChecked == true);
                }
            });
            rogueBoxes[path] = box;
        }

        private CheckBox AddCheckBox(string text, RoutedEventHandler handler)
        {
            CheckBox box = new CheckBox();
            box.Content = text;
            box.Margin = new Thickness(0, 4, 0, 4);
            box.Click += handler;
            root.Children.Add(box);
            return box;
        }

        private void BuildNewRunRow()
        {
            StackPanel row = new StackPanel();
            row.Orientation = Orientation.Horizontal;
            row.Margin = new Thickness(0, 0, 0, 4);
            row.Children.Add(new TextBlock { Text = "SEED ", VerticalAlignment = VerticalAlignment.Center });
            seedBox = new TextBox();
            seedBox.Width = 90;
            seedBox.Text = controller.RunSeed.ToString(CultureInfo.InvariantCulture);
            seedBox.KeyDown += SeedKeyDown;
            row.Children.Add(seedBox);
            row.Children.Add(new TextBlock { Text = " (0 = random)   SCENARIO ", VerticalAlignment = VerticalAlignment.Center });
            scenarioBox = new ComboBox();
            scenarioBox.Width = 110;
            scenarioBox.Items.Add("random");
            scenarioBox.Items.Add("calibration");
            scenarioBox.SelectedItem = controller.RunScenario;
            row.Children.Add(scenarioBox);
            root.Children.Add(row);

            Button start = new Button();
            start.Content = "NEW RUN";
            start.Width = 100;
            start.HorizontalAlignment = HorizontalAlignment.Left;
            start.Click += (sender, e) => StartNewRun();
            root.Children.Add(start);
        }

        // ---- actions ----

        private void SeedKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                StartNewRun();
            }
        }

        private void StartNewRun()
        {
            string problem;
            if (!controller.StartNewRun(seedBox.Text, scenarioBox.SelectedItem as string, out problem))
            {
                Messages.Error(problem);
            }
        }

        private void SeaFromWindChanged(object sender, RoutedEventArgs e)
        {
            controller.SetRuntimeFlag(SeaFromWindPath, seaFromWindBox.IsChecked == true);
        }

        private void InstructorChanged(object sender, RoutedEventArgs e)
        {
            controller.SetInstructor(instructorBox.IsChecked == true);
        }

        // ---- showing the controller's state ----

        private void Refresh()
        {
            if (refreshing)
            {
                return;
            }
            refreshing = true;
            foreach (ValueControl control in valueControls)
            {
                double value;
                if (controller.Numbers.TryGetValue(control.Path, out value))
                {
                    control.ConfirmFromSim(value);
                }
                control.SetStyle(controller.Style);
            }
            foreach (ValueControl control in localControls)
            {
                control.SetStyle(controller.Style);
            }
            string word;
            if (controller.Words.TryGetValue(DisplayController.ColourPath, out word))
            {
                Select(colourBox, word);
            }
            if (controller.Words.TryGetValue(DisplayController.StylePath, out word))
            {
                Select(styleBox, word);
            }
            if (controller.Words.TryGetValue(DisplayController.DarkPath, out word))
            {
                Select(darkBox, word);
            }
            bool on;
            seaFromWindBox.IsChecked = controller.Flags.TryGetValue(SeaFromWindPath, out on) && on;
            instructorBox.IsChecked = controller.InstructorOn;
            foreach (KeyValuePair<string, CheckBox> pair in rogueBoxes)
            {
                pair.Value.IsChecked = controller.Flags.TryGetValue(pair.Key, out on) && on;
            }
            refreshing = false;
        }
    }
}
