// SpokeSource.cs - takes SPOKES payloads from the link, queues them, and paints
// them into the PPI bitmap on its own thread, so the UI thread never waits for video.
// Units: none of its own. In true motion the view origin is shared with the UI through the bitmap.
// Called by: MainWindow (Enqueue from SimLink's reader thread, SetGeometry and Stop
// from the UI thread) and SelfTest.

using System;
using System.Collections.Concurrent;
using System.IO;
using System.Threading;

namespace RadarSim
{
    public class SpokeSource
    {
        private const int QueueLimitFrames = 400;       // about 25,000 spokes, 3 s of video at 1x (chosen)

        private readonly PpiBitmap bitmap;
        private readonly BlockingCollection<byte[]> queue = new BlockingCollection<byte[]>(QueueLimitFrames);
        private readonly Thread thread;
        private PpiGeometry geometry;                   // the painter's own copy; changed only under bitmap.Sync
        private long framesDropped;
        private long framesBad;

        public SpokeSource(PpiBitmap bitmap, PpiGeometry geometry)
        {
            this.bitmap = bitmap;
            this.geometry = geometry.Copy();
            thread = new Thread(PaintLoop);
            thread.IsBackground = true;
            thread.Name = "SpokeSource painter";
            thread.Start();
        }

        public long FramesDropped
        {
            get { return Interlocked.Read(ref framesDropped); }
        }

        public long FramesBad
        {
            get { return Interlocked.Read(ref framesBad); }
        }

        // Any thread. A frame that does not fit in the queue is dropped (the painter has fallen behind).
        public void Enqueue(byte[] payload)
        {
            if (!queue.TryAdd(payload))
            {
                Interlocked.Increment(ref framesDropped);
            }
        }

        // UI thread. Gives the painter new geometry; with clear the picture and the
        // frames still waiting are thrown away.
        public void SetGeometry(PpiGeometry newGeometry, bool clear)
        {
            if (clear)
            {
                byte[] discarded;
                while (queue.TryTake(out discarded))
                {
                }
            }
            lock (bitmap.Sync)
            {
                PpiGeometry copy = newGeometry.Copy();
                if (copy.OriginChanged)
                {
                    bitmap.PublishOrigin(copy);                 // the UI set a new view origin
                }
                else
                {
                    copy.ViewOriginXNm = bitmap.ViewOriginXNm;  // keep the painter's own origin
                    copy.ViewOriginYNm = bitmap.ViewOriginYNm;
                }
                geometry = copy;
                newGeometry.OriginChanged = false;              // taken
                newGeometry.OriginPending = false;              // the painter's copy carries it now
                if (clear)
                {
                    bitmap.Clear();
                    bitmap.Trails.Clear();                      // a cleared picture clears the trails too
                }
            }
        }

        public void Stop()
        {
            queue.CompleteAdding();
        }

        private void PaintLoop()
        {
            foreach (byte[] payload in queue.GetConsumingEnumerable())
            {
                SpokeFrame frame;
                try
                {
                    frame = Protocol.ParseSpokes(payload);
                }
                catch (InvalidDataException)
                {
                    Interlocked.Increment(ref framesBad);
                    continue;
                }
                lock (bitmap.Sync)
                {
                    bitmap.PaintFrame(frame, geometry);
                }
            }
        }
    }
}
