// Messages.cs - the display's console and message-pane output, a port of Oliver's messages.py
// (BRIEF.md Section 3). Same tags, same default verbosities, same rule: a message prints if the
// verbosity setting is not below the message's verbosity, so a higher setting prints more.
// Verbosity 0 always prints. Danger always prints.
// Streams: Abort, Error, Fail and Warn go to the error stream; Status, Ok, Done, Info, Debug, Trace
// and Why go to the standard output stream.
// The display is a WinExe with no console of its own, so every printed line also goes to Pane,
// which the window shows in its message pane. A log file gets every message with a timestamp and no
// colour, even one too quiet to print.
// There is no Prompt: a window asks its questions with controls.
// Units: verbosity 0 to 10 (general.message_verbosity in radarsim.toml).
// Called by: App, MainWindow, SimLink, SelfTest.

using System;
using System.IO;
using System.Runtime.InteropServices;

namespace RadarSim
{
    public static class Messages
    {
        public static int? Verbosity = null;            // null = every message prints
        public static TextWriter LogFile = null;
        public static int LogVerbosity = 10;
        public static Action<string> Pane = null;       // gets each printed line, tag and text, no colour
        public static TextWriter Out = Console.Out;
        public static TextWriter Err = Console.Error;
        public static bool Colour = false;              // ANSI colours; only when the console understands them

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetStdHandle(int handle);

        [DllImport("kernel32.dll")]
        private static extern bool GetConsoleMode(IntPtr handle, out int mode);

        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleMode(IntPtr handle, int mode);

        // Turns on ANSI colours for the console this process wrote to. Returns false, and leaves
        // colours off, on a console that does not know them.
        public static bool EnableColour()
        {
            const int StdOutputHandle = -11;
            const int EnableVirtualTerminalProcessing = 0x0004;
            try
            {
                IntPtr handle = GetStdHandle(StdOutputHandle);
                int mode;
                if (handle == IntPtr.Zero || !GetConsoleMode(handle, out mode))
                {
                    return false;
                }
                Colour = SetConsoleMode(handle, mode | EnableVirtualTerminalProcessing);
            }
            catch (Exception error) when (error is DllNotFoundException || error is EntryPointNotFoundException)
            {
                Colour = false;
            }
            return Colour;
        }

        private static void WriteLog(string tag, string message)
        {
            try
            {
                LogFile.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + tag + message);
                LogFile.Flush();
            }
            catch (IOException)
            {
                LogFile = null;                         // a log that cannot be written must not stop the program
            }
        }

        private static void ShowLine(TextWriter stream, string tag, string colour, string message)
        {
            try
            {
                if (Colour)
                {
                    stream.WriteLine("\u001b[" + colour + "m" + tag + "\u001b[0m" + message);
                }
                else
                {
                    stream.WriteLine(tag + message);
                }
                stream.Flush();
            }
            catch (IOException)
            {
            }
            if (Pane != null)
            {
                Pane(tag + message);
            }
        }

        public static void Danger(string message, int verbosity = 0)
        {
            // Physical harm to a person. Always prints and logs. verbosity is accepted but ignored.
            string tag = "[DANGER]  ";
            if (LogFile != null)
            {
                WriteLog(tag, message);
            }
            ShowLine(Err, tag, "1;97;101", message);
        }

        public static void Abort(string message, int verbosity = 0)
        {
            // The program cannot continue. Prints the message, then exits with status 1.
            string tag = "[ABORT]   ";
            if (LogFile != null && verbosity <= LogVerbosity)
            {
                WriteLog(tag, message);
            }
            bool quiet = Verbosity.HasValue && verbosity > Verbosity.Value;
            if (!quiet)
            {
                ShowLine(Err, tag, "38;5;196", message);
            }
            Environment.Exit(1);
        }

        public static void Error(string message, int verbosity = 1)
        {
            // Something went wrong, but the program can continue.
            string tag = "[ERROR]   ";
            if (LogFile != null && verbosity <= LogVerbosity)
            {
                WriteLog(tag, message);
            }
            if (Verbosity.HasValue && verbosity > Verbosity.Value)
            {
                return;
            }
            ShowLine(Err, tag, "38;5;160", message);
        }

        public static void Fail(string message, int verbosity = 1)
        {
            // Negative outcome of a test or check.
            string tag = "[FAIL]    ";
            if (LogFile != null && verbosity <= LogVerbosity)
            {
                WriteLog(tag, message);
            }
            if (Verbosity.HasValue && verbosity > Verbosity.Value)
            {
                return;
            }
            ShowLine(Err, tag, "38;5;202", message);
        }

        public static void Warn(string message, int verbosity = 2)
        {
            // Deserves attention: irreversible action, etc.
            string tag = "[WARN]    ";
            if (LogFile != null && verbosity <= LogVerbosity)
            {
                WriteLog(tag, message);
            }
            if (Verbosity.HasValue && verbosity > Verbosity.Value)
            {
                return;
            }
            ShowLine(Err, tag, "38;5;214", message);
        }

        public static void Status(string message, int verbosity = 3)
        {
            // Progress of the program.
            string tag = "[STATUS]  ";
            if (LogFile != null && verbosity <= LogVerbosity)
            {
                WriteLog(tag, message);
            }
            if (Verbosity.HasValue && verbosity > Verbosity.Value)
            {
                return;
            }
            ShowLine(Out, tag, "38;5;39", message);
        }

        public static void Ok(string message, int verbosity = 4)
        {
            // Positive outcome of a test or check.
            string tag = "[OK]      ";
            if (LogFile != null && verbosity <= LogVerbosity)
            {
                WriteLog(tag, message);
            }
            if (Verbosity.HasValue && verbosity > Verbosity.Value)
            {
                return;
            }
            ShowLine(Out, tag, "38;5;77", message);
        }

        public static void Done(string message, int verbosity = 5)
        {
            // An action finished successfully.
            string tag = "[DONE]    ";
            if (LogFile != null && verbosity <= LogVerbosity)
            {
                WriteLog(tag, message);
            }
            if (Verbosity.HasValue && verbosity > Verbosity.Value)
            {
                return;
            }
            ShowLine(Out, tag, "38;5;34", message);
        }

        public static void Info(string message, int verbosity = 6)
        {
            // Useful, but non-essential information.
            string tag = "[INFO]    ";
            if (LogFile != null && verbosity <= LogVerbosity)
            {
                WriteLog(tag, message);
            }
            if (Verbosity.HasValue && verbosity > Verbosity.Value)
            {
                return;
            }
            ShowLine(Out, tag, "38;5;33", message);
        }

        public static void Debug(string message, int verbosity = 7)
        {
            string tag = "[DEBUG]   ";
            if (LogFile != null && verbosity <= LogVerbosity)
            {
                WriteLog(tag, message);
            }
            if (Verbosity.HasValue && verbosity > Verbosity.Value)
            {
                return;
            }
            ShowLine(Out, tag, "38;5;99", message);
        }

        public static void Trace(string message, int verbosity = 8)
        {
            // Helps the user understand what the program is doing.
            string tag = "[TRACE]   ";
            if (LogFile != null && verbosity <= LogVerbosity)
            {
                WriteLog(tag, message);
            }
            if (Verbosity.HasValue && verbosity > Verbosity.Value)
            {
                return;
            }
            ShowLine(Out, tag, "38;5;207", message);
        }

        public static void Why(string message, int verbosity = 9)
        {
            // Helps the user understand why the program works the way it does.
            string tag = "[WHY]     ";
            if (LogFile != null && verbosity <= LogVerbosity)
            {
                WriteLog(tag, message);
            }
            if (Verbosity.HasValue && verbosity > Verbosity.Value)
            {
                return;
            }
            ShowLine(Out, tag, "38;5;219", message);
        }
    }
}
