// SelfTest.cs - the display's self-tests: `RadarSim.exe --selftest` (or
// `dotnet run --project gui -- --selftest`) runs them all, writes selftest_results.txt
// in the project root as PASS and FAIL lines, prints them to the console if one is
// attached, and exits 0 or 1. No test framework. Later modules add their tests here.
// BRIEF.md Section 15, M5 acceptance tests 1-9 (test 10 is manual), M6 to M9 tests below.
// Units: ranges NM, bearings deg T, pixels, sim time s.
// Called by: App.xaml.cs.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Windows.Input;

namespace RadarSim
{
    public static class SelfTest
    {
        [DllImport("kernel32.dll")]
        private static extern bool AttachConsole(int processId);

        private const int AttachParentProcess = -1;
        private const string ResultsFileName = "selftest_results.txt";

        private static int failures;

        public static int Run(string root)
        {
            failures = 0;
            TryAttachConsole();
            Messages.Verbosity = 10;                    // a test run shows everything
            string path = root != null ? Path.Combine(root, ResultsFileName) : ResultsFileName;
            try
            {
                Messages.LogFile = new StreamWriter(path, false);
            }
            catch (IOException error)
            {
                Messages.Warn("Could not write " + path + ": " + error.Message);
            }

            RunOne("0 SPOKES parse", TestSpokesParse);
            RunOne("0 SpokeSource", TestSpokeSource);
            RunOne("1 geometry", TestGeometry);
            RunOne("2 scan conversion", TestScanConversion);
            RunOne("3 no holes", TestNoHoles);
            RunOne("4 afterglow", TestAfterglow);
            RunOne("5 palettes", TestPalettes);
            RunOne("6 range rings", TestRings);
            RunOne("7 heading line", TestHeadingLine);
            RunOne("8 bearing scale", TestBearingScale);
            RunOne("9 throughput", TestThroughput);
            RunOne("M6 1 knob and slider mapping", TestM6Mapping);
            RunOne("M6 2 typed input", TestM6Typed);
            RunOne("M6 3 rate limit", TestM6RateLimit);
            RunOne("M6 4 setting correction", TestM6Setting);
            RunOne("M6 5 hotkeys", TestM6Hotkeys);
            RunOne("M6 6 EBL and VRM geometry", TestM6EblVrm);
            RunOne("M6 7 control style at runtime", TestM6ControlStyle);
            RunOne("M7 1 true motion, ground mode", TestM7GroundMotion);
            RunOne("M7 2 true motion, sea mode with a current", TestM7SeaMotion);
            RunOne("M7 3 true motion reset", TestM7Reset);
            RunOne("M7 4 true trails", TestM7TrueTrails);
            RunOne("M7 5 relative trails", TestM7RelativeTrails);
            RunOne("M7 6 trail time and clearing", TestM7TrailTime);
            RunOne("M7 7 motion and orientation", TestM7MotionOrientation);
            RunOne("M9 1 box positions", TestM9Positions);
            RunOne("M9 2 vectors", TestM9Vectors);
            RunOne("M9 3 states", TestM9States);
            RunOne("M9 4 history dots", TestM9History);
            RunOne("M9 5 hit test", TestM9HitTest);
            RunOne("M9 6 keys", TestM9Keys);
            RunOne("M9 7 alarm list", TestM9Alarms);
            RunOne("M9 8 guard zones", TestM9GuardZones);
            RunOne("M9 9 trial and readout", TestM9TrialReadout);
            RunOne("M10 1 new run", TestM10NewRun);
            RunOne("M10 2 setup controls", TestM10Setup);
            RunOne("M10 3 game events", TestM10Events);
            RunOne("M10 4 instructor overlay", TestM10Instructor);
            RunOne("M10 5 help and keys", TestM10Help);
            RunOne("M10 6 offset and rings", TestM10Offset);
            RunOne("M10 7 trial vectors", TestM10TrialVectors);
            RunOne("M10 9 contact list", TestM10ContactList);
            RunOne("M10 10 bearing scale", TestM10BearingScale);
            RunOne("M10 11 dark mode and big readout", TestM10DarkAndReadout);
            RunOne("M10 12 multiple acquire", TestM10MultiAcquire);
            RunOne("M10 13 parallel index", TestM10ParallelIndex);
            RunOne("M10 16 knobs and hybrid", TestM10Controls);
            RunOne("M10 14 chart request", TestM10ChartRequest);
            RunOne("M10 15 wheelhouse", TestM10Wheelhouse);
            Messages.Info("Not run, manual: 10 manual, with the sim running (BRIEF.md Section 15, M5 test 10)");
            Messages.Info("Not run, manual: M6 8 manual: gain, STC and FTC by mouse, keyboard and typed value; the first 10 rows of the hotkey table by hand");
            Messages.Info("Not run, manual: M7 8 manual: calibration scenario, 10 KN, 12 NM scale: true motion in ground and sea mode, buoys, trails");
            Messages.Info("Not run, manual: M10 8 end-to-end checklist (BRIEF.md Section 15, M10 test 8), with the sim running");
            Messages.Info("Not run, manual: M9 10 manual: calibration scenario, 10 KN, 6 NM scale: acquire S3 and S4, watch the vectors settle, the S4 CPA/TCPA alarm, true and relative vectors, guard zone with sea clutter at sea state 5");
            if (failures == 0)
            {
                Messages.Done("All self-tests passed");
            }
            else
            {
                Messages.Fail(failures + " self-test line(s) failed");
            }
            if (Messages.LogFile != null)
            {
                Messages.LogFile.Dispose();
                Messages.LogFile = null;
            }
            return failures == 0 ? 0 : 1;
        }

        // A WinExe has no console of its own. If it was started from one, Messages writes there too.
        private static TextWriter TryAttachConsole()
        {
            try
            {
                if (AttachConsole(AttachParentProcess))
                {
                    StreamWriter output = new StreamWriter(Console.OpenStandardOutput());
                    output.AutoFlush = true;
                    StreamWriter error = new StreamWriter(Console.OpenStandardError());
                    error.AutoFlush = true;
                    Messages.Out = output;
                    Messages.Err = error;
                    Messages.EnableColour();
                    return output;
                }
            }
            catch (Exception error) when (error is DllNotFoundException || error is EntryPointNotFoundException
                                          || error is IOException)
            {
            }
            return null;
        }

        private static void RunOne(string name, Action test)
        {
            try
            {
                test();
            }
            catch (Exception error)
            {
                Report(false, name, "stopped by " + error.GetType().Name + ": " + error.Message);
            }
        }

        private static void Report(bool ok, string name, string detail)
        {
            if (!ok)
            {
                failures++;
            }
            if (ok)
            {
                Messages.Ok(name + ": " + detail);
            }
            else
            {
                Messages.Fail(name + ": " + detail);
            }
        }

        private static string Number(double value, string pattern)
        {
            return value.ToString(pattern, CultureInfo.InvariantCulture);
        }

        private static double AngleError(double a, double b)
        {
            double difference = Math.Abs(PpiGeometry.Normalise360(a) - PpiGeometry.Normalise360(b));
            return difference > 180.0 ? 360.0 - difference : difference;
        }

        // ---- 0: SPOKES layout and queue ----

        private static void TestSpokesParse()
        {
            // A frame laid out by hand from BRIEF.md Section 7 (not with PackSpokes).
            MemoryStream bytes = new MemoryStream();
            BinaryWriter writer = new BinaryWriter(bytes);
            writer.Write((ushort)1);                // spoke_count
            writer.Write((ushort)4);                // bins_per_spoke
            writer.Write(2.5f);                     // video_range_nm
            writer.Write((ushort)513);              // azimuth_index
            writer.Write((ushort)12345);            // gyro_heading_cdeg
            writer.Write(1234.5);                   // sim_time_s, f64
            writer.Write(1.5f);                     // ref_x_nm
            writer.Write(-2.5f);                    // ref_y_nm
            writer.Write(new byte[] { 1, 2, 3, 4 });
            writer.Flush();
            SpokeFrame frame = Protocol.ParseSpokes(bytes.ToArray());
            bool byHand = frame.SpokeCount == 1 && frame.BinsPerSpoke == 4 && frame.VideoRangeNm == 2.5
                && frame.AzimuthIndex[0] == 513 && frame.GyroHeadingCdeg[0] == 12345 && frame.SimTimeS[0] == 1234.5
                && frame.RefXNm[0] == 1.5f && frame.RefYNm[0] == -2.5f
                && frame.Video[0] == 1 && frame.Video[3] == 4;

            SpokeFrame revolution = SyntheticSource.Revolution(new SyntheticEcho[] { new SyntheticEcho(4.0, 45.0) }, 6.0, 37.5, 100.0, 2.5);
            SpokeFrame again = Protocol.ParseSpokes(Protocol.PackSpokes(revolution));
            bool roundTrip = again.SpokeCount == 2048 && again.BinsPerSpoke == 1024 && again.VideoRangeNm == 6.0;
            for (int i = 0; i < revolution.Video.Length && roundTrip; i++)
            {
                roundTrip = revolution.Video[i] == again.Video[i];
            }
            for (int spoke = 0; spoke < revolution.SpokeCount && roundTrip; spoke++)
            {
                roundTrip = revolution.SimTimeS[spoke] == again.SimTimeS[spoke]
                    && revolution.AzimuthIndex[spoke] == again.AzimuthIndex[spoke]
                    && revolution.GyroHeadingCdeg[spoke] == again.GyroHeadingCdeg[spoke];
            }

            bool refused = false;
            try
            {
                Protocol.ParseSpokes(new byte[10]);
            }
            catch (InvalidDataException)
            {
                refused = true;
            }
            Report(byHand && roundTrip && refused, "0 SPOKES parse", "a frame laid out by hand reads back right: " + byHand
                + "; 2048 spokes x 1024 bins pack and parse unchanged: " + roundTrip + "; a short payload is refused: " + refused);
        }

        private static void TestSpokeSource()
        {
            PpiGeometry geometry = new PpiGeometry();
            geometry.RangeScaleNm = 6.0;
            PpiBitmap bitmap = new PpiBitmap(geometry.SizePx);
            SpokeSource source = new SpokeSource(bitmap, geometry);
            SpokeFrame revolution = SyntheticSource.Revolution(new SyntheticEcho[] { new SyntheticEcho(4.0, 45.0) }, 6.0, 0.0, 100.0, 2.5);
            source.Enqueue(Protocol.PackSpokes(revolution));
            source.Enqueue(new byte[3]);
            Stopwatch waited = Stopwatch.StartNew();
            while (Interlocked.Read(ref bitmap.SpokesPainted) < 2048 && source.FramesBad < 1 && waited.ElapsedMilliseconds < 10000)
            {
                Thread.Sleep(10);
            }
            Thread.Sleep(50);
            int peak = 0;
            lock (bitmap.Sync)
            {
                for (int i = 0; i < bitmap.Intensity.Length; i++)
                {
                    peak = Math.Max(peak, bitmap.Intensity[i]);
                }
            }
            source.Stop();
            Report(peak == 65535 && source.FramesBad == 1, "0 SpokeSource", "a queued frame was painted on the painter thread in "
                + waited.ElapsedMilliseconds + " ms; echo peak " + peak + " (65535); a bad frame was skipped and counted: " + source.FramesBad);
        }

        // ---- 1: geometry ----

        private struct GeoCase
        {
            public PpiOrientation Orientation;
            public double HeadingDeg, LatchedDeg, OffsetX, OffsetY, RangeNm, BearingDeg, ExpectedX, ExpectedY;

            public GeoCase(PpiOrientation orientation, double headingDeg, double latchedDeg, double offsetX, double offsetY,
                           double rangeNm, double bearingDeg, double expectedX, double expectedY)
            {
                Orientation = orientation;
                HeadingDeg = headingDeg;
                LatchedDeg = latchedDeg;
                OffsetX = offsetX;
                OffsetY = offsetY;
                RangeNm = rangeNm;
                BearingDeg = bearingDeg;
                ExpectedX = expectedX;
                ExpectedY = expectedY;
            }
        }

        // 1000 px bitmap (radius 500 px), 6 NM scale. The expected pixels were worked out
        // separately by rotating a vector (a different formula from the one in PpiGeometry).
        private static readonly GeoCase[] GeoCases = new GeoCase[]
        {
            new GeoCase(PpiOrientation.NorthUp, 123.0, 0.0, 0.0, 0.0, 3.0, 90.0, 750.0000, 500.0000),
            new GeoCase(PpiOrientation.NorthUp, 123.0, 0.0, 0.0, 0.0, 6.0, 0.0, 500.0000, 0.0000),
            new GeoCase(PpiOrientation.NorthUp, 0.0, 0.0, 0.0, 0.0, 3.0, 180.0, 500.0000, 750.0000),
            new GeoCase(PpiOrientation.NorthUp, 0.0, 0.0, 0.0, 0.0, 6.0, 270.0, 0.0000, 500.0000),
            new GeoCase(PpiOrientation.NorthUp, 0.0, 0.0, 0.0, 0.0, 3.0, 45.0, 676.7767, 323.2233),
            new GeoCase(PpiOrientation.NorthUp, 0.0, 0.0, 0.0, 0.0, 4.5, 200.0, 371.7424, 852.3847),
            new GeoCase(PpiOrientation.NorthUp, 50.0, 0.0, 0.0, -0.5, 3.0, 0.0, 500.0000, 500.0000),
            new GeoCase(PpiOrientation.NorthUp, 50.0, 0.0, 0.0, -0.5, 5.0, 135.0, 794.6278, 1044.6278),
            new GeoCase(PpiOrientation.NorthUp, 250.0, 0.0, 0.3, 0.2, 2.0, 315.0, 532.1489, 282.1489),
            new GeoCase(PpiOrientation.NorthUp, 250.0, 0.0, -0.4, -0.3, 6.0, 30.0, 550.0000, 216.9873),
            new GeoCase(PpiOrientation.NorthUp, 10.0, 0.0, 0.0, -0.5, 0.5, 359.5, 499.6364, 708.3349),
            new GeoCase(PpiOrientation.NorthUp, 10.0, 0.0, 0.5, 0.0, 4.0, 225.0, 514.2977, 735.7023),
            new GeoCase(PpiOrientation.NorthUp, 10.0, 0.0, 0.0, 0.0, 0.0, 77.0, 500.0000, 500.0000),
            new GeoCase(PpiOrientation.NorthUp, 310.0, 0.0, -0.2, 0.4, 5.5, 160.0, 556.7592, 730.6925),
            new GeoCase(PpiOrientation.HeadUp, 90.0, 0.0, 0.0, 0.0, 3.0, 90.0, 500.0000, 250.0000),
            new GeoCase(PpiOrientation.HeadUp, 90.0, 0.0, 0.0, 0.0, 3.0, 180.0, 750.0000, 500.0000),
            new GeoCase(PpiOrientation.HeadUp, 90.0, 0.0, 0.0, 0.0, 3.0, 0.0, 250.0000, 500.0000),
            new GeoCase(PpiOrientation.HeadUp, 90.0, 0.0, 0.0, 0.0, 6.0, 270.0, 500.0000, 1000.0000),
            new GeoCase(PpiOrientation.HeadUp, 37.5, 0.0, 0.0, 0.0, 4.0, 37.5, 500.0000, 166.6667),
            new GeoCase(PpiOrientation.HeadUp, 37.5, 0.0, 0.0, 0.0, 4.0, 82.5, 735.7023, 264.2977),
            new GeoCase(PpiOrientation.HeadUp, 90.0, 0.0, 0.0, -0.5, 3.0, 90.0, 500.0000, 500.0000),
            new GeoCase(PpiOrientation.HeadUp, 270.0, 0.0, 0.0, -0.5, 3.0, 0.0, 750.0000, 750.0000),
            new GeoCase(PpiOrientation.HeadUp, 355.0, 0.0, 0.3, 0.2, 2.0, 5.0, 678.9414, 235.8654),
            new GeoCase(PpiOrientation.HeadUp, 355.0, 0.0, -0.4, -0.3, 6.0, 175.0, 300.0000, 1150.0000),
            new GeoCase(PpiOrientation.HeadUp, 180.0, 0.0, 0.0, -0.5, 5.0, 180.0, 500.0000, 333.3333),
            new GeoCase(PpiOrientation.HeadUp, 180.0, 0.0, 0.5, 0.0, 4.0, 45.0, 514.2977, 735.7023),
            new GeoCase(PpiOrientation.HeadUp, 12.3, 0.0, 0.0, 0.0, 0.0, 200.0, 500.0000, 500.0000),
            new GeoCase(PpiOrientation.HeadUp, 200.0, 0.0, -0.2, 0.4, 5.5, 20.0, 400.0000, 758.3333),
            new GeoCase(PpiOrientation.CourseUp, 10.0, 45.0, 0.0, 0.0, 3.0, 45.0, 500.0000, 250.0000),
            new GeoCase(PpiOrientation.CourseUp, 10.0, 45.0, 0.0, 0.0, 3.0, 135.0, 750.0000, 500.0000),
            new GeoCase(PpiOrientation.CourseUp, 10.0, 45.0, 0.0, 0.0, 6.0, 225.0, 500.0000, 1000.0000),
            new GeoCase(PpiOrientation.CourseUp, 10.0, 45.0, 0.0, 0.0, 3.0, 315.0, 250.0000, 500.0000),
            new GeoCase(PpiOrientation.CourseUp, 300.0, 300.0, 0.0, 0.0, 4.0, 300.0, 500.0000, 166.6667),
            new GeoCase(PpiOrientation.CourseUp, 300.0, 300.0, 0.0, 0.0, 4.0, 30.0, 833.3333, 500.0000),
            new GeoCase(PpiOrientation.CourseUp, 150.0, 45.0, 0.0, -0.5, 3.0, 45.0, 500.0000, 500.0000),
            new GeoCase(PpiOrientation.CourseUp, 150.0, 45.0, 0.0, -0.5, 5.0, 100.0, 841.3134, 511.0098),
            new GeoCase(PpiOrientation.CourseUp, 0.0, 359.0, 0.3, 0.2, 2.0, 0.0, 652.9087, 233.3587),
            new GeoCase(PpiOrientation.CourseUp, 0.0, 359.0, -0.4, -0.3, 6.0, 180.0, 291.2738, 1149.9238),
            new GeoCase(PpiOrientation.CourseUp, 200.0, 20.0, 0.0, -0.5, 0.5, 20.0, 500.0000, 708.3333),
            new GeoCase(PpiOrientation.CourseUp, 200.0, 20.0, 0.5, 0.0, 4.0, 290.0, 416.6667, 500.0000),
            new GeoCase(PpiOrientation.CourseUp, 77.0, 120.0, 0.0, 0.0, 0.0, 10.0, 500.0000, 500.0000),
            new GeoCase(PpiOrientation.CourseUp, 88.0, 210.0, -0.2, 0.4, 5.5, 33.3, 373.6165, 757.5733),
        };

        private static void TestGeometry()
        {
            PpiGeometry geometry = new PpiGeometry();
            geometry.SizePx = 1000;
            geometry.RangeScaleNm = 6.0;
            double worstPixelPx = 0.0;
            double worstRangeNm = 0.0;
            double worstBearingDeg = 0.0;
            int perOrientation = 0;
            foreach (GeoCase test in GeoCases)
            {
                geometry.Orientation = test.Orientation;
                geometry.HeadingDegTrue = test.HeadingDeg;
                geometry.LatchedCourseDegTrue = test.LatchedDeg;
                geometry.OffsetXFraction = test.OffsetX;
                geometry.OffsetYFraction = test.OffsetY;
                double x, y;
                geometry.PixelOf(test.RangeNm, test.BearingDeg, out x, out y);
                worstPixelPx = Math.Max(worstPixelPx, Math.Max(Math.Abs(x - test.ExpectedX), Math.Abs(y - test.ExpectedY)));
                double rangeNm, bearingDeg;
                geometry.RangeBearingOf(x, y, out rangeNm, out bearingDeg);
                worstRangeNm = Math.Max(worstRangeNm, Math.Abs(rangeNm - test.RangeNm));
                if (test.RangeNm > 0.01)
                {
                    worstBearingDeg = Math.Max(worstBearingDeg, AngleError(bearingDeg, test.BearingDeg));
                }
                if (test.Orientation == PpiOrientation.NorthUp)
                {
                    perOrientation++;
                }
            }

            // The cases named in the brief.
            geometry.Orientation = PpiOrientation.NorthUp;
            geometry.OffsetXFraction = 0.0;
            geometry.OffsetYFraction = -0.5;
            double ownBelowCentrePx = geometry.OwnYPx - geometry.CentreYPx;
            double centreX, centreY;
            geometry.PixelOf(3.0, 0.0, out centreX, out centreY);
            bool offsetCase = Math.Abs(ownBelowCentrePx - 250.0) < 0.001 && Math.Abs(centreX - 500.0) < 0.001 && Math.Abs(centreY - 500.0) < 0.001;

            bool ok = GeoCases.Length >= 36 && perOrientation >= 12 && worstPixelPx <= 0.01 && worstRangeNm <= 0.01
                && worstBearingDeg <= 0.1 && offsetCase;
            Report(ok, "1 geometry", GeoCases.Length + " cases (" + perOrientation + " per orientation, 6 NM scale, 1000 px): worst pixel error "
                + Number(worstPixelPx, "0.0000") + " px (0.01); pixel back to range and bearing: worst " + Number(worstRangeNm, "0.0000")
                + " NM (0.01) and " + Number(worstBearingDeg, "0.0000") + " deg (0.1); offset (0, -0.5) puts own ship "
                + Number(ownBelowCentrePx, "0") + " px below the centre and 3 NM north at the centre: " + offsetCase);
        }

        // ---- 2: scan conversion ----

        private static void TestScanConversion()
        {
            PpiOrientation[] orientations = { PpiOrientation.NorthUp, PpiOrientation.HeadUp, PpiOrientation.CourseUp };
            double[] offsetsY = { 0.0, -0.5 };
            double worstPx = 0.0;
            int combinations = 0;
            foreach (PpiOrientation orientation in orientations)
            {
                foreach (double offsetY in offsetsY)
                {
                    PpiGeometry geometry = new PpiGeometry();
                    geometry.RangeScaleNm = 6.0;
                    geometry.Orientation = orientation;
                    geometry.HeadingDegTrue = 37.5;
                    geometry.LatchedCourseDegTrue = 20.0;
                    geometry.OffsetYFraction = offsetY;
                    double videoRangeNm = 6.0 * (1.0 + geometry.OffsetMagnitude);
                    PpiBitmap bitmap = new PpiBitmap(geometry.SizePx);
                    SpokeFrame revolution = SyntheticSource.Revolution(new SyntheticEcho[] { new SyntheticEcho(4.0, 45.0) },
                                                                       videoRangeNm, 37.5, 100.0, 2.5);
                    bitmap.PaintFrame(revolution, geometry);

                    double sumX = 0.0, sumY = 0.0;
                    int count = 0;
                    for (int y = 0; y < bitmap.SizePx; y++)
                    {
                        for (int x = 0; x < bitmap.SizePx; x++)
                        {
                            if (bitmap.Intensity[y * bitmap.SizePx + x] > 0)
                            {
                                sumX += x + 0.5;
                                sumY += y + 0.5;
                                count++;
                            }
                        }
                    }
                    double expectedX, expectedY;
                    geometry.PixelOf(4.0, 45.0, out expectedX, out expectedY);
                    double errorPx = count == 0 ? 1.0e9 : Math.Sqrt(Math.Pow(sumX / count - expectedX, 2) + Math.Pow(sumY / count - expectedY, 2));
                    worstPx = Math.Max(worstPx, errorPx);
                    combinations++;
                }
            }
            Report(worstPx <= 1.5, "2 scan conversion", "an echo at 045 deg T, 4 NM, gyro heading 037.5 deg, in " + combinations
                + " combinations of orientation and offset (north-up, head-up, course-up latched at 020; no offset and (0, -0.5)): worst distance from the geometry's pixel "
                + Number(worstPx, "0.00") + " px (1.5)");
        }

        // ---- 3: no holes ----

        private static double LitFractionInsideCircle(PpiBitmap bitmap)
        {
            double radius = bitmap.SizePx / 2.0;
            int inside = 0;
            int lit = 0;
            for (int y = 0; y < bitmap.SizePx; y++)
            {
                for (int x = 0; x < bitmap.SizePx; x++)
                {
                    double dx = x + 0.5 - radius;
                    double dy = y + 0.5 - radius;
                    if (dx * dx + dy * dy < radius * radius)
                    {
                        inside++;
                        if (bitmap.Intensity[y * bitmap.SizePx + x] > 0)
                        {
                            lit++;
                        }
                    }
                }
            }
            return 100.0 * lit / inside;
        }

        private static void TestNoHoles()
        {
            PpiGeometry geometry = new PpiGeometry();
            geometry.RangeScaleNm = 24.0;
            PpiBitmap bitmap = new PpiBitmap(geometry.SizePx);
            bitmap.PaintFrame(SyntheticSource.UniformRevolution(200, 24.0, 0.0, 100.0, 2.5), geometry);
            double centredPercent = LitFractionInsideCircle(bitmap);

            geometry.OffsetYFraction = -0.5;
            PpiBitmap offsetBitmap = new PpiBitmap(geometry.SizePx);
            offsetBitmap.PaintFrame(SyntheticSource.UniformRevolution(200, 24.0 * 1.5, 0.0, 100.0, 2.5), geometry);
            double offsetPercent = LitFractionInsideCircle(offsetBitmap);

            Report(centredPercent >= 99.9 && offsetPercent >= 99.9, "3 no holes", "uniform video 200 from 2048 spokes at the 24 NM scale covers "
                + Number(centredPercent, "0.000") + " % of the pixels inside the radius (99.9 or more); with own ship offset (0, -0.5) and video range 36 NM: "
                + Number(offsetPercent, "0.000") + " %");
        }

        // ---- 4: afterglow ----

        private static double PeakIntensity(PpiBitmap bitmap)
        {
            int peak = 0;
            for (int i = 0; i < bitmap.Intensity.Length; i++)
            {
                peak = Math.Max(peak, bitmap.Intensity[i]);
            }
            return peak;
        }

        // The sim time the bitmap has faded up to after painting this frame. PpiBitmap.Advance runs once
        // per frame, at the frame's first spoke, so that is the start of the fade, not the last spoke.
        private static double LastSimTimeS(SpokeFrame frame)
        {
            return frame.SimTimeS[0];
        }

        // Fade is measured from the first spoke of the painted frame (see LastSimTimeS).
        private static void TestAfterglow()
        {
            PpiGeometry geometry = new PpiGeometry();
            geometry.RangeScaleNm = 6.0;
            SyntheticEcho[] echo = { new SyntheticEcho(4.0, 45.0) };

            // Mono: 10 % after afterglow_sim_s (6 s).
            PpiBitmap mono = new PpiBitmap(geometry.SizePx);
            mono.AfterglowSimS = 6.0;
            SpokeFrame monoRevolution = SyntheticSource.Revolution(echo, 6.0, 0.0, 100.0, 2.5);
            double monoEndS = LastSimTimeS(monoRevolution);
            mono.PaintFrame(monoRevolution, geometry);
            double start = PeakIntensity(mono);
            mono.PaintFrame(SyntheticSource.EmptySpoke(1000, monoEndS + 3.0, 6.0), geometry);
            double halfway = PeakIntensity(mono) / start;
            mono.PaintFrame(SyntheticSource.EmptySpoke(1000, monoEndS + 6.0, 6.0), geometry);
            double monoRatio = PeakIntensity(mono) / start;

            // No spokes, no fade: wall time does not matter.
            double before = PeakIntensity(mono);
            mono.Colourise();
            Thread.Sleep(200);
            mono.Colourise();
            bool paused = PeakIntensity(mono) == before;

            // Colour: about 10 % after one revolution (2.5 s at 24 rpm).
            PpiBitmap colour = new PpiBitmap(geometry.SizePx);
            colour.ColourMode = true;
            colour.RevolutionSimS = 2.5;
            colour.SettingsChanged();
            SpokeFrame colourRevolution = SyntheticSource.Revolution(echo, 6.0, 0.0, 100.0, 2.5);
            double colourEndS = LastSimTimeS(colourRevolution);
            colour.PaintFrame(colourRevolution, geometry);
            double colourStart = PeakIntensity(colour);
            colour.PaintFrame(SyntheticSource.EmptySpoke(1000, colourEndS + 2.5, 6.0), geometry);
            double colourRatio = PeakIntensity(colour) / colourStart;

            double expectedHalfway = Math.Exp(-3.0 * Math.Log(10.0) / 6.0);
            bool ok = Math.Abs(monoRatio - 0.1) <= 0.03 && Math.Abs(halfway - expectedHalfway) <= 0.03 && paused && Math.Abs(colourRatio - 0.1) <= 0.03;
            Report(ok, "4 afterglow", "mono, afterglow_sim_s 6: brightness " + Number(halfway, "0.000") + " of the start after 3 s (expected "
                + Number(expectedHalfway, "0.000") + "), " + Number(monoRatio, "0.000") + " after 6 s (0.10 +/- 0.03); no spokes, no fade: " + paused
                + "; colour after one revolution of 2.5 s: " + Number(colourRatio, "0.000") + " (0.10 +/- 0.03)");
        }

        // ---- 5: palettes ----

        private static void TestPalettes()
        {
            PpiBitmap bitmap = new PpiBitmap(64);
            bitmap.ColourMode = true;
            bitmap.VideoBrilliance = 1.0;
            bitmap.SettingsChanged();
            uint weakest = bitmap.ColourOfVideo(1);
            uint middle = bitmap.ColourOfVideo(128);
            uint strongest = bitmap.ColourOfVideo(255);
            uint nothing = bitmap.ColourOfVideo(0);
            bool colourOk = weakest == 0xFF0000FF && middle == 0xFF00FFFF && strongest == 0xFFFFFF00 && nothing == bitmap.ColourBackground;

            bitmap.ColourMode = false;
            bitmap.MonoHue = 0xFF33FF33;
            bitmap.MonoBackground = 0xFF000000;
            bitmap.VideoBrilliance = 1.0;
            bitmap.SettingsChanged();
            uint monoFull = bitmap.ColourOfVideo(255);
            uint monoNothing = bitmap.ColourOfVideo(0);
            bool monoOk = monoFull == 0xFF33FF33 && monoNothing == 0xFF000000;

            Report(colourOk && monoOk, "5 palettes", "colour video 1 / 128 / 255 = " + weakest.ToString("X8") + " / " + middle.ToString("X8") + " / "
                + strongest.ToString("X8") + " (first, middle and last stop: 0000FF, 00FFFF, FFFF00); mono 255 at brilliance 100 = "
                + monoFull.ToString("X8") + " (the configured 33FF33)");
        }

        // ---- 6: range rings ----

        private static void TestRings()
        {
            double[] scalesNm = { 0.25, 0.5, 0.75, 1.5, 3.0, 6.0, 12.0, 24.0 };
            double[] intervalsNm = { 0.05, 0.1, 0.25, 0.25, 0.5, 1.0, 2.0, 4.0 };       // radarsim.toml, one per range scale
            int[] expectedCounts = { 5, 5, 3, 6, 6, 6, 6, 6 };
            PpiGeometry geometry = new PpiGeometry();
            geometry.SizePx = 1000;
            double worstPx = 0.0;
            bool counts = true;
            for (int scale = 0; scale < scalesNm.Length; scale++)
            {
                geometry.RangeScaleNm = scalesNm[scale];
                List<double> radii = geometry.RingRadiiPx(intervalsNm[scale]);
                counts = counts && radii.Count == expectedCounts[scale];
                for (int ring = 0; ring < radii.Count; ring++)
                {
                    double expectedPx = (ring + 1) * intervalsNm[scale] / scalesNm[scale] * 500.0;     // NM -> px at radius 500 px
                    worstPx = Math.Max(worstPx, Math.Abs(radii[ring] - expectedPx));
                }
            }
            Report(counts && worstPx <= 1.0, "6 range rings", "all 8 range scales: ring counts 5, 5, 3, 6, 6, 6, 6, 6 as expected: " + counts
                + "; worst difference from n x interval / scale x radius " + Number(worstPx, "0.0000") + " px (1)");
        }

        // ---- 7: heading line ----

        private static void TestHeadingLine()
        {
            PpiOrientation[] orientations = { PpiOrientation.NorthUp, PpiOrientation.HeadUp, PpiOrientation.CourseUp };
            double[] expectedAngles = { 75.0, 0.0, 235.0 };                  // heading 075, latched 200: 75, 0 and 75 - 200 = -125
            double[,] offsets = { { 0.0, 0.0 }, { 0.0, -0.5 }, { 0.3, 0.2 } };
            double worstAngleDeg = 0.0;
            double worstEdgePx = 0.0;
            for (int i = 0; i < orientations.Length; i++)
            {
                for (int o = 0; o < 3; o++)
                {
                    PpiGeometry geometry = new PpiGeometry();
                    geometry.SizePx = 1000;
                    geometry.Orientation = orientations[i];
                    geometry.HeadingDegTrue = 75.0;
                    geometry.LatchedCourseDegTrue = 200.0;
                    geometry.OffsetXFraction = offsets[o, 0];
                    geometry.OffsetYFraction = offsets[o, 1];
                    double endX, endY;
                    geometry.HeadingLineEndPx(out endX, out endY);
                    double angleDeg = Math.Atan2(endX - geometry.OwnXPx, geometry.OwnYPx - endY) * 180.0 / Math.PI;     // rad -> deg
                    worstAngleDeg = Math.Max(worstAngleDeg, AngleError(angleDeg, expectedAngles[i]));
                    double fromCentre = Math.Sqrt(Math.Pow(endX - 500.0, 2) + Math.Pow(endY - 500.0, 2));
                    worstEdgePx = Math.Max(worstEdgePx, Math.Abs(fromCentre - 500.0));
                }
            }
            Report(worstAngleDeg <= 0.1 && worstEdgePx <= 0.5, "7 heading line", "heading 075 in north-up, head-up and course-up (latched 200), with 3 offsets each: worst angle error "
                + Number(worstAngleDeg, "0.0000") + " deg (0.1); the line ends on the PPI circle within " + Number(worstEdgePx, "0.0000") + " px (0.5)");
        }

        // ---- 8: bearing scale ----

        private static void TestBearingScale()
        {
            PpiOrientation[] orientations = { PpiOrientation.NorthUp, PpiOrientation.HeadUp, PpiOrientation.CourseUp };
            // Heading 090 and latched course 060. Screen angle of true bearings 000, 090, 180, 270 for each orientation.
            double[][] expected =
            {
                new double[] { 0.0, 90.0, 180.0, 270.0 },
                new double[] { 270.0, 0.0, 90.0, 180.0 },
                new double[] { 300.0, 30.0, 120.0, 210.0 },
            };
            double[] expectedTop = { 0.0, 90.0, 60.0 };
            double[] atBearings = { 0.0, 90.0, 180.0, 270.0 };
            bool anglesOk = true;
            bool countsOk = true;
            bool topOk = true;
            for (int i = 0; i < orientations.Length; i++)
            {
                PpiGeometry geometry = new PpiGeometry();
                geometry.Orientation = orientations[i];
                geometry.HeadingDegTrue = 90.0;
                geometry.LatchedCourseDegTrue = 60.0;
                List<BearingTick> ticks = geometry.BearingTicks();
                int longTicks = 0;
                int labelled = 0;
                double labelAtTopDeg = -1.0;
                foreach (BearingTick tick in ticks)
                {
                    longTicks += tick.IsLong ? 1 : 0;
                    labelled += tick.HasLabel ? 1 : 0;
                    if (tick.HasLabel && AngleError(tick.ScreenAngleDeg, 0.0) < 0.001)
                    {
                        labelAtTopDeg = tick.BearingDegTrue;
                    }
                    for (int b = 0; b < atBearings.Length; b++)
                    {
                        if (tick.BearingDegTrue == atBearings[b])
                        {
                            anglesOk = anglesOk && AngleError(tick.ScreenAngleDeg, expected[i][b]) < 0.001;
                        }
                    }
                }
                countsOk = countsOk && ticks.Count == 36 && longTicks == 12 && labelled == 12;
                topOk = topOk && labelAtTopDeg == expectedTop[i] && AngleError(geometry.TopBearingDegTrue, expectedTop[i]) < 0.001;
            }
            Report(anglesOk && countsOk && topOk, "8 bearing scale", "36 ticks (a tick every 10 deg, 12 long and labelled every 30 deg): " + countsOk
                + "; tick angles for 000, 090, 180, 270 deg T right in north-up, head-up (heading 090) and course-up (latched 060): " + anglesOk
                + "; the label at the top reads 000, 090 and 060 deg T: " + topOk);
        }

        // ---- 9: throughput ----

        private static void TestThroughput()
        {
            PpiGeometry geometry = new PpiGeometry();
            geometry.RangeScaleNm = 6.0;
            geometry.OffsetYFraction = -0.5;
            PpiBitmap bitmap = new PpiBitmap(geometry.SizePx);
            SpokeFrame frame = SyntheticSource.UniformRevolution(0, 9.0, 0.0, 100.0, 2.5);
            Random random = new Random(1);
            for (int spoke = 0; spoke < frame.SpokeCount; spoke++)
            {
                for (int bin = 0; bin < frame.BinsPerSpoke; bin++)
                {
                    bool clutter = bin < 150;                                    // dense near own ship
                    if (clutter || random.Next(100) == 0)
                    {
                        frame.Video[spoke * frame.BinsPerSpoke + bin] = (byte)random.Next(256);
                    }
                }
            }
            const int revolutions = 4;
            Stopwatch clock = Stopwatch.StartNew();
            for (int revolution = 0; revolution < revolutions; revolution++)
            {
                bitmap.PaintFrame(frame, geometry);
            }
            clock.Stop();
            double spokes = revolutions * (double)frame.SpokeCount;
            double rate = spokes / clock.Elapsed.TotalSeconds;
            Report(true, "9 throughput", Number(spokes, "0") + " spokes of 1024 bins painted in " + Number(clock.Elapsed.TotalMilliseconds, "0")
                + " ms = " + Number(rate, "0") + " spokes per second, one thread, own ship offset (0, -0.5), 6 NM scale (aim: 8200 or more for 10x"
                + (rate >= 8200.0 ? ", reached" : ", not reached; reported, not a failure") + ")");
        }

        // ---- M6: controls panel ----

        private static JsonElement M6Hello()
        {
            string json = """
            {"t":"hello","protocol":1,
             "radar":{"range_scales_nm":[0.25,0.5,0.75,1.5,3.0,6.0,12.0,24.0],"offset_max_fraction":0.66,"azimuth_bins":2048,"antenna_rpm":24.0},
             "display":{"range_ring_interval_nm":[0.05,0.1,0.25,0.25,0.5,1.0,2.0,4.0],"orientation":"north_up","color_mode":"mono_green",
                        "control_style":"knob","offset_enabled":true,"offset_x_fraction":0.0,"offset_y_fraction":-0.5,"range_scale_nm":6.0,
                        "motion_mode":"relative","trails_mode":"off","trail_time_min":6.0,"trail_video_threshold":60,
                        "true_motion_reset_fraction":0.875},
             "controls":[
              {"path":"general.sim_speed_multiplier","unit":"x","value":1.0,"min":1.0,"max":10.0,"step":1.0},
              {"path":"radar_controls.gain_percent","unit":"%","value":60.0,"min":0.0,"max":100.0,"step":1.0},
              {"path":"radar_controls.stc_percent","unit":"%","value":20.0,"min":0.0,"max":100.0,"step":1.0},
              {"path":"radar_controls.ftc_percent","unit":"%","value":0.0,"min":0.0,"max":100.0,"step":1.0},
              {"path":"radar.video_range_nm","unit":"NM","value":10.0,"min":0.1,"max":48.0,"step":0.01},
              {"path":"display.range_scale_nm","unit":"NM","value":6.0,"choices":[0.25,0.5,0.75,1.5,3.0,6.0,12.0,24.0]},
              {"path":"display.orientation","unit":"","value":"north_up","choices":["north_up","head_up","course_up"]},
              {"path":"display.color_mode","unit":"","value":"mono_green","choices":["mono_green","mono_amber","color"]},
              {"path":"display.control_style","unit":"","value":"knob","choices":["knob","slider","hybrid"]},
              {"path":"display.video_brilliance_percent","unit":"%","value":80.0,"min":0.0,"max":100.0,"step":1.0},
              {"path":"display.rings_brilliance_percent","unit":"%","value":50.0,"min":0.0,"max":100.0,"step":1.0},
              {"path":"display.symbols_brilliance_percent","unit":"%","value":100.0,"min":0.0,"max":100.0,"step":1.0},
              {"path":"display.afterglow_sim_s","unit":"s","value":6.0,"min":0.5,"max":60.0,"step":0.5},
              {"path":"display.motion_mode","unit":"","value":"relative","choices":["relative","true"]},
              {"path":"display.trails_mode","unit":"","value":"off","choices":["off","true","relative"]},
              {"path":"display.trail_time_min","unit":"MIN","value":6.0,"choices":[0.5,1.0,3.0,6.0,12.0,15.0,30.0]},
              {"path":"arpa.stabilization","unit":"","value":"sea","choices":["sea","ground"]}
             ]}
            """;
            return JsonDocument.Parse(json).RootElement;
        }

        private static DisplayController M6Controller(List<Dictionary<string, object>> sent)
        {
            DisplayController controller = new DisplayController(sent.Add);
            controller.ApplyHello(M6Hello());
            controller.Geometry.SizePx = 1024;
            controller.ApplyGeometry(true, false);
            return controller;
        }

        // The numbers of the "set" messages for one path, in order.
        private static List<double> SetValues(List<Dictionary<string, object>> sent, string path)
        {
            List<double> values = new List<double>();
            foreach (Dictionary<string, object> message in sent)
            {
                if ((string)message["t"] == "set" && (string)message["path"] == path && message["value"] is double)
                {
                    values.Add((double)message["value"]);
                }
            }
            return values;
        }

        private static string LastWord(List<Dictionary<string, object>> sent, string path)
        {
            string word = null;
            foreach (Dictionary<string, object> message in sent)
            {
                if ((string)message["t"] == "set" && (string)message["path"] == path && message["value"] is string)
                {
                    word = (string)message["value"];
                }
            }
            return word;
        }

        private static void Expect(List<string> problems, bool ok, string what)
        {
            if (!ok)
            {
                problems.Add(what);
            }
        }

        private static void ReportProblems(string name, List<string> problems, string detail)
        {
            if (problems.Count == 0)
            {
                Report(true, name, detail);
            }
            else
            {
                Report(false, name, string.Join("; ", problems));
            }
        }

        private static bool Near(double a, double b, double tolerance)
        {
            return Math.Abs(a - b) <= tolerance;
        }

        // M6 test 1: knob and slider mapping, value -> angle or position -> value.
        private static void TestM6Mapping()
        {
            List<string> problems = new List<string>();
            ValueModel gain = new ValueModel { Minimum = 0.0, Maximum = 100.0, Step = 1.0 };
            ValueModel range = new ValueModel { Choices = new double[] { 0.25, 0.5, 0.75, 1.5, 3.0, 6.0, 12.0, 24.0 } };
            ValueModel signed = new ValueModel { Minimum = -35.0, Maximum = 35.0, Step = 1.0 };
            double[] gainValues = { 0.0, 1.0, 25.0, 60.0, 99.0, 100.0 };
            double[] signedValues = { -35.0, -10.0, 0.0, 12.0, 35.0 };
            int cases = 0;

            foreach (double value in gainValues)
            {
                gain.Value = value;
                double viaKnob = gain.ValueFromFraction(ControlMath.FractionFromKnobAngle(ControlMath.KnobAngleDeg(gain.Fraction)));
                double viaSlider = gain.ValueFromFraction(ControlMath.FractionFromSliderPx(ControlMath.SliderPositionPx(gain.Fraction, 200.0), 200.0));
                Expect(problems, Math.Abs(viaKnob - value) <= gain.Step, "gain knob " + value + " -> " + viaKnob);
                Expect(problems, Math.Abs(viaSlider - value) <= gain.Step, "gain slider " + value + " -> " + viaSlider);
                cases += 2;
            }
            foreach (double value in range.Choices)
            {
                range.Value = value;
                double viaKnob = range.ValueFromFraction(ControlMath.FractionFromKnobAngle(ControlMath.KnobAngleDeg(range.Fraction)));
                double viaSlider = range.ValueFromFraction(ControlMath.FractionFromSliderPx(ControlMath.SliderPositionPx(range.Fraction, 200.0), 200.0));
                Expect(problems, viaKnob == value, "range knob " + value + " -> " + viaKnob);
                Expect(problems, viaSlider == value, "range slider " + value + " -> " + viaSlider);
                cases += 2;
            }
            foreach (double value in signedValues)
            {
                signed.Value = value;
                double viaKnob = signed.ValueFromFraction(ControlMath.FractionFromKnobAngle(ControlMath.KnobAngleDeg(signed.Fraction)));
                double viaSlider = signed.ValueFromFraction(ControlMath.FractionFromSliderPx(ControlMath.SliderPositionPx(signed.Fraction, 200.0), 200.0));
                Expect(problems, Math.Abs(viaKnob - value) <= signed.Step, "signed knob " + value + " -> " + viaKnob);
                Expect(problems, Math.Abs(viaSlider - value) <= signed.Step, "signed slider " + value + " -> " + viaSlider);
                cases += 2;
            }

            // Both ends, and a pointer in the gap at the bottom of the knob.
            Expect(problems, ControlMath.KnobAngleDeg(0.0) == -135.0 && ControlMath.KnobAngleDeg(1.0) == 135.0, "knob end angles");
            Expect(problems, ControlMath.FractionFromKnobAngle(-170.0) == 0.0, "knob gap, left half, goes to the minimum");
            Expect(problems, ControlMath.FractionFromKnobAngle(170.0) == 1.0, "knob gap, right half, goes to the maximum");
            Expect(problems, Near(ControlMath.FractionFromKnobAngle(0.0), 0.5, 1e-9), "knob top is the middle");
            Expect(problems, ControlMath.FractionFromSliderPx(-10.0, 200.0) == 0.0 && ControlMath.FractionFromSliderPx(250.0, 200.0) == 1.0, "slider ends");
            Expect(problems, gain.ValueFromFraction(2.0) == 100.0 && gain.ValueFromFraction(-1.0) == 0.0, "values clamp at both ends");
            ReportProblems("M6 1 knob and slider mapping", problems, cases + " round trips (gain, range list, signed) within one step; both ends clamp");
        }

        // M6 test 2: typed input.
        private static void TestM6Typed()
        {
            List<string> problems = new List<string>();
            ValueModel gain = new ValueModel { Minimum = 0.0, Maximum = 100.0, Step = 1.0, Value = 40.0 };
            double value;
            Expect(problems, gain.TryParseTyped("55", out value) && value == 55.0, "55");
            Expect(problems, gain.TryParseTyped("55.5", out value) && value == 55.5, "55.5");
            Expect(problems, gain.TryParseTyped("  55 ", out value) && value == 55.0, "'  55 '");
            Expect(problems, !gain.TryParseTyped("abc", out value) && value == 40.0, "abc keeps the old value");
            Expect(problems, !gain.TryParseTyped("", out value) && value == 40.0, "an empty box keeps the old value");
            Expect(problems, gain.TryParseTyped("1e9", out value) && value == 100.0, "1e9 is clamped to 100");
            Expect(problems, gain.TryParseTyped("-5", out value) && value == 0.0, "-5 is clamped to 0");
            ReportProblems("M6 2 typed input", problems, "55, 55.5 and '  55 ' accepted; abc and empty rejected (old value kept); 1e9 clamped to 100");
        }

        // M6 test 3: a simulated drag of 200 changes in 1 s sends at most 21 messages.
        private static void TestM6RateLimit()
        {
            List<string> problems = new List<string>();
            ValueControl control = new ValueControl();
            control.Configure("radar_controls.gain_percent", "GAIN", "%", 0.0, 100.0, 1.0, null, 60.0);
            List<double> sent = new List<double>();
            control.ValueSent += delegate (ValueControl source, double value) { sent.Add(value); };
            control.Model.Dragging = true;
            for (int change = 0; change < 200; change++)
            {
                control.ChangeValue(change * 0.5, change * 5L, false);          // one change every 5 ms
            }
            control.CommitDrag(1000L);
            Expect(problems, sent.Count <= 21, sent.Count + " messages, more than 21");
            Expect(problems, sent.Count > 0 && sent[sent.Count - 1] == 99.5, "the last message does not carry the final value");
            ReportProblems("M6 3 rate limit", problems, "200 changes in 1 s sent " + sent.Count + " messages; the last carried " + (sent.Count > 0 ? Number(sent[sent.Count - 1], "0.0") : "nothing"));
        }

        // M6 test 4: a value the sim corrects is shown corrected.
        private static void TestM6Setting()
        {
            List<string> problems = new List<string>();
            ValueControl control = new ValueControl();
            control.Configure("radar_controls.gain_percent", "GAIN", "%", 0.0, 100.0, 1.0, null, 60.0);
            List<double> sent = new List<double>();
            control.ValueSent += delegate (ValueControl source, double value) { sent.Add(value); };
            control.ChangeValue(130.0, 5000L, true);
            Expect(problems, control.Model.Value == 100.0, "a request of 130 shows " + control.Model.Value);
            Expect(problems, sent.Count == 1 && sent[0] == 100.0, "the request of 130 was sent as 100");
            control.ConfirmFromSim(100.0);
            Expect(problems, control.Model.Value == 100.0, "the confirmed 100 is shown");
            control.ChangeValue(50.0, 6000L, true);
            control.ConfirmFromSim(45.0);
            Expect(problems, control.Model.Value == 45.0, "a corrected 45 is shown, not 50");
            control.Model.Dragging = true;
            control.ConfirmFromSim(10.0);
            Expect(problems, control.Model.Value == 45.0, "a confirmation during a drag is ignored");
            control.Model.Dragging = false;
            ReportProblems("M6 4 setting correction", problems, "a request of 130 for gain shows 100; a corrected value snaps in; ignored during a drag");
        }

        // M6 test 5: every row of the hotkey table that has an action, simulated.
        private static void TestM6Hotkeys()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M6Controller(sent);
            sent.Clear();
            ModifierKeys none = ModifierKeys.None;
            ModifierKeys shift = ModifierKeys.Shift;
            ModifierKeys ctrl = ModifierKeys.Control;
            ModifierKeys ctrlShift = ModifierKeys.Control | ModifierKeys.Shift;

            Expect(problems, HotkeyTable.Rows.Length == 23, HotkeyTable.Rows.Length + " rows in the table, expected 23");

            // Range: PageUp, PageDown.
            c.HandleKeyDown(Key.PageUp, none, false, 0, 0);
            Expect(problems, c.Geometry.RangeScaleNm == 12.0, "PageUp: range " + c.Geometry.RangeScaleNm);
            List<double> rangeSets = SetValues(sent, DisplayController.RangeScalePath);
            Expect(problems, rangeSets.Count == 1 && rangeSets[0] == 12.0, "PageUp sends set display.range_scale_nm 12");
            List<double> videoSets = SetValues(sent, DisplayController.VideoRangePath);
            Expect(problems, videoSets.Count == 1 && Near(videoSets[0], 18.0, 1e-9), "PageUp sends video range 18 (12 x 1.5)");
            c.HandleKeyDown(Key.PageDown, none, false, 0, 0);
            c.HandleKeyDown(Key.PageDown, none, false, 0, 0);
            Expect(problems, c.Geometry.RangeScaleNm == 3.0, "PageDown twice: range " + c.Geometry.RangeScaleNm);
            c.HandleKeyDown(Key.PageUp, none, false, 0, 0);
            Expect(problems, c.Geometry.RangeScaleNm == 6.0, "back to 6 NM");

            // G, S, F in 5 % steps.
            c.HandleKeyDown(Key.G, none, false, 0, 0);
            Expect(problems, c.Numbers[DisplayController.GainPath] == 65.0, "G: gain " + c.Numbers[DisplayController.GainPath]);
            c.HandleKeyDown(Key.G, shift, false, 0, 0);
            Expect(problems, c.Numbers[DisplayController.GainPath] == 60.0, "Shift+G: gain " + c.Numbers[DisplayController.GainPath]);
            for (int press = 0; press < 10; press++)
            {
                c.HandleKeyDown(Key.G, none, false, 0, 0);
            }
            Expect(problems, c.Numbers[DisplayController.GainPath] == 100.0, "G ten times from 60: gain " + c.Numbers[DisplayController.GainPath]);
            bool tooHigh = false;
            foreach (double value in SetValues(sent, DisplayController.GainPath))
            {
                if (value > 100.0)
                {
                    tooHigh = true;
                }
            }
            Expect(problems, !tooHigh, "a gain message above 100 was sent");
            Expect(problems, SetValues(sent, DisplayController.GainPath)[SetValues(sent, DisplayController.GainPath).Count - 1] == 100.0, "the last gain message is 100");
            c.HandleKeyDown(Key.S, none, false, 0, 0);
            Expect(problems, c.Numbers[DisplayController.StcPath] == 25.0, "S: STC " + c.Numbers[DisplayController.StcPath]);
            c.HandleKeyDown(Key.S, shift, false, 0, 0);
            Expect(problems, c.Numbers[DisplayController.StcPath] == 20.0, "Shift+S: STC " + c.Numbers[DisplayController.StcPath]);
            c.HandleKeyDown(Key.F, none, false, 0, 0);
            Expect(problems, c.Numbers[DisplayController.FtcPath] == 5.0, "F: FTC " + c.Numbers[DisplayController.FtcPath]);
            c.HandleKeyDown(Key.F, shift, false, 0, 0);
            Expect(problems, c.Numbers[DisplayController.FtcPath] == 0.0, "Shift+F: FTC " + c.Numbers[DisplayController.FtcPath]);

            // O and C cycle.
            c.HandleKeyDown(Key.O, none, false, 0, 0);
            Expect(problems, c.Geometry.Orientation == PpiOrientation.HeadUp && LastWord(sent, DisplayController.OrientationPath) == "head_up", "O: head up");
            c.HandleKeyDown(Key.O, none, false, 0, 0);
            c.HandleKeyDown(Key.O, none, false, 0, 0);
            Expect(problems, c.Geometry.Orientation == PpiOrientation.NorthUp, "O three times: back to north up");
            c.HandleKeyDown(Key.C, none, false, 0, 0);
            Expect(problems, c.ColourModeName == "mono_amber" && LastWord(sent, DisplayController.ColourPath) == "mono_amber", "C: mono amber");
            c.HandleKeyDown(Key.C, none, false, 0, 0);
            c.HandleKeyDown(Key.C, none, false, 0, 0);
            Expect(problems, c.ColourModeName == "mono_green", "C three times: back to mono green");

            // 1, 2, 3, 4 and the EBL and VRM step keys.
            c.HandleKeyDown(Key.D1, none, false, 0, 0);
            Expect(problems, c.EblVrm.EblOn[0] && c.EblVrm.SelectedEbl == 0 && c.EblVrm.EblBearingDeg[0] == 0.0, "1: EBL 1 on at 000");
            c.HandleKeyDown(Key.Left, none, false, 0, 0);
            Expect(problems, Near(c.EblVrm.EblBearingDeg[0], 359.0, 1e-9), "Left: EBL " + c.EblVrm.EblBearingDeg[0]);
            c.HandleKeyDown(Key.Right, shift, false, 0, 0);
            Expect(problems, Near(c.EblVrm.EblBearingDeg[0], 359.1, 1e-9), "Shift+Right: EBL " + c.EblVrm.EblBearingDeg[0]);
            c.HandleKeyDown(Key.Right, ctrl, false, 0, 0);
            Expect(problems, Near(c.EblVrm.EblBearingDeg[0], 9.1, 1e-9), "Ctrl+Right: EBL " + c.EblVrm.EblBearingDeg[0]);
            c.HandleKeyDown(Key.D3, none, false, 0, 0);
            Expect(problems, c.EblVrm.VrmOn[0] && Near(c.EblVrm.VrmNm[0], 3.0, 1e-9), "3: VRM 1 on at 50 % of 6 NM = 3 NM");
            c.HandleKeyDown(Key.Up, none, false, 0, 0);
            Expect(problems, Near(c.EblVrm.VrmNm[0], 3.06, 1e-9), "Up: VRM " + c.EblVrm.VrmNm[0]);
            c.HandleKeyDown(Key.Up, shift, false, 0, 0);
            Expect(problems, Near(c.EblVrm.VrmNm[0], 3.066, 1e-9), "Shift+Up: VRM " + c.EblVrm.VrmNm[0]);
            c.HandleKeyDown(Key.Down, ctrl, false, 0, 0);
            Expect(problems, Near(c.EblVrm.VrmNm[0], 2.466, 1e-9), "Ctrl+Down: VRM " + c.EblVrm.VrmNm[0]);
            c.HandleKeyDown(Key.D2, none, false, 0, 0);
            c.HandleKeyDown(Key.D4, none, false, 0, 0);
            Expect(problems, c.EblVrm.EblOn[1] && c.EblVrm.VrmOn[1] && c.EblVrm.SelectedEbl == 1 && c.EblVrm.SelectedVrm == 1, "2 and 4: EBL 2 and VRM 2 on and selected");
            c.HandleKeyDown(Key.D2, none, false, 0, 0);
            Expect(problems, !c.EblVrm.EblOn[1], "2 again: EBL 2 off");

            // P, F5, F6.
            c.HandleKeyDown(Key.P, none, false, 0, 0);
            Dictionary<string, object> last = sent[sent.Count - 1];
            Expect(problems, (string)last["t"] == "pause" && (bool)last["paused"], "P sends pause true");
            c.HandleKeyDown(Key.F6, none, false, 0, 0);
            c.HandleKeyDown(Key.F6, none, false, 0, 0);
            Expect(problems, c.SimSpeedRequested == 3.0, "F6 twice from 1: " + c.SimSpeedRequested);
            c.HandleKeyDown(Key.F5, none, false, 0, 0);
            Expect(problems, c.SimSpeedRequested == 2.0, "F5: " + c.SimSpeedRequested);
            Expect(problems, SetValues(sent, DisplayController.SpeedPath).Count == 3, "three speed messages sent");
            c.HandleKeyDown(Key.F5, none, false, 0, 0);
            int speedMessages = SetValues(sent, DisplayController.SpeedPath).Count;
            c.HandleKeyDown(Key.F5, none, false, 0, 0);
            Expect(problems, c.SimSpeedRequested == 1.0 && SetValues(sent, DisplayController.SpeedPath).Count == speedMessages, "F5 at 1: nothing more sent");

            // Offset: Ctrl+O to the cursor, Ctrl+Shift+O to the centre.
            c.HandleKeyDown(Key.O, ctrl, true, 700.0, 300.0);
            Expect(problems, Near(c.Geometry.OwnXPx, 700.0, 0.01) && Near(c.Geometry.OwnYPx, 300.0, 0.01), "Ctrl+O: own ship at " + c.Geometry.OwnXPx + ", " + c.Geometry.OwnYPx);
            c.HandleKeyDown(Key.O, ctrlShift, false, 0, 0);
            Expect(problems, Near(c.Geometry.OwnXPx, 512.0, 0.01) && Near(c.Geometry.OwnYPx, 512.0, 0.01), "Ctrl+Shift+O: own ship centred");

            // H is held; Enter and Esc.
            c.HandleKeyDown(Key.H, none, false, 0, 0);
            Expect(problems, c.HeadingLineHeld, "H down hides the heading line");
            c.HandleKeyUp(Key.H);
            Expect(problems, !c.HeadingLineHeld, "H up shows it again");
            bool focusOrder = false;
            bool focusRequests = false;
            c.OrderFocusRequested += delegate (bool focus) { focusOrder = focus; focusRequests = true; };
            c.HandleKeyDown(Key.Enter, none, false, 0, 0);
            Expect(problems, focusRequests && focusOrder, "Enter focuses the order box");
            c.HandleKeyDown(Key.Escape, none, false, 0, 0);
            Expect(problems, !focusOrder, "Esc leaves it");

            // The M9 keys are tested in M9 test 6, Ctrl+Shift+T and F1 in M10 test 5.
            ReportProblems("M6 5 hotkeys", problems, "23 rows; PageUp/Down, G, S, F, O, C, 1-4, Left/Right, Up/Down, P, F5/F6, Ctrl+O, Ctrl+Shift+O, H, Enter, Esc checked; G x10 from 60 gives 100");
        }

        // M6 test 6: EBL and VRM geometry.
        private static void TestM6EblVrm()
        {
            List<string> problems = new List<string>();
            PpiGeometry g = new PpiGeometry();
            g.SizePx = 1024;
            g.RangeScaleNm = 6.0;
            double centre = 512.0;
            double endX, endY;

            // North-up, EBL 090 deg T: horizontal, to the right.
            EblVrmSet set = new EblVrmSet();
            set.SetEblReading(0, 90.0);
            set.EblEndPx(0, g, out endX, out endY);
            Expect(problems, Near(endY, centre, 0.5) && Near(endX, centre + 512.0, 1.0), "north-up 090 T ends at " + endX + ", " + endY);

            // Head-up with heading 090: EBL 090 deg T points straight up.
            g.Orientation = PpiOrientation.HeadUp;
            g.HeadingDegTrue = 90.0;
            set.EblEndPx(0, g, out endX, out endY);
            Expect(problems, Near(endX, centre, 0.5) && Near(endY, 0.0, 1.0), "head-up 090 T ends at " + endX + ", " + endY);

            // Relative EBL 000 deg R in head-up points straight up.
            EblVrmSet relative = new EblVrmSet();
            relative.EblRelative = true;
            relative.SetEblReading(0, 0.0);
            relative.EblEndPx(0, g, out endX, out endY);
            Expect(problems, Near(endX, centre, 0.5) && Near(endY, 0.0, 1.0), "head-up 000 R ends at " + endX + ", " + endY);

            // A relative bearing reads the right true bearing with a heading that is not zero.
            g.Orientation = PpiOrientation.NorthUp;
            g.HeadingDegTrue = 30.0;
            relative.SetEblReading(0, 45.0);
            Expect(problems, Near(relative.EblTrueDeg(0, g.HeadingDegTrue), 75.0, 1e-9), "045 R with heading 030 reads " + relative.EblTrueDeg(0, g.HeadingDegTrue) + " T");
            Expect(problems, Near(relative.EblScreenAngleDeg(0, g), 75.0, 1e-9), "and sits at screen angle 075");

            // Switching true <-> relative keeps the line where it is.
            EblVrmSet switching = new EblVrmSet();
            switching.SetEblReading(0, 200.0);
            switching.SetRelativeMode(true, 30.0);
            Expect(problems, Near(switching.EblBearingDeg[0], 170.0, 1e-9), "200 T with heading 030 becomes 170 R");
            switching.SetRelativeMode(false, 30.0);
            Expect(problems, Near(switching.EblBearingDeg[0], 200.0, 1e-9), "and back to 200 T");

            // VRM 0.6 NM at the 6 NM scale: 0.1 of the PPI radius.
            EblVrmSet ranges = new EblVrmSet();
            ranges.VrmNm[0] = 0.6;
            double radiusPx = ranges.VrmRadiusPx(0, g);
            Expect(problems, Near(radiusPx, 0.1 * g.RadiusPx, 1.0), "VRM 0.6 NM is " + radiusPx + " px, expected " + 0.1 * g.RadiusPx);

            // Dragging an end to a pixel sets the bearing to the pointer's.
            double dragX, dragY;
            g.PixelOf(2.0, 200.0, out dragX, out dragY);
            EblVrmSet dragged = new EblVrmSet();
            dragged.SetEblFromPixel(0, g, dragX, dragY);
            Expect(problems, AngleError(dragged.EblBearingDeg[0], 200.0) <= 0.5, "dragged true EBL reads " + dragged.EblBearingDeg[0]);
            dragged.SetRelativeMode(true, g.HeadingDegTrue);
            g.PixelOf(3.0, 250.0, out dragX, out dragY);
            dragged.SetEblFromPixel(0, g, dragX, dragY);
            Expect(problems, AngleError(dragged.EblBearingDeg[0], 220.0) <= 0.5, "dragged relative EBL reads " + dragged.EblBearingDeg[0] + " R, expected 220");
            Expect(problems, AngleError(dragged.EblTrueDeg(0, g.HeadingDegTrue), 250.0) <= 0.5, "and " + dragged.EblTrueDeg(0, g.HeadingDegTrue) + " T, expected 250");

            // The mouse finds a line near it and not one far away.
            EblVrmSet hit = new EblVrmSet();
            g.HeadingDegTrue = 0.0;
            hit.SetEblReading(0, 90.0);
            hit.EblOn[0] = true;
            bool isEbl;
            int index;
            Expect(problems, hit.HitTest(g, centre + 100.0, centre + 3.0, 8.0, out isEbl, out index) && isEbl && index == 0, "a point 3 px from the EBL is a hit");
            Expect(problems, !hit.HitTest(g, centre + 100.0, centre + 30.0, 8.0, out isEbl, out index), "a point 30 px away is not");
            ReportProblems("M6 6 EBL and VRM geometry", problems, "EBL true, head-up and relative directions; heading 030 gives 075; mode switch; VRM 0.6 NM = " + Number(radiusPx, "0.0") + " px; drag within 0.5 deg");
        }

        // M6 test 7: the control style changes every ValueControl and loses no value.
        private static void TestM6ControlStyle()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController controller = M6Controller(sent);
            ControlPanel panel = new ControlPanel();
            panel.Build(controller);
            int count = panel.ValueControls.Count;
            Expect(problems, count == 7, count + " value controls, expected 7 (GAIN, STC, FTC, 3 BRILLIANCE, AFTERGLOW)");

            double[] before = new double[count];
            for (int i = 0; i < count; i++)
            {
                before[i] = panel.ValueControls[i].Model.Value;
            }
            Expect(problems, before.Length == 7 && before[0] == 60.0 && before[1] == 20.0 && before[3] == 80.0 && before[6] == 6.0, "values start as hello gave them");

            controller.SetControlStyle("slider");
            for (int i = 0; i < count; i++)
            {
                Expect(problems, panel.ValueControls[i].Look == ControlLook.Slider, panel.ValueControls[i].Path + " is not a slider");
                Expect(problems, panel.ValueControls[i].Model.Value == before[i], panel.ValueControls[i].Path + " lost its value");
            }
            Expect(problems, LastWord(sent, DisplayController.StylePath) == "slider", "set display.control_style slider was sent");
            controller.SetControlStyle("knob");
            for (int i = 0; i < count; i++)
            {
                Expect(problems, panel.ValueControls[i].Look == ControlLook.Knob, panel.ValueControls[i].Path + " is not a knob");
                Expect(problems, panel.ValueControls[i].Model.Value == before[i], panel.ValueControls[i].Path + " lost its value");
            }
            ReportProblems("M6 7 control style at runtime", problems, count + " controls switched knob -> slider -> knob with their values");
        }

        // ---- M7: trails and true motion ----

        private const int M7Bins = 1024;
        private const double M7RevolutionS = 2.5;           // antenna revolution, sim s (24 rpm)
        private const double M7KnotNmPerS = 1.0 / 3600.0;   // 1 kn in NM per s

        // One spoke with one echo. The spoke's azimuth is bin 0 and the gyro heading carries the
        // echo's true bearing, so azimuth + gyro points at it; the painter and the trail layer
        // only use that sum.
        private static SpokeFrame M7EchoFrame(double videoRangeNm, double simTimeS, double refXNm, double refYNm,
                                              double echoRangeNm, double echoBearingDegTrue)
        {
            SpokeFrame frame = new SpokeFrame(1, M7Bins, videoRangeNm);
            double azimuthDeg = 0.5 * 360.0 / 2048.0;                               // centre of azimuth bin 0
            frame.AzimuthIndex[0] = 0;
            frame.GyroHeadingCdeg[0] = (ushort)Math.Round(PpiGeometry.Normalise360(echoBearingDegTrue - azimuthDeg) * 100.0);   // deg -> cdeg
            frame.SimTimeS[0] = simTimeS;
            frame.RefXNm[0] = (float)refXNm;
            frame.RefYNm[0] = (float)refYNm;
            int bin = (int)(echoRangeNm / videoRangeNm * M7Bins);
            if (bin >= 0 && bin < M7Bins)
            {
                frame.Video[bin] = 200;
            }
            return frame;
        }

        // The brightness-weighted centre of everything painted, in bitmap pixels (pixel i covers i to i + 1).
        private static bool M7Centroid(PpiBitmap bitmap, out double xPx, out double yPx)
        {
            double sum = 0.0, sumX = 0.0, sumY = 0.0;
            for (int i = 0; i < bitmap.Intensity.Length; i++)
            {
                if (bitmap.Intensity[i] > 0)
                {
                    sum += bitmap.Intensity[i];
                    sumX += bitmap.Intensity[i] * (i % bitmap.SizePx + 0.5);
                    sumY += bitmap.Intensity[i] * (i / bitmap.SizePx + 0.5);
                }
            }
            xPx = sum > 0.0 ? sumX / sum : double.NaN;
            yPx = sum > 0.0 ? sumY / sum : double.NaN;
            return sum > 0.0;
        }

        private static PpiGeometry M7Geometry(double rangeScaleNm)
        {
            PpiGeometry geometry = new PpiGeometry();
            geometry.SizePx = 1024;
            geometry.RangeScaleNm = rangeScaleNm;
            geometry.Orientation = PpiOrientation.NorthUp;
            geometry.TrueMotion = true;
            geometry.OffsetXFraction = 0.0;
            geometry.OffsetYFraction = -0.5;
            return geometry;
        }

        // M7 test 1: true motion in ground mode. The reference position moves 1 NM north at 10 KN;
        // a stationary echo stays on its pixel and own ship's mark moves 1 NM / scale x radius.
        private static void TestM7GroundMotion()
        {
            List<string> problems = new List<string>();
            PpiGeometry geometry = M7Geometry(6.0);
            geometry.ResetViewOrigin(0.0, 0.0);
            PpiBitmap bitmap = new PpiBitmap(1024);
            double videoRangeNm = 6.0 * 1.75;
            double echoNorthNm = 3.5;                                   // the echo's place in the stabilisation frame, NM north of the start
            double firstX = 0.0, firstY = 0.0, worstPx = 0.0;
            double markStartY = 0.0, markMovedPx = 0.0;
            for (int step = 0; step <= 4; step++)
            {
                double refYNm = 0.25 * step;                            // NM; 0.25 NM is 90 s at 10 KN
                double timeS = refYNm / (10.0 * M7KnotNmPerS);
                bitmap.Clear();
                bitmap.PaintFrame(M7EchoFrame(videoRangeNm, timeS, 0.0, refYNm, echoNorthNm - refYNm, 0.0), geometry);
                double x, y;
                Expect(problems, M7Centroid(bitmap, out x, out y), "step " + step + ": nothing was painted");
                double markX, markY;
                geometry.OwnPixelFor(0.0, refYNm, out markX, out markY);
                if (step == 0)
                {
                    firstX = x;
                    firstY = y;
                    markStartY = markY;
                }
                worstPx = Math.Max(worstPx, Math.Max(Math.Abs(x - firstX), Math.Abs(y - firstY)));
                markMovedPx = markStartY - markY;
                Expect(problems, Math.Abs(markX - 512.0) < 0.01, "step " + step + ": the mark left the heading line");
            }
            double expectedMovePx = 1.0 / 6.0 * 512.0;                  // 1 NM / scale x radius
            Expect(problems, worstPx <= 1.0, "the echo moved " + Number(worstPx, "0.00") + " px (limit 1)");
            Expect(problems, Math.Abs(markMovedPx - expectedMovePx) < 0.01, "own ship moved " + Number(markMovedPx, "0.00") + " px, expected " + Number(expectedMovePx, "0.00"));
            Expect(problems, bitmap.ResetCount == 0, "a reset happened");
            ReportProblems("M7 1 true motion, ground mode", problems, "ref moved 1 NM at 10 KN: echo moved " + Number(worstPx, "0.00")
                + " px (limit 1); own ship's mark moved " + Number(markMovedPx, "0.0") + " px (expected " + Number(expectedMovePx, "0.0") + ")");
        }

        // M7 test 2: sea mode, 2 KN current east, own ship 10 KN north through the water. The reference
        // position only follows the water, so a buoy fixed on the ground drifts west at 2 KN on the screen.
        private static void TestM7SeaMotion()
        {
            List<string> problems = new List<string>();
            PpiGeometry geometry = M7Geometry(12.0);
            geometry.ResetViewOrigin(0.0, 0.0);
            PpiBitmap bitmap = new PpiBitmap(1024);
            double videoRangeNm = 12.0 * 1.75;
            double pxPerNm = 512.0 / 12.0;
            double buoyEastNm = 0.0, buoyNorthNm = 8.0;                 // on the ground
            List<double> times = new List<double>();
            List<double> xs = new List<double>();
            double firstY = 0.0, worstYPx = 0.0;
            for (int step = 0; step <= 6; step++)
            {
                double timeS = 300.0 * step;
                double realEastNm = 2.0 * M7KnotNmPerS * timeS;         // own ship over the ground: current plus water
                double realNorthNm = 10.0 * M7KnotNmPerS * timeS;
                double refYNm = 10.0 * M7KnotNmPerS * timeS;            // sea mode: water only
                double relEast = buoyEastNm - realEastNm;
                double relNorth = buoyNorthNm - realNorthNm;
                double rangeNm = Math.Sqrt(relEast * relEast + relNorth * relNorth);
                double bearingDeg = Math.Atan2(relEast, relNorth) * 180.0 / Math.PI;    // rad -> deg
                bitmap.Clear();
                bitmap.PaintFrame(M7EchoFrame(videoRangeNm, timeS, 0.0, refYNm, rangeNm, bearingDeg), geometry);
                double x, y;
                Expect(problems, M7Centroid(bitmap, out x, out y), "step " + step + ": nothing was painted");
                times.Add(timeS);
                xs.Add(x);
                if (step == 0)
                {
                    firstY = y;
                }
                worstYPx = Math.Max(worstYPx, Math.Abs(y - firstY));
            }
            double meanT = 0.0, meanX = 0.0;
            for (int i = 0; i < times.Count; i++)
            {
                meanT += times[i] / times.Count;
                meanX += xs[i] / times.Count;
            }
            double cross = 0.0, spread = 0.0;
            for (int i = 0; i < times.Count; i++)
            {
                cross += (times[i] - meanT) * (xs[i] - meanX);
                spread += (times[i] - meanT) * (times[i] - meanT);
            }
            double slopePxPerS = cross / spread;                        // px per s, + is east
            double westKn = -slopePxPerS / pxPerNm / M7KnotNmPerS;      // px/s -> NM/s -> kn
            Expect(problems, westKn > 1.9 && westKn < 2.1, "the echo moves west at " + Number(westKn, "0.000") + " kn, expected 2.0 +-5 %");
            Expect(problems, worstYPx <= 1.0, "the echo moved " + Number(worstYPx, "0.00") + " px north or south (limit 1)");
            ReportProblems("M7 2 true motion, sea mode with a current", problems, "buoy fixed on the ground drifts west at " + Number(westKn, "0.000")
                + " kn on the screen (2.0 +-5 %), 30 min at 10 KN, 12 NM scale");
        }

        // The tiny harness the window provides: geometry changes go to the painter, and a reset in true
        // motion takes own ship's position from the latest spoke.
        private static void M7Wire(DisplayController controller, PpiBitmap bitmap, SpokeSource source)
        {
            controller.GeometryChanged += delegate (bool clear)
            {
                if (controller.ViewResetPending && controller.Geometry.TrueMotionActive)
                {
                    bitmap.ApplyViewReset(controller.Geometry);
                }
                controller.ViewResetPending = false;
                source.SetGeometry(controller.Geometry, clear);
            };
        }

        private static void M7WaitPainted(PpiBitmap bitmap, long spokes)
        {
            Stopwatch waited = Stopwatch.StartNew();
            while (Interlocked.Read(ref bitmap.SpokesPainted) < spokes && waited.ElapsedMilliseconds < 10000)
            {
                Thread.Sleep(10);
            }
            Thread.Sleep(30);
        }

        private static int M7NonZero(PpiBitmap bitmap)
        {
            int count = 0;
            lock (bitmap.Sync)
            {
                for (int i = 0; i < bitmap.Intensity.Length; i++)
                {
                    if (bitmap.Intensity[i] > 0)
                    {
                        count++;
                    }
                }
            }
            return count;
        }

        // M7 test 3: own ship passes 75 % of the radius, and the next frame has it at the offset position
        // with a cleared picture. The RESET button does the same.
        private static void TestM7Reset()
        {
            List<string> problems = new List<string>();
            PpiGeometry geometry = M7Geometry(6.0);
            geometry.ResetViewOrigin(0.0, 0.0);
            PpiBitmap bitmap = new PpiBitmap(1024);
            double videoRangeNm = 6.0 * 1.75;

            // Own ship at 0.75 x 512 px = 384 px from the centre. Starting 256 px below it, that is 7.5 NM north.
            bitmap.PaintFrame(M7EchoFrame(videoRangeNm, 0.0, 0.0, 7.4, 2.0, 180.0), geometry);      // 2 NM astern, on the screen
            Expect(problems, bitmap.ResetCount == 0, "7.4 NM north is inside the circle but a reset happened");
            Expect(problems, M7NonZero(bitmap) > 0, "the echo was not painted");
            double markX, markY;
            geometry.OwnPixelFor(0.0, 7.4, out markX, out markY);
            Expect(problems, Math.Abs(markY - (512.0 - 375.47)) < 0.1, "mark at " + Number(markY, "0.0") + " px before the reset");

            bitmap.PaintFrame(M7EchoFrame(videoRangeNm, 5.0, 0.0, 7.6, -1.0, 0.0), geometry);       // a negative range puts no echo in this frame
            Expect(problems, bitmap.ResetCount == 1, "reset count " + bitmap.ResetCount + ", expected 1");
            Expect(problems, M7NonZero(bitmap) == 0, "the picture was not cleared");
            geometry.OwnPixelFor(0.0, 7.6, out markX, out markY);
            Expect(problems, Math.Abs(markX - 512.0) < 0.01 && Math.Abs(markY - 768.0) < 0.01,
                   "after the reset the mark is at " + Number(markX, "0.0") + ", " + Number(markY, "0.0") + ", expected 512, 768 (offset 0, -0.5)");
            Expect(problems, Math.Abs(bitmap.ViewOriginYNm - 10.6) < 1e-6, "the painter's view origin is " + Number(bitmap.ViewOriginYNm, "0.000") + ", expected 10.6");

            // The RESET button, through the controller and the painter thread.
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController controller = M6Controller(sent);
            PpiBitmap liveBitmap = new PpiBitmap(1024);
            SpokeSource source = new SpokeSource(liveBitmap, controller.Geometry);
            M7Wire(controller, liveBitmap, source);
            controller.SetMotion(true);
            source.Enqueue(Protocol.PackSpokes(M7EchoFrame(10.5, 1.0, 0.0, 3.0, 2.0, 0.0)));
            M7WaitPainted(liveBitmap, 1);
            Expect(problems, M7NonZero(liveBitmap) > 0, "live: the echo was not painted");
            controller.ResetTrueMotion();
            double liveX, liveY;
            controller.Geometry.OwnPixelFor(0.0, 3.0, out liveX, out liveY);
            Expect(problems, Math.Abs(liveX - 512.0) < 0.01 && Math.Abs(liveY - 768.0) < 0.01,
                   "RESET: the mark is at " + Number(liveX, "0.0") + ", " + Number(liveY, "0.0") + ", expected 512, 768");
            Expect(problems, M7NonZero(liveBitmap) == 0, "RESET: the picture was not cleared");
            Expect(problems, Math.Abs(liveBitmap.ViewOriginYNm - 6.0) < 1e-6, "RESET: the painter's origin is " + Number(liveBitmap.ViewOriginYNm, "0.000") + ", expected 6");
            controller.SetMotion(false);
            controller.ResetTrueMotion();
            source.Stop();
            ReportProblems("M7 3 true motion reset", problems, "own ship at 7.6 NM (past 0.75 of the radius) is put back at 512, 768 with a cleared picture; 7.4 NM is not reset; RESET does the same");
        }

        // One antenna revolution for the trail layer: the spoke with the echo, then a late empty spoke so
        // that the next revolution's first spoke goes backwards in azimuth.
        private static void M7TrailRevolution(TrailLayer trails, double simTimeS, double refXNm, double refYNm,
                                              double echoEastNm, double echoNorthNm)
        {
            double relEast = echoEastNm - refXNm;
            double relNorth = echoNorthNm - refYNm;
            double rangeNm = Math.Sqrt(relEast * relEast + relNorth * relNorth);
            double bearingDeg = Math.Atan2(relEast, relNorth) * 180.0 / Math.PI;       // rad -> deg
            byte[] video = new byte[M7Bins];
            video[(int)(rangeNm / 12.0 * M7Bins)] = 200;
            trails.AddSpoke(100, simTimeS, bearingDeg, refXNm, refYNm, video, 0, M7Bins, 12.0);
            trails.AddSpoke(2000, simTimeS + 2.0, 0.0, refXNm, refYNm, new byte[M7Bins], 0, M7Bins, 12.0);
        }

        // Extent of everything lit in the trail layer: the two lit pixels furthest apart, in NM, and the lit count.
        private static double M7TrailLengthNm(TrailLayer trails, double pxPerNm, out int litCount, out int firstIndex, out int lastIndex)
        {
            litCount = 0;
            firstIndex = -1;
            lastIndex = -1;
            double best = 0.0;
            List<int> lit = new List<int>();
            for (int i = 0; i < trails.Alpha.Length; i++)
            {
                if (trails.Alpha[i] > 0)
                {
                    lit.Add(i);
                }
            }
            litCount = lit.Count;
            if (lit.Count == 0)
            {
                return 0.0;
            }
            // The track is a straight line: its ends are the extreme pixels along y (then x).
            int lowest = lit[0], highest = lit[0];
            foreach (int index in lit)
            {
                if (index < lowest)
                {
                    lowest = index;
                }
                if (index > highest)
                {
                    highest = index;
                }
            }
            double dx = (highest % trails.SizePx) - (lowest % trails.SizePx);
            double dy = (highest / trails.SizePx) - (lowest / trails.SizePx);
            best = Math.Sqrt(dx * dx + dy * dy) / pxPerNm;
            firstIndex = lowest;
            lastIndex = highest;
            return best;
        }

        // M7 test 4: true trails. A target at 10 KN for 6 MIN draws 1.0 NM +-5 %; a stationary one draws
        // nothing longer than the beam width plus one pixel.
        private static void TestM7TrueTrails()
        {
            List<string> problems = new List<string>();
            PpiGeometry geometry = M7Geometry(6.0);
            geometry.TrueMotion = false;
            double pxPerNm = 512.0 / 6.0;

            TrailLayer moving = new TrailLayer(1024);
            moving.Mode = TrailMode.True;
            moving.TimeMin = 6.0;
            double nowS = 0.0;
            for (int revolution = 0; revolution <= 240; revolution++)           // 10 min of revolutions
            {
                nowS = revolution * M7RevolutionS;
                M7TrailRevolution(moving, nowS, 0.0, 0.0, 0.0, 1.0 + 10.0 * M7KnotNmPerS * nowS);
            }
            geometry.OwnRefXNm = 0.0;
            geometry.OwnRefYNm = 0.0;
            moving.Redraw(geometry, nowS);
            int lit, first, last;
            double lengthNm = M7TrailLengthNm(moving, pxPerNm, out lit, out first, out last);
            Expect(problems, lengthNm > 0.95 && lengthNm < 1.05, "the trail is " + Number(lengthNm, "0.000") + " NM long, expected 1.0 +-5 %");

            TrailLayer still = new TrailLayer(1024);
            still.Mode = TrailMode.True;
            still.TimeMin = 6.0;
            for (int revolution = 0; revolution <= 240; revolution++)
            {
                M7TrailRevolution(still, revolution * M7RevolutionS, 0.0, 0.0, 0.0, 1.0);
            }
            still.Redraw(geometry, 240 * M7RevolutionS);
            int stillLit, stillFirst, stillLast;
            double stillNm = M7TrailLengthNm(still, pxPerNm, out stillLit, out stillFirst, out stillLast);
            double beamPx = 1.0 * (360.0 / 2048.0 * Math.PI / 180.0) * pxPerNm;      // range 1 NM, one spoke wide, in px
            Expect(problems, stillNm * pxPerNm <= beamPx + 1.0, "a stationary target's trail is " + Number(stillNm * pxPerNm, "0.00") + " px, limit " + Number(beamPx + 1.0, "0.00"));
            ReportProblems("M7 4 true trails", problems, "10 KN for 6 MIN: " + Number(lengthNm, "0.000") + " NM (1.0 +-5 %); stationary target: "
                + Number(stillNm * pxPerNm, "0.00") + " px (limit " + Number(beamPx + 1.0, "0.00") + ")");
        }

        // M7 test 5: relative trails. Own ship 10 KN north; a stationary target draws 1.0 NM +-5 %, with the
        // newest (brightest) end on the side opposite to own ship's motion. A target that moves with own ship draws no trail.
        private static void TestM7RelativeTrails()
        {
            List<string> problems = new List<string>();
            PpiGeometry geometry = M7Geometry(6.0);
            geometry.TrueMotion = false;
            double pxPerNm = 512.0 / 6.0;

            TrailLayer trails = new TrailLayer(1024);
            trails.Mode = TrailMode.Relative;
            trails.TimeMin = 6.0;
            double nowS = 0.0, refYNm = 0.0;
            for (int revolution = 0; revolution <= 240; revolution++)
            {
                nowS = revolution * M7RevolutionS;
                refYNm = 10.0 * M7KnotNmPerS * nowS;
                M7TrailRevolution(trails, nowS, 0.0, refYNm, 0.0, 8.0);        // fixed on the ground, 8 NM north of the start
            }
            geometry.OwnRefXNm = 0.0;
            geometry.OwnRefYNm = refYNm;
            trails.Redraw(geometry, nowS);
            int lit, first, last;
            double lengthNm = M7TrailLengthNm(trails, pxPerNm, out lit, out first, out last);
            Expect(problems, lengthNm > 0.95 && lengthNm < 1.05, "the trail is " + Number(lengthNm, "0.000") + " NM long, expected 1.0 +-5 %");
            // Own ship moves north, so its relative picture moves south: the newest end is the southern one (larger y).
            int southIndex = Math.Max(first, last);
            int northIndex = Math.Min(first, last);
            Expect(problems, trails.Alpha[southIndex] > trails.Alpha[northIndex], "the southern end (alpha " + trails.Alpha[southIndex]
                + ") is not brighter than the northern end (alpha " + trails.Alpha[northIndex] + ")");

            TrailLayer together = new TrailLayer(1024);
            together.Mode = TrailMode.Relative;
            together.TimeMin = 6.0;
            double togetherRefY = 0.0;
            for (int revolution = 0; revolution <= 240; revolution++)
            {
                double t = revolution * M7RevolutionS;
                togetherRefY = 10.0 * M7KnotNmPerS * t;
                M7TrailRevolution(together, t, 0.0, togetherRefY, 0.0, 6.0 + togetherRefY);   // moves exactly with own ship
            }
            geometry.OwnRefYNm = togetherRefY;
            together.Redraw(geometry, 240 * M7RevolutionS);
            int togetherLit, togetherFirst, togetherLast;
            double togetherNm = M7TrailLengthNm(together, pxPerNm, out togetherLit, out togetherFirst, out togetherLast);
            Expect(problems, togetherNm * pxPerNm <= 1.0 + 1.0, "a target moving with own ship drew " + Number(togetherNm * pxPerNm, "0.00") + " px of trail");
            ReportProblems("M7 5 relative trails", problems, "stationary target from own ship at 10 KN: " + Number(lengthNm, "0.000")
                + " NM (1.0 +-5 %), newest end on the stern side; target moving with own ship: " + Number(togetherNm * pxPerNm, "0.00") + " px");
        }

        // M7 test 6: trail time, and clearing on a mode or range change.
        private static void TestM7TrailTime()
        {
            List<string> problems = new List<string>();
            TrailLayer trails = new TrailLayer(1024);
            trails.Mode = TrailMode.True;
            trails.TimeMin = 1.0;
            double nowS = 0.0;
            for (int revolution = 0; revolution < 100; revolution++)
            {
                nowS = revolution * M7RevolutionS;
                M7TrailRevolution(trails, nowS, 0.0, 0.0, 0.0, 2.0);
            }
            double oldestS = trails.OldestAgeS(nowS);
            Expect(problems, oldestS <= 60.0 && oldestS > 60.0 - M7RevolutionS - 1e-9,
                   "the oldest revolution is " + Number(oldestS, "0.0") + " s old, expected 60 s within one revolution (2.5 s)");
            int before = trails.PointCount;
            trails.SetMode(TrailMode.True);
            Expect(problems, trails.PointCount == before && before > 0, "setting the same mode cleared the trails");
            trails.SetMode(TrailMode.Relative);
            Expect(problems, trails.PointCount == 0, "a new mode left " + trails.PointCount + " points");

            // A range change clears the picture and the trails (through the painter's SetGeometry).
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController controller = M6Controller(sent);
            PpiBitmap bitmap = new PpiBitmap(1024);
            SpokeSource source = new SpokeSource(bitmap, controller.Geometry);
            M7Wire(controller, bitmap, source);
            bitmap.Trails.Mode = TrailMode.True;
            for (int revolution = 0; revolution < 10; revolution++)
            {
                M7TrailRevolution(bitmap.Trails, revolution * M7RevolutionS, 0.0, 0.0, 0.0, 2.0);
            }
            Expect(problems, bitmap.Trails.PointCount > 0, "no trail points before the range change");
            controller.StepRange(1);
            Expect(problems, bitmap.Trails.PointCount == 0, "a range change left " + bitmap.Trails.PointCount + " trail points");
            source.Stop();
            ReportProblems("M7 6 trail time and clearing", problems, "1 MIN trail: oldest revolution " + Number(oldestS, "0.0")
                + " s old (60 +-2.5); a mode change and a range change clear the trails");
        }

        // M7 test 7: true motion needs north-up, in both directions, with a line for the message pane;
        // the M and T hotkeys; trail time snaps to the list; hello supplies the new defaults.
        private static void TestM7MotionOrientation()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M6Controller(sent);
            List<string> notices = new List<string>();
            c.Notice += notices.Add;
            ModifierKeys none = ModifierKeys.None;

            Expect(problems, c.TrailVideoThreshold == 60, "trail_video_threshold from hello: " + c.TrailVideoThreshold);
            Expect(problems, Near(c.Geometry.TrueMotionResetFraction, 0.875, 1e-9), "true_motion_reset_fraction from hello: " + c.Geometry.TrueMotionResetFraction);
            Expect(problems, !c.MotionTrue && c.TrailsModeName == "off" && c.TrailTimeMin == 6.0, "defaults from hello: relative motion, trails off, 6 MIN");

            c.HandleKeyDown(Key.O, none, false, 0, 0);
            Expect(problems, c.Geometry.Orientation == PpiOrientation.HeadUp, "O: head up");
            sent.Clear();
            c.HandleKeyDown(Key.M, none, false, 0, 0);
            Expect(problems, c.MotionTrue && c.Geometry.TrueMotionActive, "M in head-up: true motion on");
            Expect(problems, c.Geometry.Orientation == PpiOrientation.NorthUp && LastWord(sent, DisplayController.OrientationPath) == "north_up", "M in head-up switches to north-up");
            Expect(problems, LastWord(sent, DisplayController.MotionPath) == "true", "set display.motion_mode true was sent");
            Expect(problems, notices.Count == 1 && notices[0].Contains("NORTH UP"), "one line for the message pane: " + string.Join(" | ", notices));
            List<double> videoSets = SetValues(sent, DisplayController.VideoRangePath);
            Expect(problems, videoSets.Count > 0 && Near(videoSets[videoSets.Count - 1], 11.25, 1e-9),
                   "in true motion the video range covers the reset circle: 6 NM x 1.875 = 11.25 NM, sent " + (videoSets.Count > 0 ? Number(videoSets[videoSets.Count - 1], "0.00") : "nothing"));

            c.HandleKeyDown(Key.O, none, false, 0, 0);
            Expect(problems, !c.MotionTrue && !c.Geometry.TrueMotion, "choosing another orientation: relative motion again");
            Expect(problems, LastWord(sent, DisplayController.MotionPath) == "relative", "set display.motion_mode relative was sent");
            Expect(problems, notices.Count == 2 && notices[1].Contains("RELATIVE"), "a second line for the message pane: " + string.Join(" | ", notices));

            c.HandleKeyDown(Key.M, none, false, 0, 0);                  // head-up again: north-up first
            Expect(problems, c.MotionTrue && c.Geometry.Orientation == PpiOrientation.NorthUp && notices.Count == 3, "M again from head-up");
            c.HandleKeyDown(Key.M, none, false, 0, 0);
            Expect(problems, !c.MotionTrue && LastWord(sent, DisplayController.MotionPath) == "relative", "M toggles true motion off");

            sent.Clear();
            c.HandleKeyDown(Key.T, none, false, 0, 0);
            c.HandleKeyDown(Key.T, none, false, 0, 0);
            string afterTwo = c.TrailsModeName;
            c.HandleKeyDown(Key.T, none, false, 0, 0);
            Expect(problems, afterTwo == "relative" && c.TrailsModeName == "off", "T cycles off, true, relative, off: " + afterTwo + ", then " + c.TrailsModeName);
            int trailMessages = 0;
            foreach (Dictionary<string, object> message in sent)
            {
                if ((string)message["t"] == "set" && (string)message["path"] == DisplayController.TrailsModePath)
                {
                    trailMessages++;
                }
            }
            Expect(problems, trailMessages == 3, trailMessages + " trails_mode messages, expected 3");

            bool trailsChanged = false;
            c.TrailsChanged += delegate { trailsChanged = true; };
            c.SetTrailTimeMin(10.0);
            Expect(problems, c.TrailTimeMin == 12.0 && SetValues(sent, DisplayController.TrailTimePath).Count == 1
                   && SetValues(sent, DisplayController.TrailTimePath)[0] == 12.0 && trailsChanged, "a trail time of 10 MIN snaps to 12 MIN: " + c.TrailTimeMin);

            c.SetStabilisation("ground");
            Expect(problems, LastWord(sent, DisplayController.StabilisationPath) == "ground" && c.Words[DisplayController.StabilisationPath] == "ground", "SetStabilisation sends set arpa.stabilization ground");
            ReportProblems("M7 7 motion and orientation", problems, "M switches head-up to north-up with a line, another orientation switches back to relative motion with a line; T cycles trails; hello defaults read; 10 MIN snaps to 12");
        }

        // ---- M9 tests begin (the harness extracts everything up to the end marker) ----

        private static string M9Json(double? value)
        {
            return value.HasValue ? value.Value.ToString("R", CultureInfo.InvariantCulture) : "null";
        }

        // One synthetic target for a "targets" message. Range and bearing follow from X and Y with own ship at the message's reference position.
        private class M9T
        {
            public int Id = 1;
            public string State = "TRACK";
            public double X;
            public double Y;
            public double? Course = null, Speed = null, RelCourse = null, RelSpeed = null, Cpa = null, Tcpa = null,
                Bcr = null, Bct = null, TrialCpa = null, TrialTcpa = null;
            public string History = "[]";
        }

        private static JsonElement M9Targets(double refX, double refY, params M9T[] targets)
        {
            StringBuilder json = new StringBuilder();
            json.Append("{\"t\":\"targets\",\"sim_time_s\":300.0,\"ref_x_nm\":" + M9Json(refX) + ",\"ref_y_nm\":" + M9Json(refY) + ",\"targets\":[");
            for (int i = 0; i < targets.Length; i++)
            {
                M9T t = targets[i];
                double dx = t.X - refX;
                double dy = t.Y - refY;
                double range = Math.Sqrt(dx * dx + dy * dy);
                double bearing = PpiGeometry.Normalise360(Math.Atan2(dx, dy) * 180.0 / Math.PI);
                if (i > 0)
                {
                    json.Append(",");
                }
                json.Append("{\"id\":" + t.Id + ",\"state\":\"" + t.State + "\",\"x_nm\":" + M9Json(t.X) + ",\"y_nm\":" + M9Json(t.Y)
                    + ",\"range_nm\":" + M9Json(range) + ",\"bearing_deg_true\":" + M9Json(bearing)
                    + ",\"course_deg_true\":" + M9Json(t.Course) + ",\"speed_kn\":" + M9Json(t.Speed)
                    + ",\"rel_course_deg_true\":" + M9Json(t.RelCourse) + ",\"rel_speed_kn\":" + M9Json(t.RelSpeed)
                    + ",\"cpa_nm\":" + M9Json(t.Cpa) + ",\"tcpa_min\":" + M9Json(t.Tcpa)
                    + ",\"bcr_nm\":" + M9Json(t.Bcr) + ",\"bct_min\":" + M9Json(t.Bct)
                    + ",\"trial_cpa_nm\":" + M9Json(t.TrialCpa) + ",\"trial_tcpa_min\":" + M9Json(t.TrialTcpa)
                    + ",\"history\":" + t.History + "}");
            }
            json.Append("]}");
            return JsonDocument.Parse(json.ToString()).RootElement;
        }

        private static JsonElement M9Alarms(string alarmsJson)
        {
            return JsonDocument.Parse("{\"t\":\"alarms\",\"alarms\":" + alarmsJson + "}").RootElement;
        }

        private static JsonElement M9Hello()
        {
            string json = """
            {"t":"hello","protocol":1,
             "radar":{"range_scales_nm":[0.25,0.5,0.75,1.5,3.0,6.0,12.0,24.0],"offset_max_fraction":0.66,"azimuth_bins":2048,"antenna_rpm":24.0},
             "display":{"range_ring_interval_nm":[0.05,0.1,0.25,0.25,0.5,1.0,2.0,4.0],"orientation":"north_up","color_mode":"mono_green",
                        "control_style":"knob","offset_enabled":false,"offset_x_fraction":0.0,"offset_y_fraction":0.0,"range_scale_nm":6.0,
                        "motion_mode":"relative","trails_mode":"off","trail_time_min":6.0,"trail_video_threshold":60,
                        "true_motion_reset_fraction":0.875},
             "controls":[
              {"path":"general.sim_speed_multiplier","unit":"x","value":1.0,"min":1.0,"max":10.0,"step":1.0},
              {"path":"radar.video_range_nm","unit":"NM","value":10.0,"min":0.1,"max":48.0,"step":0.01},
              {"path":"display.range_scale_nm","unit":"NM","value":6.0,"choices":[0.25,0.5,0.75,1.5,3.0,6.0,12.0,24.0]},
              {"path":"display.orientation","unit":"","value":"north_up","choices":["north_up","head_up","course_up"]},
              {"path":"display.motion_mode","unit":"","value":"relative","choices":["relative","true"]},
              {"path":"arpa.stabilization","unit":"","value":"sea","choices":["sea","ground"]},
              {"path":"display.vector_mode","unit":"","value":"true","choices":["true","relative"]},
              {"path":"display.vector_time_min","unit":"MIN","value":6.0,"choices":[0.5,1.0,3.0,6.0,12.0,15.0,30.0,60.0]},
              {"path":"display.history_dots","unit":"","value":true,"choices":[false,true]},
              {"path":"arpa.cpa_limit_nm","unit":"NM","value":1.0,"min":0.0,"max":10.0,"step":0.1},
              {"path":"arpa.tcpa_limit_min","unit":"MIN","value":12.0,"min":1.0,"max":60.0,"step":1.0},
              {"path":"arpa.alarm_sound","unit":"","value":true,"choices":[false,true]},
              {"path":"arpa.guard_zone_reference","unit":"","value":"relative","choices":["relative","true"]}
             ]}
            """;
            return JsonDocument.Parse(json).RootElement;
        }

        private static DisplayController M9Controller(List<Dictionary<string, object>> sent)
        {
            DisplayController controller = new DisplayController(sent.Add);
            controller.ApplyHello(M9Hello());
            controller.Geometry.SizePx = 1000;          // radius 500 px, so 6 NM = 500 px and 3 NM = 250 px as in the brief
            controller.ApplyGeometry(true, false);
            return controller;
        }

        // A 1000 px PPI at 6 NM. The centre is (500, 500) and 1 NM is 83.33 px.
        private static PpiGeometry M9Geometry(PpiOrientation orientation, double headingDegTrue, double offsetYFraction)
        {
            PpiGeometry geometry = new PpiGeometry();
            geometry.SizePx = 1000;
            geometry.RangeScaleNm = 6.0;
            geometry.Orientation = orientation;
            geometry.HeadingDegTrue = headingDegTrue;
            geometry.LatchedCourseDegTrue = 100.0;
            geometry.OffsetYFraction = offsetYFraction;
            return geometry;
        }

        private static List<Dictionary<string, object>> M9Messages(List<Dictionary<string, object>> sent, string name)
        {
            List<Dictionary<string, object>> found = new List<Dictionary<string, object>>();
            foreach (Dictionary<string, object> message in sent)
            {
                if ((string)message["t"] == name)
                {
                    found.Add(message);
                }
            }
            return found;
        }

        // The screen angle (deg clockwise from the top) of the line from one point to another.
        private static double M9ScreenAngle(double fromX, double fromY, double toX, double toY)
        {
            return PpiGeometry.Normalise360(Math.Atan2(toX - fromX, fromY - toY) * 180.0 / Math.PI);
        }

        // M9 test 1: where a box is, in every orientation, with an offset, and in true motion.
        private static void TestM9Positions()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M9Controller(sent);
            c.Arpa.SetTargets(M9Targets(0.0, 0.0, new M9T { X = 3.0, Y = 0.0 }));        // 3 NM, 090 deg T

            PpiGeometry north = M9Geometry(PpiOrientation.NorthUp, 0.0, 0.0);
            TargetShape box = c.Arpa.Layout(north)[0];
            Expect(problems, Near(box.BoxXPx, 750.0, 1.0) && Near(box.BoxYPx, 500.0, 1.0), "north-up: box at (" + Number(box.BoxXPx, "0.0") + ", " + Number(box.BoxYPx, "0.0") + "), expected (750, 500)");

            PpiGeometry head = M9Geometry(PpiOrientation.HeadUp, 90.0, 0.0);
            box = c.Arpa.Layout(head)[0];
            Expect(problems, Near(box.BoxXPx, 500.0, 1.0) && Near(box.BoxYPx, 250.0, 1.0), "head-up 090: box at (" + Number(box.BoxXPx, "0.0") + ", " + Number(box.BoxYPx, "0.0") + "), expected straight up (500, 250)");

            PpiGeometry offset = M9Geometry(PpiOrientation.NorthUp, 0.0, -0.5);
            box = c.Arpa.Layout(offset)[0];
            double wantX, wantY;
            offset.PixelOf(3.0, 90.0, out wantX, out wantY);                              // the M5 geometry
            Expect(problems, Near(box.BoxXPx, wantX, 1.0) && Near(box.BoxYPx, wantY, 1.0) && Near(box.BoxYPx, 750.0, 1.0),
                "offset (0, -0.5): box at (" + Number(box.BoxXPx, "0.0") + ", " + Number(box.BoxYPx, "0.0") + "), PixelOf gives (" + Number(wantX, "0.0") + ", " + Number(wantY, "0.0") + ")");

            PpiGeometry course = M9Geometry(PpiOrientation.CourseUp, 0.0, 0.0);           // latched course 100
            box = c.Arpa.Layout(course)[0];
            course.PixelOf(3.0, 90.0, out wantX, out wantY);
            Expect(problems, Near(box.BoxXPx, wantX, 1.0) && Near(box.BoxYPx, wantY, 1.0), "course-up: box at (" + Number(box.BoxXPx, "0.0") + ", " + Number(box.BoxYPx, "0.0") + "), PixelOf gives (" + Number(wantX, "0.0") + ", " + Number(wantY, "0.0") + ")");

            // A message whose reference position is not the origin: the same displacement gives the same box.
            c.Arpa.SetTargets(M9Targets(10.0, 20.0, new M9T { X = 13.0, Y = 20.0 }));
            box = c.Arpa.Layout(north)[0];
            Expect(problems, Near(box.BoxXPx, 750.0, 1.0) && Near(box.BoxYPx, 500.0, 1.0), "reference (10, 20): box at (" + Number(box.BoxXPx, "0.0") + ", " + Number(box.BoxYPx, "0.0") + ")");

            // True motion: the box is fixed in the picture while own ship moves.
            PpiGeometry truth = M9Geometry(PpiOrientation.NorthUp, 0.0, 0.0);
            truth.TrueMotion = true;
            truth.ViewOriginXNm = 10.0;
            truth.ViewOriginYNm = 20.0;
            box = c.Arpa.Layout(truth)[0];
            Expect(problems, Near(box.BoxXPx, 750.0, 1.0) && Near(box.BoxYPx, 500.0, 1.0), "true motion: box at (" + Number(box.BoxXPx, "0.0") + ", " + Number(box.BoxYPx, "0.0") + ")");
            c.Arpa.SetTargets(M9Targets(10.0, 20.1, new M9T { X = 13.0, Y = 20.0 }));      // own ship 0.1 NM further north, the target where it was
            box = c.Arpa.Layout(truth)[0];
            Expect(problems, Near(box.BoxXPx, 750.0, 1.0) && Near(box.BoxYPx, 500.0, 1.0), "true motion, own ship moved: box at (" + Number(box.BoxXPx, "0.0") + ", " + Number(box.BoxYPx, "0.0") + ") should not move");
            ReportProblems("M9 1 box positions", problems, "3 NM 090: (750, 500) north-up, straight up in head-up 090, offset (0, -0.5) as PixelOf, course-up, reference shift, true motion fixed (1000 px bitmap, 83.3 px/NM)");
        }

        // M9 test 2: vector length and direction; true and relative.
        private static void TestM9Vectors()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M9Controller(sent);
            c.Arpa.SetTargets(M9Targets(0.0, 0.0, new M9T { X = 3.0, Y = 0.0, Course = 45.0, Speed = 12.0, RelCourse = 200.0, RelSpeed = 8.0 }));

            PpiOrientation[] orientations = { PpiOrientation.NorthUp, PpiOrientation.HeadUp, PpiOrientation.CourseUp };
            string[] names = { "north-up", "head-up", "course-up" };
            for (int i = 0; i < 3; i++)
            {
                PpiGeometry g = M9Geometry(orientations[i], 30.0, 0.0);                   // heading 030, latched course 100
                TargetShape shape = c.Arpa.Layout(g)[0];
                double length = Math.Sqrt(Math.Pow(shape.VectorEndXPx - shape.BoxXPx, 2) + Math.Pow(shape.VectorEndYPx - shape.BoxYPx, 2));
                double angle = M9ScreenAngle(shape.BoxXPx, shape.BoxYPx, shape.VectorEndXPx, shape.VectorEndYPx);
                double wantAngle = PpiGeometry.Normalise360(45.0 - g.TopBearingDegTrue);
                Expect(problems, shape.HasVector && Near(length, 100.0, 1.0), names[i] + ": true vector " + Number(length, "0.0") + " px, expected 100 (12 KN x 6 MIN = 1.2 NM)");
                Expect(problems, AngleError(angle, wantAngle) < 0.5, names[i] + ": true vector points " + Number(angle, "0.0") + " deg on the screen, expected " + Number(wantAngle, "0.0"));
            }

            c.Arpa.SetVectorMode(false);
            Expect(problems, LastWord(sent, ArpaController.VectorModePath) == "relative", "V sends set display.vector_mode relative");
            for (int i = 0; i < 3; i++)
            {
                PpiGeometry g = M9Geometry(orientations[i], 30.0, 0.0);
                TargetShape shape = c.Arpa.Layout(g)[0];
                double length = Math.Sqrt(Math.Pow(shape.VectorEndXPx - shape.BoxXPx, 2) + Math.Pow(shape.VectorEndYPx - shape.BoxYPx, 2));
                double angle = M9ScreenAngle(shape.BoxXPx, shape.BoxYPx, shape.VectorEndXPx, shape.VectorEndYPx);
                double wantAngle = PpiGeometry.Normalise360(200.0 - g.TopBearingDegTrue);
                Expect(problems, Near(length, 66.67, 1.0), names[i] + ": relative vector " + Number(length, "0.0") + " px, expected 66.7 (8 KN x 6 MIN = 0.8 NM)");
                Expect(problems, AngleError(angle, wantAngle) < 0.5, names[i] + ": relative vector points " + Number(angle, "0.0") + ", expected " + Number(wantAngle, "0.0"));
            }
            c.Arpa.SetVectorMode(true);
            c.Arpa.SetVectorTimeMin(12.0);
            TargetShape twelve = c.Arpa.Layout(M9Geometry(PpiOrientation.NorthUp, 0.0, 0.0))[0];
            Expect(problems, Near(Math.Sqrt(Math.Pow(twelve.VectorEndXPx - twelve.BoxXPx, 2) + Math.Pow(twelve.VectorEndYPx - twelve.BoxYPx, 2)), 200.0, 1.0), "12 MIN doubles the vector to 200 px");
            ReportProblems("M9 2 vectors", problems, "12 KN, 6 MIN = 100 px along the true course in all three orientations; relative vector 66.7 px along the relative course; 12 MIN gives 200 px");
        }

        // M9 test 3: ACQ, TREND, TRACK, LOST; selection; flashing until acknowledged.
        private static void TestM9States()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M9Controller(sent);
            c.Arpa.SetTargets(M9Targets(0.0, 0.0,
                new M9T { Id = 1, State = "ACQ", X = 1.0, Y = 1.0 },
                new M9T { Id = 2, State = "TREND", X = 2.0, Y = 1.0, Course = 90.0, Speed = 10.0, RelCourse = 90.0, RelSpeed = 10.0 },
                new M9T { Id = 3, State = "TRACK", X = 3.0, Y = 1.0, Course = 90.0, Speed = 10.0, RelCourse = 90.0, RelSpeed = 10.0 },
                new M9T { Id = 5, State = "LOST", X = 4.0, Y = 1.0, Course = 90.0, Speed = 10.0, RelCourse = 90.0, RelSpeed = 10.0 }));
            c.Arpa.SetAlarms(M9Alarms("[{\"id\":1,\"kind\":\"LOST_TARGET\",\"target_id\":5,\"zone_index\":null,\"range_nm\":4.1,\"bearing_deg_true\":76.0,\"acknowledged\":false,\"active\":true}]"));
            c.Arpa.SelectedId = 3;
            PpiGeometry g = M9Geometry(PpiOrientation.NorthUp, 0.0, 0.0);
            List<TargetShape> shapes = c.Arpa.Layout(g);
            Expect(problems, shapes.Count == 4, shapes.Count + " shapes, expected 4");
            Expect(problems, !shapes[0].HasVector && shapes[0].Label == "" && !shapes[0].Crossed, "ACQ: no vector, no ID, not crossed");
            Expect(problems, shapes[1].HasVector && shapes[1].VectorDashed && shapes[1].Label == "2", "TREND: dashed vector with its ID");
            Expect(problems, shapes[2].HasVector && !shapes[2].VectorDashed && shapes[2].Label == "3" && shapes[2].Selected, "TRACK: solid vector, ID, selected");
            Expect(problems, !shapes[1].Selected && !shapes[0].Selected, "only the selected target is selected");
            Expect(problems, shapes[3].Crossed && shapes[3].Flashing && !shapes[3].HasVector, "LOST: crossed, flashing, no vector");
            sent.Clear();
            c.HandleKeyDown(Key.Space, ModifierKeys.None, false, 0, 0);
            shapes = c.Arpa.Layout(g);
            Expect(problems, M9Messages(sent, "ack_alarm").Count == 1, "Space sends ack_alarm");
            Expect(problems, shapes[3].Crossed && !shapes[3].Flashing, "after the acknowledgement the LOST box is crossed and steady");
            ReportProblems("M9 3 states", problems, "ACQ no vector, TREND dashed, TRACK solid, LOST crossed and flashing until ack_alarm is sent");
        }

        // M9 test 4: history dots.
        private static void TestM9History()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M9Controller(sent);
            string history = "[[60.0,1.0,2.0,0.0,0.0],[120.0,1.1,2.0,0.0,0.1],[180.0,1.2,2.0,0.0,0.2],[240.0,1.3,2.0,0.0,0.3],[300.0,1.4,2.0,0.0,0.4]]";
            c.Arpa.SetTargets(M9Targets(0.0, 0.5, new M9T { X = 1.5, Y = 2.0, Course = 90.0, Speed = 6.0, RelCourse = 90.0, RelSpeed = 6.0, History = history }));
            PpiGeometry g = M9Geometry(PpiOrientation.NorthUp, 0.0, 0.0);
            double pxPerNm = 500.0 / 6.0;                                                 // 83.33 px per NM

            // True vector mode: the true past positions, drawn from own ship's position now (0, 0.5).
            TargetShape shape = c.Arpa.Layout(g)[0];
            Expect(problems, shape.HistoryPx.Count == 5, shape.HistoryPx.Count + " dots in true mode, expected 5");
            double[] trueEast = { 1.0, 1.1, 1.2, 1.3, 1.4 };
            for (int i = 0; i < shape.HistoryPx.Count && i < 5; i++)
            {
                double wantX = 500.0 + trueEast[i] * pxPerNm;
                double wantY = 500.0 - (2.0 - 0.5) * pxPerNm;
                Expect(problems, Near(shape.HistoryPx[i].X, wantX, 0.5) && Near(shape.HistoryPx[i].Y, wantY, 0.5),
                    "true dot " + i + " at (" + Number(shape.HistoryPx[i].X, "0.0") + ", " + Number(shape.HistoryPx[i].Y, "0.0") + "), expected (" + Number(wantX, "0.0") + ", " + Number(wantY, "0.0") + ")");
            }

            // Relative vector mode: where the target was relative to own ship at the time.
            c.Arpa.SetVectorMode(false);
            shape = c.Arpa.Layout(g)[0];
            double[] relNorth = { 2.0, 1.9, 1.8, 1.7, 1.6 };
            Expect(problems, shape.HistoryPx.Count == 5, shape.HistoryPx.Count + " dots in relative mode, expected 5");
            for (int i = 0; i < shape.HistoryPx.Count && i < 5; i++)
            {
                double wantX = 500.0 + trueEast[i] * pxPerNm;
                double wantY = 500.0 - relNorth[i] * pxPerNm;
                Expect(problems, Near(shape.HistoryPx[i].X, wantX, 0.5) && Near(shape.HistoryPx[i].Y, wantY, 0.5),
                    "relative dot " + i + " at (" + Number(shape.HistoryPx[i].X, "0.0") + ", " + Number(shape.HistoryPx[i].Y, "0.0") + "), expected (" + Number(wantX, "0.0") + ", " + Number(wantY, "0.0") + ")");
            }

            c.Arpa.SetHistory(false);
            Expect(problems, c.Arpa.Layout(g)[0].HistoryPx.Count == 0, "history dots off: none");
            Expect(problems, M9Messages(sent, "set").Count > 0 && !c.Arpa.HistoryOn, "history off is sent and kept");
            ReportProblems("M9 4 history dots", problems, "5 dots at the true past positions (true mode) and at the positions relative to own ship then (relative mode); none when off");
        }

        // M9 test 5: hit test.
        private static void TestM9HitTest()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M9Controller(sent);
            PpiGeometry g = M9Geometry(PpiOrientation.NorthUp, 0.0, 0.0);
            c.Arpa.SetTargets(M9Targets(0.0, 0.0, new M9T { Id = 7, X = 3.0, Y = 0.0 }));        // box at (750, 500)
            bool hit = c.Arpa.SelectAtPixel(g, 757.9, 500.0, 8.0);
            Expect(problems, hit && c.Arpa.SelectedId == 7, "7.9 px away: selected " + c.Arpa.SelectedId);
            hit = c.Arpa.SelectAtPixel(g, 759.0, 500.0, 8.0);
            Expect(problems, !hit && c.Arpa.SelectedId == -1, "9 px away: selected " + c.Arpa.SelectedId + " (a click on empty screen deselects)");
            c.Arpa.SetTargets(M9Targets(0.0, 0.0, new M9T { Id = 7, X = 3.0, Y = 0.0 }, new M9T { Id = 8, X = 3.05, Y = 0.0 }));   // 4.2 px apart
            hit = c.Arpa.SelectAtPixel(g, 757.0, 500.0, 8.0);                             // 7.0 px from 7 and 2.8 px from 8
            Expect(problems, hit && c.Arpa.SelectedId == 8, "two boxes in reach: chose " + c.Arpa.SelectedId + ", the nearer is 8");
            hit = c.Arpa.SelectAtPixel(g, 749.0, 500.0, 8.0);                             // 1.0 px from 7
            Expect(problems, hit && c.Arpa.SelectedId == 7, "pointer next to 7: chose " + c.Arpa.SelectedId);
            c.Arpa.SetTargets(M9Targets(0.0, 0.0, new M9T { Id = 8, X = 3.05, Y = 0.0 }));
            c.Arpa.SelectedId = 7;
            c.Arpa.SetTargets(M9Targets(0.0, 0.0, new M9T { Id = 8, X = 3.05, Y = 0.0 }));
            Expect(problems, c.Arpa.SelectedId == -1, "the selected target is gone from the message: deselected");
            ReportProblems("M9 5 hit test", problems, "7.9 px selects, 9 px does not and deselects, of two boxes within 8 px the nearer");
        }

        // M9 test 6: A, Delete, Ctrl+Delete, V, [ and ].
        private static void TestM9Keys()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M9Controller(sent);
            sent.Clear();
            ModifierKeys none = ModifierKeys.None;

            // A: pointer at pixel (300, 200), 6 NM scale, 1000 px bitmap, no offset.
            double wantRange = Math.Sqrt(200.0 * 200.0 + 300.0 * 300.0) * 6.0 / 500.0;
            double wantBearing = PpiGeometry.Normalise360(Math.Atan2(-200.0, 300.0) * 180.0 / Math.PI);
            c.HandleKeyDown(Key.A, none, true, 300.0, 200.0);
            List<Dictionary<string, object>> acquires = M9Messages(sent, "acquire");
            Expect(problems, acquires.Count == 1, acquires.Count + " acquire messages, expected 1");
            if (acquires.Count == 1)
            {
                double range = (double)acquires[0]["range_nm"];
                double bearing = (double)acquires[0]["bearing_deg_true"];
                Expect(problems, Near(range, wantRange, 0.01) && AngleError(bearing, wantBearing) < 0.1,
                    "acquire at " + Number(range, "0.000") + " NM " + Number(bearing, "0.00") + " deg T, expected " + Number(wantRange, "0.000") + " NM " + Number(wantBearing, "0.00"));
            }
            sent.Clear();
            c.HandleKeyDown(Key.A, none, false, 300.0, 200.0);
            Expect(problems, sent.Count == 0, "A with the pointer off the picture sends nothing");

            // A in head-up with heading 045: the same pixel is 45 deg further round in true bearing.
            c.Geometry.HeadingDegTrue = 45.0;
            c.SetOrientation("head_up");
            sent.Clear();
            c.HandleKeyDown(Key.A, none, true, 300.0, 200.0);
            acquires = M9Messages(sent, "acquire");
            double wantHeadUp = PpiGeometry.Normalise360(wantBearing + 45.0);
            Expect(problems, acquires.Count == 1 && AngleError((double)acquires[0]["bearing_deg_true"], wantHeadUp) < 0.1,
                "head-up 045: bearing " + (acquires.Count == 1 ? Number((double)acquires[0]["bearing_deg_true"], "0.00") : "none") + ", expected " + Number(wantHeadUp, "0.00"));
            c.SetOrientation("north_up");

            // Delete and Ctrl+Delete.
            sent.Clear();
            c.HandleKeyDown(Key.Delete, none, false, 0, 0);
            Expect(problems, sent.Count == 0, "Delete with nothing selected sends nothing");
            c.Arpa.SetTargets(M9Targets(0.0, 0.0, new M9T { Id = 4, X = 3.0, Y = 0.0 }));
            c.Arpa.SelectAtPixel(M9Geometry(PpiOrientation.NorthUp, 0.0, 0.0), 750.0, 500.0, 8.0);
            c.HandleKeyDown(Key.Delete, none, false, 0, 0);
            List<Dictionary<string, object>> cancels = M9Messages(sent, "cancel_target");
            Expect(problems, cancels.Count == 1 && (int)cancels[0]["id"] == 4, "Delete sends cancel_target for the selected ID 4");
            c.HandleKeyDown(Key.Delete, ModifierKeys.Control, false, 0, 0);
            Expect(problems, M9Messages(sent, "cancel_all_targets").Count == 1, "Ctrl+Delete sends cancel_all_targets");

            // V, [ and ].
            sent.Clear();
            c.HandleKeyDown(Key.V, none, false, 0, 0);
            Expect(problems, LastWord(sent, ArpaController.VectorModePath) == "relative" && !c.Arpa.VectorTrue, "V: relative vectors");
            c.HandleKeyDown(Key.V, none, false, 0, 0);
            Expect(problems, LastWord(sent, ArpaController.VectorModePath) == "true" && c.Arpa.VectorTrue, "V again: true vectors");
            c.HandleKeyDown(Key.OemCloseBrackets, none, false, 0, 0);
            Expect(problems, c.Arpa.VectorTimeMin == 12.0, "]: vector time " + c.Arpa.VectorTimeMin + ", expected 12");
            c.HandleKeyDown(Key.OemOpenBrackets, none, false, 0, 0);
            c.HandleKeyDown(Key.OemOpenBrackets, none, false, 0, 0);
            c.HandleKeyDown(Key.OemOpenBrackets, none, false, 0, 0);
            c.HandleKeyDown(Key.OemOpenBrackets, none, false, 0, 0);
            Expect(problems, c.Arpa.VectorTimeMin == 0.5, "[ four times from 12: " + c.Arpa.VectorTimeMin + ", expected 0.5");
            int before = SetValues(sent, ArpaController.VectorTimePath).Count;
            c.HandleKeyDown(Key.OemOpenBrackets, none, false, 0, 0);
            Expect(problems, SetValues(sent, ArpaController.VectorTimePath).Count == before && c.Arpa.VectorTimeMin == 0.5, "[ at 0.5 MIN sends nothing");

            // The table: from M10 on every binding has a function.
            int withoutAction = 0;
            foreach (HotkeyRow row in HotkeyTable.Rows)
            {
                foreach (HotkeyBinding binding in row.Bindings)
                {
                    if (binding.Action == null)
                    {
                        withoutAction++;
                    }
                }
            }
            Expect(problems, withoutAction == 0, withoutAction + " bindings without a function, expected 0");
            ReportProblems("M9 6 keys", problems, "A sends range and bearing within 0.01 NM and 0.1 deg (north-up and head-up), Delete and Ctrl+Delete, V, [ and ]");
        }

        // M9 test 7: the alarm list, Space, the sound.
        private static void TestM9Alarms()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M9Controller(sent);
            string three = "[{\"id\":3,\"kind\":\"GUARD_ZONE\",\"target_id\":null,\"zone_index\":1,\"range_nm\":2.0,\"bearing_deg_true\":10.0,\"acknowledged\":false,\"active\":true},"
                + "{\"id\":1,\"kind\":\"CPA_TCPA\",\"target_id\":4,\"zone_index\":null,\"range_nm\":5.0,\"bearing_deg_true\":180.0,\"acknowledged\":false,\"active\":true},"
                + "{\"id\":2,\"kind\":\"LOST_TARGET\",\"target_id\":5,\"zone_index\":null,\"range_nm\":3.0,\"bearing_deg_true\":90.0,\"acknowledged\":true,\"active\":true}]";
            c.Arpa.SetAlarms(M9Alarms(three));
            string[] want = { "CPA/TCPA 4", "LOST TARGET 5", "GUARD ZONE 1" };
            Expect(problems, c.Arpa.Alarms.Count == 3, c.Arpa.Alarms.Count + " alarms, expected 3");
            for (int i = 0; i < c.Arpa.Alarms.Count && i < 3; i++)
            {
                Expect(problems, c.Arpa.Alarms[i].Text == want[i], "alarm " + i + " reads '" + c.Arpa.Alarms[i].Text + "', expected '" + want[i] + "' (time order)");
            }
            AlarmItem capacity = new AlarmItem();
            capacity.Kind = "CAPACITY";
            Expect(problems, capacity.Text == "TARGET CAPACITY", "capacity alarm reads '" + capacity.Text + "'");
            Expect(problems, c.Arpa.SoundWanted, "the sound is wanted while an alarm is unacknowledged");
            sent.Clear();
            c.HandleKeyDown(Key.Space, ModifierKeys.None, false, 0, 0);
            List<Dictionary<string, object>> acks = M9Messages(sent, "ack_alarm");
            Expect(problems, acks.Count == 1 && (acks[0]["id"] as string) == "all", "Space sends ack_alarm with id all");
            Expect(problems, !c.Arpa.AnyUnacknowledged && !c.Arpa.SoundWanted, "after Space nothing is unacknowledged and the sound stops");

            // alarm_sound false: no sound for a new alarm.
            c.ConfirmSetting(ArpaController.AlarmSoundPath, JsonDocument.Parse("false").RootElement);
            c.Arpa.SetAlarms(M9Alarms(three));
            Expect(problems, c.Arpa.AnyUnacknowledged && !c.Arpa.SoundWanted, "alarm_sound false: unacknowledged alarm, no sound");
            c.ConfirmSetting(ArpaController.AlarmSoundPath, JsonDocument.Parse("true").RootElement);
            Expect(problems, c.Arpa.SoundWanted, "alarm_sound true again: sound wanted");

#if !HARNESS
            // The panel's timer runs only while the sound is wanted.
            AlarmPanel panel = new AlarmPanel();
            panel.Attach(c);
            Expect(problems, panel.SoundTimerRunning, "panel: the sound timer runs with an unacknowledged alarm");
            c.Arpa.AcknowledgeAll();
            Expect(problems, !panel.SoundTimerRunning, "panel: the sound timer stops after the acknowledgement");
            c.ConfirmSetting(ArpaController.AlarmSoundPath, JsonDocument.Parse("false").RootElement);
            c.Arpa.SetAlarms(M9Alarms(three));
            Expect(problems, !panel.SoundTimerRunning, "panel: no timer with alarm_sound false");
            c.ConfirmSetting(ArpaController.AlarmSoundPath, JsonDocument.Parse("true").RootElement);
            Expect(problems, panel.SoundTimerRunning, "panel: the timer starts when alarm_sound is turned on again");
            c.Arpa.AcknowledgeAll();
            Expect(problems, !panel.SoundTimerRunning, "panel: stopped again");
#endif
            ReportProblems("M9 7 alarm list", problems, "three alarms in time order with the right text; Space acknowledges all; the sound runs only while an alarm is unacknowledged and alarm_sound is true");
        }

        // M9 test 8: guard zones.
        private static void TestM9GuardZones()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M9Controller(sent);
            sent.Clear();
            c.Arpa.SetGuardZone(1, true, 1.0, 3.0, 0.0, 90.0);
            List<Dictionary<string, object>> zones = M9Messages(sent, "guard_zone");
            Expect(problems, zones.Count == 1, zones.Count + " guard_zone messages, expected 1");
            if (zones.Count == 1)
            {
                Dictionary<string, object> m = zones[0];
                Expect(problems, (int)m["index"] == 1 && (bool)m["enabled"] && (double)m["inner_nm"] == 1.0 && (double)m["outer_nm"] == 3.0
                    && (double)m["start_deg"] == 0.0 && (double)m["end_deg"] == 90.0, "guard_zone carries the typed values");
            }
            Expect(problems, c.Arpa.ZoneShapes(M9Geometry(PpiOrientation.NorthUp, 0.0, 0.0)).Count == 1, "only the zone that is on is drawn");

            // Relative to the bow, heading 000, north-up: 0 to 90 deg R is 0 to 90 deg T. 1 NM = 83.33 px.
            PpiGeometry g = M9Geometry(PpiOrientation.NorthUp, 0.0, 0.0);
            GuardZoneShape shape = c.Arpa.ZoneShapes(g)[0];
            Expect(problems, Near(shape.StartInner.X, 500.0, 1.0) && Near(shape.StartInner.Y, 416.67, 1.0) && Near(shape.StartOuter.X, 500.0, 1.0) && Near(shape.StartOuter.Y, 250.0, 1.0),
                "start edge from (" + Number(shape.StartInner.X, "0.0") + ", " + Number(shape.StartInner.Y, "0.0") + ") to (" + Number(shape.StartOuter.X, "0.0") + ", " + Number(shape.StartOuter.Y, "0.0") + "), expected (500, 416.7) to (500, 250)");
            Expect(problems, Near(shape.EndInner.X, 583.33, 1.0) && Near(shape.EndInner.Y, 500.0, 1.0) && Near(shape.EndOuter.X, 750.0, 1.0) && Near(shape.EndOuter.Y, 500.0, 1.0),
                "end edge from (" + Number(shape.EndInner.X, "0.0") + ", " + Number(shape.EndInner.Y, "0.0") + ") to (" + Number(shape.EndOuter.X, "0.0") + ", " + Number(shape.EndOuter.Y, "0.0") + "), expected (583.3, 500) to (750, 500)");
            Expect(problems, Near(shape.SweepDeg, 90.0, 1e-6), "sweep " + shape.SweepDeg + " deg, expected 90");

            // Relative reference with heading 090: the zone turns with the bow, so its start edge points east.
            g = M9Geometry(PpiOrientation.NorthUp, 90.0, 0.0);
            shape = c.Arpa.ZoneShapes(g)[0];
            Expect(problems, Near(shape.StartOuter.X, 750.0, 1.0) && Near(shape.StartOuter.Y, 500.0, 1.0) && Near(shape.EndOuter.X, 500.0, 1.0) && Near(shape.EndOuter.Y, 750.0, 1.0),
                "relative zone, heading 090: edges at (" + Number(shape.StartOuter.X, "0.0") + ", " + Number(shape.StartOuter.Y, "0.0") + ") and (" + Number(shape.EndOuter.X, "0.0") + ", " + Number(shape.EndOuter.Y, "0.0") + "), expected (750, 500) and (500, 750)");

            // True reference: the heading does not matter.
            c.ConfirmSetting(ArpaController.GuardReferencePath, JsonDocument.Parse("\"true\"").RootElement);
            shape = c.Arpa.ZoneShapes(g)[0];
            Expect(problems, Near(shape.StartOuter.X, 500.0, 1.0) && Near(shape.StartOuter.Y, 250.0, 1.0), "true zone, heading 090: start edge at (" + Number(shape.StartOuter.X, "0.0") + ", " + Number(shape.StartOuter.Y, "0.0") + "), expected (500, 250)");

            // Head-up, true reference, heading 090: a zone at 090 true is straight up.
            c.Arpa.SetGuardZone(1, true, 1.0, 3.0, 90.0, 180.0);
            shape = c.Arpa.ZoneShapes(M9Geometry(PpiOrientation.HeadUp, 90.0, 0.0))[0];
            Expect(problems, Near(shape.StartOuter.X, 500.0, 1.0) && Near(shape.StartOuter.Y, 250.0, 1.0), "head-up: a zone starting at 090 T is straight up");

            // Equal bearings give a full ring; off draws nothing; typed numbers.
            c.Arpa.SetGuardZone(1, true, 1.0, 3.0, 0.0, 0.0);
            Expect(problems, Near(c.Arpa.ZoneShapes(g)[0].SweepDeg, 360.0, 1e-6), "equal bearings: a full ring");
            c.Arpa.SetGuardZone(1, false, 1.0, 3.0, 0.0, 0.0);
            Expect(problems, c.Arpa.ZoneShapes(g).Count == 0, "zone off: not drawn");
            double typed;
            Expect(problems, ArpaController.TryParseNumber(" 1,5 ", out typed) && typed == 1.5 && !ArpaController.TryParseNumber("x", out typed), "typed numbers: '1,5' is 1.5, 'x' is refused");
            ReportProblems("M9 8 guard zones", problems, "guard_zone carries the typed values; the sector's four corner points are at the right pixels for relative and true reference, north-up and head-up");
        }

        // M9 test 9: trial and the readout.
        private static void TestM9TrialReadout()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M9Controller(sent);
            sent.Clear();
            c.Arpa.SetTrial(true, 45.0, 8.0, 30.0);
            List<Dictionary<string, object>> trials = M9Messages(sent, "trial");
            Expect(problems, trials.Count == 1 && (bool)trials[0]["enabled"] && (double)trials[0]["course_deg_true"] == 45.0
                && (double)trials[0]["speed_kn"] == 8.0 && (double)trials[0]["delay_s"] == 30.0, "trial sends enabled, 045 deg T, 8 KN, 30 s");
            Expect(problems, c.Arpa.Trial.Enabled, "the trial is on");
            c.Arpa.SetTrial(false, 45.0, 8.0, 30.0);
            trials = M9Messages(sent, "trial");
            Expect(problems, trials.Count == 2 && !(bool)trials[1]["enabled"] && !c.Arpa.Trial.Enabled, "trial off is sent");

            TargetRecord acq = new TargetRecord();
            acq.Id = 6;
            acq.BearingDegTrue = 90.0;
            acq.RangeNm = 3.0;
            List<ReadoutRow> rows = TargetReadout.Rows(acq, 45.0, true);
            string[] labels = { "ID", "BRG", "RNG", "CRS", "SPD", "CPA", "TCPA", "BCR", "BCT", "TRIAL CPA", "TRIAL TCPA" };
            Expect(problems, rows.Count == labels.Length, rows.Count + " rows with a trial on, expected " + labels.Length);
            for (int i = 0; i < rows.Count && i < labels.Length; i++)
            {
                Expect(problems, rows[i].Label == labels[i], "row " + i + " is " + rows[i].Label + ", expected " + labels[i]);
                bool empty = i >= 3;
                Expect(problems, !empty || rows[i].Text == "--", rows[i].Label + " reads '" + rows[i].Text + "', expected --");
            }
            Expect(problems, rows.Count > 1 && rows[1].Text == "090.0 deg T   045.0 deg R", "BRG reads '" + (rows.Count > 1 ? rows[1].Text : "") + "'");
            Expect(problems, rows.Count > 2 && rows[2].Text == "3.00 NM", "RNG reads '" + (rows.Count > 2 ? rows[2].Text : "") + "'");
            Expect(problems, TargetReadout.Rows(acq, 45.0, false).Count == 9, "no trial rows while the trial is off");

            TargetRecord full = new TargetRecord();
            full.Id = 2;
            full.BearingDegTrue = 10.0;
            full.RangeNm = 4.5;
            full.CourseDegTrue = 270.0;
            full.SpeedKn = 12.0;
            full.CpaNm = 0.45;
            full.TcpaMin = -3.4;
            full.BcrNm = 1.25;
            full.BctMin = 8.0;
            full.TrialCpaNm = 1.1;
            full.TrialTcpaMin = 9.5;
            rows = TargetReadout.Rows(full, 0.0, true);
            Expect(problems, rows[3].Text == "270.0 deg T" && rows[4].Text == "12.0 KN" && rows[5].Text == "0.45 NM" && rows[6].Text == "-3.4 MIN"
                && rows[7].Text == "1.25 NM" && rows[8].Text == "8.0 MIN" && rows[9].Text == "1.10 NM" && rows[10].Text == "9.5 MIN",
                "readout values with units: " + rows[3].Text + " | " + rows[4].Text + " | " + rows[5].Text + " | " + rows[6].Text + " | " + rows[7].Text + " | " + rows[8].Text);

            // The settings the sim reports come from the controls: bool controls and the limits.
            Expect(problems, c.Arpa.HistoryOn && c.Arpa.AlarmSoundOn && c.Arpa.GuardReferenceRelative && c.Arpa.VectorTrue && c.Arpa.VectorTimeMin == 6.0,
                "defaults from hello: history on, sound on, relative zones, true vectors, 6 MIN");
            Expect(problems, c.Limits.ContainsKey(ArpaController.CpaLimitPath) && c.Numbers[ArpaController.CpaLimitPath] == 1.0 && c.Numbers[ArpaController.TcpaLimitPath] == 12.0,
                "CPA and TCPA limits from hello: 1.0 NM and 12 MIN");
            c.SetRuntimeNumber(ArpaController.CpaLimitPath, 99.0);
            Expect(problems, c.Numbers[ArpaController.CpaLimitPath] == 10.0, "CPA limit clamped to the sim's 10 NM maximum");
            ReportProblems("M9 9 trial and readout", problems, "trial messages; readout rows with units; -- for no value; TCPA keeps its sign; no trial rows while off");
        }

        // ---- M9 tests end ----

        // ---- M10 tests begin (the harness extracts everything up to the end marker) ----

        private static JsonElement M10Hello(bool instructorOverlay)
        {
            string json = """
            {"t":"hello","protocol":1,"seed":7,"scenario":"calibration",
             "radar":{"range_scales_nm":[0.25,0.5,0.75,1.5,3.0,6.0,12.0,24.0],"offset_max_fraction":0.66,"azimuth_bins":2048,"antenna_rpm":24.0},
             "display":{"range_ring_interval_nm":[0.05,0.1,0.25,0.25,0.5,1.0,2.0,4.0],"orientation":"north_up","color_mode":"mono_green",
                        "control_style":"knob","offset_enabled":false,"offset_x_fraction":0.0,"offset_y_fraction":0.0,"range_scale_nm":6.0,
                        "motion_mode":"relative","trails_mode":"off","trail_time_min":6.0,"trail_video_threshold":60,
                        "true_motion_reset_fraction":0.875},
             "controls":[
              {"path":"general.sim_speed_multiplier","unit":"x","value":1.0,"min":1.0,"max":10.0,"step":1.0},
              {"path":"radar.video_range_nm","unit":"NM","value":10.0,"min":0.1,"max":48.0,"step":0.01},
              {"path":"display.range_scale_nm","unit":"NM","value":6.0,"choices":[0.25,0.5,0.75,1.5,3.0,6.0,12.0,24.0]},
              {"path":"display.orientation","unit":"","value":"north_up","choices":["north_up","head_up","course_up"]},
              {"path":"display.motion_mode","unit":"","value":"relative","choices":["relative","true"]},
              {"path":"environment.wind_from_deg_true","unit":"deg T","value":270.0,"min":0.0,"max":360.0,"step":1.0},
              {"path":"environment.wind_speed_kn","unit":"KN","value":12.0,"min":0.0,"max":80.0,"step":1.0},
              {"path":"environment.sea_state_from_wind","unit":"","value":true,"choices":[false,true]},
              {"path":"environment.sea_state_douglas","unit":"Douglas","value":3,"min":0,"max":9,"step":1.0},
              {"path":"environment.current_set_deg_true","unit":"deg T","value":90.0,"min":0.0,"max":360.0,"step":1.0},
              {"path":"environment.current_drift_kn","unit":"KN","value":0.5,"min":0.0,"max":5.0,"step":0.1},
              {"path":"environment.rain_rate_mm_per_h","unit":"mm/h","value":0.0,"min":0.0,"max":100.0,"step":1.0},
              {"path":"traffic.max_contacts","unit":"contacts","value":40,"min":0,"max":200,"step":1.0},
              {"path":"traffic.density_per_100_nm2","unit":"per 100 NM2","value":1.0,"min":0.0,"max":10.0,"step":0.1},
              {"path":"traffic.mix_ship","unit":"","value":0.35,"min":0.0,"max":1.0,"step":0.05},
              {"path":"traffic.mix_tug_tow","unit":"","value":0.15,"min":0.0,"max":1.0,"step":0.05},
              {"path":"traffic.mix_fishing","unit":"","value":0.25,"min":0.0,"max":1.0,"step":0.05},
              {"path":"traffic.mix_pleasure","unit":"","value":0.25,"min":0.0,"max":1.0,"step":0.05},
              {"path":"traffic.rogue_percent","unit":"%","value":3.0,"min":0.0,"max":100.0,"step":1.0},
              {"path":"traffic.rogue_no_give_way","unit":"","value":true,"choices":[false,true]},
              {"path":"traffic.rogue_cross_bow","unit":"","value":true,"choices":[false,true]},
              {"path":"traffic.rogue_late","unit":"","value":true,"choices":[false,true]},
              {"path":"display.instructor_overlay","unit":"","value":INSTRUCTOR,"choices":[false,true]}
             ]}
            """.Replace("INSTRUCTOR", instructorOverlay ? "true" : "false");
            return JsonDocument.Parse(json).RootElement;
        }

        private static DisplayController M10Controller(List<Dictionary<string, object>> sent, bool instructorOverlay)
        {
            DisplayController controller = new DisplayController(sent.Add);
            controller.ApplyHello(M10Hello(instructorOverlay));
            controller.Geometry.SizePx = 1000;          // radius 500 px: 6 NM = 500 px
            controller.ApplyGeometry(true, false);
            return controller;
        }

        // Three contacts at known range and bearing from own ship at (own_x, own_y) in the sim's ground frame.
        private static string M10Truth(double ownX, double ownY)
        {
            string C(double rangeNm, double bearingDeg, string extra)
            {
                double x = ownX + rangeNm * Math.Sin(bearingDeg * Math.PI / 180.0);
                double y = ownY + rangeNm * Math.Cos(bearingDeg * Math.PI / 180.0);
                return "{" + extra + ",\"x_nm\":" + x.ToString("R", CultureInfo.InvariantCulture)
                    + ",\"y_nm\":" + y.ToString("R", CultureInfo.InvariantCulture) + "}";
            }
            return "{\"t\":\"truth\",\"contacts\":["
                + C(2.0, 20.0, "\"id\":1,\"name\":null,\"kind\":\"ship\",\"course_deg_true\":225.0,\"speed_kn\":12.0,\"length_m\":150.0") + ","
                + C(4.5, 200.0, "\"id\":2,\"name\":\"S4\",\"kind\":\"tug_tow\",\"course_deg_true\":0.0,\"speed_kn\":16.0,\"length_m\":120.0") + ","
                + C(0.7, 310.0, "\"id\":3,\"name\":null,\"kind\":\"pleasure\",\"course_deg_true\":90.0,\"speed_kn\":5.0,\"length_m\":8.0")
                + "],\"own_track\":[[" + (ownX - 0.2).ToString(CultureInfo.InvariantCulture) + "," + (ownY - 0.3).ToString(CultureInfo.InvariantCulture)
                + "],[" + (ownX - 0.1).ToString(CultureInfo.InvariantCulture) + "," + (ownY - 0.15).ToString(CultureInfo.InvariantCulture) + "]]}";
        }

        // M10 test 1: NEW RUN message, the checks on the seed and scenario, and what the display does with the hello that follows.
        private static void TestM10NewRun()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M10Controller(sent, false);
            Expect(problems, c.RunSeed == 7 && c.RunScenario == "calibration", "seed and scenario from hello: " + c.RunSeed + ", " + c.RunScenario);

            sent.Clear();
            string problem;
            Expect(problems, c.StartNewRun("42", "random", out problem) && problem == null, "seed 42, random: accepted");
            List<Dictionary<string, object>> runs = M9Messages(sent, "new_run");
            Expect(problems, runs.Count == 1 && (int)runs[0]["seed"] == 42 && (string)runs[0]["scenario"] == "random", "new_run carries seed 42 and scenario random");
            sent.Clear();
            Expect(problems, c.StartNewRun(" 0 ", "calibration", out problem), "seed 0 with spaces, calibration: accepted");
            Expect(problems, M9Messages(sent, "new_run").Count == 1 && (int)M9Messages(sent, "new_run")[0]["seed"] == 0, "seed 0 is sent as 0 (the sim picks one)");
            sent.Clear();
            foreach (string bad in new[] { "", "abc", "-1", "1.5", "99999999999" })
            {
                bool accepted = c.StartNewRun(bad, "random", out problem);
                Expect(problems, !accepted && problem != null && problem.Contains("seed"), "seed \"" + bad + "\" refused with a message");
            }
            Expect(problems, !c.StartNewRun("5", "nowhere", out problem) && problem.Contains("scenario"), "an unknown scenario is refused with a message");
            Expect(problems, M9Messages(sent, "new_run").Count == 0, "nothing is sent for a refused seed or scenario");

            // The hello that follows a new run: targets, truth, tracks and the event text are gone; the picture is cleared.
            c.Arpa.SetTargets(JsonDocument.Parse("{\"t\":\"targets\",\"sim_time_s\":10.0,\"ref_x_nm\":0.0,\"ref_y_nm\":0.0,\"targets\":[{\"id\":1,\"state\":\"TRACK\",\"x_nm\":1.0,\"y_nm\":1.0,\"range_nm\":1.4,\"bearing_deg_true\":45.0,\"history\":[]}]}").RootElement);
            c.SetInstructor(true);
            c.ApplyTruth(JsonDocument.Parse(M10Truth(0.0, 0.0)).RootElement);
            c.ApplyEvent(JsonDocument.Parse("{\"t\":\"event\",\"kind\":\"grounding\",\"text\":\"Grounding\"}").RootElement);
            Expect(problems, c.Arpa.Targets.Targets.Count == 1 && c.Instructor.Contacts.Count == 3 && c.EventText == "Grounding", "set up: 1 target, 3 truth contacts, an event text");
            bool cleared = false;
            c.GeometryChanged += delegate (bool clear) { cleared |= clear; };
            c.ApplyHello(M10Hello(false));
            c.ApplyGeometry(true, true);
            Expect(problems, c.Arpa.Targets.Targets.Count == 0, "after hello: no targets");
            Expect(problems, c.Instructor.Contacts.Count == 0 && c.Instructor.OwnTrackNm.Count == 0 && !c.Instructor.HasData, "after hello: no truth data");
            Expect(problems, c.EventText == "", "after hello: no event text");
            Expect(problems, cleared, "after hello the geometry change asks to clear the picture and the trails");
            ReportProblems("M10 1 new run", problems, "new_run carries seed and scenario; bad seeds and scenarios are refused with a message and nothing is sent; after hello targets, truth data and the event text are gone and the picture is cleared");
        }

        // M10 test 2: every setup control sends the right set and shows what the sim confirmed.
        private static void TestM10Setup()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M10Controller(sent, false);
            string[] numberPaths = { "environment.wind_from_deg_true", "environment.wind_speed_kn", "environment.sea_state_douglas",
                                     "environment.current_set_deg_true", "environment.current_drift_kn", "environment.rain_rate_mm_per_h",
                                     "traffic.max_contacts", "traffic.density_per_100_nm2", "general.sim_speed_multiplier" };
            double[] wanted = { 123.0, 25.0, 6.0, 45.0, 1.5, 20.0, 12.0, 2.5, 5.0 };
            for (int i = 0; i < numberPaths.Length; i++)
            {
                Expect(problems, c.Limits.ContainsKey(numberPaths[i]), numberPaths[i] + " is in the controls from hello");
                sent.Clear();
                c.SetRuntimeNumber(numberPaths[i], wanted[i]);
                List<double> values = SetValues(sent, numberPaths[i]);
                Expect(problems, values.Count == 1 && Near(values[0], wanted[i], 1e-9), numberPaths[i] + ": set sent " + (values.Count == 1 ? values[0].ToString(CultureInfo.InvariantCulture) : values.Count + " messages") + ", expected " + wanted[i]);
            }
            sent.Clear();
            c.SetRuntimeNumber("environment.wind_speed_kn", 500.0);
            Expect(problems, SetValues(sent, "environment.wind_speed_kn")[0] == 80.0, "wind speed 500 is limited to the sim's 80 KN");

            sent.Clear();
            c.SetRuntimeFlag("environment.sea_state_from_wind", false);
            Expect(problems, sent.Count == 1 && (string)sent[0]["path"] == "environment.sea_state_from_wind" && (sent[0]["value"] is bool b && !b), "SEA STATE FROM WIND off sends set false");
            c.SetRuntimeFlag("environment.sea_state_from_wind", true);
            Expect(problems, c.Flags["environment.sea_state_from_wind"], "SEA STATE FROM WIND on is shown");

            // The sim turns it off when the sea state is set by hand, and says so: the check box follows.
            c.ConfirmSetting("environment.sea_state_from_wind", JsonDocument.Parse("false").RootElement);
            c.ConfirmSetting("environment.sea_state_douglas", JsonDocument.Parse("6").RootElement);
            Expect(problems, !c.Flags["environment.sea_state_from_wind"] && c.Numbers["environment.sea_state_douglas"] == 6.0, "the sim's answer switches the check box off and shows Douglas 6");

            sent.Clear();
            c.SetInstructor(true);
            Expect(problems, c.InstructorOn && sent.Count == 2 && (string)sent[0]["path"] == "display.instructor_overlay" && (bool)sent[0]["value"]
                && (string)sent[1]["t"] == "truth" && (bool)sent[1]["enabled"], "the instructor check box sends set true and truth enabled");
            sent.Clear();
            c.TrafficNow();
            Expect(problems, sent.Count == 1 && (string)sent[0]["t"] == "traffic_now", "the TRAFFIC NOW button sends {\"t\": \"traffic_now\"}");
            sent.Clear();
            c.SetInstructor(false);
            Expect(problems, !c.InstructorOn && sent.Count == 2 && !(bool)sent[1]["enabled"], "and turning it off sends set false and truth disabled");

#if !HARNESS
            SetupWindow window = new SetupWindow(c, new WheelhouseData());
            Expect(problems, window.Title == "Setup", "the setup window builds from the controls");
            window.Close();
#endif
            ReportProblems("M10 2 setup controls", problems, "each of 9 numeric controls sends its own set, limited to the sim's range; SEA STATE FROM WIND and the instructor overlay send their flags; the sim's answer switches SEA STATE FROM WIND off and shows the new sea state");
        }

        // M10 test 3: game events reach the controller, stay in the status line until the sim runs again, and clear on hello.
        private static void TestM10Events()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M10Controller(sent, false);
            string kindSeen = "", textSeen = "";
            c.EventReceived += delegate (string kind, string text) { kindSeen = kind; textSeen = text; };
            c.ApplyEvent(JsonDocument.Parse("{\"t\":\"event\",\"kind\":\"collision\",\"text\":\"Collision (ship S4)\"}").RootElement);
            Expect(problems, kindSeen == "collision" && textSeen == "Collision (ship S4)" && c.EventText == "Collision (ship S4)", "a collision event gives its kind and text");
            c.ApplyOwnState(0.0, 0.0, false, 1000);
            Expect(problems, c.EventText != "", "a state that is not paused right after the event does not remove the text (the stop is still to come)");
            c.ApplyOwnState(0.0, 0.0, true, 1100);
            Expect(problems, c.EventText != "", "while the sim is stopped the text stays");
            c.ApplyOwnState(0.0, 0.0, false, 20000);
            Expect(problems, c.EventText == "", "after P (running again) the text is gone");

            // With the game set to ignore the sim never stops: the text goes after DisplayController.EventShownMs.
            c.ApplyEvent(JsonDocument.Parse("{\"t\":\"event\",\"kind\":\"grounding\",\"text\":\"Grounding\"}").RootElement);
            long now = Environment.TickCount64;
            c.ApplyOwnState(1.0, 2.0, false, now + 1000);
            Expect(problems, c.EventText == "Grounding", "never stopped: text still shown 1 s after");
            c.ApplyOwnState(1.0, 2.0, false, now + DisplayController.EventShownMs + 2000);
            Expect(problems, c.EventText == "", "never stopped: text gone after " + DisplayController.EventShownMs / 1000 + " s");
            Expect(problems, c.OwnGroundXNm == 1.0 && c.OwnGroundYNm == 2.0, "own ground position is kept from the state");
            c.ApplyEvent(JsonDocument.Parse("{\"t\":\"event\",\"kind\":\"grounding\"}").RootElement);
            Expect(problems, c.EventText == "", "an event without text is ignored");
            ReportProblems("M10 3 game events", problems, "event gives kind and text; the text stays through the stop and goes when the sim runs again, or after 15 s when it never stopped; no pop-up exists to test");
        }

        // M10 test 4: the overlay's markers are within 1 px of the true positions; labels; own track; truth only while on.
        private static void TestM10Instructor()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M10Controller(sent, false);

            // Off: a truth message that arrives is not kept.
            c.ApplyTruth(JsonDocument.Parse(M10Truth(1.0, 2.0)).RootElement);
            Expect(problems, !c.Instructor.HasData, "overlay off: a truth message is ignored");
            c.SetInstructor(true);
            c.ApplyTruth(JsonDocument.Parse(M10Truth(1.0, 2.0)).RootElement);
            Expect(problems, c.Instructor.HasData && c.Instructor.Contacts.Count == 3 && c.Instructor.OwnTrackNm.Count == 2, "overlay on: 3 contacts and 2 track points kept");
            c.SetInstructor(false);
            Expect(problems, !c.Instructor.HasData && c.Instructor.Contacts.Count == 0, "overlay turned off: data dropped");

            // A hello with the overlay on asks the sim for truth.
            sent.Clear();
            DisplayController on = M10Controller(sent, true);
            List<Dictionary<string, object>> truths = M9Messages(sent, "truth");
            Expect(problems, truths.Count == 1 && (bool)truths[0]["enabled"], "hello with the overlay on sends truth enabled");

            // Positions against PpiGeometry.PixelOf, which works from range and bearing, in each orientation.
            double[][] contacts = { new[] { 2.0, 20.0 }, new[] { 4.5, 200.0 }, new[] { 0.7, 310.0 } };
            string[] orientations = { "north_up", "head_up", "course_up" };
            double worst = 0.0;
            foreach (string orientation in orientations)
            {
                foreach (double range in new[] { 6.0, 12.0 })
                {
                    DisplayController d = M10Controller(new List<Dictionary<string, object>>(), true);
                    d.SetOrientation(orientation);
                    d.SetRangeNm(range);
                    d.Geometry.HeadingDegTrue = 40.0;
                    if (orientation == "course_up")
                    {
                        d.Geometry.LatchedCourseDegTrue = 75.0;
                    }
                    d.SetOffsetPercent(40.0, 30.0);
                    d.ApplyOwnState(1.0, 2.0, false, 0);
                    d.ApplyTruth(JsonDocument.Parse(M10Truth(1.0, 2.0)).RootElement);
                    InstructorShapes shapes = d.Instructor.Layout(d.Geometry, d.OwnGroundXNm, d.OwnGroundYNm, 1.0, 2.0);
                    for (int i = 0; i < contacts.Length; i++)
                    {
                        double expectedX, expectedY;
                        d.Geometry.PixelOf(contacts[i][0], contacts[i][1], out expectedX, out expectedY);
                        double error = Math.Max(Math.Abs(shapes.Contacts[i].XPx - expectedX), Math.Abs(shapes.Contacts[i].YPx - expectedY));
                        worst = Math.Max(worst, error);
                        Expect(problems, error <= 1.0, orientation + " " + range + " NM contact " + (i + 1) + ": " + error.ToString("0.00", CultureInfo.InvariantCulture) + " px from the true position");
                    }
                }
            }

            // True motion: the marker is own ship's pixel (reference minus view origin) plus the displacement, north up.
            DisplayController t = M10Controller(new List<Dictionary<string, object>>(), true);
            t.Geometry.TrueMotion = true;
            t.Geometry.ViewOriginXNm = 0.4;
            t.Geometry.ViewOriginYNm = -0.2;
            t.ApplyOwnState(1.0, 2.0, false, 0);
            t.ApplyTruth(JsonDocument.Parse(M10Truth(1.0, 2.0)).RootElement);
            InstructorShapes moving = t.Instructor.Layout(t.Geometry, 1.0, 2.0, 1.1, 2.05);
            double pxPerNm = t.Geometry.RadiusPx / t.Geometry.RangeScaleNm;
            double ownX = t.Geometry.CentreXPx + (1.1 - 0.4) * pxPerNm;
            double ownY = t.Geometry.CentreYPx - (2.05 + 0.2) * pxPerNm;
            double ex = ownX + 2.0 * Math.Sin(20.0 * Math.PI / 180.0) * pxPerNm;
            double ey = ownY - 2.0 * Math.Cos(20.0 * Math.PI / 180.0) * pxPerNm;
            Expect(problems, Near(moving.Contacts[0].XPx, ex, 1.0) && Near(moving.Contacts[0].YPx, ey, 1.0), "true motion: contact 1 at (" + moving.Contacts[0].XPx.ToString("0.0", CultureInfo.InvariantCulture) + ", " + moving.Contacts[0].YPx.ToString("0.0", CultureInfo.InvariantCulture) + "), expected (" + ex.ToString("0.0", CultureInfo.InvariantCulture) + ", " + ey.ToString("0.0", CultureInfo.InvariantCulture) + ")");

            // The line is 6 MIN of true motion: contact 1, 12 KN toward 225 deg = 1.2 NM.
            DisplayController n = M10Controller(new List<Dictionary<string, object>>(), true);
            n.ApplyOwnState(1.0, 2.0, false, 0);
            n.ApplyTruth(JsonDocument.Parse(M10Truth(1.0, 2.0)).RootElement);
            InstructorShapes plain = n.Instructor.Layout(n.Geometry, 1.0, 2.0, 1.0, 2.0);
            double npx = n.Geometry.RadiusPx / n.Geometry.RangeScaleNm;
            double lineX = plain.Contacts[0].LineEndXPx - plain.Contacts[0].XPx;
            double lineY = plain.Contacts[0].LineEndYPx - plain.Contacts[0].YPx;
            Expect(problems, Near(lineX, 1.2 * Math.Sin(225.0 * Math.PI / 180.0) * npx, 0.5) && Near(lineY, -1.2 * Math.Cos(225.0 * Math.PI / 180.0) * npx, 0.5),
                "contact 1's line is 1.2 NM (6 MIN at 12 KN) toward 225 deg: (" + lineX.ToString("0.0", CultureInfo.InvariantCulture) + ", " + lineY.ToString("0.0", CultureInfo.InvariantCulture) + ") px");

            // Labels: kind, true course, speed and length; the calibration name first.
            Expect(problems, plain.Contacts[0].Label == "SHIP 225°T 12.0 KN 150 M", "label 1 reads '" + plain.Contacts[0].Label + "'");
            Expect(problems, plain.Contacts[1].Label == "S4 TUG TOW 000°T 16.0 KN 120 M", "label 2 reads '" + plain.Contacts[1].Label + "'");
            Expect(problems, plain.Contacts[2].Label == "PLEASURE 090°T 5.0 KN 8 M", "label 3 reads '" + plain.Contacts[2].Label + "'");

            // Own track: the point 0.1 NM west and 0.15 NM south of own ship is that far from own ship's pixel.
            double trackX = plain.OwnTrackPx[1].X - n.Geometry.OwnXPx;
            double trackY = plain.OwnTrackPx[1].Y - n.Geometry.OwnYPx;
            Expect(problems, plain.OwnTrackPx.Count == 2 && Near(trackX, -0.1 * npx, 0.5) && Near(trackY, 0.15 * npx, 0.5), "own track point: (" + trackX.ToString("0.0", CultureInfo.InvariantCulture) + ", " + trackY.ToString("0.0", CultureInfo.InvariantCulture) + ") px from own ship");
            ReportProblems("M10 4 instructor overlay", problems, "markers within " + worst.ToString("0.00", CultureInfo.InvariantCulture) + " px of the true range and bearing in north-up, head-up and course-up at 6 and 12 NM with an offset (limit 1 px), and in true motion; line, labels and own track right; truth kept only while the overlay is on; hello with the overlay on sends truth enabled");
        }

        // M10 test 5: Ctrl+Shift+T, F1, and the help text.
        private static void TestM10Help()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M10Controller(sent, false);
            Expect(problems, c.HandleKeyDown(Key.T, ModifierKeys.Control | ModifierKeys.Shift, false, 0, 0) && c.InstructorOn, "Ctrl+Shift+T turns the overlay on");
            Expect(problems, M9Messages(sent, "truth").Count == 1, "and sends truth enabled");
            c.HandleKeyDown(Key.T, ModifierKeys.Control | ModifierKeys.Shift, false, 0, 0);
            Expect(problems, !c.InstructorOn, "Ctrl+Shift+T again turns it off");
            Expect(problems, c.TrailsModeName == "off", "plain T (trails) was not affected");
            int asked = 0;
            c.HelpRequested += delegate { asked++; };
            Expect(problems, c.HandleKeyDown(Key.F1, ModifierKeys.None, false, 0, 0) && asked == 1, "F1 asks for the help window");

            string text = HelpText.Text();
            int missing = 0;
            foreach (HotkeyRow row in HotkeyTable.Rows)
            {
                if (!text.Contains(row.KeysText) || !text.Contains(row.ActionText))
                {
                    missing++;
                    problems.Add("help text lacks the hotkey row '" + row.KeysText + "'");
                }
            }
            string[] groups = { "RECEIVER", "DISPLAY", "EBL / VRM", "ARPA", "GUARD ZONES", "TRIAL MANEUVER", "ALARMS", "OWN SHIP", "SIM", "SETUP", "INSTRUCTOR OVERLAY" };
            foreach (string group in groups)
            {
                bool found = false;
                foreach (string[] entry in HelpText.Groups)
                {
                    found |= entry[0] == group && entry[1].Length > 40;
                }
                Expect(problems, found, "help has a paragraph for " + group);
            }
            Expect(problems, !text.Contains("disclaimer") && !text.Contains("TODO"), "no disclaimer or placeholder text");
#if !HARNESS
            HelpWindow window = new HelpWindow();
            Expect(problems, window.Title == "Radar Sim help", "the help window builds");
            window.Close();
#endif
            ReportProblems("M10 5 help and keys", problems, "Ctrl+Shift+T and F1 work; the help text holds all " + HotkeyTable.Rows.Length + " hotkey rows and a paragraph for each of " + groups.Length + " control groups");
        }

        // The offset buttons: OFFSET (one click places own ship) and CENTRE, a typed offset after
        // CENTRE, and the range rings reaching past the range scale when own ship is offset.
        private static void TestM10Offset()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M10Controller(sent, false);
            double max = c.Geometry.OffsetMaxFraction;

            c.CentreOffset();
            Expect(problems, c.OffsetXFraction == 0.0 && c.OffsetYFraction == 0.0, "CENTRE gives (0, 0)");
            c.SetOffsetPercent(30.0, -40.0);
            Expect(problems, Near(c.OffsetXFraction, 0.3, 1e-9) && Near(c.OffsetYFraction, -0.4, 1e-9), "a typed offset after CENTRE is kept");
            c.SetOffsetPercent(100.0, 0.0);
            Expect(problems, Near(c.OffsetXFraction, max, 1e-9), "a typed offset beyond the limit is cut to " + max);

            c.CentreOffset();
            c.ToggleOffsetPlace();
            Expect(problems, c.OffsetPlaceArmed, "OFFSET arms the next click");
            c.PlaceOffsetAtPixel(c.Geometry.CentreXPx + 100.0, c.Geometry.CentreYPx - 150.0);
            Expect(problems, !c.OffsetPlaceArmed && Near(c.OffsetXFraction, 0.2, 1e-9) && Near(c.OffsetYFraction, 0.3, 1e-9),
                "the click puts own ship 100 px right and 150 px up (radius 500 px) and disarms: (" + c.OffsetXFraction + ", " + c.OffsetYFraction + ")");
            c.ToggleOffsetPlace();
            c.CentreOffset();
            Expect(problems, !c.OffsetPlaceArmed, "CENTRE disarms OFFSET");

            // Rings: 6 NM scale, 1 NM interval. Centred: 6 rings. Own ship half a radius below the centre:
            // the far side of the circle is 9 NM from own ship, so 9 rings.
            c.Geometry.RangeScaleNm = 6.0;
            c.CentreOffset();
            int centred = c.Geometry.RingRadiiPx(1.0).Count;
            c.SetOffsetPercent(0.0, -50.0);
            List<double> offsetRings = c.Geometry.RingRadiiPx(1.0);
            Expect(problems, centred == 6 && offsetRings.Count == 9, "rings: " + centred + " centred, " + offsetRings.Count + " with own ship half a radius below the centre (6 and 9)");
            Expect(problems, Near(offsetRings[8], 9.0 / 6.0 * 500.0, 1e-6), "the ninth ring is 9 NM = 750 px out");

            double lastX = double.NaN;
            double lastY = double.NaN;
            foreach (Dictionary<string, object> message in sent)
            {
                object path;
                if (message.TryGetValue("path", out path) && message.ContainsKey("value"))
                {
                    if ((string)path == DisplayController.OffsetXPath)
                    {
                        lastX = Convert.ToDouble(message["value"], CultureInfo.InvariantCulture);
                    }
                    if ((string)path == DisplayController.OffsetYPath)
                    {
                        lastY = Convert.ToDouble(message["value"], CultureInfo.InvariantCulture);
                    }
                }
            }
            Expect(problems, Near(lastX, c.OffsetXFraction, 1e-9) && Near(lastY, c.OffsetYFraction, 1e-9), "the last values sent to the sim are the ones now shown");
            ReportProblems("M10 6 offset and rings", problems, "OFFSET takes one click, CENTRE then a typed offset is kept, a long offset is cut to " + max + "; the rings reach the far edge of the circle (9 rings at 6 NM with a half-radius offset)");
        }

        // Trial maneuver: the relative vector shows the trial, the true vector does not change.
        private static void TestM10BearingScale()
        {
            List<string> problems = new List<string>();
            PpiGeometry g = new PpiGeometry();
            g.SizePx = 1000;
            g.RangeScaleNm = 6.0;
            g.OffsetXFraction = 0.5;
            g.OffsetYFraction = -0.3;
            double worst = 0.0;
            double worstDirection = 0.0;
            foreach (BearingTick tick in g.BearingTicks())
            {
                double x, y, ox, oy;
                g.ScaleEdgePoint(tick.ScreenAngleDeg, out x, out y, out ox, out oy);
                double fromCentre = Math.Sqrt((x - g.CentreXPx) * (x - g.CentreXPx) + (y - g.CentreYPx) * (y - g.CentreYPx));
                worst = Math.Max(worst, Math.Abs(fromCentre - g.RadiusPx));
                // The line from own ship to the tick must point along the bearing.
                double rangeNm, bearing;
                g.RangeBearingOf(x, y, out rangeNm, out bearing);
                worstDirection = Math.Max(worstDirection, Math.Abs(((bearing - tick.BearingDegTrue + 540.0) % 360.0) - 180.0));
            }
            Expect(problems, worst < 1e-6, "every tick is on the edge of the display circle (worst " + worst.ToString("0.000000", CultureInfo.InvariantCulture) + " px)");
            Expect(problems, worstDirection < 1e-6, "each tick lies on its bearing as seen from own ship (worst " + worstDirection.ToString("0.000000", CultureInfo.InvariantCulture) + " deg)");
            PpiGeometry centred = new PpiGeometry();
            double cx, cy, cox, coy;
            centred.ScaleEdgePoint(90.0, out cx, out cy, out cox, out coy);
            Expect(problems, Math.Abs(cx - (centred.CentreXPx + centred.RadiusPx)) < 1e-6 && Math.Abs(cy - centred.CentreYPx) < 1e-6, "with own ship in the middle the 090 tick is at the right edge as before");
            ReportProblems("M10 10 bearing scale", problems, "with an offset the bearing ticks are where the lines from own ship at each bearing meet the edge of the circle; centred it is as before");
        }

        private static void TestM10DarkAndReadout()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M10Controller(sent, false);
            Expect(problems, !c.DarkMode, "dark mode is off when the sim does not say");
            c.SetDarkMode(true);
            Expect(problems, c.DarkMode && LastWord(sent, DisplayController.DarkPath) == "on", "SetDarkMode(true) is sent as display.dark_mode on");
            c.SetDarkMode(false);
            Expect(problems, !c.DarkMode && LastWord(sent, DisplayController.DarkPath) == "off", "and back to off");
            Expect(problems, BigReadoutText.Heading(5.0) == "005.0" && BigReadoutText.Heading(359.96) == "000.0" && BigReadoutText.Heading(-10.0) == "350.0"
                && BigReadoutText.Heading(360.0) == "000.0" && BigReadoutText.Heading(123.44) == "123.4", "heading text is 000.0 to 359.9 and wraps (359.96 -> 000.0, -10 -> 350.0)");
            Expect(problems, BigReadoutText.Speed(12.04) == "12.0" && BigReadoutText.Speed(0.0) == "0.0", "speed text has one decimal");
            ReportProblems("M10 11 dark mode and big readout", problems, "dark mode is sent as display.dark_mode on/off and defaults to off; the big heading wraps into 000.0 to 359.9 and the speed has one decimal");
        }

        private static void TestM10Wheelhouse()
        {
            List<string> problems = new List<string>();
            Expect(problems, Near(WheelhouseMath.Daylight(12.0), 1.0, 1e-9) && Near(WheelhouseMath.Daylight(0.0), 0.0, 1e-9)
                && WheelhouseMath.Daylight(6.0) > 0.2 && WheelhouseMath.Daylight(6.0) < 0.4 && WheelhouseMath.Daylight(20.0) == 0.0,
                "noon is full day, midnight is dark, 06:00 is dawn");
            Expect(problems, Near(WheelhouseMath.HorizonDistanceM(22.0) / WheelhouseMath.MPerNm, 9.77, 0.05)
                && Near(WheelhouseMath.HorizonDipRad(22.0) * 180.0 / Math.PI, 0.139, 0.003),
                "from 22 m the sea horizon is 9.8 NM away and 0.14 deg below the horizontal");
            Expect(problems, Near(WheelhouseMath.Elevation(100.0 - 22.0, 5.0 * WheelhouseMath.MPerNm), 0.00780, 0.00005),
                "a 100 m hill 5 NM away is seen 0.0078 above the horizontal");
            Expect(problems, Near(WheelhouseMath.BearingDeg(1.0, 0.0), 90.0, 1e-9) && Near(WheelhouseMath.BearingDeg(0.0, -1.0), 180.0, 1e-9)
                && Near(WheelhouseMath.BearingDeg(-1.0, 0.0), 270.0, 1e-9) && Near(WheelhouseMath.Wrap180(190.0), -170.0, 1e-9),
                "bearings from east and north displacements, and wrapping");
            Expect(problems, Near(WheelhouseMath.ScreenX(100.0, 90.0, 6.0, 1200.0), 660.0, 1e-9) && Near(WheelhouseMath.ScreenX(355.0, 5.0, 6.0, 1200.0), 540.0, 1e-9),
                "10 deg right of the centre is 60 px right of the middle; wrapping through north works");
            Expect(problems, WheelhouseMath.ZoomIndex(0, -1) == 0 && WheelhouseMath.ZoomIndex(0, 1) == 1
                && WheelhouseMath.ZoomIndex(WheelhouseMath.FieldsOfViewDeg.Length - 1, 1) == WheelhouseMath.FieldsOfViewDeg.Length - 1, "zoom stays in the list");

            LightSet ahead = WheelhouseMath.LightsSeenFrom(0.0);
            LightSet onStarboard = WheelhouseMath.LightsSeenFrom(90.0);
            LightSet astern = WheelhouseMath.LightsSeenFrom(150.0);
            LightSet onPort = WheelhouseMath.LightsSeenFrom(-90.0);
            Expect(problems, ahead.Masthead && ahead.Red && ahead.Green && !ahead.Stern, "head on: masthead and both sidelights, no stern light");
            Expect(problems, onStarboard.Masthead && onStarboard.Green && !onStarboard.Red && !onStarboard.Stern, "from the ship's starboard side: green only");
            Expect(problems, onPort.Masthead && onPort.Red && !onPort.Green && !onPort.Stern, "from the ship's port side: red only");
            Expect(problems, astern.Stern && !astern.Masthead && !astern.Red && !astern.Green, "from astern: the stern light only");
            Expect(problems, WheelhouseMath.LightsSeenFrom(112.0).Green && !WheelhouseMath.LightsSeenFrom(113.0).Green
                && WheelhouseMath.LightsSeenFrom(113.0).Stern && !WheelhouseMath.LightsSeenFrom(112.0).Stern, "the sectors end at 112.5 deg from ahead");

            Expect(problems, Near(WheelhouseMath.VisibilityUpperNm(2.0, 0.0), 2.0, 1e-9) && Near(WheelhouseMath.VisibilityUpperNm(2.0, 0.5), 4.0, 1e-9)
                && Near(WheelhouseMath.VisibilityUpperNm(2.0, 1.0), WheelhouseMath.ClearVisibilityNm, 1e-9) && Near(WheelhouseMath.VisibilityUpperNm(0.5, 0.25), 0.75, 1e-9),
                "visibility variability 0 keeps the set value, 0.5 doubles it at most, 1 reaches clear");
            bool wanders = true;
            double lowest = 1e9, highest = -1e9;
            for (int t = 0; t < 2000; t += 7)
            {
                double now = WheelhouseMath.VisibilityNowNm(2.0, 0.5, t);
                lowest = Math.Min(lowest, now);
                highest = Math.Max(highest, now);
                wanders = wanders && now >= 2.0 - 1e-9 && now <= 4.0 + 1e-9 && Near(WheelhouseMath.VisibilityNowNm(2.0, 0.0, t), 2.0, 1e-9);
            }
            Expect(problems, wanders && highest - lowest > 1.0, "the visibility wanders between the set value and its upper limit, and stands still at variability 0");
            Expect(problems, WheelhouseMath.FogFraction(5000.0, WheelhouseMath.ClearVisibilityNm) == 0.0
                && WheelhouseMath.FogFraction(1852.0, 1.0) > 0.9 && WheelhouseMath.FogFraction(1852.0, 1.0) < WheelhouseMath.FogFraction(3704.0, 1.0)
                && WheelhouseMath.FogFraction(1852.0, 5.0) < WheelhouseMath.FogFraction(1852.0, 1.0),
                "no fog at clear; fog grows with range and as the visibility falls");
            Expect(problems, Near(WheelhouseMath.LightRangeZoom(180.0), 1.0, 1e-9) && Near(WheelhouseMath.LightRangeZoom(30.0), 3.0, 1e-9)
                && Near(WheelhouseMath.LightRangeZoom(4.0), 8.0, 1e-9), "lights reach 1x at 180 deg, 3x at 30 deg, 8x at the narrowest");
            Expect(problems, Near(WheelhouseMath.LightReachM(20.0, 22.0), 35300.0, 400.0), "a light 20 m up is seen about 19 NM from an eye 22 m up");

            byte[] cells = new byte[16];
            cells[2 * 4 + 3] = 50;
            string landText = "{\"t\":\"land_view\",\"size\":4,\"cell_nm\":1.0,\"west_nm\":-2.0,\"south_nm\":-2.0,\"height_step_m\":2.0,\"data\":\"" + Convert.ToBase64String(cells) + "\"}";
            WheelhouseData data = new WheelhouseData();
            data.SetLand(JsonDocument.Parse(landText).RootElement);
            Expect(problems, data.Land.Size == 4 && Near(data.Land.HeightM(1.5, 0.5), 100.0, 1e-9) && data.Land.HeightM(0.5, 0.5) == 0.0 && data.Land.HeightM(9.0, 0.0) == 0.0,
                "the land message is read: the hill is 100 m, the water is 0, outside is 0");
            string viewText = "{\"t\":\"view\",\"own\":{\"x_nm\":1.5,\"y_nm\":-2.5,\"heading_deg_true\":45.0,\"gyro_heading_deg\":45.2},"
                + "\"contacts\":[{\"id\":7,\"name\":\"\",\"kind\":\"tug_tow\",\"x_nm\":3.0,\"y_nm\":4.0,\"course_deg_true\":120.0,\"speed_kn\":5.0,\"length_m\":30.0}]}";
            data.SetView(JsonDocument.Parse(viewText).RootElement);
            Expect(problems, data.HasOwn && Near(data.OwnXNm, 1.5, 1e-9) && Near(data.GyroHeadingDeg, 45.2, 1e-9) && data.Contacts.Count == 1
                && data.Contacts[0].Id == 7 && data.Contacts[0].Kind == "tug_tow" && Near(data.Contacts[0].LengthM, 30.0, 1e-9), "the view message is read");
            string towText = "{\"t\":\"view\",\"own\":{\"x_nm\":0,\"y_nm\":0,\"heading_deg_true\":0,\"gyro_heading_deg\":0},"
                + "\"env\":{\"wind_from_deg_true\":270.0,\"wind_speed_kn\":18.0,\"sea_state_douglas\":4},"
                + "\"contacts\":[{\"id\":8,\"name\":\"\",\"kind\":\"tug_tow\",\"x_nm\":1.0,\"y_nm\":1.0,\"course_deg_true\":0,\"speed_kn\":4,\"length_m\":30,"
                + "\"sail\":false,\"tow\":{\"x_nm\":1.0,\"y_nm\":0.9,\"length_m\":185.2}},"
                + "{\"id\":9,\"name\":\"\",\"kind\":\"pleasure\",\"x_nm\":2.0,\"y_nm\":1.0,\"course_deg_true\":0,\"speed_kn\":4,\"length_m\":9,\"sail\":true}]}";
            data.SetView(JsonDocument.Parse(towText).RootElement);
            Expect(problems, data.SeaState == 4 && Near(data.WindSpeedKn, 18.0, 1e-9) && Near(data.WindFromDeg, 270.0, 1e-9) && data.Contacts.Count == 2
                && data.Contacts[0].HasTow && Near(data.Contacts[0].TowLengthM, 185.2, 1e-9) && Near(data.Contacts[0].TowYNm, 0.9, 1e-9)
                && !data.Contacts[0].Sail && data.Contacts[1].Sail && !data.Contacts[1].HasTow, "wind, sea state, a tug's tow and a sailing vessel are read from the view message");
            string markText = "{\"t\":\"view\",\"own\":{\"x_nm\":0,\"y_nm\":0,\"heading_deg_true\":0,\"gyro_heading_deg\":0},"
                + "\"contacts\":[{\"id\":1000003,\"name\":\"R4\",\"kind\":\"buoy\",\"x_nm\":0.5,\"y_nm\":2.0,\"course_deg_true\":0,\"speed_kn\":0,\"length_m\":2,"
                + "\"sail\":false,\"mark\":{\"colour\":\"red\",\"shape\":\"nun\",\"light\":{\"colour\":\"red\",\"period_s\":4.0,\"flash_s\":0.5},\"lane\":\"harbour approach\"}},"
                + "{\"id\":1,\"name\":\"B1\",\"kind\":\"buoy\",\"x_nm\":0,\"y_nm\":2,\"course_deg_true\":0,\"speed_kn\":0,\"length_m\":2}]}";
            data.SetView(JsonDocument.Parse(markText).RootElement);
            WheelhouseContact markBuoy = data.Contacts[0];
            WheelhouseContact plainBuoy = data.Contacts[1];
            Expect(problems, markBuoy.HasMark && markBuoy.MarkColour == "red" && markBuoy.MarkShape == "nun" && markBuoy.LightColour == "red"
                && Near(markBuoy.LightPeriodS, 4.0, 1e-9) && Near(markBuoy.LightFlashS, 0.5, 1e-9) && !plainBuoy.HasMark,
                "a lane buoy's colour, shape and light are read from the view message; a calibration buoy has none");
            int flashing = 0;
            for (long ms = 0; ms < 4000; ms += 10)
            {
                if (WheelhouseMath.LightIsOn(markBuoy, ms))
                {
                    flashing++;
                }
            }
            Expect(problems, flashing >= 48 && flashing <= 52, "a 0.5 s flash every 4 s is on for 50 of the 400 ten-millisecond ticks in a period: " + flashing);
            WheelhouseContact other = new WheelhouseContact();
            other.Id = markBuoy.Id + 1;
            other.LightPeriodS = 4.0;
            other.LightFlashS = 0.5;
            bool apart = false;
            for (long ms = 0; ms < 4000; ms += 10)
            {
                if (WheelhouseMath.LightIsOn(markBuoy, ms) != WheelhouseMath.LightIsOn(other, ms))
                {
                    apart = true;
                }
            }
            Expect(problems, apart, "neighbouring buoys do not flash together");
            string groupText = "{\"t\":\"view\",\"own\":{\"x_nm\":0,\"y_nm\":0,\"heading_deg_true\":0,\"gyro_heading_deg\":0},"
                + "\"rain\":{\"peak_mm_per_h\":12.0,\"radius_nm\":2.0,\"cells\":[[0.0,3.0],[10.0,10.0]]},"
                + "\"contacts\":[{\"id\":1000010,\"name\":\"G5\",\"kind\":\"buoy\",\"x_nm\":0,\"y_nm\":6,\"course_deg_true\":0,\"speed_kn\":0,\"length_m\":2,"
                + "\"mark\":{\"colour\":\"green\",\"shape\":\"can\",\"light\":{\"colour\":\"green\",\"period_s\":6.0,\"flash_s\":0.5,"
                + "\"flashes\":[[0.0,0.5],[1.5,0.5]],\"code\":\"Fl(2) G 6s\"},\"lane\":\"coastal\"}}]}";
            data.SetView(JsonDocument.Parse(groupText).RootElement);
            WheelhouseContact groupBuoy = data.Contacts[0];
            int groupOn = 0;
            int groupEdges = 0;
            bool previous = false;
            for (long ms = 0; ms < 6000; ms += 10)
            {
                bool on = WheelhouseMath.LightIsOn(groupBuoy, ms);
                groupOn += on ? 1 : 0;
                groupEdges += on && !previous ? 1 : 0;
                previous = on;
            }
            Expect(problems, groupBuoy.LightCode == "Fl(2) G 6s" && groupBuoy.LightFlashes.Length == 2 && groupOn >= 98 && groupOn <= 102 && groupEdges >= 2 && groupEdges <= 3,
                "a group-flashing light (two 0.5 s flashes 1.5 s apart every 6 s) is on 100 of 600 ticks and starts two flashes in a period: " + groupOn + ", " + groupEdges);
            data.OwnXNm = 0.0;
            data.OwnYNm = 0.0;
            WheelhouseContact behind = new WheelhouseContact();
            behind.XNm = 0.0;
            behind.YNm = 6.0;
            WheelhouseContact clear = new WheelhouseContact();
            clear.XNm = 6.0;
            clear.YNm = 0.0;
            Expect(problems, data.RainCells.Count == 2 && Near(data.RainPeakMmH, 12.0, 1e-9) && Near(data.RainRadiusNm, 2.0, 1e-9)
                && Near(data.RainRateAt(0.0, 3.0), 12.0, 1e-9) && Near(data.RainRateAt(0.0, 4.0), 6.0, 1e-9) && Near(data.RainRateAt(0.0, 5.5), 0.0, 1e-9)
                && Near(data.RainRateAt(0.0, 0.0), 0.0, 1e-9),
                "the rain cells are read, and the rate is the sim's raised cosine: 12 mm/h at the centre, 6 halfway, 0 at the edge and outside");
            Expect(problems, data.RainFogFraction(behind) > 0.9 && data.RainFogFraction(clear) < 1e-9,
                "a buoy seen through a rain cell is hidden (" + data.RainFogFraction(behind).ToString("0.00", CultureInfo.InvariantCulture) + ") and one beside it is not");
            Expect(problems, Near(WheelhouseMath.RainVisibilityNm(0.0), WheelhouseMath.ClearVisibilityNm, 1e-9) && Near(WheelhouseMath.RainVisibilityNm(12.0), 2.439, 0.01)
                && WheelhouseMath.RainVisibilityNm(50.0) < 1.0, "the visibility in rain: 30 NM in none, 2.4 NM at 12 mm/h, under 1 NM at 50 mm/h");
            data.SetView(JsonDocument.Parse(towText).RootElement);
            Expect(problems, data.RainCells.Count == 0 && data.RainPeakMmH == 0.0, "a view message without rain clears the cells");
            Expect(problems, WheelhouseMath.RelativeViewText(0.0) == "AHEAD" && WheelhouseMath.RelativeViewText(90.0) == "090 STBD"
                && WheelhouseMath.RelativeViewText(-110.0) == "110 PORT" && WheelhouseMath.RelativeViewText(180.0) == "ASTERN" && WheelhouseMath.RelativeViewText(350.0) == "010 PORT",
                "the heading indicator words the direction of view: AHEAD, 090 STBD, 110 PORT, ASTERN, 350 as 010 PORT");
            Dictionary<string, object> enable = Protocol.ViewEnable(true);
            Expect(problems, (string)enable["t"] == "view" && (bool)enable["enabled"], "the view request is {\"t\": \"view\", \"enabled\": true}");
            ReportProblems("M10 15 wheelhouse", problems, "daylight, horizon, bearings, light sectors and the view and land messages work as specified");
        }

        private static void TestM10ChartRequest()
        {
            List<string> problems = new List<string>();
            Dictionary<string, object> request = Protocol.Chart();
            Expect(problems, request.Count == 1 && (string)request["t"] == "chart", "the chart request is {\"t\": \"chart\"}");
            ReportProblems("M10 14 chart request", problems, "the CHART button sends {\"t\": \"chart\"}; the sim answers with the file's path and the display opens it");
        }

        private static void TestM10ParallelIndex()
        {
            List<string> problems = new List<string>();
            PpiGeometry g = new PpiGeometry();
            g.RangeScaleNm = 6.0;
            double x1, y1, x2, y2;
            EblVrmSet set = new EblVrmSet();
            // North-up, direction 000 (up), 3 NM to the right: a vertical line half way to the right edge.
            set.SetPiBearing(0, 0.0);
            set.SetPiNm(0, 3.0, g);
            Expect(problems, set.PiEndsPx(0, g, out x1, out y1, out x2, out y2) && Near(x1, 768.0, 0.5) && Near(x2, 768.0, 0.5)
                && Near(Math.Min(y1, y2), 512.0 - Math.Sqrt(512.0 * 512.0 - 256.0 * 256.0), 0.5), "3 NM right of a northbound line is vertical at x = 768: " + x1 + ", " + x2);
            // Negative distance: the left side.
            set.SetPiNm(0, -3.0, g);
            set.PiEndsPx(0, g, out x1, out y1, out x2, out y2);
            Expect(problems, Near(x1, 256.0, 0.5), "3 NM left is at x = 256: " + x1);
            // Direction 090 (to the right) and 2 NM to the right of that: below the centre (right of east is south).
            set.SetPiBearing(0, 90.0);
            set.SetPiNm(0, 2.0, g);
            set.PiEndsPx(0, g, out x1, out y1, out x2, out y2);
            Expect(problems, Near(y1, 512.0 + 2.0 / 6.0 * 512.0, 0.5) && Near(y2, y1, 0.5), "090, 2 NM right runs along y = " + y1);
            // Past the picture: no line.
            set.SetPiNm(0, 6.0, g);
            set.SetPiBearing(0, 0.0);
            Expect(problems, !set.PiEndsPx(0, g, out x1, out y1, out x2, out y2), "a line on the edge of the picture is not drawn");
            // The second line is its own: a pair of lines 1 NM each side of own ship, both northbound.
            EblVrmSet pair = new EblVrmSet();
            pair.SetPiBearing(0, 0.0);
            pair.SetPiNm(0, 1.0, g);
            pair.SetPiBearing(1, 0.0);
            pair.SetPiNm(1, -1.0, g);
            double a1 = 0.0, b1 = 0.0, a2 = 0.0, b2 = 0.0;
            Expect(problems, pair.PiEndsPx(0, g, out x1, out y1, out x2, out y2) && pair.PiEndsPx(1, g, out a1, out b1, out a2, out b2)
                && Near(x1, 512.0 + 512.0 / 6.0, 0.5) && Near(a1, 512.0 - 512.0 / 6.0, 0.5),
                "line 1 is 1 NM right (x = " + x1 + ") and line 2 is 1 NM left (x = " + a1 + ")");
            pair.PiOn[1] = true;
            Expect(problems, !pair.PiOn[0] && pair.PiOn[1], "the lines switch on one by one");
            // Relative reading: 000 deg R with heading 090 is 090 true, and switching modes keeps both lines where they are.
            EblVrmSet rel = new EblVrmSet();
            rel.SetPiBearing(0, 45.0);
            rel.SetPiBearing(1, 100.0);
            rel.SetRelativeMode(true, 90.0);
            Expect(problems, Near(rel.PiBearingDeg[0], 315.0, 1e-9) && Near(rel.PiTrueDeg(0, 90.0), 45.0, 1e-9)
                && Near(rel.PiBearingDeg[1], 10.0, 1e-9) && Near(rel.PiTrueDeg(1, 90.0), 100.0, 1e-9),
                "switching to relative keeps both lines on the screen: " + rel.PiBearingDeg[0] + ", " + rel.PiBearingDeg[1]);
            rel.PiOn[0] = true;
            rel.PiOn[1] = true;
            rel.PiNm[1] = 2.0;
            rel.Reset();
            Expect(problems, !rel.PiOn[0] && !rel.PiOn[1] && rel.PiNm[0] == 0.0 && rel.PiNm[1] == 0.0, "reset turns both lines off");
            ReportProblems("M10 13 parallel index", problems, "two parallel index lines each run in their set direction at their set distance to the right (+) or left (-) of own ship, are clipped to the picture, are independent, and follow the EBL true/relative mode");
        }

        // M10 16: bearing knobs turn all the way round, and the control style has a hybrid.
        private static void TestM10Controls()
        {
            List<string> problems = new List<string>();
            Expect(problems, Near(ControlMath.Wrap(370.0, 360.0), 10.0, 1e-9) && Near(ControlMath.Wrap(-10.0, 360.0), 350.0, 1e-9)
                && ControlMath.Wrap(360.0, 360.0) == 0.0 && ControlMath.Wrap(720.5, 360.0) == 0.5 && ControlMath.Wrap(0.0, 360.0) == 0.0,
                "Wrap brings 370 to 10, -10 to 350 and 360 to 0");
            Expect(problems, ValueModel.IsBearing("deg T", 0.0, 360.0) && ValueModel.IsBearing("deg R", 0.0, 360.0)
                && !ValueModel.IsBearing("deg T", 0.0, 180.0) && !ValueModel.IsBearing("NM", 0.0, 360.0) && !ValueModel.IsBearing("%", 0.0, 100.0),
                "a bearing is a deg unit from 0 to 360");

            ValueModel bearing = new ValueModel();
            bearing.Minimum = 0.0;
            bearing.Maximum = 360.0;
            bearing.Step = 0.5;
            bearing.Wrap = true;
            Expect(problems, bearing.Limit(370.0) == 10.0 && bearing.Limit(-10.0) == 350.0 && bearing.Limit(360.0) == 0.0,
                "a bearing control wraps what it is given instead of stopping at 360 and 0");
            bearing.Value = 359.5;
            Expect(problems, bearing.Nudged(1, false) == 0.0, "one step up from 359.5 is 0 (no stop at the top): " + bearing.Nudged(1, false));
            bearing.Value = 0.0;
            Expect(problems, bearing.Nudged(-1, false) == 359.5, "one step down from 0 is 359.5 (no stop at the bottom): " + bearing.Nudged(-1, false));
            Expect(problems, Near(bearing.Nudged(-1, true), 359.95, 1e-9), "Ctrl (fine) steps a tenth of a step round the top: " + bearing.Nudged(-1, true));
            Expect(problems, bearing.ValueFromAngleDeg(-90.0) == 270.0 && bearing.ValueFromAngleDeg(90.0) == 90.0 && bearing.ValueFromAngleDeg(180.0) == 180.0
                && bearing.ValueFromAngleDeg(359.8) == 0.0 && bearing.ValueFromAngleDeg(0.3) == 0.5 && bearing.ValueFromAngleDeg(540.0) == 180.0,
                "the pointer angle is the bearing, snapped to the step, all the way round (-90 is 270, 359.8 is 000)");
            double typed;
            Expect(problems, bearing.TryParseTyped("725", out typed) && typed == 5.0 && bearing.TryParseTyped("-30", out typed) && typed == 330.0,
                "typed 725 comes round to 5 and -30 to 330");
            Expect(problems, Near(bearing.Fraction, 0.0, 1e-9), "the pointer fraction of 0 is 0");

            ValueModel level = new ValueModel();
            level.Minimum = 0.0;
            level.Maximum = 100.0;
            level.Step = 1.0;
            Expect(problems, level.Limit(120.0) == 100.0 && level.Limit(-5.0) == 0.0, "a level (gain, brilliance) still stops at its ends");
            level.Value = 100.0;
            Expect(problems, level.Nudged(1, false) == 100.0, "and does not come round");

            // The control style: hybrid is its own style; knob is the default.
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M10Controller(sent, false);
            Expect(problems, c.Style == ControlStyle.Knob, "knob is the style while the sim says knob");
            c.SetControlStyle("hybrid");
            Expect(problems, c.Style == ControlStyle.Hybrid && LastWord(sent, DisplayController.StylePath) == "hybrid", "SetControlStyle(hybrid) is kept and sent as display.control_style hybrid");
            c.SetControlStyle("slider");
            Expect(problems, c.Style == ControlStyle.Slider, "slider");
            c.SetControlStyle("knob");
            Expect(problems, c.Style == ControlStyle.Knob, "and back to knob");

            // The controller's two parallel index lines.
            c.TogglePi(1);
            Expect(problems, !c.EblVrm.PiOn[0] && c.EblVrm.PiOn[1], "TogglePi(1) switches line 2 on and leaves line 1 off");
            c.SetPiBearing(0, 45.0);
            c.SetPiNm(0, 1.5);
            Expect(problems, c.EblVrm.PiOn[0] && Near(c.EblVrm.PiBearingDeg[0], 45.0, 1e-9) && Near(c.EblVrm.PiNm[0], 1.5, 1e-9)
                && c.EblVrm.PiBearingDeg[1] == 0.0, "setting a direction or distance on line 1 switches it on and leaves line 2 as it was");
            ReportProblems("M10 16 knobs and hybrid", problems, "a bearing control wraps (a knob turns all the way round, a step or a typed value comes round past 000/360) while a level stops at its ends; control style knob, slider and hybrid; two parallel index lines in the controller");
        }

        private static void TestM10MultiAcquire()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M10Controller(sent, false);
            ArpaController a = c.Arpa;
            int Count()
            {
                int n = 0;
                foreach (Dictionary<string, object> m in sent)
                {
                    if ((string)m["t"] == "acquire") { n++; }
                }
                return n;
            }
            a.ArmAcquire();
            a.AcquireAtPixel(c.Geometry, c.Geometry.CentreXPx + 50.0, c.Geometry.CentreYPx - 50.0);
            a.AcquireAtPixel(c.Geometry, c.Geometry.CentreXPx - 80.0, c.Geometry.CentreYPx + 20.0);
            a.AcquireAtPixel(c.Geometry, c.Geometry.CentreXPx + 10.0, c.Geometry.CentreYPx + 90.0);
            Expect(problems, Count() == 3 && a.AcquireArmed, "three clicks send three acquire messages and ACQUIRE stays armed");
            a.ArmAcquire();
            Expect(problems, !a.AcquireArmed, "pressing ACQUIRE again stops it");
            a.AcquireAtPixel(c.Geometry, c.Geometry.CentreXPx + 50.0, c.Geometry.CentreYPx - 50.0);
            Expect(problems, Count() == 4 && !a.AcquireArmed, "the A key acquires at the cursor and does not arm it");
            a.ArmAcquire();
            a.CheckAcquireTimeout(a.AcquireArmedAtMs + ArpaController.AcquireTimeoutMs - 1);
            Expect(problems, a.AcquireArmed, "still armed just before the time-out");
            a.CheckAcquireTimeout(a.AcquireArmedAtMs + ArpaController.AcquireTimeoutMs + 1);
            Expect(problems, !a.AcquireArmed, "ACQUIRE stops by itself " + ArpaController.AcquireTimeoutMs / 1000 + " s after the last box");
            ReportProblems("M10 12 multiple acquire", problems, "ACQUIRE stays armed for several clicks; pressing it again or " + ArpaController.AcquireTimeoutMs / 1000 + " s without a click stops it; the A key does not arm it");
        }

        private static void TestM10ContactList()
        {
            List<string> problems = new List<string>();
            List<TargetRecord> targets = new List<TargetRecord>();
            TargetRecord b = new TargetRecord { Id = 7, State = TargetState.Track, RangeNm = 5.0, BearingDegTrue = 45.0, CpaNm = 0.3, TcpaMin = 6.0 };
            TargetRecord a = new TargetRecord { Id = 2, State = TargetState.Acq, RangeNm = 12.345, BearingDegTrue = 270.0 };
            TargetRecord c = new TargetRecord { Id = 9, State = TargetState.Trend, RangeNm = 3.0, BearingDegTrue = 10.0, CpaNm = 0.2, TcpaMin = -4.0 };
            targets.Add(b); targets.Add(a); targets.Add(c);
            List<ContactLine> lines = ContactListLogic.Lines(targets, 7, 1.0, 12.0);
            Expect(problems, lines.Count == 3 && lines[0].Id == 2 && lines[1].Id == 7 && lines[2].Id == 9, "lines are in ID order");
            Expect(problems, !lines[0].Selected && lines[1].Selected && !lines[2].Selected, "only the selected target is flagged");
            Expect(problems, lines[1].Dangerous && !lines[2].Dangerous && !lines[0].Dangerous, "dangerous = CPA and TCPA inside the limits and TCPA positive (opening is not)");
            Expect(problems, lines[0].Text.Contains("12.35") && lines[0].Text.Contains("--") && lines[0].Text.Contains("ACQ"), "range with 2 decimals, missing CPA/TCPA as --, state name");
            Expect(problems, lines[2].Text.Contains("-4.0") && lines[2].Text.Contains("TREND"), "negative TCPA keeps its sign");
            Expect(problems, ContactListLogic.Lines(new List<TargetRecord>(), -1, 1.0, 12.0).Count == 0, "no targets, no lines");
            string header = ContactListLogic.Header;
            Expect(problems, lines[0].Text.IndexOf("ACQ") == header.IndexOf("STATE") && lines[0].Text.Length - 3 == header.Length - 5
                && lines[1].Text.IndexOf("0.30") + 4 == header.IndexOf("CPA NM") + 6, "the header's STATE and CPA NM columns line up with the lines");
            ReportProblems("M10 9 contact list", problems, "the contact list has one line per target in ID order with range, bearing, CPA, TCPA and state; the selected line and the dangerous ones are flagged");
        }

        private static void TestM10TrialVectors()
        {
            List<string> problems = new List<string>();
            List<Dictionary<string, object>> sent = new List<Dictionary<string, object>>();
            DisplayController c = M9Controller(sent);
            // Target: true course 000 at 10 KN. The sim's own relative values (own ship 090 at 10 KN would
            // give 315 at 14.1 KN; the message carries the present ones, 200 at 8 KN).
            c.Arpa.SetTargets(M9Targets(0.0, 0.0, new M9T { X = 3.0, Y = 0.0, Course = 0.0, Speed = 10.0, RelCourse = 200.0, RelSpeed = 8.0 }));
            c.Arpa.SetVectorMode(false);
            PpiGeometry g = M9Geometry(PpiOrientation.NorthUp, 0.0, 0.0);

            TargetShape before = c.Arpa.Layout(g)[0];
            double lengthBefore = Math.Sqrt(Math.Pow(before.VectorEndXPx - before.BoxXPx, 2) + Math.Pow(before.VectorEndYPx - before.BoxYPx, 2));
            Expect(problems, Near(lengthBefore, 66.67, 1.0), "no trial: the relative vector is the sim's (8 KN: 66.7 px), got " + Number(lengthBefore, "0.0"));

            c.Arpa.SetTrial(true, 90.0, 10.0, 60.0);
            TargetShape during = c.Arpa.Layout(g)[0];
            double dx = during.VectorEndXPx - during.BoxXPx;
            double dy = during.VectorEndYPx - during.BoxYPx;
            double lengthDuring = Math.Sqrt(dx * dx + dy * dy);
            Expect(problems, Near(lengthDuring, 14.142 * 6.0 / 60.0 * 83.333, 1.0), "trial 090 at 10 KN: relative vector 14.1 KN = 117.9 px, got " + Number(lengthDuring, "0.0"));
            Expect(problems, dx < -50.0 && dy < -50.0 && Near(-dx, -dy, 1.0), "and it points to the upper left (course 315): (" + Number(dx, "0.0") + ", " + Number(dy, "0.0") + ")");

            c.Arpa.SetVectorMode(true);
            TargetShape trueVector = c.Arpa.Layout(g)[0];
            double trueLength = Math.Sqrt(Math.Pow(trueVector.VectorEndXPx - trueVector.BoxXPx, 2) + Math.Pow(trueVector.VectorEndYPx - trueVector.BoxYPx, 2));
            Expect(problems, Near(trueLength, 100.0 * 10.0 / 12.0, 1.0) && Near(trueVector.VectorEndXPx, trueVector.BoxXPx, 1e-6), "the true vector is unchanged by the trial: 10 KN north, " + Number(trueLength, "0.0") + " px");

            c.Arpa.SetVectorMode(false);
            c.Arpa.SetTrial(false, 90.0, 10.0, 60.0);
            TargetShape after = c.Arpa.Layout(g)[0];
            Expect(problems, Near(Math.Sqrt(Math.Pow(after.VectorEndXPx - after.BoxXPx, 2) + Math.Pow(after.VectorEndYPx - after.BoxYPx, 2)), 66.67, 1.0), "trial off: the sim's relative vector again");

            double rc, rs;
            TargetLayer.TrialRelative(0.0, 10.0, 0.0, 10.0, out rc, out rs);
            Expect(problems, rs < 1e-9 && rc == 0.0, "same course and speed: no relative motion, course 0 by rule");
            TargetLayer.TrialRelative(270.0, 6.0, 90.0, 4.0, out rc, out rs);
            Expect(problems, Near(rs, 10.0, 1e-9) && Near(rc, 270.0, 1e-9), "head-on: 10 KN from 270");
            ReportProblems("M10 7 trial vectors", problems, "with a trial on, the relative vector is the target's true velocity minus own ship's trial velocity (10 KN north against own 090 at 10 KN gives 14.1 KN toward 315); the true vector does not change; trial off restores the sim's vector");
        }

        // ---- M10 tests end ----
    }
}
