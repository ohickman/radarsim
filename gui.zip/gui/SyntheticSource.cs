// SyntheticSource.cs - builds SPOKES frames with echoes at known true bearings and
// ranges, for the self-tests. Nothing here talks to the sim.
// Units: ranges NM, bearings and headings deg T, times s of sim time.
// Called by: SelfTest.

using System;

namespace RadarSim
{
    public struct SyntheticEcho
    {
        public double RangeNm;
        public double BearingDegTrue;

        public SyntheticEcho(double rangeNm, double bearingDegTrue)
        {
            RangeNm = rangeNm;
            BearingDegTrue = bearingDegTrue;
        }
    }

    public static class SyntheticSource
    {
        public const int AzimuthBins = 2048;
        public const int BinsPerSpoke = 1024;

        // One whole antenna revolution, 2048 spokes. Each echo is a block of 3 spokes by 3 bins
        // of video 255. The antenna turns at one revolution per revolutionS of sim time.
        public static SpokeFrame Revolution(SyntheticEcho[] echoes, double videoRangeNm, double gyroHeadingDegTrue,
                                            double startSimTimeS, double revolutionS)
        {
            SpokeFrame frame = new SpokeFrame(AzimuthBins, BinsPerSpoke, videoRangeNm);
            ushort gyroCdeg = (ushort)Math.Round(PpiGeometry.Normalise360(gyroHeadingDegTrue) * 100.0);
            for (int spoke = 0; spoke < AzimuthBins; spoke++)
            {
                frame.AzimuthIndex[spoke] = (ushort)spoke;
                frame.GyroHeadingCdeg[spoke] = gyroCdeg;
                frame.SimTimeS[spoke] = startSimTimeS + spoke * revolutionS / AzimuthBins;
            }

            foreach (SyntheticEcho echo in echoes)
            {
                double relativeDeg = PpiGeometry.Normalise360(echo.BearingDegTrue - gyroCdeg / 100.0);
                int centreSpoke = (int)Math.Round(relativeDeg / 360.0 * AzimuthBins - 0.5);
                int centreBin = (int)Math.Round(echo.RangeNm / videoRangeNm * BinsPerSpoke - 0.5);
                for (int spokeStep = -1; spokeStep <= 1; spokeStep++)
                {
                    int spoke = ((centreSpoke + spokeStep) % AzimuthBins + AzimuthBins) % AzimuthBins;
                    for (int binStep = -1; binStep <= 1; binStep++)
                    {
                        int bin = centreBin + binStep;
                        if (bin >= 0 && bin < BinsPerSpoke)
                        {
                            frame.Video[spoke * BinsPerSpoke + bin] = 255;
                        }
                    }
                }
            }
            return frame;
        }

        // A whole revolution with the same video value everywhere.
        public static SpokeFrame UniformRevolution(byte video, double videoRangeNm, double gyroHeadingDegTrue,
                                                   double startSimTimeS, double revolutionS)
        {
            SpokeFrame frame = Revolution(new SyntheticEcho[0], videoRangeNm, gyroHeadingDegTrue, startSimTimeS, revolutionS);
            for (int i = 0; i < frame.Video.Length; i++)
            {
                frame.Video[i] = video;
            }
            return frame;
        }

        // One empty spoke: it moves the sim clock on without painting anything near other echoes.
        public static SpokeFrame EmptySpoke(int azimuthIndex, double simTimeS, double videoRangeNm)
        {
            SpokeFrame frame = new SpokeFrame(1, BinsPerSpoke, videoRangeNm);
            frame.AzimuthIndex[0] = (ushort)azimuthIndex;
            frame.SimTimeS[0] = simTimeS;
            return frame;
        }
    }
}
