# test_m10.py - acceptance tests of Module M10 on the sim side (BRIEF.md Section 15).
# Run: python sim/test_m10.py            tests 1 to 4 (a minute or two)
#      python sim/test_m10.py --soak     test 6, the soak: 30 sim-minutes at 10x (add --minutes N for a shorter run)
# Prints [OK] or [FAIL] lines with numbers; exits 0 or 1.
# Test 5 (truth messages 5 per second) is test 18 of test_m3.py on the sim side and a self-test of the display.
# The tests run the Sim class in this process with its send() replaced, so no TCP port is used.
# Units: positions nm, distances m or nm as named, times s of sim time.

import argparse
import copy
import math
import os
import sys
import time

import numpy as np

import messages
import sim_common
import sim_config
import sim_environment
import sim_main
import sim_ownship
import sim_protocol

ROOT = sim_common.find_project_root()
CFG = sim_config.load_config(os.path.join(ROOT, sim_common.CONFIG_FILE_NAME))
M_PER_NM = sim_common.M_PER_NM

failures = 0


def report(passed, name, detail):
    global failures
    if passed:
        messages.ok(name + ": " + detail)
    else:
        failures += 1
        messages.fail(name + ": " + detail)


def make_sim(seed, scenario, changes=None):
    # A Sim in this process. Messages to the display are collected in sim.sent.
    cfg = copy.deepcopy(CFG)
    cfg["general"]["scenario"] = scenario
    cfg["general"]["write_chart"] = False          # test 7 looks at the chart; the others need not write one
    for path, value in (changes or {}).items():
        sim_config.put_value(cfg, path, value)
    messages.message_verbosity = 0
    try:
        sim = sim_main.Sim(cfg, seed)
    finally:
        messages.message_verbosity = None
    sim.sent = []
    sim.send = sim.sent.append
    return sim


def quiet(function, *arguments):
    messages.message_verbosity = 0
    try:
        return function(*arguments)
    finally:
        messages.message_verbosity = None


def contact_list(sim):
    # Random traffic spawns during the first physics steps, so the list is taken after 20 steps (2 s).
    for _ in range(20):
        quiet(sim.physics_step)
    return [(c.id, c.kind, round(c.x_nm, 6), round(c.y_nm, 6), round(c.heading_deg_true, 3), round(c.speed_kn, 3))
            for c in sim.traffic.contacts]


# ---------------------------------------------------------------- 1 new_run

def test_1_new_run():
    sim = make_sim(5, "random")
    first = contact_list(sim)
    quiet(sim.handle_new_run, 5, "random")
    again = contact_list(sim)
    quiet(sim.handle_new_run, 6, "random")
    other = contact_list(sim)
    hellos = [m for m in sim.sent if m["t"] == "hello"]
    quiet(sim.handle_new_run, 9, "calibration")
    calibration = [c[0] for c in contact_list(sim)]
    quiet(sim.handle_new_run, -1, "random")          # not understood: the run stays as it is
    answered = sim.sent[-1]["t"]
    kept = [c[0] for c in contact_list(sim)]
    report(first == again and len(first) > 0 and first != other and len(hellos) == 2
           and len(calibration) == 9 and kept == calibration
           and answered == "log",
           "1 new_run", "seed 5 twice gives the same %d contacts after 2 s of the run; seed 6 gives %d different ones; hello sent after each "
           "run (%d); calibration has %d contacts; seed -1 is answered with a log line and changes nothing"
           % (len(first), len(other), len(hellos), len(calibration)))


# ---------------------------------------------------------------- 2 setup controls

SETUP_PATHS = ["environment.wind_from_deg_true", "environment.wind_speed_kn", "environment.sea_state_from_wind",
               "environment.sea_state_douglas", "environment.current_set_deg_true", "environment.current_drift_kn",
               "environment.rain_rate_mm_per_h", "traffic.max_contacts", "traffic.density_per_100_nm2",
               "general.sim_speed_multiplier", "display.instructor_overlay"]

# Section 8.2: the highest wind speed (kn) of each Douglas state, written out here from the brief, not taken from the code.
WIND_TABLE = [(0, 0), (3, 0), (4, 1), (6, 1), (7, 2), (10, 2), (11, 3), (16, 3), (17, 4), (21, 4), (22, 5), (27, 5),
              (28, 6), (33, 6), (34, 7), (40, 7), (41, 8), (60, 8)]


def last_setting(sim, path):
    values = [m["value"] for m in sim.sent if m["t"] == "setting" and m["path"] == path]
    return values[-1] if values else None


def test_2_setup_controls():
    sim = make_sim(1, "random")
    controls = {c["path"]: c for c in sim.hello_message()["controls"]}
    missing = [p for p in SETUP_PATHS if p not in controls]
    problems = []
    for path in SETUP_PATHS:
        if path in controls:
            control = controls[path]
            if "choices" not in control and not ("min" in control and "max" in control and control["step"] > 0):
                problems.append("%s has no range" % path)

    # Each setup control: a set is confirmed by a setting message with the same path.
    tests = [("environment.wind_from_deg_true", 123.0), ("environment.current_set_deg_true", 45.0),
             ("environment.current_drift_kn", 1.5), ("environment.rain_rate_mm_per_h", 20.0), ("traffic.max_contacts", 12),
             ("traffic.density_per_100_nm2", 2.5), ("general.sim_speed_multiplier", 5.0),
             ("display.instructor_overlay", True)]
    for path, value in tests:
        sim.sent.clear()
        quiet(sim.handle_set, path, value)
        if last_setting(sim, path) != value:
            problems.append("%s: set %r answered %r" % (path, value, last_setting(sim, path)))

    # Douglas by hand switches "from wind" off, and the settings say so.
    sim.sent.clear()
    quiet(sim.handle_set, "environment.sea_state_from_wind", True)
    on = last_setting(sim, "environment.sea_state_from_wind")
    sim.sent.clear()
    quiet(sim.handle_set, "environment.sea_state_douglas", 6)
    off = last_setting(sim, "environment.sea_state_from_wind")
    douglas = last_setting(sim, "environment.sea_state_douglas")
    state = sim.environment.state_for_display()["sea_state_douglas"]
    if not (on is True and off is False and douglas == 6 and state == 6):
        problems.append("douglas by hand: from_wind %r then %r, douglas %r, state %r" % (on, off, douglas, state))

    # With "from wind" on, every wind speed gives the Douglas state of the table.
    quiet(sim.handle_set, "environment.sea_state_from_wind", True)
    wrong = []
    for wind_kn, expected in WIND_TABLE:
        quiet(sim.handle_set, "environment.wind_speed_kn", float(wind_kn))
        got = sim.environment.state_for_display()["sea_state_douglas"]
        if got != expected:
            wrong.append("%d kn -> %d (table %d)" % (wind_kn, got, expected))
    if wrong:
        problems.append("wind table: " + "; ".join(wrong))
    report(not missing and not problems, "2 setup controls",
           "%d setup paths are in hello.controls with ranges; each set is confirmed; sea_state_douglas by hand switches "
           "sea_state_from_wind off and the setting message says so; %d wind speeds give the Douglas state of Section 8.2%s"
           % (len(SETUP_PATHS), len(WIND_TABLE), "" if not (missing or problems) else "; PROBLEMS: %s %s" % (missing, problems)))


# ---------------------------------------------------------------- 3 grounding

def place_for_grounding(sim):
    # Puts own ship 0.1 nm off the coast, heading at it, 10 kn, no current, no traffic.
    # Returns the distance to land from the new position, or None if no coast was found.
    land = sim.land
    best = None
    for bearing in range(0, 360, 5):
        for start_x_nm, start_y_nm in [(sim.own_ship.x_nm, sim.own_ship.y_nm)]:
            distance = land.first_land_along(start_x_nm, start_y_nm, float(bearing), 25.0)
            if distance is not None and distance > 0.5 and (best is None or distance < best[0]):
                best = (distance, bearing, start_x_nm, start_y_nm)
    if best is None:
        return None
    distance, bearing, x_nm, y_nm = best
    x_nm += (distance - 0.1) * math.sin(math.radians(bearing))
    y_nm += (distance - 0.1) * math.cos(math.radians(bearing))
    sim.own_ship = sim_ownship.OwnShip(sim.cfg, sim.random_streams["own_ship"], x_nm, y_nm, float(bearing), 10.0)
    sim.traffic.contacts.clear()
    sim.traffic.spawning = False
    sim.game.aground = False
    return land.first_land_along(x_nm, y_nm, float(bearing), 25.0)


def run_steps(sim, seconds, until=None):
    # Physics steps of the sim, stopping early when until() is true or the sim is paused.
    steps = int(seconds / sim.physics_step_s)
    for _ in range(steps):
        if sim.paused:
            break
        quiet(sim.physics_step)
        if until is not None and until():
            break


def events_of(sim, kind):
    return [m for m in sim.sent if m["t"] == "event" and m["kind"] == kind]


def test_3_grounding():
    results = []
    for mode in ("stop", "ignore"):
        sim = make_sim(1, "random", {"game.on_grounding": mode, "environment.current_drift_kn": 0.0})
        left_nm = place_for_grounding(sim)
        if left_nm is None:
            report(False, "3 grounding", "no coast within 25 nm of the start (seed 1)")
            return
        run_steps(sim, 120.0)
        first = events_of(sim, "grounding")
        paused_after = sim.paused
        time_of_event = sim.sim_time_s
        sim.paused = False                          # P
        run_steps(sim, 60.0)
        after = events_of(sim, "grounding")
        results.append((mode, left_nm, len(first), paused_after, time_of_event, len(after), sim.paused,
                        first[0]["text"] if first else None))
    stop, ignore = results
    ok = (stop[2] == 1 and stop[3] is True and stop[5] == 1
          and ignore[2] == 1 and ignore[3] is False and ignore[5] == 1 and ignore[6] is False)
    report(ok, "3 grounding",
           "own ship %.2f nm from land at 10 kn: stop: %d event ('%s') at t = %.0f s, sim paused %s, %d event after P; "
           "ignore: %d event, never paused (%s), %d after 60 s more"
           % (stop[1], stop[2], stop[7], stop[4], stop[3], stop[5], ignore[2], ignore[3] is False, ignore[5]))


# ---------------------------------------------------------------- 4 collision

def run_calibration(mode, current_kn, seconds):
    # Calibration scenario, own ship north at 10 kn. Returns the events and, for every contact, the least
    # distance in m over the run, with the collision limit in m.
    sim = make_sim(1, "calibration", {"game.on_collision": mode, "environment.current_drift_kn": current_kn})
    least_m = {}
    limits_m = {}
    names = {c.id: (c.kind if c.name is None else "%s %s" % (c.kind, c.name)) for c in sim.traffic.contacts}
    own_length_m = sim.cfg["own_ship"]["length_m"]
    factor = sim.cfg["game"]["collision_distance_factor"]
    resumed = 0
    steps = int(seconds / sim.physics_step_s)
    for _ in range(steps):
        if sim.paused:
            sim.paused = False                      # P
            resumed += 1
        quiet(sim.physics_step)
        for contact in sim.traffic.contacts:
            distance_m = math.hypot(contact.x_nm - sim.own_ship.x_nm, contact.y_nm - sim.own_ship.y_nm) * M_PER_NM
            if distance_m < least_m.get(contact.id, 1e18):
                least_m[contact.id] = distance_m
            limits_m[contact.id] = factor * (own_length_m + contact.length_m) / 2.0
    events = events_of(sim, "collision")
    return sim, events, names, least_m, limits_m, resumed


def test_4_collision():
    parts = []
    ok = True
    # Own ship on a collision course with S4 (and with buoy B1 on the way): each limit crossed gives one event.
    sim, events, names, least_m, limits_m, resumed = run_calibration("stop", 0.0, 1900.0)
    hit = sorted(names[i] for i in names if least_m[i] < limits_m[i])
    got = sorted(e["text"] for e in events)
    expected = sorted("Collision (%s)" % name for name in hit)
    ok = ok and got == expected and "Collision (ship S4)" in got and resumed == len(events)
    parts.append("collision course, 31 min, on_collision stop: %d events %s, least distances inside the limit for %s; "
                 "the sim paused %d times, P resumed each" % (len(events), got, hit, resumed))
    # With the current setting own ship drifts clear: contacts that pass clear raise none.
    sim, events, names, least_m, limits_m, resumed = run_calibration("ignore", 0.5, 2400.0)
    hit = sorted(names[i] for i in names if least_m[i] < limits_m[i])
    got = sorted(e["text"] for e in events)
    expected = sorted("Collision (%s)" % name for name in hit)
    ok = ok and got == expected and resumed == 0
    s4 = least_m[[i for i in names if names[i] == "ship S4"][0]]
    parts.append("0.5 kn current, 40 min, on_collision ignore: %d events %s; S4 passed at %.0f m (limit %.1f m); never paused"
                 % (len(events), got, s4, limits_m[[i for i in names if names[i] == "ship S4"][0]]))
    report(ok, "4 collision", "; ".join(parts))


# ---------------------------------------------------------------- 6 soak

def process_memory_mb():
    # Resident memory of this process in MB, with no extra package.
    try:
        with open("/proc/self/status") as status:
            for line in status:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) / 1024.0                 # kB -> MB
    except OSError:
        pass
    import ctypes
    from ctypes import wintypes

    class Counters(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD), ("PeakWorkingSetSize", ctypes.c_size_t),
                    ("WorkingSetSize", ctypes.c_size_t), ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPagedPoolUsage", ctypes.c_size_t), ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaNonPagedPoolUsage", ctypes.c_size_t), ("PagefileUsage", ctypes.c_size_t),
                    ("PeakPagefileUsage", ctypes.c_size_t)]
    counters = Counters()
    counters.cb = ctypes.sizeof(Counters)
    handle = ctypes.windll.kernel32.GetCurrentProcess()
    ctypes.windll.psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb)
    return counters.WorkingSetSize / (1024.0 * 1024.0)                  # bytes -> MB


def test_7_chart():
    # The practice chart: the land and lanes of a generated scenario (a small, quick land square) and the
    # buoys of the calibration scenario; the border's latitude scale is 1 nm per minute.
    import tempfile
    import re
    import sim_chart
    folder = tempfile.mkdtemp()
    path = os.path.join(folder, "chart.svg")
    sim = make_sim(5, "random", {"general.land_extent_nm": 30.0, "general.land_cell_nm": 0.05})
    sim.cfg["general"]["chart_file"] = path
    sim.write_chart(5, "random", (0.0, 0.0, 90.0))
    with open(path, encoding="utf-8") as svg_file:
        text = svg_file.read()
    has_lanes = "COASTAL" in text and "(TWO-WAY)" in text and "data:image/png;base64," in text
    # Latitude border boxes: the white and black boxes along the left edge are one minute of latitude, SCALE units each.
    heights = sorted(set(round(float(h), 1) for h in re.findall(r'<rect x="[\d.]+" y="[\d.]+" width="8.0" height="([\d.]+)"', text)))
    full_boxes = [h for h in heights if abs(h - sim_chart.SCALE) < 0.2]
    sim.handle_frame(sim_protocol.FRAME_JSON, sim_protocol.encode_json({"t": "chart"}))
    replies = [message for message in sim.sent if message.get("t") == "chart"]
    with open(path, encoding="utf-8") as svg_file:
        now_text = svg_file.read()
    report(len(replies) == 1 and replies[0]["path"] == path and ">Own ship<" in now_text and ">Own ship start<" not in now_text,
           "7 chart on request", "a chart message from the display writes the chart with own ship where it is and replies with its path")
    report(has_lanes and len(full_boxes) == 1, "7 chart (random)",
           "SVG of %d kB with the shading picture and the lane names; border boxes of %.1f units = 1 nm (found %s)"
           % (len(text) // 1024, sim_chart.SCALE, heights[:4]))
    calibration = make_sim(5, "calibration")
    calibration.cfg["general"]["chart_file"] = path
    calibration.write_chart(5, "calibration", (0.0, 0.0, 0.0))
    with open(path, encoding="utf-8") as svg_file:
        text = svg_file.read()
    report(all(">B%d<" % number in text for number in (1, 2, 3, 4)) and "Own ship start" in text,
           "7 chart (calibration)", "the four buoys B1 to B4 and own ship's start are on the open-sea chart")


def test_8_wheelhouse_data():
    # The data of the wheelhouse view: the land as one byte per cell, and own ship and the contacts.
    import base64
    import numpy as np
    sim = make_sim(5, "random", {"general.land_extent_nm": 30.0, "general.land_cell_nm": 0.05})
    message = sim.land_view_message()
    cells = np.frombuffer(base64.b64decode(message["data"]), dtype=np.uint8)
    size = message["size"]
    highest_m = float(sim.land.heights_m.max())
    ok_land = (size > 0 and cells.size == size * size and abs(message["west_nm"] + 15.0) < 1e-9
               and abs(cells.max() * message["height_step_m"] - highest_m) <= message["height_step_m"] and cells.max() > 0)
    report(ok_land, "8 wheelhouse land", "%d x %d cells of %.3f nm, highest %.0f m sent as %.0f m (step %.0f m)"
           % (size, size, message["cell_nm"], highest_m, cells.max() * message["height_step_m"], message["height_step_m"]))
    sim.handle_frame(sim_protocol.FRAME_JSON, sim_protocol.encode_json({"t": "view", "enabled": True}))
    view = sim.view_message()
    own = view["own"]
    ok_view = (sim.view_enabled and set(own) == {"x_nm", "y_nm", "heading_deg_true", "gyro_heading_deg"}
               and {"wind_from_deg_true", "wind_speed_kn", "sea_state_douglas"} <= set(view["env"])
               and all(set(c) >= {"id", "kind", "x_nm", "y_nm", "course_deg_true", "speed_kn", "length_m"} for c in view["contacts"]))
    sim.handle_frame(sim_protocol.FRAME_JSON, sim_protocol.encode_json({"t": "view", "enabled": False}))
    calibration = make_sim(5, "calibration")
    sea = calibration.land_view_message()
    report(ok_view and not sim.view_enabled and sea["size"] == 0 and len(calibration.view_message()["contacts"]) == 9,
           "8 wheelhouse view", "view message holds own ship and %d contacts; enable and disable work; open sea sends no land cells"
           % len(view["contacts"]))


def test_9_lane_marks():
    # The buoys along the lanes (BRIEF.md Section 8.6): placed from the lane geometry, in the right colours,
    # present only near own ship, outside the traffic count and the traffic's random numbers, seen by the radar,
    # shown to the wheelhouse view, and something own ship can hit.
    import numpy as np
    import sim_contacts
    import sim_land
    import sim_radar
    changes = {"general.land_extent_nm": 30.0, "general.land_cell_nm": 0.05}
    sim = make_sim(5, "random", changes)
    traffic = sim.traffic
    land = sim.land
    lanes = {lane.name: lane for lane in land.lanes}
    problems = []
    approach = lanes[sim_land.HARBOUR_APPROACH]
    by_colour = {"red": [], "green": []}
    harbour = np.asarray(approach.points_nm, dtype=float)[-1]
    sides = {}                                       # the side of the direction of buoyage each lane's marks are on
    for mark in traffic.marks:
        by_colour[mark.colour].append(mark)
        lane = lanes[mark.lane]
        offset_nm = sim_land.distance_to_polyline_nm(mark.x_nm, mark.y_nm, lane.points_nm)
        if abs(offset_nm - lane.width_nm / 2.0) > 0.01:
            problems.append("%s is %.3f nm from its lane's centre line, expected %.3f" % (mark.name, offset_nm, lane.width_nm / 2.0))
        if land.is_land_point(mark.x_nm, mark.y_nm):
            problems.append("%s is on land" % mark.name)
        if (mark.shape == "can") != (int(mark.name[1:]) % 2 == 1):
            problems.append("%s: shape %s does not match its number (port can, odd)" % (mark.name, mark.shape))
    # Region B: facing the direction of buoyage (toward the harbour), red is to starboard and green to port, on every lane.
    for lane in land.lanes:
        points = np.asarray(lane.points_nm, dtype=float)
        if lane.name != sim_land.HARBOUR_APPROACH and np.hypot(*(points[0] - harbour)) < np.hypot(*(points[-1] - harbour)):
            points = points[::-1]
        for mark in traffic.marks:
            if mark.lane != lane.name:
                continue
            # the direction of the lane segment nearest the buoy
            steps = np.diff(points, axis=0)
            mids = (points[:-1] + points[1:]) / 2.0
            index = int(np.argmin(np.hypot(mids[:, 0] - mark.x_nm, mids[:, 1] - mark.y_nm)))
            direction = steps[index] / np.hypot(steps[index, 0], steps[index, 1])
            right = np.array([direction[1], -direction[0]])
            side = float(np.dot(np.array([mark.x_nm, mark.y_nm]) - mids[index], right))
            if (mark.colour == "red") != (side > 0.0):
                problems.append("%s (%s) is on the wrong side going toward the harbour" % (mark.name, mark.colour))
    red_numbers = [int(mark.name[1:]) for mark in by_colour["red"]]
    green_numbers = [int(mark.name[1:]) for mark in by_colour["green"]]
    if not (red_numbers and all(n % 2 == 0 for n in red_numbers) and all(n % 2 == 1 for n in green_numbers)):
        problems.append("red buoys are not even-numbered and green odd: %s %s" % (red_numbers[:4], green_numbers[:4]))
    if len(by_colour["red"]) < 4 or len(by_colour["green"]) < 4 or len({m.lane for m in traffic.marks}) < 2:
        problems.append("marks: %d red, %d green in %d lanes" % (len(by_colour["red"]), len(by_colour["green"]), len({m.lane for m in traffic.marks})))
    codes = {m.light["code"] for m in traffic.marks}
    if not (any(c.startswith("Q ") for c in codes) and any(c.startswith("Fl(2) ") for c in codes) and any(c.startswith("Iso ") for c in codes)
            and any(c.startswith("Fl ") for c in codes)):
        problems.append("light rhythms: %s" % sorted(codes)[:8])
    for m in traffic.marks:
        flashes = m.light["flashes"]
        if not flashes or any(s < 0.0 or s + d > m.light["period_s"] for s, d in flashes) or m.light["code"][-1] not in "sG R".replace(" ", "") + "0123456789" and False:
            problems.append("%s has a bad flash pattern" % m.name)
    # No buoy inside another lane (the approach must be open where it leaves the through lane).
    for mark in traffic.marks:
        for lane in land.lanes:
            if lane.name != mark.lane and sim_land.distance_to_polyline_nm(mark.x_nm, mark.y_nm, lane.points_nm) < lane.width_nm / 2.0:
                problems.append("%s lies inside lane %s" % (mark.name, lane.name))
    # Region A turns the colours round and keeps the shapes by side.
    region_a = make_sim(5, "random", dict(changes, **{"traffic.buoyage_region": "A"}))
    same = len(region_a.traffic.marks) == len(traffic.marks)
    flipped = same and all(a.colour != b.colour and a.shape == b.shape and (a.x_nm, a.y_nm) == (b.x_nm, b.y_nm)
                           for a, b in zip(region_a.traffic.marks, traffic.marks))
    if not flipped:
        problems.append("region A is not region B with the colours exchanged")
    ok_geometry = not problems
    report(ok_geometry, "9 lane marks placed", "%d red and %d green buoys in %d lanes (even/odd, red to starboard going toward the harbour, can to port), "
           "rhythms %s, all on a lane edge, on water and clear of the other lanes; region A exchanges the colours%s"
           % (len(by_colour["red"]), len(by_colour["green"]), len({m.lane for m in traffic.marks}), sorted(codes)[:4],
              "" if ok_geometry else ": " + "; ".join(problems[:4])))

    # Present only near own ship, with a fixed id, and kept out of the traffic.
    traffic.mark_contacts.clear()                      # the run made some for own ship's own start
    traffic.update_marks(0.0, 0.0)
    near = dict(traffic.mark_contacts)
    radius_nm = sim.cfg["traffic"]["mark_radius_nm"]
    inside = [m for m in traffic.marks if math.hypot(m.x_nm, m.y_nm) <= radius_nm]
    ids_ok = all(c.id == sim_contacts.MARK_ID_BASE + number and c.kind == "buoy" and c.behaviour == "fixed" for number, c in near.items())
    count_before = len(traffic.contacts)
    far_x = max(m.x_nm for m in traffic.marks)
    far_y = [m.y_nm for m in traffic.marks if m.x_nm == far_x][0]
    traffic.update_marks(far_x, far_y)
    moved = set(traffic.mark_contacts)
    traffic.update_marks(0.0, 0.0)
    back_ok = all(number in traffic.mark_contacts and traffic.mark_contacts[number].id == c.id for number, c in near.items())
    ok_near = len(near) == len(inside) and len(inside) > 5 and ids_ok and len(traffic.contacts) == count_before and moved != set(near) and back_ok
    report(ok_near, "9 lane marks near own ship", "%d of %d buoys within %.0f nm of the start exist, with fixed ids; they are not in the traffic list (%d vessels); "
           "away from the start another set exists and the same ids return" % (len(near), len(traffic.marks), radius_nm, len(traffic.contacts)))

    # The traffic does not change when the buoys are switched off (no random numbers are used for them).
    def run_traffic(lane_marks):
        other = make_sim(5, "random", dict(changes, **{"traffic.lane_marks": lane_marks}))
        t = other.traffic
        for step in range(1, 1800):
            t.step(1.0, float(step), 0.0, 0.0, 0.0, 0.0)
        return [(c.kind, round(c.x_nm, 6), round(c.y_nm, 6)) for c in t.contacts], len(t.marks), len(t.mark_contacts)
    with_marks, marks_on, near_on = run_traffic(True)
    without_marks, marks_off, near_off = run_traffic(False)
    report(with_marks == without_marks and marks_on > 0 and marks_off == 0 and near_off == 0 and near_on > 0,
           "9 traffic unchanged", "30 min of traffic gives the same %d vessels at the same places with %d buoys and with none (lane_marks = false)"
           % (len(with_marks), marks_on))

    # The radar, the wheelhouse view, the chart and the collision test see them.
    sim.traffic.update_marks(0.0, 0.0)
    ids = sim_radar.scatterers_of(sim.traffic.everything())[0]
    mark_ids = [c.id * 8 for c in sim.traffic.mark_contacts.values()]
    radar_ok = all(i in set(ids.tolist()) for i in mark_ids) and len(mark_ids) > 5
    entries = [e for e in sim.traffic.truth_for_display() if "mark" in e]
    entry_ok = (len(entries) == len(mark_ids) and all(set(e["mark"]) == {"colour", "shape", "light", "lane"} for e in entries)
                and all(set(e["mark"]["light"]) == {"colour", "period_s", "flash_s", "flashes", "code"} for e in entries)
                and all(e["kind"] == "buoy" for e in entries)
                and not any("mark" in e for e in sim.traffic.truth_for_display() if e["kind"] != "buoy"))
    target = next(iter(sim.traffic.mark_contacts.values()))
    sim.own_ship.x_nm, sim.own_ship.y_nm = target.x_nm, target.y_nm
    events = sim.game.check(sim.own_ship, sim.traffic.everything(), sim.land)
    hit_ok = any(kind == "collision" and target.name in text for kind, text in events)
    report(radar_ok and entry_ok and hit_ok, "9 lane marks seen", "%d buoys are radar scatterers; the view message gives each its colour, shape and light; "
           "own ship on %s reports %s" % (len(mark_ids), target.name, [text for kind, text in events]))

    # Switched off: nothing.
    off = make_sim(5, "random", dict(changes, **{"traffic.lane_marks": False}))
    off.traffic.update_marks(0.0, 0.0)
    calibration = make_sim(5, "calibration")
    report(len(off.traffic.marks) == 0 and len(off.traffic.mark_contacts) == 0 and len(calibration.traffic.marks) == 0,
           "9 lane marks off", "lane_marks = false gives no buoys; the calibration scenario has none")


def test_6_soak(minutes):
    # The Sim class, the radar and the ARPA, 20 targets tracked, run as fast as this PC allows. The achieved
    # speed is sim time over wall time; the brief asks for 10x.
    sim = make_sim(3, "random", {"traffic.density_per_100_nm2": 3.0, "traffic.max_contacts": 40,
                                 "general.sim_speed_multiplier": 10.0})
    # A guard zone makes the radar run, so plots exist; then acquire the nearest 20 contacts.
    sim.arpa.set_guard_zone(1, True, 0.2, 0.3, 0.0, 359.0)
    quiet(sim.physics_step)
    tracked = 0
    for _ in range(int(600.0 / sim.physics_step_s)):
        if len(sim.arpa.tracks) >= 20:
            break
        quiet(sim.physics_step)
        if sim.sim_time_s % 5.0 < sim.physics_step_s:
            near = sorted(sim.traffic.contacts, key=lambda c: math.hypot(c.x_nm - sim.own_ship.x_nm, c.y_nm - sim.own_ship.y_nm))
            for contact in near:
                dx = contact.x_nm - sim.own_ship.x_nm
                dy = contact.y_nm - sim.own_ship.y_nm
                quiet(sim.arpa.acquire, math.hypot(dx, dy), math.degrees(math.atan2(dx, dy)) % 360.0)
                if len(sim.arpa.tracks) >= 20:
                    break
    sim.arpa.set_guard_zone(1, False, 0.2, 0.3, 0.0, 359.0)
    tracked = len(sim.arpa.tracks)
    start_mb = process_memory_mb()
    start_sim_s = sim.sim_time_s
    wall_start = time.perf_counter()
    problem = None
    try:
        for _ in range(int(minutes * 60.0 / sim.physics_step_s)):
            quiet(sim.physics_step)
            sim.sent.clear()                        # the display is not reading
            if sim.sim_time_s % 600.0 < sim.physics_step_s:
                messages.info("Soak: %.0f of %.0f sim-minutes, %.0f MB" % ((sim.sim_time_s - start_sim_s) / 60.0, minutes,
                                                                          process_memory_mb()), verbosity=0)
    except Exception as error:                      # any failure is the result
        problem = "%s: %s" % (type(error).__name__, error)
    wall_s = time.perf_counter() - wall_start
    end_mb = process_memory_mb()
    speed = (sim.sim_time_s - start_sim_s) / wall_s
    growth = 100.0 * (end_mb - start_mb) / start_mb
    report(problem is None and growth < 20.0 and tracked >= 20,
           "6 soak", "%.0f sim-minutes with %d targets tracked at the start (%d at the end) in %.0f s of wall time: achieved "
           "%.1f x (10 x asked for); memory %.0f MB at the start, %.0f MB at the end, %+.1f %% (limit 20 %%); exception: %s"
           % (minutes, tracked, len(sim.arpa.tracks), wall_s, speed, start_mb, end_mb, growth, problem or "none"))


def test_10_rain():
    # The rain cell count and size can be changed while running, and the view message carries the cells.
    sim = make_sim(5, "random", {"environment.rain_rate_mm_per_h": 12.0, "environment.rain_cell_count": 3})
    env = sim.environment
    sim.view_message()
    first = sim.view_message()["rain"]
    sim.cfg["environment"]["rain_cell_count"] = 6
    sim.cfg["environment"]["rain_cell_radius_nm"] = 2.5
    env.step(0.1, sim.own_ship.x_nm, sim.own_ship.y_nm)
    grown = len(env.cell_x_nm)
    sim.cfg["environment"]["rain_cell_count"] = 2
    env.step(0.1, sim.own_ship.x_nm, sim.own_ship.y_nm)
    shrunk = len(env.cell_x_nm)
    sim.cfg["environment"]["rain_cell_count"] = 5
    env.step(0.1, sim.own_ship.x_nm, sim.own_ship.y_nm)
    # a cell placed on own ship gives the full rate at the cell centre, and the message names it
    env.cell_x_nm[0], env.cell_y_nm[0] = sim.own_ship.x_nm + 1.0, sim.own_ship.y_nm
    message = sim.view_message()["rain"]
    rate_at_centre = float(env.rain_rate_at(np.array([sim.own_ship.x_nm + 1.0]), np.array([sim.own_ship.y_nm]))[0])
    sim.cfg["environment"]["rain_rate_mm_per_h"] = 0.0
    dry = sim.view_message()["rain"]
    ok = (first["peak_mm_per_h"] == 12.0 and abs(first["radius_nm"] - 4.0) < 1e-9 and grown == 6 and shrunk == 2 and len(env.cell_x_nm) == 5
          and abs(message["radius_nm"] - 2.5) < 1e-9 and [round(sim.own_ship.x_nm + 1.0, 3), round(sim.own_ship.y_nm, 3)] in message["cells"]
          and abs(rate_at_centre - 12.0) < 1e-6 and dry["cells"] == [] and dry["peak_mm_per_h"] == 0.0)
    report(ok, "10 rain controls", "the rain cell count (3 to 6 to 2 to 5) and radius (4 to 2.5 nm) follow the settings while running; the view message gives the "
           "peak rate (12 mm/h), the radius and the cell centres, and nothing when the rate is 0; the rate at a cell's centre is %.1f mm/h" % rate_at_centre)


def test_11_traffic_now():
    # The TRAFFIC NOW button: the count follows the density setting at once, in both directions, and nothing is put near own ship.
    import math
    sim = make_sim(5, "random", {"general.land_extent_nm": 30.0, "general.land_cell_nm": 0.05})
    traffic = sim.traffic
    for step in range(1, 61):
        traffic.step(1.0, float(step), 0.0, 0.0, 0.0, 0.0)
    start = len(traffic.contacts)
    sim.cfg["traffic"]["density_per_100_nm2"] = 3.0
    sim.cfg["traffic"]["max_contacts"] = 200
    sim.sent.clear()
    sim.handle_frame(sim_protocol.FRAME_JSON, sim_protocol.encode_json({"t": "traffic_now"}))
    more = len(traffic.contacts)
    wanted = round(math.pi * traffic.traffic["active_radius_nm"] ** 2 * 3.0 / 100.0)
    near = [c for c in traffic.contacts if math.hypot(c.x_nm, c.y_nm) < 1.5 and c.age_s == 0.0]
    logged = [m for m in sim.sent if m.get("t") == "log" and "Traffic set to" in m.get("text", "")]
    sim.cfg["traffic"]["density_per_100_nm2"] = 0.5
    sim.handle_frame(sim_protocol.FRAME_JSON, sim_protocol.encode_json({"t": "traffic_now"}))
    fewer = len(traffic.contacts)
    wanted_fewer = round(math.pi * traffic.traffic["active_radius_nm"] ** 2 * 0.5 / 100.0)
    calibration = make_sim(5, "calibration")
    before = len(calibration.traffic.contacts)
    calibration.handle_frame(sim_protocol.FRAME_JSON, sim_protocol.encode_json({"t": "traffic_now"}))
    ok = (more == wanted and fewer == wanted_fewer and start != more and not near and len(logged) == 1
          and len(calibration.traffic.contacts) == before)
    report(ok, "11 traffic now", "density 3 per 100 nm2: %d contacts at once (wanted %d, was %d), none new within 1.5 nm of own ship; density 0.5: %d (wanted %d); "
           "the calibration scenario is left alone" % (more, wanted, start, fewer, wanted_fewer))


def test_12_lane_ship():
    # A ship in a traffic lane keeps to it: head-on with own ship on its own track in a two-way lane it slows and shifts a little
    # (staying inside the lane) and accepts the smaller in-lane CPA, instead of turning 35 deg out of the lane.
    def meet(own_offset_nm, in_lane_cpa_nm):
        sim = make_sim(5, "random", {"general.land_extent_nm": 30.0, "general.land_cell_nm": 0.05,
                                     "traffic.colregs_cpa_limit_in_lane_nm": in_lane_cpa_nm})
        traffic = sim.traffic
        traffic.spawning = False
        traffic.contacts.clear()
        ship = traffic.start_on_route("ship", 0, 1, 40.0, 12.0, 12.0)         # the coastal lane, 2 nm wide, two-way
        traffic.contacts.append(ship)
        heading = math.radians(ship.heading_deg_true)
        own_x = ship.x_nm + 6.0 * math.sin(heading) + own_offset_nm * math.cos(heading)
        own_y = ship.y_nm + 6.0 * math.cos(heading) - own_offset_nm * math.sin(heading)
        own_vx, own_vy = -10.0 * math.sin(heading), -10.0 * math.cos(heading)
        closest = 99.0
        worst_share = 0.0
        slowest = 99.0
        steps_in_lane = 0
        largest_turn = 0.0
        for step in range(30 * 60):
            traffic.step(1.0, float(step), own_x, own_y, own_vx, own_vy)
            own_x += own_vx / 3600.0
            own_y += own_vy / 3600.0
            closest = min(closest, math.hypot(ship.x_nm - own_x, ship.y_nm - own_y))
            if ship.lane_half_nm:
                worst_share = max(worst_share, abs(ship.lane_right_nm) / ship.lane_half_nm)
            slowest = min(slowest, ship.speed_kn)
            steps_in_lane += 1 if ship.give_way_in_lane else 0
            largest_turn = max(largest_turn, abs((ship.heading_deg_true - ship.lane_heading_deg + 180.0) % 360.0 - 180.0))
        return closest, worst_share, slowest, steps_in_lane, largest_turn
    closest, share, slowest, in_lane, turn = meet(0.0, 0.25)
    ok = in_lane > 0 and share <= 1.0 and slowest < 11.0 and closest >= 0.2 and turn < 30.0
    report(ok, "12 lane ship", "head-on on its own track in a 2 nm lane: gave way inside the lane for %d s (slowed to %.1f kn from 12, largest "
           "course change %.0f deg, never more than %.2f of the half width from the centre line), closest %.2f nm (in-lane limit 0.25)"
           % (in_lane, slowest, turn, share, closest))
    # With the CPA limit raised to the open-water 1.0 nm the same ship still gives way, so the setting is what sets it.
    close_loose, _, _, _, _ = meet(0.0, 1.0)
    report(close_loose >= closest - 0.05, "12 lane ship limit", "with the in-lane limit at 1.0 nm the closest approach is %.2f nm (0.25 nm: %.2f)" % (close_loose, closest))


def test_13_rogue():
    # Misbehaving ships: the share follows the setting, the switches choose the mistakes, and each mistake does what it says.
    def scene(x_nm, y_nm, heading_deg, speed_kn, rogue_percent=100.0, only=None, minutes=40):
        # Own ship from the origin, 000 at 10 kn, doing nothing; one ship contact in open sea (the calibration scenario's sea).
        sim = make_sim(5, "calibration", {"traffic.rogue_percent": rogue_percent,
                                          "traffic.rogue_no_give_way": only in (None, "no_give_way"),
                                          "traffic.rogue_cross_bow": only in (None, "cross_bow"),
                                          "traffic.rogue_late": only in (None, "late")})
        traffic = sim.traffic
        traffic.contacts.clear()
        ship = traffic.add_contact("ship", x_nm, y_nm, heading_deg, speed_kn)
        ship.complies = True
        closest = 99.0
        first_turn_s = None
        for step in range(minutes * 60):
            own_y = 10.0 * step / 3600.0
            traffic.step(1.0, float(step), 0.0, own_y, 0.0, 10.0)
            closest = min(closest, math.hypot(ship.x_nm, ship.y_nm - own_y))
            if first_turn_s is None and abs((ship.heading_deg_true - heading_deg + 180.0) % 360.0 - 180.0) > 3.0:
                first_turn_s = float(step)
        return closest, first_turn_s, ship.rogue_now
    crossing = (-5.0, 5.0, 90.0, 10.0)                  # from own port side on a collision course: it is the give-way vessel
    good_closest, good_turn, good_type = scene(*crossing, rogue_percent=0.0)
    held_closest, held_turn, held_type = scene(*crossing, only="no_give_way")
    late_closest, late_turn, late_type = scene(*crossing, only="late")
    ok = (good_type is None and good_turn is not None and good_closest >= 0.5
          and held_type == "no_give_way" and held_turn is None and held_closest < 0.1
          and late_type == "late" and late_turn is not None and late_turn > good_turn + 120.0 and late_closest < good_closest)
    report(ok, "13 rogue: no give way, late", "crossing from port, 10 kn each: it turns at %.0f s and passes at %.2f nm when it behaves; as no_give_way it holds on "
           "(first turn %s) and passes at %.2f nm; as late it turns at %.0f s and passes at %.2f nm"
           % (good_turn or -1, good_closest, held_turn, held_closest, late_turn or -1, late_closest))
    parallel = (-1.3, 8.0, 180.0, 10.0)                 # coming the other way, passing 1.3 nm to port: no risk
    far_closest, far_turn, far_type = scene(*parallel, rogue_percent=0.0, minutes=60)
    bow_closest, bow_turn, bow_type = scene(*parallel, only="cross_bow", minutes=60)
    report(far_turn is None and far_closest > 1.0 and bow_type == "cross_bow" and bow_turn is not None and bow_closest < far_closest - 0.3,
           "13 rogue: cross bow", "a ship passing 1.3 nm off, head to head: %.2f nm when it behaves; as cross_bow it turns toward own ship's track (at %s s) and "
           "passes at %.2f nm" % (far_closest, bow_turn, bow_closest))
    # The share follows the setting and the switches.
    sim = make_sim(5, "calibration")
    traffic = sim.traffic
    traffic.contacts.clear()
    for index in range(1000):
        traffic.add_contact("ship", 20.0, float(index) * 0.01, 0.0, 10.0)
    def share(percent, **switches):
        for name in ROGUE_NAMES:
            traffic.traffic["rogue_" + name] = switches.get(name, True)
        traffic.traffic["rogue_percent"] = percent
        traffic.now_s += 1000.0
        traffic.check_colregs()
        kinds = {}
        for contact in traffic.contacts:
            kinds[contact.rogue_now] = kinds.get(contact.rogue_now, 0) + 1
        return kinds
    ROGUE_NAMES = ("no_give_way", "cross_bow", "late")
    three = share(3.0)
    ten = share(10.0)
    none = share(0.0)
    only_late = share(10.0, no_give_way=False, cross_bow=False)
    off = share(10.0, no_give_way=False, cross_bow=False, late=False)
    bad = lambda kinds: 1000 - kinds.get(None, 0)
    ok = (25 <= bad(three) <= 35 and 90 <= bad(ten) <= 110 and bad(none) == 0 and set(only_late) <= {None, "late"} and bad(only_late) >= 90 and bad(off) == 0
          and all(count > 0 for name, count in three.items() if name is not None) and len(three) == 4)
    report(ok, "13 rogue: share and switches", "of 1000 ships %d are bad at 3 %% (mixed over the three mistakes), %d at 10 %%, %d at 0 %%; with only 'late' on, "
           "%d at 10 %% and all of that kind; with all three off, %d" % (bad(three), bad(ten), bad(none), bad(only_late), bad(off)))


def test_14_mix():
    # The kind weights are runtime settings: TRAFFIC NOW builds the mix they ask for, and all-zero means equal.
    def build(weights):
        sim = make_sim(5, "random", {"general.land_extent_nm": 30.0, "general.land_cell_nm": 0.05})
        for kind, weight in weights.items():
            sim.cfg["traffic"]["mix_" + kind] = weight
        sim.cfg["traffic"]["density_per_100_nm2"] = 4.0
        sim.cfg["traffic"]["max_contacts"] = 200
        sim.handle_frame(sim_protocol.FRAME_JSON, sim_protocol.encode_json({"t": "traffic_now"}))
        counts = {}
        for contact in sim.traffic.contacts:
            counts[contact.kind] = counts.get(contact.kind, 0) + 1
        return counts, sim
    sails, sim = build({"ship": 0.0, "tug_tow": 0.0, "fishing": 0.0, "pleasure": 1.0})
    fish, _ = build({"ship": 0.0, "tug_tow": 0.0, "fishing": 1.0, "pleasure": 0.0})
    even, even_sim = build({"ship": 0.0, "tug_tow": 0.0, "fishing": 0.0, "pleasure": 0.0})
    total_even = max(1, sum(even.values()))
    ok = (len(sails) == 1 and "pleasure" in sails and sails["pleasure"] > 20
          and len(fish) == 1 and "fishing" in fish
          and all(0.1 < even.get(kind, 0) / total_even < 0.4 for kind in sim_config.TRAFFIC_KINDS)
          and abs(sum(even_sim.traffic.mix_fraction(kind) for kind in sim_config.TRAFFIC_KINDS) - 1.0) < 1e-12)
    report(ok, "14 traffic mix weights", "all weight on pleasure: %s; on fishing: %s; all four 0: %s" % (sails, fish, even))


def main():
    parser = argparse.ArgumentParser(description="Acceptance tests of M10, sim side")
    parser.add_argument("--soak", action="store_true", help="run the soak test (test 6) instead of tests 1 to 4")
    parser.add_argument("--minutes", type=float, default=30.0, help="sim-minutes of the soak (default 30)")
    arguments = parser.parse_args()
    if arguments.soak:
        test_6_soak(arguments.minutes)
    else:
        test_1_new_run()
        test_2_setup_controls()
        test_3_grounding()
        test_4_collision()
        test_7_chart()
        test_8_wheelhouse_data()
        test_9_lane_marks()
        test_10_rain()
        test_11_traffic_now()
        test_12_lane_ship()
        test_13_rogue()
        test_14_mix()
    if failures:
        messages.fail("%d test line(s) failed" % failures)
        sys.exit(1)
    messages.done("All M10 tests passed")


if __name__ == "__main__":
    main()
