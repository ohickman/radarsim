# sim_marks.py - the buoys that mark the traffic lanes (BRIEF.md Section 8.6).
# build_marks(land, traffic_cfg) lists every buoy of the run, once, from the lane geometry alone:
# no random numbers, so the same land always gets the same buoys and the traffic is unchanged.
#   - Every lane is buoyed with lateral marks, in gates of one buoy on each edge. The direction of
#     buoyage is toward the harbour (the harbour approach already runs sea to harbour; the other
#     lanes are turned to run toward it). Facing that way, IALA region B (the Americas) puts red to
#     starboard and green to port ("red right returning"); region A (traffic.buoyage_region) the
#     other way round. A port-hand buoy is a can, a starboard-hand buoy a cone (nun), in both regions.
#     Numbers rise from seaward, odd to port and even to starboard.
#   - Each gate has a light rhythm (Fl, Q, Fl(2), Iso) in the colour of the buoy; the first gate of
#     each lane is quick flashing, the others cycle through the rest. The chart prints the code.
# Chosen, not from a source: the spacings, the first gate 0.2 nm outside the lane the approach
# leaves, the rhythms and their order, the radar cross-sections and the buoy sizes.
# Units: positions nm (x east, y north), cross-sections m2, sizes m, times s.
# Called by: sim_contacts.Traffic (places the ones near own ship as fixed contacts), sim_main (chart).

import math
from dataclasses import dataclass

import numpy as np

from sim_land import HARBOUR_APPROACH, distance_to_polyline_nm

CLEAR_OF_OTHER_LANES_NM = 0.15   # a buoy stays this far outside any other lane's edge
CLEAR_OF_LAND_NM = 0.05          # and this far from land
FIRST_GATE_NM = 0.2              # the approach's first gate lies this far outside the lane it leaves
RCS_RANGE_M2 = (3.0, 10.0)       # a buoy with a radar reflector; each gets its own value from its number

# Light rhythms: name, period s, the flashes as (start s, duration s) within the period, chart text with {c} = colour letter.
RHYTHMS = {
    "Q": (1.0, [(0.0, 0.3)], "Q {c}"),
    "Fl4": (4.0, [(0.0, 0.5)], "Fl {c} 4s"),
    "Fl2": (6.0, [(0.0, 0.5), (1.5, 0.5)], "Fl(2) {c} 6s"),
    "Fl3": (3.0, [(0.0, 0.5)], "Fl {c} 3s"),
    "Iso4": (4.0, [(0.0, 2.0)], "Iso {c} 4s"),
}
LATER_GATES = ["Fl4", "Fl2", "Fl3", "Iso4"]       # after the first (quick flashing) gate of a lane, in turn
COLOUR_LETTER = {"red": "R", "green": "G"}


def light_for(colour, rhythm):
    period_s, flashes, text = RHYTHMS[rhythm]
    return {"colour": colour, "period_s": period_s, "flash_s": flashes[0][1], "flashes": [list(f) for f in flashes],
            "code": text.format(c=COLOUR_LETTER[colour])}


@dataclass
class Mark:
    number: int                  # 0, 1, 2 ... in the order built; the contact's id is MARK_ID_BASE + number
    name: str                    # "G1", "R2", "Y7"
    colour: str                  # "red" or "green"
    shape: str                   # "can" (port hand) or "nun" (starboard hand)
    x_nm: float
    y_nm: float
    rcs_m2: float
    lane: str
    light: dict                  # colour, period_s, flash_s, flashes [[start_s, duration_s]...], code ("Fl(2) G 6s")

    def display_entry(self):
        # What the wheelhouse view needs to draw it (the "mark" field of a contact).
        return {"colour": self.colour, "shape": self.shape, "light": dict(self.light), "lane": self.lane}


def rcs_for(number):
    # A fixed spread between the limits that depends only on the number, so a buoy keeps its echo.
    share = (number * 0.6180339887) % 1.0
    return RCS_RANGE_M2[0] + share * (RCS_RANGE_M2[1] - RCS_RANGE_M2[0])


def along_positions(total_nm, spacing_nm, first_nm):
    positions = []
    along_nm = first_nm
    while along_nm <= total_nm - 0.05:
        positions.append(along_nm)
        along_nm += spacing_nm
    return positions


def point_and_right(points_nm, along_nm):
    # The point at a distance along a polyline, and the unit vector to the right of its direction.
    steps = np.diff(points_nm, axis=0)
    lengths = np.hypot(steps[:, 0], steps[:, 1])
    ends = np.cumsum(lengths)
    index = int(min(np.searchsorted(ends, along_nm), len(lengths) - 1))
    start_along_nm = ends[index] - lengths[index]
    fraction = (along_nm - start_along_nm) / max(lengths[index], 1e-9)
    x_nm = points_nm[index, 0] + fraction * steps[index, 0]
    y_nm = points_nm[index, 1] + fraction * steps[index, 1]
    dx = steps[index, 0] / max(lengths[index], 1e-9)
    dy = steps[index, 1] / max(lengths[index], 1e-9)
    return x_nm, y_nm, dy, -dx                       # right of (dx, dy) is (dy, -dx)


def build_marks(land, traffic_cfg):
    marks = []
    if not traffic_cfg["lane_marks"]:
        return marks
    lateral_nm = traffic_cfg["lateral_spacing_nm"]
    lane_nm = traffic_cfg["lane_spacing_nm"]
    region_b = traffic_cfg["buoyage_region"] == "B"
    starboard_colour, port_colour = ("red", "green") if region_b else ("green", "red")
    lanes = land.lanes
    harbour = None
    for lane in lanes:
        if lane.name == HARBOUR_APPROACH:
            harbour = np.asarray(lane.points_nm, dtype=float)[-1]

    def clear(x_nm, y_nm, lane):
        if land.is_land_point(x_nm, y_nm):
            return False
        for other in lanes:
            if other is not lane and distance_to_polyline_nm(x_nm, y_nm, other.points_nm) < other.width_nm / 2.0 + CLEAR_OF_OTHER_LANES_NM:
                return False
        # Not on the shore: a small ring of points around the buoy must be water too.
        for angle_deg in (0.0, 90.0, 180.0, 270.0):
            if land.is_land_point(x_nm + CLEAR_OF_LAND_NM * math.sin(math.radians(angle_deg)),
                                  y_nm + CLEAR_OF_LAND_NM * math.cos(math.radians(angle_deg))):
                return False
        return True

    def add(colour, shape, x_nm, y_nm, lane, number_in_lane, rhythm):
        number = len(marks)
        name = "%s%d" % (COLOUR_LETTER[colour], number_in_lane)
        marks.append(Mark(number, name, colour, shape, float(x_nm), float(y_nm), rcs_for(number), lane.name, light_for(colour, rhythm)))

    gate = 0                                          # the numbers run on through all the lanes
    for lane in lanes:
        points = np.asarray(lane.points_nm, dtype=float)
        if lane.name != HARBOUR_APPROACH and harbour is not None:
            # The direction of buoyage is toward the harbour: turn the lane round if its far end is the nearer one.
            if np.hypot(*(points[0] - harbour)) < np.hypot(*(points[-1] - harbour)):
                points = points[::-1].copy()
        total_nm = float(np.sum(np.hypot(*np.diff(points, axis=0).T)))
        half_nm = lane.width_nm / 2.0
        if lane.name == HARBOUR_APPROACH:
            spacing_nm, first_nm = lateral_nm, half_nm_of_leaving_lane(lanes, lane) + FIRST_GATE_NM
        else:
            spacing_nm, first_nm = lane_nm, 0.0
        first_in_lane = True
        later = 0
        for along_nm in along_positions(total_nm, spacing_nm, first_nm):
            x_nm, y_nm, right_x, right_y = point_and_right(points, along_nm)
            gate += 1
            if first_in_lane:
                rhythm = "Q"
                first_in_lane = False
            else:
                rhythm = LATER_GATES[later % len(LATER_GATES)]
                later += 1
            port_x, port_y = x_nm - right_x * half_nm, y_nm - right_y * half_nm
            starboard_x, starboard_y = x_nm + right_x * half_nm, y_nm + right_y * half_nm
            if clear(port_x, port_y, lane):
                add(port_colour, "can", port_x, port_y, lane, 2 * gate - 1, rhythm)
            if clear(starboard_x, starboard_y, lane):
                add(starboard_colour, "nun", starboard_x, starboard_y, lane, 2 * gate, rhythm)
    return marks


def half_nm_of_leaving_lane(lanes, approach):
    # The approach leaves another lane at its first point; the gates start outside that lane's edge.
    start_x, start_y = approach.points_nm[0]
    widest_nm = 0.0
    for other in lanes:
        if other is not approach and distance_to_polyline_nm(start_x, start_y, other.points_nm) < 0.05:
            widest_nm = max(widest_nm, other.width_nm / 2.0)
    return widest_nm
