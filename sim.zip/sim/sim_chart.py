# sim_chart.py - a practice chart of the scenario, drawn from the same data the radar uses:
# the land raster, the traffic lanes, the fixed buoys and own ship's start. The output is one
# SVG file (open it in a browser; no extra program or Python package is needed) styled after a
# paper chart: buff land, blue depth tints, magenta traffic lanes, soundings, spot heights, a
# compass rose and a graduated border.
# The land raster has no depths, so the depths are made up here from the distance to the
# nearest shore (see DEPTH_*); the sim itself never uses them.
# The chart is a plane chart centred on the world origin: 1 minute of latitude = 1 nm, and
# 1 minute of longitude = cos(latitude) nm, as in sim_common.latlon_to_xy_nm. Over the
# 60 nm of the land square the true Mercator stretch is under 2 %, so it is not drawn.
# Units: positions and distances nm (x east, y north, origin at the centre of the land
# square), depths and heights m, bearings deg true. SVG drawing units: SCALE per nm.
# Called by: sim_main.py (once per run, after the scenario is built).

import base64
import html
import math
import struct
import zlib

import numpy as np

import sim_land
from sim_common import NM_PER_DEG_LAT, xy_nm_to_latlon

IMAGE_PX = 1500                  # the shading picture is about this many pixels a side
DEPTH_AT_SHORE_M = 2.0           # chosen, not charted: depth = this + DEPTH_PER_NM_M x distance from shore
DEPTH_PER_NM_M = 14.0
DEPTH_LIMIT_NM = 8.0             # further than this from shore is "deep" (over about 110 m)
DEPTH_BAND_EDGES_M = [5.0, 10.0, 20.0, 50.0]
SOUNDING_SPACING_NM = 1.5
SPOT_HEIGHT_BLOCK_NM = 5.0
SPOT_HEIGHT_COUNT = 8
SCALE = 20.0                     # SVG drawing units per nm
MARGIN = 60.0                    # border on the left, right and top, in drawing units
FOOTER = 120.0                   # title block under the chart
ROSE_RADIUS_NM = 3.0

WATER_COLOURS = [(146, 187, 222), (174, 207, 234), (203, 224, 242), (228, 239, 249), (255, 255, 255)]
LAND_COLOUR = (241, 226, 168)
COAST_COLOUR = (50, 45, 40)
DEPTH_LINE_COLOUR = (96, 138, 182)
HEIGHT_LINE_COLOUR = (196, 164, 100)
HEIGHT_BAND_EDGES_M = [50.0, 100.0, 200.0]
MAGENTA = "#a8287e"
SEA_BLUE = "#2f5d86"


# ---------------------------------------------------------------- picture

def png_bytes(rgb):
    # A PNG (8 bit RGB) from a uint8 array of shape (rows, columns, 3).
    rows, columns = rgb.shape[:2]
    raw = np.concatenate([np.zeros((rows, 1), dtype=np.uint8), rgb.reshape(rows, columns * 3)], axis=1).tobytes()

    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)

    header = struct.pack(">IIBBBBB", columns, rows, 8, 2, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b"")


def distance_to_land_cells(land_mask, cap_cells):
    # Exact distance in cells from every cell to the nearest land cell, limited to cap_cells.
    rows, columns = land_mask.shape
    far = float(cap_cells + 1)
    vertical = np.full((rows, columns), far)
    vertical[land_mask] = 0.0
    for row in range(1, rows):
        vertical[row] = np.minimum(vertical[row], vertical[row - 1] + 1.0)
    for row in range(rows - 2, -1, -1):
        vertical[row] = np.minimum(vertical[row], vertical[row + 1] + 1.0)
    vertical = np.minimum(vertical, far)
    squared = vertical * vertical
    result = squared.copy()
    for shift in range(1, cap_cells + 1):
        result[:, shift:] = np.minimum(result[:, shift:], squared[:, :-shift] + shift * shift)
        result[:, :-shift] = np.minimum(result[:, :-shift], squared[:, shift:] + shift * shift)
    return np.sqrt(result)


def edges_between(values):
    # True where a cell differs from its right or lower neighbour.
    edge = np.zeros(values.shape, dtype=bool)
    edge[:, :-1] |= values[:, :-1] != values[:, 1:]
    edge[:-1, :] |= values[:-1, :] != values[1:, :]
    return edge


def build_picture(land, extent_nm, cell_nm):
    # Returns (rgb picture north-up, heights m per pixel north-up, depth m per pixel north-up,
    # nm per pixel, side of the picture in nm). The picture's south-west corner is at (-extent/2, -extent/2).
    if land is None:
        heights = np.zeros((IMAGE_PX, IMAGE_PX), dtype=np.int16)
        pixel_nm = extent_nm / IMAGE_PX
    else:
        block = max(1, int(math.ceil(land.cells / IMAGE_PX)))
        size = int(math.ceil(land.cells / (2.0 * block))) * 2          # even, so the depth picture can be half size
        padded = np.zeros((size * block, size * block), dtype=np.int16)
        padded[:land.cells, :land.cells] = land.heights_m
        heights = padded.reshape(size, block, size, block).max(axis=(1, 3))
        pixel_nm = block * cell_nm
    heights = np.ascontiguousarray(heights[::-1])                      # row 0 = north
    size = heights.shape[0]
    on_land = heights > 0

    # Depth from distance to shore, worked out at half size.
    half_size = size // 2
    coarse_land = on_land.reshape(half_size, 2, half_size, 2).any(axis=(1, 3))
    cap_cells = max(2, int(DEPTH_LIMIT_NM / (2.0 * pixel_nm)))
    coarse_nm = distance_to_land_cells(coarse_land, cap_cells) * 2.0 * pixel_nm
    distance_nm = np.repeat(np.repeat(coarse_nm, 2, axis=0), 2, axis=1)
    depth_m = DEPTH_AT_SHORE_M + DEPTH_PER_NM_M * distance_nm
    depth_m = np.where(on_land, 0.0, depth_m).astype(np.float32)

    band = np.searchsorted(np.array(DEPTH_BAND_EDGES_M), depth_m, side="right")
    colours = np.array(WATER_COLOURS, dtype=np.uint8)
    picture = colours[band]
    picture[on_land] = LAND_COLOUR

    height_band = np.searchsorted(np.array(HEIGHT_BAND_EDGES_M), heights, side="right")
    height_band = np.where(on_land, height_band, -1)
    picture[edges_between(height_band) & on_land] = HEIGHT_LINE_COLOUR
    water_band = np.where(on_land, -1, band)
    picture[edges_between(water_band) & ~on_land] = DEPTH_LINE_COLOUR
    coast = on_land & (edges_between(on_land) | np.roll(edges_between(on_land), 1, axis=0) | np.roll(edges_between(on_land), 1, axis=1))
    picture[coast] = COAST_COLOUR
    return picture, heights, depth_m, pixel_nm, size * pixel_nm


# ---------------------------------------------------------------- small helpers

def format_latitude(minutes_total):
    degrees, minutes = divmod(int(round(abs(minutes_total))), 60)
    return "%d°%02d′%s" % (degrees, minutes, "N" if minutes_total >= 0 else "S")


def format_longitude(minutes_total):
    degrees, minutes = divmod(int(round(abs(minutes_total))), 60)
    return "%d°%02d′%s" % (degrees, minutes, "E" if minutes_total >= 0 else "W")


def offset_polyline(points, distance_nm):
    # The polyline moved sideways by distance_nm (+ to the left of its direction).
    points = np.asarray(points, dtype=float)
    steps = np.diff(points, axis=0)
    lengths = np.maximum(np.hypot(steps[:, 0], steps[:, 1]), 1e-9)
    directions = steps / lengths[:, None]
    vertex_directions = np.zeros_like(points)
    vertex_directions[:-1] += directions
    vertex_directions[1:] += directions
    norms = np.maximum(np.hypot(vertex_directions[:, 0], vertex_directions[:, 1]), 1e-9)
    vertex_directions /= norms[:, None]
    left = np.column_stack([-vertex_directions[:, 1], vertex_directions[:, 0]])
    return points + left * distance_nm


# ---------------------------------------------------------------- the chart

class ChartWriter:
    def __init__(self, extent_nm, lat0_deg, lon0_deg):
        self.half_nm = extent_nm / 2.0
        self.extent_nm = extent_nm
        self.lat0_deg = lat0_deg
        self.lon0_deg = lon0_deg
        self.parts = []

    def sx(self, x_nm):
        return MARGIN + (x_nm + self.half_nm) * SCALE

    def sy(self, y_nm):
        return MARGIN + (self.half_nm - y_nm) * SCALE

    def add(self, text):
        self.parts.append(text)

    def text(self, x, y, content, size=7.0, anchor="start", colour="#000000", italic=False, rotate=0.0, weight="normal"):
        transform = ' transform="rotate(%.1f %.1f %.1f)"' % (rotate, x, y) if rotate else ""
        self.add('<text x="%.1f" y="%.1f" font-size="%.1f" text-anchor="%s" fill="%s" font-family="Georgia, serif" '
                 'font-style="%s" font-weight="%s"%s>%s</text>' % (
                     x, y, size, anchor, colour, "italic" if italic else "normal", weight, transform, html.escape(content)))

    def polyline(self, points_nm, colour, width, dash=None, fill="none", close=False, opacity=1.0):
        coordinates = " ".join("%.1f,%.1f" % (self.sx(x), self.sy(y)) for x, y in points_nm)
        tag = "polygon" if close else "polyline"
        dash_text = ' stroke-dasharray="%s"' % dash if dash else ""
        self.add('<%s points="%s" fill="%s" fill-opacity="%.2f" stroke="%s" stroke-width="%.2f" stroke-opacity="%.2f"%s/>' % (
            tag, coordinates, fill, opacity, colour, width, 1.0 if fill != "none" else opacity, dash_text))

    # ---- parts ----

    def draw_graticule_and_border(self, grid):
        # grid True: the faint graticule lines only (inside the clip); False: the border (outside it).
        cos_lat = math.cos(math.radians(self.lat0_deg))
        lat0_min = self.lat0_deg * 60.0
        lon0_min = self.lon0_deg * 60.0
        left, top = self.sx(-self.half_nm), self.sy(self.half_nm)
        right, bottom = self.sx(self.half_nm), self.sy(-self.half_nm)
        lat_minutes = range(int(math.floor(lat0_min - self.half_nm)), int(math.ceil(lat0_min + self.half_nm)) + 1)
        lon_minutes = range(int(math.floor(lon0_min - self.half_nm / cos_lat)), int(math.ceil(lon0_min + self.half_nm / cos_lat)) + 1)
        # Faint graticule every 10 minutes, under the chart symbols.
        for minute in (lat_minutes if grid else []):
            y_nm = minute - lat0_min
            if minute % 10 == 0 and -self.half_nm <= y_nm <= self.half_nm:
                self.add('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="0.5" stroke-opacity="0.45"/>' % (
                    left, self.sy(y_nm), right, self.sy(y_nm), MAGENTA))
        for minute in (lon_minutes if grid else []):
            x_nm = (minute - lon0_min) * cos_lat
            if minute % 10 == 0 and -self.half_nm <= x_nm <= self.half_nm:
                self.add('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="0.5" stroke-opacity="0.45"/>' % (
                    self.sx(x_nm), top, self.sx(x_nm), bottom, MAGENTA))
        if grid:
            return
        # The border: alternate black and white boxes, one minute each.
        band = 8.0
        self.add('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="none" stroke="#000" stroke-width="1.2"/>' % (
            left - band, top - band, right - left + 2 * band, bottom - top + 2 * band))
        self.add('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="none" stroke="#000" stroke-width="1.2"/>' % (
            left, top, right - left, bottom - top))
        previous = -self.half_nm
        for index, minute in enumerate(lat_minutes):
            y_nm = min(max(minute - lat0_min, -self.half_nm), self.half_nm)
            if y_nm > previous:
                fill = "#000" if minute % 2 == 0 else "#fff"
                for x in (left - band, right):
                    self.add('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="%s" stroke="#000" stroke-width="0.5"/>' % (
                        x, self.sy(y_nm), band, (y_nm - previous) * SCALE, fill))
                previous = y_nm
            if minute % 5 == 0 and -self.half_nm <= minute - lat0_min <= self.half_nm:
                label_y = self.sy(minute - lat0_min) + 2.5
                self.text(left - band - 3, label_y, format_latitude(minute), 7.0, "end")
                self.text(right + band + 3, label_y, format_latitude(minute), 7.0, "start")
        previous = -self.half_nm
        for index, minute in enumerate(lon_minutes):
            x_nm = min(max((minute - lon0_min) * cos_lat, -self.half_nm), self.half_nm)
            if x_nm > previous:
                fill = "#000" if minute % 2 == 0 else "#fff"
                for y in (top - band, bottom):
                    self.add('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="%s" stroke="#000" stroke-width="0.5"/>' % (
                        self.sx(previous), y, (x_nm - previous) * SCALE, band, fill))
                previous = x_nm
            if minute % 10 == 0 and -self.half_nm <= (minute - lon0_min) * cos_lat <= self.half_nm:
                label_x = self.sx((minute - lon0_min) * cos_lat)
                self.text(label_x, top - band - 4, format_longitude(minute), 7.0, "middle")
                self.text(label_x, bottom + band + 11, format_longitude(minute), 7.0, "middle")

    def draw_lanes(self, lanes):
        for lane in lanes:
            points = np.asarray(lane.points_nm, dtype=float)
            half_width = lane.width_nm / 2.0
            left_edge = offset_polyline(points, half_width)
            right_edge = offset_polyline(points, -half_width)
            outline = list(map(tuple, left_edge)) + list(map(tuple, right_edge[::-1]))
            self.polyline(outline, MAGENTA, 0.0, fill=MAGENTA, close=True, opacity=0.10)
            self.polyline(map(tuple, left_edge), MAGENTA, 1.1)
            self.polyline(map(tuple, right_edge), MAGENTA, 1.1)
            self.polyline(map(tuple, points), MAGENTA, 0.7, dash="7 5")
            # Arrows: traffic keeps to the right of the centre line, so each half carries its own direction.
            samples, along_nm, total_nm = sim_land.sample_polyline(points, 0.05)
            arrow_half = min(0.3, lane.width_nm * 0.35)
            spacing = max(3.0, 12.0 * arrow_half)
            position = spacing / 2.0
            while position < total_nm:
                index = int(np.searchsorted(along_nm, position))
                index = min(max(index, 1), len(samples) - 1)
                direction = samples[index] - samples[index - 1]
                direction = direction / max(math.hypot(direction[0], direction[1]), 1e-9)
                right_normal = np.array([direction[1], -direction[0]])
                for sign in ((1.0, -1.0) if lane.two_way else (0.0,)):
                    centre = samples[index] + right_normal * sign * lane.width_nm / 4.0
                    along = direction * sign if sign != 0.0 else direction
                    side = np.array([along[1], -along[0]])
                    tip = centre + along * arrow_half
                    base_left = centre - along * arrow_half + side * arrow_half * 0.5
                    base_right = centre - along * arrow_half - side * arrow_half * 0.5
                    if abs(centre[0]) < self.half_nm and abs(centre[1]) < self.half_nm:
                        self.polyline([tuple(tip), tuple(base_left), tuple(base_right)], MAGENTA, 0.4, fill=MAGENTA, close=True)
                position += spacing
            # Name, along the lane, a little to the left of it.
            middle = len(samples) // 2
            direction = samples[min(middle + 10, len(samples) - 1)] - samples[max(middle - 10, 0)]
            angle = math.degrees(math.atan2(-direction[1], direction[0]))      # SVG y runs down
            if angle > 90.0 or angle < -90.0:
                angle += 180.0
            label_point = samples[middle] + np.array([-direction[1], direction[0]]) / max(math.hypot(*direction), 1e-9) * (half_width + 0.3)
            name = lane.name.upper() + (" (TWO-WAY)" if lane.two_way else "")
            self.text(self.sx(label_point[0]), self.sy(label_point[1]), name, 6.5, "middle", MAGENTA, True, angle)
            if lane.name == sim_land.HARBOUR_APPROACH:
                end = points[-1]
                self.text(self.sx(end[0]) + 8, self.sy(end[1]) + 14, "Harbour", 8.0, "start", "#000", True)

    def draw_soundings(self, depth_m, pixel_nm, rng, avoid):
        size = depth_m.shape[0]
        steps = int(self.extent_nm / SOUNDING_SPACING_NM)
        for row in range(steps):
            for column in range(steps):
                x_nm = -self.half_nm + (column + rng.uniform(0.2, 0.8)) * SOUNDING_SPACING_NM
                y_nm = -self.half_nm + (row + rng.uniform(0.2, 0.8)) * SOUNDING_SPACING_NM
                pixel_x = int((x_nm + self.half_nm) / pixel_nm)
                pixel_y = size - 1 - int((y_nm + self.half_nm) / pixel_nm)
                if not (0 <= pixel_x < size and 0 <= pixel_y < size):
                    continue
                depth = float(depth_m[pixel_y, pixel_x])
                if depth <= 0.0:
                    continue
                if depth > 90.0 and (row % 2 == 1 or column % 2 == 1):
                    continue
                if depth > 50.0 and (row + column) % 2 == 1:
                    continue
                if math.hypot(x_nm - avoid[0], y_nm - avoid[1]) < ROSE_RADIUS_NM + 0.5:
                    continue
                depth *= rng.uniform(0.92, 1.08)
                label = "%.1f" % depth if depth < 10.0 else "%d" % round(depth)
                self.text(self.sx(x_nm), self.sy(y_nm), label, 5.2, "middle", SEA_BLUE, True)

    def draw_spot_heights(self, heights, pixel_nm):
        size = heights.shape[0]
        block_px = max(1, int(SPOT_HEIGHT_BLOCK_NM / pixel_nm))
        found = []
        for top in range(0, size, block_px):
            for left in range(0, size, block_px):
                window = heights[top:top + block_px, left:left + block_px]
                peak = int(window.max())
                if peak >= 15:
                    index = int(np.argmax(window))
                    row, column = divmod(index, window.shape[1])
                    found.append((peak, top + row, left + column))
        found.sort(reverse=True)
        for peak, row, column in found[:SPOT_HEIGHT_COUNT]:
            x_nm = -self.half_nm + (column + 0.5) * pixel_nm
            y_nm = self.half_nm - (row + 0.5) * pixel_nm
            self.add('<circle cx="%.1f" cy="%.1f" r="1.6" fill="#000"/>' % (self.sx(x_nm), self.sy(y_nm)))
            self.text(self.sx(x_nm) + 3, self.sy(y_nm) - 2, "%d" % peak, 6.5, "start", "#000")

    def draw_rose(self, x_nm, y_nm):
        centre_x, centre_y = self.sx(x_nm), self.sy(y_nm)
        radius = ROSE_RADIUS_NM * SCALE
        for scale in (1.0, 0.78):
            self.add('<circle cx="%.1f" cy="%.1f" r="%.1f" fill="none" stroke="%s" stroke-width="0.8"/>' % (
                centre_x, centre_y, radius * scale, MAGENTA))
        for bearing in range(0, 360, 5):
            angle = math.radians(bearing)
            length = 0.22 if bearing % 10 == 0 else 0.11
            outer = radius * 0.78
            inner = outer - radius * length * 0.6
            self.add('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="0.5"/>' % (
                centre_x + inner * math.sin(angle), centre_y - inner * math.cos(angle),
                centre_x + outer * math.sin(angle), centre_y - outer * math.cos(angle), MAGENTA))
            if bearing % 30 == 0:
                label_radius = radius * 0.89
                self.text(centre_x + label_radius * math.sin(angle), centre_y - label_radius * math.cos(angle) + 2.2,
                          "%03d" % bearing, 5.5, "middle", MAGENTA)
        # The true north arrow and the four points.
        self.polyline([(x_nm, y_nm + ROSE_RADIUS_NM * 0.7), (x_nm - 0.15, y_nm), (x_nm + 0.15, y_nm)], MAGENTA, 0.6, fill=MAGENTA, close=True)
        self.add('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="0.8"/>' % (
            centre_x, centre_y + radius * 0.5, centre_x, centre_y - radius * 0.5, MAGENTA))
        self.add('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="0.8"/>' % (
            centre_x - radius * 0.5, centre_y, centre_x + radius * 0.5, centre_y, MAGENTA))
        self.text(centre_x, centre_y - radius * 0.55, "N", 8.0, "middle", MAGENTA, False, 0.0, "bold")

    def draw_buoys(self, buoys):
        # buoys: (x_nm, y_nm, name, colour, light_code). The fixed buoys of the calibration scene have no colour
        # (magenta, with a name); a lane buoy is drawn in its own colour with its number and, as on a paper chart,
        # its light ("Fl G 4s") beside it.
        paint = {"red": "#c01818", "green": "#108030"}
        for x_nm, y_nm, name, colour, code in buoys:
            x, y = self.sx(x_nm), self.sy(y_nm)
            if colour == "":
                self.add('<circle cx="%.1f" cy="%.1f" r="3" fill="none" stroke="%s" stroke-width="1"/>' % (x, y, MAGENTA))
                self.add('<circle cx="%.1f" cy="%.1f" r="0.9" fill="%s"/>' % (x, y, MAGENTA))
                self.add('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="1"/>' % (x, y - 3, x, y - 8, MAGENTA))
                self.text(x + 5, y - 5, name, 6.5, "start", MAGENTA, True)
            else:
                self.add('<circle cx="%.1f" cy="%.1f" r="2.2" fill="%s" stroke="#222" stroke-width="0.4"/>' % (x, y, paint[colour]))
                self.text(x + 4, y - 3, (name + "  " + code).strip(), 5.5, "start", paint[colour], True)

    def draw_track(self, track):
        if len(track) >= 2:
            self.polyline([(x, y) for x, y in track], "#900", 0.8, dash="3 3")

    def draw_start(self, x_nm, y_nm, heading_deg, label):
        x, y = self.sx(x_nm), self.sy(y_nm)
        angle = math.radians(heading_deg)
        points = []
        for turn, length in ((0.0, 9.0), (140.0, 6.0), (220.0, 6.0)):
            a = angle + math.radians(turn)
            points.append("%.1f,%.1f" % (x + length * math.sin(a), y - length * math.cos(a)))
        self.add('<polygon points="%s" fill="#c01818" fill-opacity="0.8" stroke="#600" stroke-width="0.8"/>' % " ".join(points))
        self.text(x + 9, y + 12, label, 6.5, "start", "#900", True)

    def draw_title_block(self, seed, scenario, lanes_present):
        top = self.sy(-self.half_nm) + 36.0
        left = self.sx(-self.half_nm) - 8.0
        lat, lon = xy_nm_to_latlon(0.0, 0.0, self.lat0_deg, self.lon0_deg)
        lines = [
            ("PRACTICE CHART — %s scenario, seed %d" % (scenario, seed), 12.0, "bold"),
            ("Centre %s %s.  Scale: one minute of latitude on the border = 1 nautical mile; one minute of longitude = %.2f nm. "
             "Plane chart, north at the top." % (format_latitude(lat * 60.0), format_longitude(lon * 60.0),
                                                 math.cos(math.radians(self.lat0_deg))), 8.0, "normal"),
            ("Depths in metres, made up from the distance to the shore (they are not used by the radar). Heights in metres "
             "above sea level. Land contours at 50, 100 and 200 m.", 8.0, "normal"),
            ("Magenta: traffic lanes" + (" (arrows show the direction on each side of the centre line)" if lanes_present else "")
             + ", lateral buoys (red and green, with their lights), compass rose. Graticule every 10 minutes.", 8.0, "normal"),
        ]
        y = top
        for content, size, weight in lines:
            self.text(left, y, content, size, "start", "#000", False, 0.0, weight)
            y += size + 6.0


def write_chart(path, land, cfg, seed, scenario, own_start, buoys, track=None, own_label="Own ship start"):
    # land: the LandModel (an open-sea model for the calibration scenario); own_start: (x_nm, y_nm,
    # heading deg true); buoys: [(x_nm, y_nm, name, colour, light code)]; track: [[x_nm, y_nm], ...] own ship's ground track so far.
    # Writes the SVG to path and returns the path.
    general = cfg["general"]
    open_sea = land.cells < 100
    extent_nm = general["land_extent_nm"] if open_sea else land.extent_nm
    picture, heights, depth_m, pixel_nm, picture_nm = build_picture(None if open_sea else land, extent_nm,
                                                                     None if open_sea else land.cell_nm)
    chart = ChartWriter(extent_nm, general["origin_lat_deg"], general["origin_lon_deg"])
    lanes = [] if open_sea else land.lanes

    # A place for the compass rose: the corner or edge middle furthest from land and lanes.
    best_score, rose = -1.0, (0.0, 0.0)
    inset = extent_nm / 2.0 - ROSE_RADIUS_NM - 1.0
    size = depth_m.shape[0]
    for x_nm in (-inset, 0.0, inset):
        for y_nm in (-inset, 0.0, inset):
            if x_nm == 0.0 and y_nm == 0.0:
                continue
            pixel_x = min(size - 1, int((x_nm + extent_nm / 2.0) / pixel_nm))
            pixel_y = min(size - 1, size - 1 - int((y_nm + extent_nm / 2.0) / pixel_nm))
            land_nm = (float(depth_m[pixel_y, pixel_x]) - DEPTH_AT_SHORE_M) / DEPTH_PER_NM_M
            lane_nm = min([sim_land.distance_to_polyline_nm(x_nm, y_nm, lane.points_nm) - lane.width_nm / 2.0 for lane in lanes] or [99.0])
            score = min(land_nm, lane_nm)
            if score > best_score:
                best_score, rose = score, (x_nm, y_nm)

    width = extent_nm * SCALE + 2.0 * MARGIN
    height = extent_nm * SCALE + MARGIN + FOOTER
    chart.add('<svg xmlns="http://www.w3.org/2000/svg" width="%.0f" height="%.0f" viewBox="0 0 %.0f %.0f">' % (width, height, width, height))
    chart.add('<rect width="100%" height="100%" fill="#fbf7ec"/>')
    chart.add('<clipPath id="map"><rect x="%.1f" y="%.1f" width="%.1f" height="%.1f"/></clipPath>' % (
        chart.sx(-extent_nm / 2.0), chart.sy(extent_nm / 2.0), extent_nm * SCALE, extent_nm * SCALE))
    encoded = base64.b64encode(png_bytes(picture)).decode("ascii")
    chart.add('<g clip-path="url(#map)">')
    chart.add('<image x="%.1f" y="%.1f" width="%.1f" height="%.1f" preserveAspectRatio="none" href="data:image/png;base64,%s"/>' % (
        chart.sx(-extent_nm / 2.0), chart.sy(-extent_nm / 2.0 + picture_nm), picture_nm * SCALE, picture_nm * SCALE, encoded))
    chart.draw_graticule_and_border(True)
    if not open_sea:
        chart.draw_soundings(depth_m, pixel_nm, np.random.default_rng(seed), rose)      # open sea has no shore to take a depth from
    chart.draw_lanes(lanes)
    chart.draw_spot_heights(heights, pixel_nm)
    chart.draw_buoys(buoys)
    chart.draw_rose(*rose)
    chart.draw_track(track or [])
    chart.draw_start(own_start[0], own_start[1], own_start[2], own_label)
    chart.add("</g>")
    chart.draw_graticule_and_border(False)
    chart.draw_title_block(seed, scenario, bool(lanes))
    chart.add("</svg>")
    with open(path, "w", encoding="utf-8") as svg_file:
        svg_file.write("\n".join(chart.parts))
    return path
