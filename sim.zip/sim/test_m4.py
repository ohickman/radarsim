# test_m4.py - acceptance tests of Module M4, the radar video generator
# (BRIEF.md Section 15). Run: python sim/test_m4.py
# Prints [OK] or [FAIL] lines with numbers; exits 0 or 1. Takes a few minutes.
# Writes preview_radar_calm.png, _sea5.png, _rain.png and _coast.png into the project
# root for Oliver to look at (each shows the 6 NM scale on the left, 12 NM on the right).
# Units: ranges nm, levels dB above mean noise, video 0..255, radar cross-section m2.

import copy
import hashlib
import math
import os
import socket
import subprocess
import sys
import time

import numpy as np

import devtools
import messages
import sim_common
import sim_config
import sim_contacts
import sim_environment
import sim_land
import sim_protocol
import sim_radar

ROOT = sim_common.find_project_root()
CONFIG_PATH = os.path.join(ROOT, sim_common.CONFIG_FILE_NAME)
SIM_MAIN = os.path.join(ROOT, "sim", "sim_main.py")
TEMP_CONFIG_PATH = os.path.join(ROOT, "test_m4_tmp.toml")     # deleted at the end
CFG = sim_config.load_config(CONFIG_PATH)
THRESHOLD_DB = CFG["radar"]["display_threshold_db"]
WINDOW_DB = CFG["radar"]["video_window_db"]
SPOKES = CFG["radar"]["azimuth_bins"]
BINS = CFG["radar"]["range_bins"]
DETECT_VIDEO = 50                 # a target counts as detected with peak video of at least 50 (BRIEF.md M4 test 4)

# IMO Resolution MSC.192(79), Annex, section 5.3.1.1, Table 2, "Minimum detection ranges
# in clutter-free conditions", X-band column. (name, height above sea level in m,
# X-band range in NM, radar cross-section in m2, where the cross-section comes from.)
# The table is for an antenna 15 m up and a target shown in 8 of 10 scans; this test
# follows the brief instead: antenna 25 m, 50 % of scans.
TABLE_2_POINT_ROWS = [
    ("SOLAS ship over 5,000 GT", 10.0, 11.0, 220.0, "chosen: Table 2 gives no cross-section for ships"),
    ("SOLAS ship over 500 GT", 5.0, 8.0, 60.0, "chosen: Table 2 gives no cross-section for ships"),
    ("small vessel with radar reflector", 4.0, 5.0, 7.5, "Table 2 note 1"),
    ("navigation buoy with corner reflector", 3.5, 4.9, 10.0, "Table 2 note 2"),
    ("typical navigation buoy", 3.5, 4.6, 5.0, "Table 2 note 3"),
    ("small vessel of 10 m, no reflector", 2.0, 3.4, 2.5, "Table 2 note 4"),
]
TABLE_2_SHORE_ROWS = [            # (name, height the shoreline rises to in m, X-band range in NM)
    ("shoreline rising to 60 m", 60.0, 20.0),
    ("shoreline rising to 6 m", 6.0, 8.0),
    ("shoreline rising to 3 m", 3.0, 6.0),
]

failures = 0


def report(passed, name, detail):
    global failures
    if passed:
        messages.ok(name + ": " + detail)
    else:
        failures += 1
        messages.fail(name + ": " + detail)


# ---------------------------------------------------------------- helpers

def calm_cfg():
    # No sea clutter, no rain, receiver controls at gain 60, STC 0, FTC 0.
    cfg = copy.deepcopy(CFG)
    cfg["environment"].update({"sea_state_from_wind": False, "sea_state_douglas": 0, "rain_rate_mm_per_h": 0.0,
                               "wind_from_deg_true": 0.0, "wind_speed_kn": 10.0})
    cfg["radar_controls"].update({"gain_percent": 60.0, "stc_percent": 0.0, "ftc_percent": 0.0})
    cfg["own_ship"]["antenna_height_m"] = 25.0
    return cfg


def make_radar(cfg, land=None, fluctuate=True, seed=1):
    if land is None:
        land = sim_land.make_open_sea(cfg)
    environment = sim_environment.Environment(cfg, np.random.default_rng(100 + seed), 0.0, 0.0)
    radar = sim_radar.RadarVideo(cfg, np.random.default_rng(seed), land, environment, fluctuate)
    return radar, environment


def snapshot(time_s, scatterers=(), own_x_nm=0.0, own_y_nm=0.0, heading_deg=0.0, gyro_deg=None, ref=None):
    # scatterers: (id, x_nm, y_nm, rcs_m2, height_m)
    table = np.array(scatterers, dtype=float).reshape(-1, 5)
    if gyro_deg is None:
        gyro_deg = heading_deg
    if ref is None:
        ref = (own_x_nm, own_y_nm)
    return sim_radar.Snapshot(time_s, own_x_nm, own_y_nm, heading_deg, gyro_deg, ref[0], ref[1],
                              table[:, 0].astype(np.int64), table[:, 1].copy(), table[:, 2].copy(),
                              table[:, 3].copy(), table[:, 4].copy())


def at(bearing_deg, range_nm):
    return range_nm * math.sin(math.radians(bearing_deg)), range_nm * math.cos(math.radians(bearing_deg))


def sector(revolution, bearing_rel_deg, half_width_deg):
    # The spoke numbers of one revolution within half_width_deg of a relative bearing.
    centre = int(bearing_rel_deg / 360.0 * SPOKES)
    half = int(math.ceil(half_width_deg / 360.0 * SPOKES))
    return revolution * SPOKES + centre + np.arange(-half, half + 1)


def still_world(radar, scatterers, numbers, heading_deg=0.0):
    # Levels for some spokes with nothing moving.
    before = snapshot(0.0, scatterers, heading_deg=heading_deg)
    after = snapshot(1.0e9, scatterers, heading_deg=heading_deg)
    return radar.compute_levels_db(numbers, before, after)


def video_of(levels_db):
    return sim_radar.quantise(levels_db, THRESHOLD_DB, WINDOW_DB)


def footprint_peak(radar, levels_db, range_nm, extra_nm=0.0):
    # Highest level in the bins a target at range_nm fills (its pulse length, one bin spare each side).
    bin_nm = radar.video_range_nm() / BINS
    first = max(int(range_nm / bin_nm) - 1, 0)
    last = int((range_nm + extra_nm) / bin_nm) + radar.pulse_bins() + 1
    return float(levels_db[:, first:last + 1].max())


def detection_fraction(radar, scatterer, bearing_deg, range_nm, revolutions):
    detected = 0
    x_nm, y_nm = at(bearing_deg, range_nm)
    target = [(scatterer[0], x_nm, y_nm, scatterer[1], scatterer[2])]
    for revolution in range(1, revolutions + 1):
        levels_db, header = still_world(radar, target, sector(revolution, bearing_deg, 1.5))
        peak_video = (footprint_peak(radar, levels_db, range_nm) - THRESHOLD_DB) * 255.0 / WINDOW_DB
        if peak_video >= DETECT_VIDEO:
            detected += 1
    return detected / revolutions


def crossing_range(ranges_nm, fractions):
    # The range where the detection fraction first falls through 0.5, by straight-line interpolation.
    for index in range(len(ranges_nm) - 1):
        high, low = fractions[index], fractions[index + 1]
        if high >= 0.5 > low:
            return ranges_nm[index] + (high - 0.5) / (high - low) * (ranges_nm[index + 1] - ranges_nm[index])
    return ranges_nm[0] if fractions[0] < 0.5 else ranges_nm[-1]


# ---------------------------------------------------------------- 1 format, 2 determinism

def moving_run(seed):
    # 10 s of sim time: own ship turning and moving, one contact moving.
    cfg = calm_cfg()
    radar, environment = make_radar(cfg, seed=seed)
    dt_s = cfg["general"]["physics_step_s"]
    frames = []

    def world(step):
        time_s = step * dt_s
        own_y_nm = 10.0 * time_s / 3600.0
        heading_deg = (350.0 + 2.0 * time_s) % 360.0             # turns through north
        contact = [(8, 1.0 + 0.001 * time_s, 2.0, 500.0, 10.0)]
        return snapshot(time_s, contact, 0.0, own_y_nm, heading_deg, (heading_deg + 2.0) % 360.0,
                        (0.25 * time_s / 3600.0, own_y_nm))
    for step in range(100):
        spokes = radar.make_spokes(world(step), world(step + 1))
        if spokes is not None:
            frames.append(spokes)
    return radar, frames


def test_1_format():
    radar, frames = moving_run(1)
    index = np.concatenate([frame["azimuth_index"] for frame in frames]).astype(np.int64)
    time_s = np.concatenate([frame["sim_time_s"] for frame in frames])
    ref_x = np.concatenate([frame["ref_x_nm"] for frame in frames])
    ref_y = np.concatenate([frame["ref_y_nm"] for frame in frames])
    gyro = np.concatenate([frame["gyro_heading_cdeg"] for frame in frames]).astype(np.int64)
    count = len(index)
    counts_up = bool(np.all((np.diff(index) % SPOKES) == 1)) and index.max() == SPOKES - 1 and index.min() == 0
    spacing_s = 60.0 / (24.0 * 2048.0)
    spacing_error_s = float(np.max(np.abs(np.diff(time_s) - spacing_s)))
    ref_error_nm = float(max(np.max(np.abs(ref_x - 0.25 * time_s / 3600.0)), np.max(np.abs(ref_y - 10.0 * time_s / 3600.0))))
    gyro_expected = np.round(((350.0 + 2.0 * time_s + 2.0) % 360.0) * 100.0).astype(np.int64) % 36000
    gyro_error = int(np.max(np.abs((gyro - gyro_expected + 18000) % 36000 - 18000)))
    ok = abs(count - 8192) <= 1 and counts_up and spacing_error_s <= 1e-6 and ref_error_nm < 1e-6 and gyro_error <= 1
    report(ok, "1a format", "%d spokes in 10 s (8192 +/- 1); azimuth index counts up and wraps: %s; sim_time_s spacing "
           "off by at most %.1e s (limit 1e-6); reference position off by at most %.1e nm; gyro heading off by at most "
           "%d hundredths of a degree" % (count, counts_up, spacing_error_s, ref_error_nm, gyro_error))

    frame = frames[3]
    payload = sim_protocol.pack_spokes(frame["video_range_nm"], frame["azimuth_index"], frame["gyro_heading_cdeg"],
                                       frame["sim_time_s"], frame["ref_x_nm"], frame["ref_y_nm"], frame["video"])
    back = sim_protocol.unpack_spokes(payload)
    same = all(np.array_equal(back[name], frame[name]) for name in
               ["azimuth_index", "gyro_heading_cdeg", "sim_time_s", "ref_x_nm", "ref_y_nm", "video"])
    same = same and back["video_range_nm"] == np.float32(frame["video_range_nm"]) and frame["video"].dtype == np.uint8
    report(same, "1b pack and unpack", "a frame of %d spokes x %d bins (%d bytes) comes back unchanged: %s"
           % (frame["video"].shape[0], frame["video"].shape[1], len(payload), same))


def test_2_determinism():
    def digest(seed):
        radar, frames = moving_run(seed)
        sha = hashlib.sha256()
        for frame in frames:
            sha.update(frame["video"].tobytes())
        return sha.hexdigest()
    first, second, other = digest(1), digest(1), digest(2)
    report(first == second and first != other, "2 determinism", "same seed and inputs: identical video (sha256 %s...); "
           "another seed differs: %s" % (first[:12], first != other))


# ---------------------------------------------------------------- 3 noise

def test_3_noise():
    fractions = {}
    for gain in (60.0, 100.0, 20.0):
        cfg = calm_cfg()
        cfg["radar_controls"]["gain_percent"] = gain
        radar, environment = make_radar(cfg)
        lit = 0
        cells = 0
        for block in range(0, 5 * SPOKES, 256):
            levels_db, header = still_world(radar, [], np.arange(block, block + 256))
            video = video_of(levels_db)
            lit += int(np.count_nonzero(video))
            cells += video.size
        fractions[gain] = 100.0 * lit / cells
    ok = 0.05 <= fractions[60.0] <= 1.0 and fractions[100.0] > 20.0 and fractions[20.0] < 0.001
    report(ok, "3 noise", "cells with video above 0 over 5 revolutions: %.3f %% at gain 60 (0.05 to 1), %.1f %% at "
           "gain 100 (above 20), %.5f %% at gain 20 (below 0.001)" % (fractions[60.0], fractions[100.0], fractions[20.0]))


# ---------------------------------------------------------------- 4 detection

class RingShore:
    # Test land: open water out to shore_nm in every direction, then ground rising to
    # top_m within 0.05 nm and level beyond. Stands in for a LandModel.
    def __init__(self, shore_nm, top_m):
        self.shore_nm = shore_nm
        self.top_m = top_m

    def height_m_at(self, x_nm, y_nm):
        distance_nm = np.hypot(x_nm, y_nm)
        return self.top_m * np.clip((distance_nm - self.shore_nm) / 0.05, 0.0, 1.0)


def test_4_detection():
    steps = np.arange(0.6, 1.4001, 0.05)
    all_ok = True
    for name, height_m, table_nm, rcs_m2, source in TABLE_2_POINT_ROWS:
        cfg = calm_cfg()
        cfg["radar"]["video_range_nm"] = 16.0
        cfg["display"]["range_scale_nm"] = 12.0
        radar, environment = make_radar(cfg)
        ranges_nm = table_nm * steps
        fractions = [detection_fraction(radar, (1, rcs_m2, height_m), 45.0, range_nm, 100) for range_nm in ranges_nm]
        r50_nm = crossing_range(ranges_nm, fractions)
        ok = abs(r50_nm / table_nm - 1.0) <= 0.25
        all_ok = all_ok and ok
        messages.info("%-38s %5.1f m high, %6.1f m2 (%s): R50 = %5.2f nm, table %4.1f NM, %+5.1f %%  %s"
                      % (name, height_m, rcs_m2, source, r50_nm, table_nm, 100.0 * (r50_nm / table_nm - 1.0), "ok" if ok else "OUT"))

    for name, top_m, table_nm in TABLE_2_SHORE_ROWS:
        cfg = calm_cfg()
        cfg["radar"]["video_range_nm"] = 30.0 if table_nm > 10.0 else 16.0
        cfg["display"]["range_scale_nm"] = 24.0 if table_nm > 10.0 else 12.0
        ranges_nm = table_nm * steps
        fractions = []
        for shore_nm in ranges_nm:
            # Land echoes do not fade from sweep to sweep, so one revolution is looked
            # at in 100 places round the shore instead of one place for 100 revolutions.
            radar, environment = make_radar(cfg, RingShore(shore_nm, top_m))
            levels_db, header = still_world(radar, [], np.arange(SPOKES, 2 * SPOKES))
            detected = 0
            for place in range(100):
                centre = int(place * SPOKES / 100)
                rows = np.arange(centre - 5, centre + 6) % SPOKES
                peak_video = (footprint_peak(radar, levels_db[rows], shore_nm, 0.05) - THRESHOLD_DB) * 255.0 / WINDOW_DB
                detected += 1 if peak_video >= DETECT_VIDEO else 0
            fractions.append(detected / 100.0)
        r50_nm = crossing_range(ranges_nm, fractions)
        ok = abs(r50_nm / table_nm - 1.0) <= 0.25
        all_ok = all_ok and ok
        messages.info("%-38s land model, no cross-section: R50 = %5.2f nm, table %4.1f NM, %+5.1f %%  %s"
                      % (name, r50_nm, table_nm, 100.0 * (r50_nm / table_nm - 1.0), "ok" if ok else "OUT"))
    report(all_ok, "4 detection against MSC.192(79) Table 2", "all 9 rows above are within 25 %% of the table range: %s. "
           "The two ship rows pass by construction: their cross-sections were chosen to fit." % all_ok)


# ---------------------------------------------------------------- 5 gain, 6 STC

def steady_peak(cfg, scatterer, bearing_deg, range_nm):
    radar, environment = make_radar(cfg, fluctuate=False)
    x_nm, y_nm = at(bearing_deg, range_nm)
    levels_db, header = still_world(radar, [(1, x_nm, y_nm, scatterer[0], scatterer[1])], sector(1, bearing_deg, 1.0))
    return footprint_peak(radar, levels_db, range_nm)


def test_5_gain():
    cfg = calm_cfg()
    at_60 = steady_peak(cfg, (5000.0, 10.0), 45.0, 3.0)
    cfg["radar_controls"]["gain_percent"] = 70.0
    at_70 = steady_peak(cfg, (5000.0, 10.0), 45.0, 3.0)
    report(abs(at_70 - at_60 - 4.0) <= 0.2, "5 gain", "a steady target reads %.2f dB at gain 60 and %.2f dB at gain 70: "
           "+%.2f dB (4.0 +/- 0.2)" % (at_60, at_70, at_70 - at_60))


def test_6_stc():
    def levels(stc_percent, range_nm, rcs_m2):
        cfg = calm_cfg()
        cfg["radar_controls"]["stc_percent"] = stc_percent
        return steady_peak(cfg, (rcs_m2, 10.0), 45.0, range_nm)
    near_drop = levels(0.0, 1.0, 5000.0) - levels(50.0, 1.0, 5000.0)
    far_drop = levels(0.0, 4.0, 5000.0) - levels(50.0, 4.0, 5000.0)
    # STC 100 % reaches 6 nm; at 0.05 nm the law asks for 30 x log10(6 / 0.05) = 62 dB, limited to stc_max_db.
    limit_drop = levels(0.0, 0.05, 5000.0) - levels(100.0, 0.05, 5000.0)
    stc_max_db = CFG["radar"]["stc_max_db"]
    ok = abs(near_drop - 14.3) <= 0.5 and abs(far_drop) <= 0.1 and limit_drop <= stc_max_db + 0.1 and limit_drop >= stc_max_db - 1.0
    report(ok, "6 STC", "at STC 50 %% a target at 1.0 nm is %.2f dB lower (14.3 +/- 0.5) and one at 4.0 nm, beyond the "
           "3 nm STC range, %.2f dB lower (0); at STC 100 %% a target at 0.05 nm is %.1f dB lower (never more than "
           "stc_max_db = %.0f)" % (near_drop, far_drop, limit_drop, stc_max_db))


# ---------------------------------------------------------------- 7 sea clutter

def sea_profile(douglas, bearing_deg, stc_percent=0.0, revolutions=20):
    # Mean clutter power (noise taken off) and the share of lit cells, per range bin,
    # looking along one true bearing. Wind from 000, own ship heading 000.
    cfg = calm_cfg()
    cfg["environment"]["sea_state_douglas"] = douglas
    cfg["radar_controls"]["stc_percent"] = stc_percent
    radar, environment = make_radar(cfg)
    power_sum = np.zeros(BINS)
    lit = np.zeros(BINS)
    rows = 0
    for revolution in range(1, revolutions + 1):
        levels_db, header = still_world(radar, [], sector(revolution, bearing_deg, 10.0))
        power_sum += np.sum(10.0 ** (levels_db / 10.0), axis=0)
        lit += np.count_nonzero(video_of(levels_db), axis=0)
        rows += levels_db.shape[0]
    range_nm = (np.arange(BINS) + 0.5) * radar.video_range_nm() / BINS
    return range_nm, power_sum / rows - 1.0, lit / rows


def clutter_extent_nm(range_nm, lit_share):
    # The farthest 0.1 nm ring in which at least 5 % of the cells are lit.
    extent = 0.0
    for ring_start in np.arange(0.1, 9.9, 0.1):
        ring = (range_nm >= ring_start) & (range_nm < ring_start + 0.1)
        if lit_share[ring].mean() >= 0.05:
            extent = ring_start + 0.1
    return extent


def test_7_sea_clutter():
    range_nm, up5, lit_up5 = sea_profile(5, 0.0)
    range_nm, down5, lit_down5 = sea_profile(5, 180.0)
    range_nm, up3, lit_up3 = sea_profile(3, 0.0)
    range_nm, up3_stc, lit_up3_stc = sea_profile(3, 0.0, stc_percent=50.0)
    band = (range_nm >= 0.5) & (range_nm <= 2.0)
    slope, intercept = np.polyfit(np.log10(range_nm[band]), 10.0 * np.log10(up5[band]), 1)
    up_down_db = 10.0 * math.log10(up5[band].sum() / down5[band].sum())
    states_db = 10.0 * math.log10(up5[band].sum() / up3[band].sum())
    ok = abs(slope + 30.0) <= 3.0 and abs(up_down_db - 6.0) <= 1.5 and states_db >= 5.0
    report(ok, "7a sea clutter strength", "falls with range at %.1f dB per decade between 0.5 and 2 nm (-30 +/- 3); "
           "upwind is %.1f dB above downwind (6 +/- 1.5); Douglas 5 is %.1f dB above Douglas 3 (5 or more)"
           % (slope, up_down_db, states_db))

    extent_3 = clutter_extent_nm(range_nm, lit_up3)
    extent_5 = clutter_extent_nm(range_nm, lit_up5)
    extent_3_stc = clutter_extent_nm(range_nm, lit_up3_stc)
    ok = 1.5 <= extent_3 <= 3.5 and extent_5 >= 1.3 * extent_3 and extent_3_stc < 0.5 * extent_3
    report(ok, "7b sea clutter extent", "upwind, gain 60, STC 0: fewer than 5 %% of cells lit beyond %.1f nm at "
           "Douglas 3 (1.5 to 3.5) and %.1f nm at Douglas 5 (%.2f times as far, 1.3 or more); with STC 50 %% at "
           "Douglas 3: %.1f nm (less than half)" % (extent_3, extent_5, extent_5 / max(extent_3, 1e-9), extent_3_stc))

    cfg = calm_cfg()
    radar, environment = make_radar(cfg)
    levels_db, header = still_world(radar, [], np.arange(SPOKES, SPOKES + 256))
    calm_lit = 100.0 * np.count_nonzero(video_of(levels_db)[:, 5:100]) / (256 * 95)
    report(calm_lit < 1.0, "7c sea state 0", "no sea clutter: %.2f %% of cells lit within 1 nm (noise only)" % calm_lit)


# ---------------------------------------------------------------- 8 rain and FTC

def rain_scene(rate_mm_per_h, ftc_percent, with_ship, seed=1):
    # One rain cell centred 5 nm north, own ship heading 000. Returns range, mean
    # clutter power per bin, mean video per bin and the ship's peak video.
    cfg = calm_cfg()
    cfg["environment"]["rain_rate_mm_per_h"] = rate_mm_per_h
    cfg["radar_controls"]["ftc_percent"] = ftc_percent
    radar, environment = make_radar(cfg, fluctuate=False, seed=seed)
    environment.cell_x_nm = np.array([0.0])
    environment.cell_y_nm = np.array([5.0])
    ship = [(1, 0.0, 5.0, 8000.0, 10.0)] if with_ship else []
    power_sum = np.zeros(BINS)
    video_sum = np.zeros(BINS)
    ship_peak = 0
    rows = 0
    for revolution in range(1, 11):
        levels_db, header = still_world(radar, ship, sector(revolution, 0.0, 4.0))
        video = video_of(levels_db)
        power_sum += np.sum(10.0 ** (levels_db / 10.0), axis=0)
        video_sum += np.sum(video, axis=0)
        rows += levels_db.shape[0]
        bin_nm = radar.video_range_nm() / BINS
        ship_peak = max(ship_peak, int(video[:, int(5.0 / bin_nm) - 1:int(5.0 / bin_nm) + radar.pulse_bins() + 2].max()))
    range_nm = (np.arange(BINS) + 0.5) * radar.video_range_nm() / BINS
    return range_nm, power_sum / rows - 1.0, video_sum / rows, ship_peak


def test_8_rain_and_ftc():
    range_nm, power_5, video_5, peak = rain_scene(5.0, 0.0, False)
    range_nm, power_10, video_10, peak = rain_scene(10.0, 0.0, False)
    # Measured in the near part of the cell, where little rain lies in front to weaken the echo.
    band = (range_nm >= 3.0) & (range_nm <= 4.5)
    rise_db = 10.0 * math.log10(power_10[band].sum() / power_5[band].sum())
    outside = (range_nm >= 0.2) & (range_nm <= 0.9)       # the cell begins 1 nm out (5 nm - its 4 nm radius)
    report(abs(rise_db - 4.8) <= 0.5 and abs(power_10[outside].mean()) < 0.1, "8a rain clutter",
           "10 mm/h is %.2f dB above 5 mm/h inside the cell (4.8 +/- 0.5, rate^1.6); outside the cell the mean clutter "
           "power is %.3f x noise (0)" % (rise_db, power_10[outside].mean()))

    patch = (range_nm >= 3.5) & (range_nm <= 6.5)
    range_nm, power, video_off, ship_off = rain_scene(10.0, 0.0, True)
    range_nm, power, video_on, ship_on = rain_scene(10.0, 100.0, True)
    range_nm, power, video_empty_off, peak = rain_scene(10.0, 0.0, False)
    range_nm, power, video_empty_on, peak = rain_scene(10.0, 100.0, False)
    fall = 1.0 - video_empty_on[patch].mean() / video_empty_off[patch].mean()
    kept = ship_on / ship_off
    report(fall >= 0.5 and kept >= 0.7, "8b FTC", "with FTC 100 %% the mean video in the rain patch falls from %.1f to "
           "%.1f (%.0f %% less; 50 or more needed); a ship in the patch peaks at video %d against %d without FTC "
           "(keeps %.0f %%; 70 or more needed)" % (video_empty_off[patch].mean(), video_empty_on[patch].mean(),
                                                  100.0 * fall, ship_on, ship_off, 100.0 * kept))


# ---------------------------------------------------------------- 9 beam and pulse

def test_9_beam_and_pulse():
    cfg = calm_cfg()                                      # 6 nm scale, pulse 0.5 us, video range 10 nm
    cfg["display"]["range_scale_nm"] = 6.0
    cfg["radar"]["video_range_nm"] = 10.0
    radar, environment = make_radar(cfg, fluctuate=False)
    bearing_deg, target_nm = 45.0, 3.0
    x_nm, y_nm = at(bearing_deg, target_nm)
    numbers = sector(1, bearing_deg, 3.0)
    levels_db, header = still_world(radar, [(1, x_nm, y_nm, 5000.0, 10.0)], numbers)
    bin_nm = radar.video_range_nm() / BINS
    target_bin = int(target_nm / bin_nm)

    # Azimuth: width of the profile 3 dB below its peak, interpolating between spokes.
    across = levels_db[:, target_bin]
    spoke_deg = 360.0 / SPOKES
    top = int(np.argmax(across))
    half_db = across[top] - 3.0103

    def crossing(step):
        index = top
        while across[index + step] > half_db:
            index += step
        share = (across[index] - half_db) / (across[index] - across[index + step])
        return (index + step * share) * spoke_deg
    width_deg = crossing(1) - crossing(-1)
    wanted_deg = cfg["radar"]["horizontal_beamwidth_deg"]

    # Range: bins within 3 dB of the peak along the strongest spoke.
    along = levels_db[top]
    width_bins = int(np.count_nonzero(along[target_bin - 20:target_bin + 30] > along.max() - 3.0))
    wanted_bins = sim_common.NM_PER_US_PULSE * radar.pulse_length_us() / bin_nm
    ok = abs(width_deg / wanted_deg - 1.0) <= 0.10 and abs(width_bins - wanted_bins) <= 1.5 and width_bins >= 1
    report(ok, "9 beam and pulse", "azimuth half-power width %.3f deg (beamwidth %.1f +/- 10 %%); range width %d bins "
           "at the 6 nm scale, pulse %.2f us (0.0809 x pulse / bin = %.2f +/- 1.5)"
           % (width_deg, wanted_deg, width_bins, radar.pulse_length_us(), wanted_bins))


# ---------------------------------------------------------------- 10 fluctuation

def test_10_fluctuation():
    cfg = calm_cfg()
    radar, environment = make_radar(cfg)
    x_nm, y_nm = at(45.0, 2.0)
    powers = []
    for revolution in range(1, 201):
        levels_db, header = still_world(radar, [(1, x_nm, y_nm, 100.0, 10.0)], sector(revolution, 45.0, 1.0))
        powers.append(10.0 ** (footprint_peak(radar, levels_db, 2.0) / 10.0))
    powers = np.array(powers)
    ratio = float(powers.std() / powers.mean())
    report(abs(ratio - 1.0) <= 0.2, "10a Swerling 1 fading", "one steady scatterer over 200 revolutions: standard "
           "deviation / mean of its power = %.2f (1.0 +/- 0.2, as for an exponential distribution)" % ratio)

    # A 3 m2 boat near its detection range (the 10 m2 reference range x 0.3^(1/4)).
    boat_nm = 5.1 * 0.3 ** 0.25
    fraction = detection_fraction(radar, (2, 3.0, 2.0), 120.0, boat_nm, 200)
    report(0.2 <= fraction <= 0.8, "10b small boat flickers", "a 3 m2 boat at %.2f nm is detected in %.0f %% of 200 "
           "revolutions (20 to 80)" % (boat_nm, 100.0 * fraction))


# ---------------------------------------------------------------- 11 horizon and shadow

class PeakIsland:
    # Test land: an island 100 m high and 0.5 nm in radius, 5 nm north, with a central
    # peak and low shores, and a 20 m hill 6 nm north. Stands in for a LandModel.
    def height_m_at(self, x_nm, y_nm):
        from_island_nm = np.hypot(x_nm, y_nm - 5.0)
        island_m = 100.0 * np.clip(1.0 - from_island_nm / 0.5, 0.0, 1.0) ** 2
        from_hill_nm = np.hypot(x_nm, y_nm - 6.0)
        hill_m = 20.0 * np.clip(1.0 - from_hill_nm / 0.15, 0.0, 1.0)
        return np.maximum(island_m, hill_m)


def test_11_horizon_and_shadow():
    cfg = calm_cfg()
    cfg["radar"]["video_range_nm"] = 24.0
    cfg["display"]["range_scale_nm"] = 24.0
    radar, environment = make_radar(cfg, fluctuate=False)
    peaks = {}
    for range_nm in (16.0, 19.5):
        x_nm, y_nm = at(45.0, range_nm)
        levels_db, header = still_world(radar, [(1, x_nm, y_nm, 1.0e7, 10.0)], sector(1, 45.0, 1.0))
        peaks[range_nm] = video_of(levels_db[:, int(range_nm / (24.0 / BINS)) - 1:int(range_nm / (24.0 / BINS)) + 6]).max()
    limit_nm = 2.2 * (math.sqrt(25.0) + math.sqrt(10.0))
    report(peaks[16.0] >= DETECT_VIDEO and peaks[19.5] < DETECT_VIDEO, "11a radar horizon",
           "a strong scatterer 10 m high, antenna at 25 m: peak video %d at 16 nm (seen) and %d at 19.5 nm (not seen); "
           "expected limit 2.2 x (sqrt 25 + sqrt 10) = %.1f nm" % (peaks[16.0], peaks[19.5], limit_nm))

    cfg = calm_cfg()
    cfg["radar"]["video_range_nm"] = 10.0
    radar, environment = make_radar(cfg, PeakIsland(), fluctuate=False)
    bin_nm = 10.0 / BINS
    ship_behind = (1, 0.0, 6.5, 1.0e5, 10.0)
    side_x_nm, side_y_nm = at(5.0, 6.5)
    ship_aside = (2, side_x_nm, side_y_nm, 1.0e5, 10.0)
    levels_db, header = still_world(radar, [ship_behind, ship_aside], sector(1, 0.0, 8.0) % SPOKES + SPOKES)
    video = video_of(levels_db)
    bearing = (header["bearing_deg_true"] + 180.0) % 360.0 - 180.0
    on_axis = np.abs(bearing) <= 0.5
    island_video = video[on_axis][:, int(4.5 / bin_nm):int(5.0 / bin_nm)].max()
    hill_video = video[on_axis][:, int(5.8 / bin_nm):int(6.2 / bin_nm)].max()
    behind_video = video[on_axis][:, int(6.45 / bin_nm):int(6.6 / bin_nm)].max()
    aside = np.abs(bearing - 5.0) <= 0.5
    aside_video = video[aside][:, int(6.45 / bin_nm):int(6.6 / bin_nm)].max()
    ok = island_video >= DETECT_VIDEO and hill_video < DETECT_VIDEO and behind_video < DETECT_VIDEO and aside_video >= 200
    report(ok, "11b shadow", "peak video: the island's near face %d (seen); the 20 m hill behind it %d (hidden); a "
           "strong ship at 6.5 nm behind it %d (hidden); the same ship 5 deg to the side %d (seen)"
           % (island_video, hill_video, behind_video, aside_video))

    cfg = calm_cfg()
    cfg["environment"]["sea_state_douglas"] = 6
    cfg["radar_controls"]["gain_percent"] = 100.0
    cfg["radar"]["video_range_nm"] = 0.5
    cfg["display"]["range_scale_nm"] = 0.25
    radar, environment = make_radar(cfg)
    levels_db, header = still_world(radar, [(1, 0.0, 0.01, 1000.0, 10.0)], np.arange(SPOKES, 2 * SPOKES))
    video = video_of(levels_db)
    range_nm = (np.arange(BINS) + 0.5) * 0.5 / BINS
    inside = range_nm < cfg["radar"]["minimum_range_nm"]
    report(video[:, inside].max() == 0 and video[:, ~inside].mean() > 100, "11c minimum range",
           "gain 100, Douglas 6, a target at 0.01 nm: highest video inside %.2f nm is %d (%d bins x %d spokes); mean "
           "video outside it %.0f" % (cfg["radar"]["minimum_range_nm"], video[:, inside].max(),
                                      int(inside.sum()), SPOKES, video[:, ~inside].mean()))


# ---------------------------------------------------------------- 12 tug and tow

def two_peaks(profile_db):
    # For a profile with two echoes: how far the dip between the two highest peaks
    # lies below the lower of them, in dB. 0 if there is only one peak.
    peaks = [index for index in range(1, len(profile_db) - 1)
             if profile_db[index] >= profile_db[index - 1] and profile_db[index] > profile_db[index + 1]
             and profile_db[index] > 15.0]
    if len(peaks) < 2:
        return 0.0
    peaks.sort(key=lambda index: profile_db[index], reverse=True)
    first, second = sorted(peaks[:2])
    return float(min(profile_db[first], profile_db[second]) - profile_db[first:second + 1].min())


def test_12_tug_and_tow():
    cfg = calm_cfg()
    cfg["display"]["range_scale_nm"] = 6.0
    cfg["radar"]["video_range_nm"] = 10.0
    radar, environment = make_radar(cfg, fluctuate=False)
    tow_nm = sim_contacts.CALIBRATION_TOW_LENGTH_M / 1852.0            # 180 m in nm
    bin_nm = 10.0 / BINS
    results = []
    for range_nm in (1.0, 2.0, 3.0):
        # Radial: the tow straight behind the tug on the same bearing.
        tug = (1,) + at(45.0, range_nm) + (50.0, 10.0)
        tow = (2,) + at(45.0, range_nm + tow_nm) + (sim_contacts.CALIBRATION_TOW_RCS_M2, 10.0)
        levels_db, header = still_world(radar, [tug, tow], sector(1, 45.0, 1.0))
        strongest = int(np.argmax(levels_db[:, int(range_nm / bin_nm)]))
        radial_db = two_peaks(levels_db[strongest, int((range_nm - 0.05) / bin_nm):int((range_nm + 0.25) / bin_nm)])
        # Tangential: the tow at the same range, 180 m to one side.
        side_deg = math.degrees(tow_nm / range_nm)
        tow = (2,) + at(45.0 + side_deg, range_nm) + (sim_contacts.CALIBRATION_TOW_RCS_M2, 10.0)
        levels_db, header = still_world(radar, [tug, tow], sector(1, 45.0 + side_deg / 2.0, side_deg + 2.0))
        target_bin = int(range_nm / bin_nm)
        tangential_db = two_peaks(levels_db[:, target_bin:target_bin + radar.pulse_bins()].max(axis=1))
        results.append((range_nm, radial_db, tangential_db))
    ok = all(radial_db >= 3.0 and tangential_db >= 1.0 for range_nm, radial_db, tangential_db in results)
    report(ok, "12 tug and tow", "180 m apart (50 and 800 m2): dip between the two peaks, radial / tangential: "
           + "; ".join("%.0f nm: %.1f / %.1f dB" % result for result in results)
           + " (3 dB or more radial, 1 dB or more tangential)")


# ---------------------------------------------------------------- 14 performance

def busy_world(seed, sea_state):
    # Generated land, 40 contacts, own ship at its start position.
    cfg = copy.deepcopy(CFG)
    cfg["environment"].update({"sea_state_from_wind": False, "sea_state_douglas": sea_state})
    cfg["traffic"]["density_per_100_nm2"] = 40.0 * 100.0 / (math.pi * cfg["traffic"]["active_radius_nm"] ** 2)
    cfg["traffic"]["density_stddev_fraction"] = 0.0
    streams = sim_common.make_random_streams(seed)
    messages.message_verbosity = 0
    try:
        land = sim_land.generate_land(cfg, streams["land"])
    finally:
        messages.message_verbosity = None
    own_x_nm, own_y_nm, heading_deg = land.find_start(streams["own_ship"])
    environment = sim_environment.Environment(cfg, streams["environment"], own_x_nm, own_y_nm)
    traffic = sim_contacts.Traffic(cfg, streams["traffic"], land, environment)
    for step in range(600):
        traffic.step(1.0, float(step), own_x_nm, own_y_nm, 0.0, 0.0)
    radar = sim_radar.RadarVideo(cfg, streams["radar"], land, environment)
    return cfg, land, environment, traffic, radar, (own_x_nm, own_y_nm, heading_deg)


def traffic_snapshot(traffic, time_s, own):
    ids, xs, ys, rcss, heights = sim_radar.scatterers_of(traffic.contacts)
    return sim_radar.Snapshot(time_s, own[0], own[1], own[2], own[2], own[0], own[1], ids, xs, ys, rcss, heights)


def test_14_performance():
    cfg, land, environment, traffic, radar, own = busy_world(1, 3)
    dt_s = cfg["general"]["physics_step_s"]
    results = []
    for video_range_nm, scale_nm in ((10.0, 6.0), (40.0, 24.0)):
        cfg["radar"]["video_range_nm"] = video_range_nm
        cfg["display"]["range_scale_nm"] = scale_nm
        spokes = 0
        start_s = time.process_time()
        step = 0
        while time.process_time() - start_s < 4.0:
            before = traffic_snapshot(traffic, step * dt_s, own)
            traffic.step(dt_s, 600.0 + step * dt_s, own[0], own[1], 0.0, 0.0)
            after = traffic_snapshot(traffic, (step + 1) * dt_s, own)
            frame = radar.make_spokes(before, after)
            spokes += frame["video"].shape[0]
            step += 1
        cpu_s = time.process_time() - start_s
        results.append((video_range_nm, spokes / cpu_s))
    needed = cfg["radar"]["antenna_rpm"] * SPOKES / 60.0                # 819.2 spokes per sim second
    slowest = min(rate for video_range_nm, rate in results)
    report(slowest >= 820.0, "14 performance", "%d contacts (%d scatterers), generated land, Douglas 3, traffic and "
           "snapshots included: %s spokes per second of CPU time on one core (820 needed at 1x). Highest multiplier "
           "the generator sustains: %.1fx (10x needs %.0f spokes/s); at 1x it uses %.0f %% of one core"
           % (len(traffic.contacts), len(sim_radar.scatterers_of(traffic.contacts)[0]),
              " and ".join("%.0f at video range %.0f nm" % (rate, video_range_nm) for video_range_nm, rate in results),
              slowest / needed, 10.0 * needed, 100.0 * needed / slowest))
    return slowest


# ---------------------------------------------------------------- 13 wiring over TCP

def test_13_wiring_over_tcp():
    # The calibration scenario: no land to make, and buoy B1 sits 2 nm dead ahead.
    with open(CONFIG_PATH, "r", encoding="utf-8") as config_file:
        text = config_file.read()
    with open(TEMP_CONFIG_PATH, "w", encoding="utf-8") as config_file:
        config_file.write(text.replace('scenario = "random"', 'scenario = "calibration"', 1))
    probe = socket.socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()
    sim = subprocess.Popen([sys.executable, "-u", SIM_MAIN, "--config", TEMP_CONFIG_PATH, "--port", str(port)],
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        deadline_s = time.perf_counter() + 10.0
        while True:
            try:
                sock = socket.create_connection(("127.0.0.1", port), timeout=60.0)
                break
            except OSError:
                if time.perf_counter() > deadline_s:
                    raise
                time.sleep(0.1)
        settings = {}
        hello = {}

        def one_revolution():
            # Throws away what is already on its way, then gathers 2048 spokes.
            frames = []
            gathered = 0
            skip = 30
            while gathered < SPOKES:
                frame_type, payload = sim_protocol.read_frame(sock)
                if frame_type == sim_protocol.FRAME_JSON:
                    message = sim_protocol.decode_json(payload)
                    if message["t"] == "setting":
                        settings[message["path"]] = message["value"]
                    if message["t"] == "hello":
                        hello.update(message)
                    continue
                if skip > 0:
                    skip -= 1
                    continue
                frame = sim_protocol.unpack_spokes(payload)
                frames.append(frame)
                gathered += len(frame["azimuth_index"])
            return frames

        def echo_bins(frames):
            # Length in bins of buoy B1's echo, dead ahead about 2 nm off: the longest
            # run of lit bins between 1.5 and 2.5 nm on the spokes within 0.5 deg of the bow.
            longest = 0
            for frame in frames:
                bin_nm = frame["video_range_nm"] / frame["video"].shape[1]
                for index, video in zip(frame["azimuth_index"], frame["video"]):
                    if index > 2 and index < SPOKES - 3:
                        continue
                    run = 0
                    for value in video[int(1.5 / bin_nm):int(2.5 / bin_nm)]:
                        run = run + 1 if value > 0 else 0
                        longest = max(longest, run)
            return longest

        def mean_video(frames):
            return float(np.mean([frame["video"].mean() for frame in frames]))

        sim_protocol.send_json(sock, {"t": "set", "path": "general.sim_speed_multiplier", "value": 4})
        first = one_revolution()
        largest_frame = max(len(frame["azimuth_index"]) for frame in first)
        controls = {control["path"] for control in hello["controls"]}
        ok = (largest_frame <= 64 and first[0]["video"].shape[1] == BINS and first[0]["video_range_nm"] == 10.0
              and {"radar.video_range_nm", "radar_controls.gain_percent", "display.range_scale_nm"} <= controls)
        report(ok, "13a SPOKES frames", "frames hold at most %d spokes (limit 64) of %d bins, video range %.1f nm; "
               "hello.controls lists the radar keys: %s" % (largest_frame, first[0]["video"].shape[1],
                                                           first[0]["video_range_nm"], ok))

        sim_protocol.send_json(sock, {"t": "set", "path": "radar_controls.gain_percent", "value": 80})
        louder = one_revolution()
        ok = settings.get("radar_controls.gain_percent") == 80.0 and mean_video(louder) > 2.0 * mean_video(first)
        report(ok, "13b set radar_controls.gain_percent", "answered with setting %s; mean video went from %.2f to %.2f"
               % (settings.get("radar_controls.gain_percent"), mean_video(first), mean_video(louder)))
        sim_protocol.send_json(sock, {"t": "set", "path": "radar_controls.gain_percent", "value": 60})

        short_pulse = echo_bins(one_revolution())                      # 6 nm scale, 0.5 us: about 4 bins
        sim_protocol.send_json(sock, {"t": "set", "path": "display.range_scale_nm", "value": 24})
        long_pulse = echo_bins(one_revolution())                       # 24 nm scale, 1.0 us: about 8 bins
        ok = settings.get("display.range_scale_nm") == 24.0 and long_pulse >= short_pulse + 3
        report(ok, "13c set display.range_scale_nm", "answered with setting %s; buoy B1's echo is %d bins long at the "
               "6 nm scale (pulse 0.5 us) and %d bins at the 24 nm scale (pulse 1.0 us), video range unchanged"
               % (settings.get("display.range_scale_nm"), short_pulse, long_pulse))

        sim_protocol.send_json(sock, {"t": "set", "path": "radar.video_range_nm", "value": 20})
        wider = one_revolution()
        sim_protocol.send_json(sock, {"t": "set", "path": "display.orientation", "value": "head_up"})
        one_revolution()
        ok = (settings.get("radar.video_range_nm") == 20.0 and wider[-1]["video_range_nm"] == 20.0
              and settings.get("display.orientation") == "head_up")
        report(ok, "13d set radar.video_range_nm", "answered with setting %s; frames now carry video_range_nm = %.1f; "
               "a display-only key (display.orientation) is stored and echoed: %s"
               % (settings.get("radar.video_range_nm"), wider[-1]["video_range_nm"], settings.get("display.orientation")))
        sim_protocol.send_json(sock, {"t": "quit"})
        sim.wait(timeout=5.0)
        sock.close()
    finally:
        if sim.poll() is None:
            sim.kill()
        if os.path.exists(TEMP_CONFIG_PATH):
            os.remove(TEMP_CONFIG_PATH)


# ---------------------------------------------------------------- 15 previews

def picture_content(picture, scale_nm, snapshot, check_contacts):
    # What the picture holds, from its pixels: the percentage of the PPI circle that is lit, and,
    # for the calibration scene, how many contacts that should be visible have a bright pixel
    # (video 64 or more) within 3 px of where the contact should be (north up, own ship at the centre).
    # Should be visible: inside 80 % of the picture range, and for cross-sections under 100 m2 also
    # inside 4.5 nm (Table 2 detection is near 5.6 nm for 10 m2, so beyond that a buoy may be missing).
    size_px = picture.shape[0]
    radius_px = size_px / 2.0
    green = picture[:, :, 1]
    offset = np.arange(size_px) + 0.5 - radius_px
    inside = np.hypot(offset[None, :], offset[:, None]) < radius_px
    lit_percent = 100.0 * np.count_nonzero(green[inside] > 0) / np.count_nonzero(inside)
    found = 0
    expected = 0
    if check_contacts:
        px_per_nm = radius_px / scale_nm
        for x_nm, y_nm, rcs_m2 in zip(snapshot.scatterer_x_nm, snapshot.scatterer_y_nm, snapshot.scatterer_rcs_m2):
            east_nm = x_nm - snapshot.own_x_nm
            north_nm = y_nm - snapshot.own_y_nm
            range_nm = math.hypot(east_nm, north_nm)
            if range_nm > 0.8 * scale_nm or rcs_m2 < 1.0 or (rcs_m2 < 100.0 and range_nm > 4.5):
                continue
            expected += 1
            column = int(round(radius_px + east_nm * px_per_nm))
            row = int(round(radius_px - north_nm * px_per_nm))
            window = green[max(row - 3, 0):row + 4, max(column - 3, 0):column + 4]
            if window.size > 0 and window.max() >= 64:
                found += 1
    return lit_percent, found, expected


def one_picture(radar, before, after, size_px):
    numbers = np.arange(SPOKES, 2 * SPOKES)
    levels_db, header = radar.compute_levels_db(numbers, before, after)
    header["video"] = video_of(levels_db)
    return devtools.render_ppi(header, size_px, header["video_range_nm"])


def test_15_previews():
    size_px = 600

    def both_scales(cfg, radar, before, after, name, text, check_contacts):
        pictures = []
        for scale_nm in (6.0, 12.0):
            cfg["radar"]["video_range_nm"] = scale_nm
            cfg["display"]["range_scale_nm"] = scale_nm
            pictures.append(one_picture(radar, before, after, size_px))
        path = os.path.join(ROOT, name)
        devtools.write_png(path, np.concatenate(pictures, axis=1))
        details = []
        ok = True
        for scale_nm, picture in zip((6.0, 12.0), pictures):
            lit_percent, found, expected = picture_content(picture, scale_nm, before, check_contacts)
            ok = ok and 0.0 < lit_percent < 50.0 and found == expected
            details.append("%.0f NM: %.1f %% of the circle lit%s" % (scale_nm, lit_percent,
                           ", %d of %d expected contacts bright" % (found, expected) if check_contacts else ""))
        report(ok, "15 preview", "%s written (6 NM scale left, 12 NM right; north up; gain 60, STC 20, FTC 0): %s; %s "
               "(some pixels lit, under 50 %% lit%s) - Oliver looks at it"
               % (name, text, "; ".join(details), ", every expected contact bright" if check_contacts else ""))

    # Open sea with the nine calibration contacts, own ship at the centre heading north.
    def calibration_scene(changes):
        cfg = copy.deepcopy(CFG)
        cfg["environment"].update({"sea_state_from_wind": False, "wind_from_deg_true": 270.0, "wind_speed_kn": 15.0,
                                   "rain_rate_mm_per_h": 0.0})
        cfg["environment"].update(changes)
        land = sim_land.make_open_sea(cfg)
        environment = sim_environment.Environment(cfg, np.random.default_rng(3), 0.0, 0.0)
        traffic = sim_contacts.Traffic(cfg, np.random.default_rng(4), land, environment)
        sim_contacts.add_calibration_contacts(traffic)
        radar = sim_radar.RadarVideo(cfg, np.random.default_rng(5), land, environment)
        own = (0.0, 0.0, 0.0)
        return cfg, environment, radar, traffic_snapshot(traffic, 0.0, own), traffic_snapshot(traffic, 1.0e9, own)

    cfg, environment, radar, before, after = calibration_scene({"sea_state_douglas": 1})
    both_scales(cfg, radar, before, after, "preview_radar_calm.png", "calibration contacts, sea state 1", True)
    cfg, environment, radar, before, after = calibration_scene({"sea_state_douglas": 5})
    both_scales(cfg, radar, before, after, "preview_radar_sea5.png", "calibration contacts, sea state 5, wind from 270", True)
    cfg, environment, radar, before, after = calibration_scene({"sea_state_douglas": 2, "rain_rate_mm_per_h": 8.0})
    environment.cell_x_nm = np.array([5.0, -6.0, 40.0])
    environment.cell_y_nm = np.array([4.0, -5.0, 40.0])
    both_scales(cfg, radar, before, after, "preview_radar_rain.png",
                "calibration contacts, sea state 2, 8 mm/h rain cells to the north-east and south-west", True)

    cfg, land, environment, traffic, radar, own = busy_world(1, 3)
    cfg["environment"].update({"wind_from_deg_true": 270.0, "wind_speed_kn": 15.0})
    # For the picture own ship is moved in from its start to the middle of the harbour
    # approach lane, heading for the harbour, so the coast is in range.
    approach = [lane for lane in land.lanes if lane.name == sim_land.HARBOUR_APPROACH][0].points_nm
    middle = (approach[0] + approach[-1]) / 2.0
    inbound = approach[-1] - approach[0]
    own = (float(middle[0]), float(middle[1]), float(sim_common.bearing_true_deg(inbound[0], inbound[1])))
    before = traffic_snapshot(traffic, 0.0, own)
    after = traffic_snapshot(traffic, 1.0e9, own)
    both_scales(cfg, radar, before, after, "preview_radar_coast.png",
                "generated land (seed 1) and 40 contacts, sea state 3, own ship at (%.1f, %.1f) nm" % (own[0], own[1]), False)


def main():
    test_1_format()
    test_2_determinism()
    test_3_noise()
    test_4_detection()
    test_5_gain()
    test_6_stc()
    test_7_sea_clutter()
    test_8_rain_and_ftc()
    test_9_beam_and_pulse()
    test_10_fluctuation()
    test_11_horizon_and_shadow()
    test_12_tug_and_tow()
    test_13_wiring_over_tcp()
    test_14_performance()
    test_15_previews()
    if failures:
        messages.fail("%d test line(s) failed" % failures)
    else:
        messages.ok("All M4 tests passed")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
