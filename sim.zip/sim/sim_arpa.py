# sim_arpa.py - the ARPA: plots from the radar video, target tracking, CPA/TCPA,
# bow crossing, history, alarms, trial maneuver, stabilisation switch (BRIEF.md Section 10).
# It works from the same 8-bit video the display gets, so gain, STC, FTC and clutter
# affect it as they affect the picture.
#
# Units: positions nm in the stabilisation frame (x east, y north), speeds kn,
# bearings deg (true unless named _rel), time s of sim time (hours only inside the
# filter, named _h), video 0..255.
# Called by: sim_main.py every physics step (add_spokes, then step), and test_m8.py.
#
# How it works, all of it chosen, not from a source:
# - The latest revolution of video is kept in a buffer, one row per azimuth index, each
#   row with the gyro heading, reference position and time its spoke carried.
# - A target is looked for once per revolution, as soon as the antenna has swept past
#   the window around its predicted position. Nothing waits for the antenna to pass
#   the bow, so an echo dead ahead is never cut in two.
# - A plot is a group of touching cells with video at or above ARPA_VIDEO_LEVEL, at
#   least PLOT_MIN_CELLS of them. Its position is the video-weighted centre, moved
#   back by half a pulse length because an echo starts at the target and is one
#   pulse long.
# - The tracker is a constant-velocity Kalman filter per target, state [x, y, vx, vy].
#   A new track starts with speed 0 and a wide speed uncertainty, so the vector takes
#   a minute or more to settle, as on a real set.
# - Measurement noise comes from the radar's resolution: half the pulse length (or half
#   a range bin if that is larger) in range, a quarter of the beamwidth in bearing.
# - Process noise comes from arpa.maneuver_allowance_kn_per_min: the speed change per
#   minute the filter allows a target. Larger follows turns sooner, with noisier vectors.
# - A small random error is added to every plot (PLOT_JITTER_*), because without it
#   the tracker is far better than real equipment.

import collections
import math
from dataclasses import dataclass

import numpy as np

import messages
from sim_common import S_PER_H, bearing_true_deg, cpa_tcpa, normalise_360, velocity_xy_kn

# ---- everything below is chosen, not from a source ----
ARPA_VIDEO_LEVEL = 1             # a cell counts as echo at this video value or above (anything the display shows)
PLOT_MIN_CELLS = 3               # fewer touching cells than this is taken for noise speckle
GUARD_MIN_CELLS = 4              # the same for a guard zone, which is large and so sees more speckle
NEAR_MARGIN_NM = 0.05            # find_plots(near=...): cells this far outside the circle still count
NEAR_BELOW_NM = 1.0              # only targets closer than this are looked for inside a circle (wide windows)
MAX_LIT_CELLS = 4000             # more echo cells than this in one window: flooded with clutter
GATE_MIN_NM = 0.1                # (BRIEF.md Section 10)
GATE_SIGMAS = 3.0                # (BRIEF.md Section 10)
GATE_MAX_NM = 0.5
GATE_GROWTH_PER_MISS = 0.25      # the gate is this much wider for every revolution without a plot
WINDOW_EXTRA_DEG = 1.5           # the search window is the gate plus this in bearing (own ship may be turning) ...
WINDOW_EXTRA_NM = 0.05           # ... and this in range
WINDOW_MAX_HALF_DEG = 60.0
START_SPEED_SIGMA_KN = 30.0      # a new track's speed is unknown: 0 kn, give or take this, on each axis
RANGE_SIGMA_PULSES = 0.5         # range measurement noise, as a share of the pulse length
BEARING_SIGMA_BEAMWIDTHS = 0.25  # bearing measurement noise, as a share of the horizontal beamwidth
# Extra random error added to every plot, to bring the tracker down to the accuracy of
# real equipment (BRIEF.md Section 10 allows it when the tracker beats MSC.192(79) by
# more than 3 times). 0 = none. With these values the hardest figure of the table
# (TCPA of a slow overtaking ship, 3 minutes after acquisition) is met about 2 times over.
PLOT_JITTER_RANGE_NM = 0.003     # standard deviation; 0.003 nm = 5.6 m
PLOT_JITTER_BEARING_DEG = 0.04   # standard deviation
SAME_ECHO_NM = 0.03              # an acquisition this close to a tracked target is the same echo: ignored
ALARM_CLEAR_REVOLUTIONS = 3      # a CPA/TCPA alarm clears when its condition has been false this many revolutions running
MESSAGE_DECIMALS = {"x_nm": 4, "y_nm": 4, "range_nm": 3, "bearing_deg_true": 1, "course_deg_true": 1, "speed_kn": 2,
                    "rel_course_deg_true": 1, "rel_speed_kn": 2, "cpa_nm": 3, "tcpa_min": 2, "bcr_nm": 3,
                    "bct_min": 2, "trial_cpa_nm": 3, "trial_tcpa_min": 2}
NEVER = -10 ** 12                # spoke number of a buffer row that has not been written


@dataclass
class OwnData:
    # What the ARPA is told about own ship every physics step: the instruments, in both
    # stabilisation frames (BRIEF.md Section 5).
    sim_time_s: float
    gyro_heading_deg: float
    sea_x_nm: float              # dead-reckoned from log and gyro
    sea_y_nm: float
    sea_vx_kn: float             # log speed along the gyro heading
    sea_vy_kn: float
    ground_x_nm: float           # GPS
    ground_y_nm: float
    ground_vx_kn: float
    ground_vy_kn: float


def own_data_from(own_ship, sim_time_s):
    sea_vx_kn, sea_vy_kn = velocity_xy_kn(own_ship.log_speed_kn, own_ship.gyro_heading_deg)
    return OwnData(sim_time_s, own_ship.gyro_heading_deg, own_ship.sea_ref_x_nm, own_ship.sea_ref_y_nm,
                   float(sea_vx_kn), float(sea_vy_kn), own_ship.x_nm, own_ship.y_nm,
                   own_ship.ground_vx_kn, own_ship.ground_vy_kn)


def bow_crossing(rel_x_nm, rel_y_nm, rel_vx_kn, rel_vy_kn, heading_deg):
    # Where and when a target crosses own ship's heading line ahead, if own ship and
    # target hold course and speed. Position and velocity are relative to own ship.
    # Returns (bcr_nm, bct_min), or (None, None) if it crosses astern or never crosses.
    heading_rad = math.radians(heading_deg)
    ahead_x, ahead_y = math.sin(heading_rad), math.cos(heading_rad)
    starboard_x, starboard_y = math.cos(heading_rad), -math.sin(heading_rad)
    ahead_nm = rel_x_nm * ahead_x + rel_y_nm * ahead_y
    starboard_nm = rel_x_nm * starboard_x + rel_y_nm * starboard_y
    ahead_kn = rel_vx_kn * ahead_x + rel_vy_kn * ahead_y
    starboard_kn = rel_vx_kn * starboard_x + rel_vy_kn * starboard_y
    if abs(starboard_kn) < 1e-9:
        return None, None
    time_h = -starboard_nm / starboard_kn
    if time_h <= 0.0:
        return None, None
    range_nm = ahead_nm + ahead_kn * time_h
    if range_nm <= 0.0:
        return None, None
    return range_nm, time_h * 60.0                       # h -> min


def trial_cpa_tcpa(rel_x_nm, rel_y_nm, target_vx_kn, target_vy_kn, own_vx_kn, own_vy_kn,
                   trial_course_deg_true, trial_speed_kn, delay_s):
    # CPA and TCPA if own ship changed at once to the trial course and speed after
    # delay_s. Until then everything goes on as now. Returns (cpa_nm, tcpa_min), TCPA
    # counted from now.
    rel_vx_kn = target_vx_kn - own_vx_kn
    rel_vy_kn = target_vy_kn - own_vy_kn
    delay_h = delay_s / S_PER_H
    cpa_nm, tcpa_min = cpa_tcpa((rel_x_nm, rel_y_nm), (rel_vx_kn, rel_vy_kn))
    if 0.0 < tcpa_min <= delay_s / 60.0:
        return cpa_nm, tcpa_min                          # closest approach comes before the maneuver
    then_x_nm = rel_x_nm + rel_vx_kn * delay_h
    then_y_nm = rel_y_nm + rel_vy_kn * delay_h
    trial_vx_kn, trial_vy_kn = velocity_xy_kn(trial_speed_kn, trial_course_deg_true)
    cpa_nm, tcpa_min = cpa_tcpa((then_x_nm, then_y_nm),
                                (target_vx_kn - float(trial_vx_kn), target_vy_kn - float(trial_vy_kn)))
    return cpa_nm, tcpa_min + delay_s / 60.0             # s -> min


def touching_groups(rows, columns):
    # Groups of cells that touch each other, corners included. rows and columns are
    # lists of the cells' places; returns a list of lists of positions in those lists.
    place = {}
    for position in range(len(rows)):
        place[(rows[position], columns[position])] = position
    group_of = [-1] * len(rows)
    groups = []
    for first in range(len(rows)):
        if group_of[first] >= 0:
            continue
        group_of[first] = len(groups)
        members = [first]
        waiting = [first]
        while waiting:
            position = waiting.pop()
            row = rows[position]
            column = columns[position]
            for row_step in (-1, 0, 1):
                for column_step in (-1, 0, 1):
                    other = place.get((row + row_step, column + column_step))
                    if other is not None and group_of[other] < 0:
                        group_of[other] = len(groups)
                        members.append(other)
                        waiting.append(other)
        groups.append(members)
    return groups


class Track:
    def __init__(self, track_id, x_nm, y_nm, time_s, position_cov):
        self.id = track_id
        self.state = "ACQ"                       # ACQ, TREND, TRACK or LOST
        self.vector = np.array([x_nm, y_nm, 0.0, 0.0])      # x_nm, y_nm, vx_kn, vy_kn in the stabilisation frame
        self.cov = np.zeros((4, 4))
        self.cov[0:2, 0:2] = position_cov
        self.cov[2, 2] = START_SPEED_SIGMA_KN ** 2
        self.cov[3, 3] = START_SPEED_SIGMA_KN ** 2
        self.time_s = time_s                     # the time the vector is valid for
        self.acquired_s = time_s
        self.misses = 0                          # revolutions running without a plot
        self.last_look_number = NEVER            # spoke number that ended the window of the last look
        self.coasting = False                    # outside the video range: carried on, not looked for
        self.history = []                        # (time_s, rel_x_nm, rel_y_nm, own sea x, y, own ground x, y)
        self.next_history_s = time_s
        self.alarm_clear_count = 0

    def position_at(self, time_s):
        dt_h = (time_s - self.time_s) / S_PER_H              # s -> h
        return (float(self.vector[0] + self.vector[2] * dt_h), float(self.vector[1] + self.vector[3] * dt_h))


class Arpa:
    def __init__(self, cfg, rng):
        self.cfg = cfg
        self.arpa = cfg["arpa"]                  # limits and switches: read when used, so a change takes effect at once
        self.rng = rng
        radar = cfg["radar"]
        self.azimuth_bins = radar["azimuth_bins"]
        self.range_bins = radar["range_bins"]
        self.minimum_range_nm = radar["minimum_range_nm"]
        self.beamwidth_deg = radar["horizontal_beamwidth_deg"]
        self.revolution_s = 60.0 / radar["antenna_rpm"]
        self.spoke_time_s = self.revolution_s / self.azimuth_bins
        # Filter process noise. The allowance is a speed change per minute; x 60 gives
        # kn per hour. Taken as a random speed change of that size every revolution it
        # is a white acceleration of (kn per hour)^2 x one revolution in hours.
        allowance_kn_per_h = self.arpa["maneuver_allowance_kn_per_min"] * 60.0          # kn/min -> kn/h
        self.process_noise = allowance_kn_per_h ** 2 * (self.revolution_s / S_PER_H)   # kn^2 per h

        # The latest revolution of video.
        self.video = np.zeros((self.azimuth_bins, self.range_bins), dtype=np.uint8)
        self.spoke_number = np.full(self.azimuth_bins, NEVER, dtype=np.int64)
        self.spoke_gyro_deg = np.zeros(self.azimuth_bins)
        self.spoke_ref_x_nm = np.zeros(self.azimuth_bins)
        self.spoke_ref_y_nm = np.zeros(self.azimuth_bins)
        self.spoke_time = np.zeros(self.azimuth_bins)
        self.video_range_nm = None
        self.pulse_bins = None
        self.valid_from_number = 0               # rows written before this spoke number are not used
        self.latest_number = NEVER

        self.own = None
        self.stabilization = self.arpa["stabilization"]
        self.tracks = {}                         # id -> Track
        self.alarms = []
        self.next_alarm_id = 1
        self.zones = {}
        for index in (1, 2):
            self.zones[index] = {"index": index, "enabled": False, "inner_nm": 0.0, "outer_nm": 0.0,
                                 "start_deg": 0.0, "end_deg": 0.0, "last_number": NEVER,
                                 "hits": collections.deque(maxlen=self.arpa["guard_hits_window"])}
        self.trial = None                        # None, or {"course_deg_true", "speed_kn", "delay_s"}
        self.revolution = None
        self.latest_targets = []
        self.targets_due = False                 # sim_main sends "targets" and clears this
        self.alarms_changed = False              # sim_main sends "alarms" and clears this
        self.look_count = 0

    # ---------------------------------------------------------------- video in

    def add_spokes(self, spokes, pulse_bins):
        # A block of spokes as RadarVideo.make_spokes returns it. A change of video
        # range or pulse length makes everything before it useless: echoes would sit
        # in other bins.
        numbers = np.round(spokes["sim_time_s"] / self.spoke_time_s).astype(np.int64)
        if spokes["video_range_nm"] != self.video_range_nm or pulse_bins != self.pulse_bins:
            if self.video_range_nm is not None:
                messages.debug(f"ARPA: video range {spokes['video_range_nm']:.2f} nm, pulse {pulse_bins} bins; "
                               f"the revolution in hand is discarded")
            self.video_range_nm = spokes["video_range_nm"]
            self.pulse_bins = pulse_bins
            self.valid_from_number = int(numbers[0])
        index = spokes["azimuth_index"].astype(np.int64)
        self.video[index] = spokes["video"]
        self.spoke_number[index] = numbers
        self.spoke_gyro_deg[index] = spokes["gyro_heading_cdeg"] / 100.0      # hundredths of a degree -> deg
        self.spoke_ref_x_nm[index] = spokes["ref_x_nm"]
        self.spoke_ref_y_nm[index] = spokes["ref_y_nm"]
        self.spoke_time[index] = spokes["sim_time_s"]
        self.latest_number = int(numbers[-1])

    def wants_video(self):
        # True if the ARPA has work that needs the radar running.
        if self.tracks:
            return True
        return self.zones[1]["enabled"] or self.zones[2]["enabled"]

    # ---------------------------------------------------------------- own ship

    def own_position(self, stabilization=None):
        if stabilization is None:
            stabilization = self.stabilization
        if stabilization == "sea":
            return self.own.sea_x_nm, self.own.sea_y_nm
        return self.own.ground_x_nm, self.own.ground_y_nm

    def own_velocity(self, stabilization=None):
        if stabilization is None:
            stabilization = self.stabilization
        if stabilization == "sea":
            return self.own.sea_vx_kn, self.own.sea_vy_kn
        return self.own.ground_vx_kn, self.own.ground_vy_kn

    # ---------------------------------------------------------------- plots

    def find_plots(self, first_index, spoke_count, first_bin, last_bin, min_cells, keep_cells=False, near=None):
        # Plots in a window of the video buffer: spoke_count rows starting at azimuth
        # index first_index (wrapping past the bow), bins first_bin to last_bin - 1.
        # Returns (list of plots, flooded). Each plot is a dict in the stabilisation frame.
        # keep_cells adds the plot's lit cells (rows, columns, values as arrays) for split_plot.
        # near = (range_nm, bearing_rel_deg, radius_nm): only the cells within that circle (and a margin)
        # count. A window round a target close to own ship is very wide in azimuth, and its corners are full of clutter.
        indices = (first_index + np.arange(spoke_count)) % self.azimuth_bins
        window = self.video[indices, first_bin:last_bin]
        lit_rows, lit_columns = np.nonzero(window >= ARPA_VIDEO_LEVEL)
        if near is not None and len(lit_rows) > 0:
            bin_nm = self.video_range_nm / self.range_bins
            cell_range_nm = (first_bin + lit_columns + 0.5) * bin_nm
            cell_bearing_rad = np.radians(indices[lit_rows] / self.azimuth_bins * 360.0)
            point_bearing_rad = math.radians(near[1])
            dx_nm = cell_range_nm * np.sin(cell_bearing_rad) - near[0] * math.sin(point_bearing_rad)
            dy_nm = cell_range_nm * np.cos(cell_bearing_rad) - near[0] * math.cos(point_bearing_rad)
            inside = np.hypot(dx_nm, dy_nm) <= near[2] + NEAR_MARGIN_NM
            lit_rows = lit_rows[inside]
            lit_columns = lit_columns[inside]
        if len(lit_rows) > MAX_LIT_CELLS:
            return [], True
        if len(lit_rows) < min_cells:
            return [], False
        rows = lit_rows.tolist()
        columns = lit_columns.tolist()
        values = window[lit_rows, lit_columns].astype(float).tolist()
        bin_nm = self.video_range_nm / self.range_bins
        plots = []
        for members in touching_groups(rows, columns):
            if len(members) < min_cells:
                continue
            plot = self.plot_of(np.array([rows[position] for position in members]),
                                np.array([columns[position] for position in members]),
                                np.array([values[position] for position in members]),
                                indices, first_index, first_bin)
            if keep_cells:
                plot["cell_rows"] = np.array([rows[position] for position in members])
                plot["cell_columns"] = np.array([columns[position] for position in members])
                plot["cell_values"] = np.array([values[position] for position in members])
            plots.append(plot)
        return plots, False

    def plot_of(self, rows, columns, values, indices, first_index, first_bin):
        # One plot from lit cells (window row, window column, video value): the video-weighted
        # centre, the spoke nearest it, and the cell count and peak.
        bin_nm = self.video_range_nm / self.range_bins
        weight = float(values.sum())
        row = float((values * rows).sum()) / weight
        column = float((values * columns).sum()) / weight
        # The spoke nearest the centre gives the gyro heading, reference position
        # and time: the plot is fixed with what the radar knew at that moment.
        spoke = int(indices[int(round(row))])
        bearing_rel_deg = (first_index + row + 0.5) * 360.0 / self.azimuth_bins
        # An echo starts at the target's range and lasts one pulse, so its centre
        # lies (pulse_bins - 1) / 2 bins beyond the target.
        range_nm = (first_bin + column + 0.5 - 0.5 * (self.pulse_bins - 1)) * bin_nm
        return {"range_nm": range_nm, "bearing_rel_deg": bearing_rel_deg % 360.0, "spoke": spoke,
                "cells": len(rows), "peak_video": float(values.max())}

    def split_plot(self, plot, track, look_time_s, look):
        # With swaps disabled, an echo that other tracks also claim is shared out: each lit
        # cell goes to the claiming track whose predicted position is nearest to it, and the
        # track's plot is the centre of its own cells. Claimants are the tracks whose
        # predicted position lies within their gate of the merged echo's centre.
        # look = (indices, first_index, first_bin). Returns the track's own plot (before
        # place_plot), the plot unchanged if nobody else claims it, or None if the track's
        # share is smaller than PLOT_MIN_CELLS.
        indices, first_index, first_bin = look
        bin_nm = self.video_range_nm / self.range_bins
        own_x_nm, own_y_nm = self.own_position()
        nm_per_row_per_nm = 2.0 * math.pi / self.azimuth_bins        # arc across the beam (nm) per row, per nm of range
        half = self.azimuth_bins / 2.0
        spots = []
        for claimant in self.tracks.values():
            if claimant.state == "LOST":
                continue
            x_nm, y_nm = claimant.position_at(look_time_s)
            range_nm = math.hypot(x_nm - own_x_nm, y_nm - own_y_nm)
            bearing_rel_deg = normalise_360(float(bearing_true_deg(x_nm - own_x_nm, y_nm - own_y_nm)) - self.own.gyro_heading_deg)
            row = (bearing_rel_deg * self.azimuth_bins / 360.0 - 0.5 - first_index + half) % self.azimuth_bins - half
            column = range_nm / bin_nm - 0.5 + 0.5 * (self.pulse_bins - 1) - first_bin
            spots.append((claimant is track, claimant, row, column, range_nm))
        rows = plot["cell_rows"]
        columns = plot["cell_columns"]
        values = plot["cell_values"]
        best_distance = None
        owner = None
        claimants = 0
        for index, (is_track, claimant, row, column, range_nm) in enumerate(spots):
            across_nm = (rows - row) * nm_per_row_per_nm * range_nm
            along_nm = (columns - column) * bin_nm
            distance = across_nm * across_nm + along_nm * along_nm
            if not is_track and math.sqrt(float(distance.min())) > self.gate_nm(claimant, look_time_s):
                continue                                              # nowhere near this echo
            claimants += 1
            if best_distance is None:
                best_distance = distance
                owner = np.full(len(rows), index)
            else:
                nearer = distance < best_distance
                owner = np.where(nearer, index, owner)
                best_distance = np.where(nearer, distance, best_distance)
        if claimants < 2:
            return plot
        mine = owner == [i for i, spot in enumerate(spots) if spot[0]][0]
        if int(mine.sum()) < PLOT_MIN_CELLS:
            return None
        return self.plot_of(rows[mine], columns[mine], values[mine], indices, first_index, first_bin)

    def place_plot(self, plot, jitter):
        # Range and relative bearing -> position in the stabilisation frame, using the
        # gyro heading and reference position the spoke carried. Gyro error therefore
        # shows up as a bearing error, as it does at sea.
        range_nm = plot["range_nm"]
        bearing_rel_deg = plot["bearing_rel_deg"]
        if jitter and PLOT_JITTER_RANGE_NM > 0.0:
            range_nm += self.rng.normal(0.0, PLOT_JITTER_RANGE_NM)
        if jitter and PLOT_JITTER_BEARING_DEG > 0.0:
            bearing_rel_deg += self.rng.normal(0.0, PLOT_JITTER_BEARING_DEG)
        spoke = plot["spoke"]
        bearing_deg_true = (bearing_rel_deg + self.spoke_gyro_deg[spoke]) % 360.0
        bearing_rad = math.radians(bearing_deg_true)
        plot["range_nm"] = range_nm
        plot["bearing_deg_true"] = bearing_deg_true
        plot["x_nm"] = float(self.spoke_ref_x_nm[spoke]) + range_nm * math.sin(bearing_rad)
        plot["y_nm"] = float(self.spoke_ref_y_nm[spoke]) + range_nm * math.cos(bearing_rad)
        plot["time_s"] = float(self.spoke_time[spoke])

    def window_around(self, range_nm, bearing_rel_deg, radius_nm):
        # The buffer window that holds everything within radius_nm of a point, with a
        # margin. Returns (first_index, spoke_count, first_bin, last_bin).
        if range_nm > radius_nm:
            half_deg = math.degrees(math.asin(radius_nm / range_nm)) + WINDOW_EXTRA_DEG
        else:
            half_deg = WINDOW_MAX_HALF_DEG
        half_deg = min(half_deg, WINDOW_MAX_HALF_DEG)
        half_spokes = int(math.ceil(half_deg / 360.0 * self.azimuth_bins))
        centre_index = int(bearing_rel_deg / 360.0 * self.azimuth_bins)
        bin_nm = self.video_range_nm / self.range_bins
        first_bin = max(0, int((range_nm - radius_nm - WINDOW_EXTRA_NM) / bin_nm))
        last_bin = min(self.range_bins, int((range_nm + radius_nm + WINDOW_EXTRA_NM) / bin_nm) + self.pulse_bins + 1)
        return centre_index - half_spokes, 2 * half_spokes + 1, first_bin, last_bin

    def measurement_cov(self, range_nm, bearing_deg_true):
        # Position uncertainty of a plot as a 2 x 2 matrix in x and y: one sigma along
        # the bearing (range), another across it (bearing, which grows with range).
        bin_nm = self.video_range_nm / self.range_bins
        pulse_nm = self.pulse_bins * bin_nm
        range_sigma_nm = math.hypot(RANGE_SIGMA_PULSES * max(pulse_nm, bin_nm), PLOT_JITTER_RANGE_NM)
        bearing_sigma_deg = math.hypot(BEARING_SIGMA_BEAMWIDTHS * self.beamwidth_deg, PLOT_JITTER_BEARING_DEG)
        cross_sigma_nm = range_nm * math.radians(bearing_sigma_deg)
        sin_b = math.sin(math.radians(bearing_deg_true))
        cos_b = math.cos(math.radians(bearing_deg_true))
        along = np.array([sin_b, cos_b])
        across = np.array([cos_b, -sin_b])
        return range_sigma_nm ** 2 * np.outer(along, along) + cross_sigma_nm ** 2 * np.outer(across, across)

    # ---------------------------------------------------------------- acquisition

    def acquire(self, range_nm, bearing_deg_true):
        # Manual acquisition: takes the plot nearest the point, within acquire_radius_nm.
        # No plot there: nothing happens. Returns the new track's id, or None.
        if self.own is None or self.video_range_nm is None:
            return None
        if len(self.tracks) >= self.arpa["max_tracked_targets"]:
            self.raise_alarm("CAPACITY", None, None, range_nm, bearing_deg_true)
            return None
        if not self.minimum_range_nm < range_nm < self.video_range_nm:
            return None
        radius_nm = self.arpa["acquire_radius_nm"]
        own_x_nm, own_y_nm = self.own_position()
        point_x_nm = own_x_nm + range_nm * math.sin(math.radians(bearing_deg_true))
        point_y_nm = own_y_nm + range_nm * math.cos(math.radians(bearing_deg_true))
        bearing_rel_deg = normalise_360(bearing_deg_true - self.own.gyro_heading_deg)
        first_index, spoke_count, first_bin, last_bin = self.window_around(range_nm, bearing_rel_deg, radius_nm)
        indices = (first_index + np.arange(spoke_count)) % self.azimuth_bins
        oldest = int(self.spoke_number[indices].min())
        if oldest < self.valid_from_number or oldest < self.latest_number - self.azimuth_bins:
            messages.debug("ARPA: acquire ignored, no fresh video there yet")
            return None
        plots, flooded = self.find_plots(first_index, spoke_count, first_bin, last_bin, PLOT_MIN_CELLS,
                                         False, (range_nm, bearing_rel_deg, radius_nm) if range_nm < NEAR_BELOW_NM else None)
        nearest = None
        nearest_nm = radius_nm
        for plot in plots:
            self.place_plot(plot, True)
            distance_nm = math.hypot(plot["x_nm"] - point_x_nm, plot["y_nm"] - point_y_nm)
            if distance_nm <= nearest_nm:
                nearest = plot
                nearest_nm = distance_nm
        if nearest is None:
            # No echo there: the box goes down anyway, as on a real set. It looks for an echo every revolution
            # and gives up after lost_after_misses of them.
            spoke = int(bearing_rel_deg / 360.0 * self.azimuth_bins) % self.azimuth_bins
            nearest = {"x_nm": point_x_nm, "y_nm": point_y_nm, "time_s": float(self.spoke_time[spoke]),
                       "range_nm": range_nm, "bearing_deg_true": bearing_deg_true, "spoke": spoke}
            messages.trace(f"ARPA: no echo within {radius_nm:.2f} nm of {range_nm:.2f} nm, {bearing_deg_true:05.1f} deg true; box placed there")
        for track in self.tracks.values():
            track_x_nm, track_y_nm = track.position_at(nearest["time_s"])
            if math.hypot(track_x_nm - nearest["x_nm"], track_y_nm - nearest["y_nm"]) < SAME_ECHO_NM:
                messages.trace(f"ARPA: that echo is already target {track.id}")
                return None
        track_id = 1
        while track_id in self.tracks:
            track_id += 1
        track = Track(track_id, nearest["x_nm"], nearest["y_nm"], nearest["time_s"],
                      self.measurement_cov(nearest["range_nm"], nearest["bearing_deg_true"]))
        track.acquired_s = self.own.sim_time_s
        track.next_history_s = self.own.sim_time_s + self.arpa["history_interval_s"]
        track.last_look_number = int(self.spoke_number[nearest["spoke"]])
        self.tracks[track_id] = track
        self.targets_due = True
        messages.info(f"ARPA: target {track_id} acquired at {nearest['range_nm']:.2f} nm, "
                      f"{nearest['bearing_deg_true']:05.1f} deg true")
        return track_id

    def cancel_target(self, track_id):
        if isinstance(track_id, int) and track_id in self.tracks:
            del self.tracks[track_id]
            self.drop_alarms_of(track_id)
            self.targets_due = True
            messages.info(f"ARPA: target {track_id} cancelled")

    def cancel_all_targets(self):
        for track_id in list(self.tracks):
            self.cancel_target(track_id)

    # ---------------------------------------------------------------- the filter

    def predict(self, track, to_time_s):
        dt_h = (to_time_s - track.time_s) / S_PER_H                       # s -> h
        if dt_h <= 0.0:
            return
        move = np.eye(4)
        move[0, 2] = dt_h
        move[1, 3] = dt_h
        noise = np.zeros((4, 4))
        q = self.process_noise
        noise[0, 0] = noise[1, 1] = q * dt_h ** 3 / 3.0
        noise[0, 2] = noise[2, 0] = noise[1, 3] = noise[3, 1] = q * dt_h ** 2 / 2.0
        noise[2, 2] = noise[3, 3] = q * dt_h
        track.vector = move @ track.vector
        track.cov = move @ track.cov @ move.T + noise
        track.time_s = to_time_s

    def update(self, track, plot):
        measurement_cov = self.measurement_cov(plot["range_nm"], plot["bearing_deg_true"])
        difference = np.array([plot["x_nm"] - track.vector[0], plot["y_nm"] - track.vector[1]])
        spread = track.cov[0:2, 0:2] + measurement_cov
        gain = track.cov[:, 0:2] @ np.linalg.inv(spread)
        track.vector = track.vector + gain @ difference
        track.cov = track.cov - gain @ track.cov[0:2, :]
        track.cov = 0.5 * (track.cov + track.cov.T)           # keeps rounding from making it lopsided

    def gate_nm(self, track, at_time_s):
        # max(0.1 nm, 3 x predicted position sigma), wider after misses.
        dt_h = max(0.0, (at_time_s - track.time_s) / S_PER_H)
        cov = track.cov
        q = self.process_noise
        variance = (cov[0, 0] + cov[1, 1] + 2.0 * dt_h * (cov[0, 2] + cov[1, 3])
                    + dt_h ** 2 * (cov[2, 2] + cov[3, 3]) + 2.0 * q * dt_h ** 3 / 3.0)
        gate_nm = max(GATE_MIN_NM, GATE_SIGMAS * math.sqrt(max(variance, 0.0)))
        return min(GATE_MAX_NM, gate_nm * (1.0 + GATE_GROWTH_PER_MISS * track.misses))

    def consider_look(self, track):
        # Looks for the track's echo if the antenna has just swept past where it should be.
        now_s = self.own.sim_time_s
        own_x_nm, own_y_nm = self.own_position()
        x_nm, y_nm = track.position_at(now_s)
        range_nm = math.hypot(x_nm - own_x_nm, y_nm - own_y_nm)
        if not self.minimum_range_nm < range_nm < self.video_range_nm:
            # Outside the picture: carried on at its last course and speed, no miss counted.
            track.coasting = True
            return
        track.coasting = False
        bearing_rel_deg = normalise_360(float(bearing_true_deg(x_nm - own_x_nm, y_nm - own_y_nm)) - self.own.gyro_heading_deg)
        gate_nm = self.gate_nm(track, now_s)
        first_index, spoke_count, first_bin, last_bin = self.window_around(range_nm, bearing_rel_deg, gate_nm)
        end_number = int(self.spoke_number[(first_index + spoke_count - 1) % self.azimuth_bins])
        if end_number <= track.last_look_number + self.azimuth_bins // 2:
            return                                   # this pass of the antenna is already used
        indices = (first_index + np.arange(spoke_count)) % self.azimuth_bins
        numbers = self.spoke_number[indices]
        if numbers[0] < self.valid_from_number or not np.all(np.diff(numbers) == 1):
            return                                   # the antenna is inside the window, or the video is stale
        track.last_look_number = end_number
        self.look_count += 1

        swaps_off = not self.arpa["target_swap_enabled"]
        plots, flooded = self.find_plots(first_index, spoke_count, first_bin, last_bin, PLOT_MIN_CELLS, swaps_off,
                                         (range_nm, bearing_rel_deg, gate_nm) if range_nm < NEAR_BELOW_NM else None)
        look_time_s = float(self.spoke_time[int(indices[spoke_count // 2])])
        nearest = None
        nearest_nm = gate_nm
        shared = False
        for plot in plots:
            if swaps_off:
                plot = self.split_plot(plot, track, look_time_s, (indices, first_index, first_bin))
                if plot is None:
                    shared = True                    # too small a share of a merged echo to use
                    continue
            self.place_plot(plot, True)
            track_x_nm, track_y_nm = track.position_at(plot["time_s"])
            distance_nm = math.hypot(plot["x_nm"] - track_x_nm, plot["y_nm"] - track_y_nm)
            if distance_nm > nearest_nm:
                continue
            nearest = plot
            nearest_nm = distance_nm
        if nearest is None and shared:
            # Its echo has run together with another target's, which has the better
            # claim to the plot. Carried on at its last course and speed; not a miss.
            self.predict(track, look_time_s)
            messages.trace(f"ARPA: target {track.id} shares its echo with another target; carried on")
            return
        if nearest is None:
            self.predict(track, look_time_s)
            track.misses += 1
            messages.trace(f"ARPA: target {track.id} not seen this revolution ({track.misses} running)")
            if track.misses >= self.arpa["lost_after_misses"]:
                track.state = "LOST"
                own_x_nm, own_y_nm = self.own_position()
                self.raise_alarm("LOST_TARGET", track.id, None, math.hypot(x_nm - own_x_nm, y_nm - own_y_nm),
                                 float(bearing_true_deg(x_nm - own_x_nm, y_nm - own_y_nm)))
                messages.info(f"ARPA: target {track.id} lost after {track.misses} revolutions without an echo")
            return
        self.predict(track, nearest["time_s"])
        self.update(track, nearest)
        track.misses = 0

    # ---------------------------------------------------------------- every physics step

    def step(self, own):
        self.own = own
        if self.video_range_nm is not None:
            for track in list(self.tracks.values()):
                if track.state == "LOST":
                    continue
                age_s = own.sim_time_s - track.acquired_s
                if age_s >= self.arpa["steady_after_s"]:
                    track.state = "TRACK"
                elif age_s >= self.arpa["trend_after_s"]:
                    track.state = "TREND"
                self.consider_look(track)
                if track.state != "LOST" and own.sim_time_s >= track.next_history_s:
                    self.add_history(track)
            for zone in self.zones.values():
                if zone["enabled"]:
                    self.check_zone(zone)
        revolution = int(own.sim_time_s / self.revolution_s)
        if revolution != self.revolution:
            self.revolution = revolution
            self.end_of_revolution()

    def end_of_revolution(self):
        self.targets_due = True
        for track_id, track in sorted(self.tracks.items()):
            self.check_cpa_alarm(track)
        if len(self.tracks) < self.arpa["max_tracked_targets"]:
            self.clear_alarm(self.find_alarm("CAPACITY", None, None))

    def add_history(self, track):
        own = self.own
        x_nm, y_nm = track.position_at(own.sim_time_s)
        own_x_nm, own_y_nm = self.own_position()
        # Kept relative to own ship, with own ship's place in both frames, so that a
        # stabilisation switch can redraw the past in the other frame.
        track.history.append((own.sim_time_s, x_nm - own_x_nm, y_nm - own_y_nm,
                              own.sea_x_nm, own.sea_y_nm, own.ground_x_nm, own.ground_y_nm))
        count = self.arpa["history_count"]
        track.history = track.history[-count:] if count > 0 else []
        track.next_history_s += self.arpa["history_interval_s"]

    # ---------------------------------------------------------------- data per target

    def target_numbers(self, track):
        # Everything the ARPA knows about one target at the present time, not rounded.
        # Motion data is None while the track is in ACQ: no vector is shown yet.
        own = self.own
        own_x_nm, own_y_nm = self.own_position()
        own_vx_kn, own_vy_kn = self.own_velocity()
        x_nm, y_nm = track.position_at(own.sim_time_s)
        if track.state == "LOST":
            x_nm, y_nm = float(track.vector[0]), float(track.vector[1])      # stays where it was last seen
        vx_kn, vy_kn = float(track.vector[2]), float(track.vector[3])
        rel_x_nm, rel_y_nm = x_nm - own_x_nm, y_nm - own_y_nm
        data = {"id": track.id, "state": track.state, "x_nm": x_nm, "y_nm": y_nm,
                "range_nm": math.hypot(rel_x_nm, rel_y_nm),
                "bearing_deg_true": float(bearing_true_deg(rel_x_nm, rel_y_nm)),
                "course_deg_true": None, "speed_kn": None, "rel_course_deg_true": None, "rel_speed_kn": None,
                "cpa_nm": None, "tcpa_min": None, "bcr_nm": None, "bct_min": None,
                "trial_cpa_nm": None, "trial_tcpa_min": None, "history": []}
        for time_s, hist_rel_x_nm, hist_rel_y_nm, sea_x_nm, sea_y_nm, ground_x_nm, ground_y_nm in track.history:
            if self.stabilization == "sea":
                then_x_nm, then_y_nm = sea_x_nm, sea_y_nm
            else:
                then_x_nm, then_y_nm = ground_x_nm, ground_y_nm
            data["history"].append([round(time_s, 1), round(then_x_nm + hist_rel_x_nm, 4), round(then_y_nm + hist_rel_y_nm, 4),
                                    round(then_x_nm, 4), round(then_y_nm, 4)])
        if track.state == "ACQ":
            return data
        rel_vx_kn, rel_vy_kn = vx_kn - own_vx_kn, vy_kn - own_vy_kn
        data["course_deg_true"] = float(bearing_true_deg(vx_kn, vy_kn))
        data["speed_kn"] = math.hypot(vx_kn, vy_kn)
        data["rel_course_deg_true"] = float(bearing_true_deg(rel_vx_kn, rel_vy_kn))
        data["rel_speed_kn"] = math.hypot(rel_vx_kn, rel_vy_kn)
        data["cpa_nm"], data["tcpa_min"] = cpa_tcpa((rel_x_nm, rel_y_nm), (rel_vx_kn, rel_vy_kn))
        data["bcr_nm"], data["bct_min"] = bow_crossing(rel_x_nm, rel_y_nm, rel_vx_kn, rel_vy_kn, own.gyro_heading_deg)
        if self.trial is not None:
            data["trial_cpa_nm"], data["trial_tcpa_min"] = trial_cpa_tcpa(
                rel_x_nm, rel_y_nm, vx_kn, vy_kn, own_vx_kn, own_vy_kn,
                self.trial["course_deg_true"], self.trial["speed_kn"], self.trial["delay_s"])
        return data

    def target_data(self, track):
        # One entry of the "targets" message.
        data = self.target_numbers(track)
        for key, places in MESSAGE_DECIMALS.items():
            if data[key] is not None:
                data[key] = round(data[key], places)
        return data

    def targets_message(self):
        own_x_nm, own_y_nm = self.own_position()
        self.latest_targets = [self.target_data(track) for track_id, track in sorted(self.tracks.items())]
        return {"t": "targets", "sim_time_s": round(self.own.sim_time_s, 3),
                "ref_x_nm": round(own_x_nm, 5), "ref_y_nm": round(own_y_nm, 5), "targets": self.latest_targets}

    # ---------------------------------------------------------------- trial, stabilisation

    def set_trial(self, enabled, course_deg_true, speed_kn, delay_s):
        if enabled:
            self.trial = {"course_deg_true": normalise_360(course_deg_true), "speed_kn": speed_kn,
                          "delay_s": max(0.0, delay_s)}
        else:
            self.trial = None
        self.targets_due = True

    def set_stabilization(self, stabilization):
        # Sea <-> ground without restarting a track. A target's place and motion
        # relative to own ship are the same in both frames, so each position shifts by
        # the difference of own ship's two positions and each velocity by the
        # difference of own ship's two velocities (which is the current).
        if stabilization == self.stabilization:
            return
        if self.own is not None:
            old_x_nm, old_y_nm = self.own_position(self.stabilization)
            new_x_nm, new_y_nm = self.own_position(stabilization)
            old_vx_kn, old_vy_kn = self.own_velocity(self.stabilization)
            new_vx_kn, new_vy_kn = self.own_velocity(stabilization)
            for track in self.tracks.values():
                if track.state != "LOST":
                    self.predict(track, self.own.sim_time_s)      # the two frames differ by today's offset
                track.vector[0] += new_x_nm - old_x_nm
                track.vector[1] += new_y_nm - old_y_nm
                track.vector[2] += new_vx_kn - old_vx_kn
                track.vector[3] += new_vy_kn - old_vy_kn
        # Spokes in the buffer carry reference positions of the old frame.
        self.valid_from_number = self.latest_number + 1
        self.stabilization = stabilization
        self.targets_due = True
        messages.status(f"ARPA: stabilisation is now {stabilization}; {len(self.tracks)} track(s) converted")
        messages.why("ARPA: tracks are converted, not restarted, because range, bearing and relative motion "
                     "do not depend on the frame; only the true vectors change, by the current")

    # ---------------------------------------------------------------- guard zones

    def set_guard_zone(self, index, enabled, inner_nm, outer_nm, start_deg, end_deg):
        if index not in self.zones:
            return
        zone = self.zones[index]
        zone["enabled"] = bool(enabled)
        zone["inner_nm"] = max(0.0, min(inner_nm, outer_nm))
        zone["outer_nm"] = max(inner_nm, outer_nm)
        zone["start_deg"] = normalise_360(start_deg)
        zone["end_deg"] = normalise_360(end_deg)
        zone["hits"] = collections.deque(maxlen=self.arpa["guard_hits_window"])
        zone["last_number"] = NEVER
        if not zone["enabled"]:
            self.drop_alarm(self.find_alarm("GUARD_ZONE", None, index))
        messages.info(f"ARPA: guard zone {index} {'on' if zone['enabled'] else 'off'}: {zone['inner_nm']:.2f} to "
                      f"{zone['outer_nm']:.2f} nm, {zone['start_deg']:05.1f} to {zone['end_deg']:05.1f} deg "
                      f"{self.arpa['guard_zone_reference']}")

    def check_zone(self, zone):
        # Once per revolution, when the antenna has just left the zone: is there an echo in it?
        start_rel_deg = zone["start_deg"]
        end_rel_deg = zone["end_deg"]
        if self.arpa["guard_zone_reference"] == "true":
            start_rel_deg = normalise_360(start_rel_deg - self.own.gyro_heading_deg)
            end_rel_deg = normalise_360(end_rel_deg - self.own.gyro_heading_deg)
        start_index = int(start_rel_deg / 360.0 * self.azimuth_bins) % self.azimuth_bins
        end_index = int(end_rel_deg / 360.0 * self.azimuth_bins) % self.azimuth_bins
        end_number = int(self.spoke_number[end_index])
        if end_number <= zone["last_number"] + self.azimuth_bins // 2:
            return
        spoke_count = (end_index - start_index) % self.azimuth_bins + 1
        if zone["start_deg"] == zone["end_deg"]:
            spoke_count = self.azimuth_bins          # the same bearing twice means all round
        indices = (start_index + np.arange(spoke_count)) % self.azimuth_bins
        oldest = int(self.spoke_number[indices].min())
        if oldest < self.valid_from_number or oldest < self.latest_number - self.azimuth_bins:
            return
        zone["last_number"] = end_number
        bin_nm = self.video_range_nm / self.range_bins
        first_bin = int(zone["inner_nm"] / bin_nm)
        last_bin = min(self.range_bins, int(zone["outer_nm"] / bin_nm) + 1)
        present = False
        range_nm = 0.5 * (zone["inner_nm"] + zone["outer_nm"])
        bearing_deg_true = normalise_360(start_rel_deg + self.own.gyro_heading_deg)
        if first_bin < last_bin:
            plots, flooded = self.find_plots(start_index, spoke_count, first_bin, last_bin, GUARD_MIN_CELLS)
            present = flooded or len(plots) > 0
            if plots:
                largest = max(plots, key=lambda plot: plot["cells"])
                self.place_plot(largest, False)
                range_nm = largest["range_nm"]
                bearing_deg_true = largest["bearing_deg_true"]
        zone["hits"].append(present)
        alarm = self.find_alarm("GUARD_ZONE", None, zone["index"])
        if sum(zone["hits"]) >= self.arpa["guard_hits_needed"]:
            if alarm is None or not alarm["active"]:
                self.raise_alarm("GUARD_ZONE", None, zone["index"], range_nm, bearing_deg_true)
        else:
            self.clear_alarm(alarm)

    # ---------------------------------------------------------------- alarms

    def find_alarm(self, kind, target_id, zone_index):
        for alarm in self.alarms:
            if alarm["kind"] == kind and alarm["target_id"] == target_id and alarm["zone_index"] == zone_index:
                return alarm
        return None

    def raise_alarm(self, kind, target_id, zone_index, range_nm, bearing_deg_true):
        # Raised once: an alarm that is already up is left as it is.
        alarm = self.find_alarm(kind, target_id, zone_index)
        if alarm is not None and alarm["active"]:
            return
        if alarm is None:
            alarm = {"id": self.next_alarm_id, "kind": kind, "target_id": target_id, "zone_index": zone_index}
            self.next_alarm_id += 1
            self.alarms.append(alarm)
        alarm["range_nm"] = round(range_nm, 3)
        alarm["bearing_deg_true"] = round(bearing_deg_true, 1)
        alarm["acknowledged"] = False
        alarm["active"] = True
        self.alarms_changed = True
        subject = f" target {target_id}" if target_id is not None else (f" zone {zone_index}" if zone_index else "")
        messages.info(f"ARPA: alarm {alarm['id']} raised: {kind}{subject}")

    def clear_alarm(self, alarm):
        # The condition is over. An acknowledged alarm goes; one not yet acknowledged
        # stays on the list, marked not active, until it is.
        if alarm is None or not alarm["active"]:
            return
        alarm["active"] = False
        if alarm["acknowledged"]:
            self.alarms.remove(alarm)
        self.alarms_changed = True
        messages.info(f"ARPA: alarm {alarm['id']} ({alarm['kind']}) condition cleared")

    def drop_alarm(self, alarm):
        if alarm is not None:
            self.alarms.remove(alarm)
            self.alarms_changed = True

    def drop_alarms_of(self, track_id):
        for alarm in [alarm for alarm in self.alarms if alarm["target_id"] == track_id]:
            self.drop_alarm(alarm)

    def acknowledge(self, alarm_id):
        # alarm_id is a number, or "all".
        for alarm in list(self.alarms):
            if alarm_id != "all" and alarm["id"] != alarm_id:
                continue
            alarm["acknowledged"] = True
            self.alarms_changed = True
            if alarm["kind"] == "LOST_TARGET":
                # An acknowledged lost target is taken off the screen.
                self.tracks.pop(alarm["target_id"], None)
                self.alarms.remove(alarm)
                self.targets_due = True
            elif alarm["kind"] == "CAPACITY" or not alarm["active"]:
                self.alarms.remove(alarm)

    def check_cpa_alarm(self, track):
        # CPA below the limit and TCPA between 0 and its limit, for a target with a vector.
        alarm = self.find_alarm("CPA_TCPA", track.id, None)
        if track.state in ("TREND", "TRACK"):
            data = self.target_numbers(track)
            if data["cpa_nm"] < self.arpa["cpa_limit_nm"] and 0.0 < data["tcpa_min"] < self.arpa["tcpa_limit_min"]:
                track.alarm_clear_count = 0
                self.raise_alarm("CPA_TCPA", track.id, None, data["range_nm"], data["bearing_deg_true"])
                return
        if alarm is not None and alarm["active"]:
            track.alarm_clear_count += 1
            if track.alarm_clear_count >= ALARM_CLEAR_REVOLUTIONS or track.state == "LOST":
                self.clear_alarm(alarm)

    def alarms_message(self):
        alarms = []
        for alarm in self.alarms:
            alarms.append({"id": alarm["id"], "kind": alarm["kind"], "target_id": alarm["target_id"],
                           "zone_index": alarm["zone_index"], "range_nm": alarm["range_nm"],
                           "bearing_deg_true": alarm["bearing_deg_true"], "acknowledged": alarm["acknowledged"],
                           "active": alarm["active"]})
        return {"t": "alarms", "alarms": alarms}
