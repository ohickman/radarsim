# sim_config.py - loads radarsim.toml and checks every key against the table below.
# The config file is the only place defaults live: a missing key stops start-up.
# Units: each key carries its unit in its name.
# Called by: sim_main.py (load at start-up, runtime "set" messages) and the tests.

import copy
import tomllib

import messages

CONFIG_HELP = "See BRIEF.md Section 6 for the full file."


class ConfigError(Exception):
    pass


# Every key: (path, kind, low, high).
# kind: int, float, bool, text, hex (colour "#RRGGBB"), choice (low = allowed words),
#       float_list and hex_list (low/high apply to each element).
# All limits are chosen, not from a source. A value outside them is clamped with a WARN.
KEY_TABLE = [
    ("general.scenario", "choice", ["random", "calibration"], None),
    ("general.seed", "int", 0, 4294967295),
    ("general.sim_speed_multiplier", "float", 1.0, 10.0),
    ("general.physics_step_s", "float", 0.01, 1.0),
    ("general.port", "int", 1024, 65535),
    ("general.python_executable", "text", None, None),
    ("general.message_verbosity", "int", 0, 10),
    ("general.land_extent_nm", "float", 30.0, 80.0),      # generated land needs 30 nm or more
    ("general.land_cell_nm", "float", 0.005, 0.1),
    ("general.origin_lat_deg", "float", -80.0, 80.0),
    ("general.origin_lon_deg", "float", -180.0, 180.0),
    ("general.write_chart", "bool", None, None),
    ("general.chart_file", "text", None, None),

    ("own_ship.name", "text", None, None),
    ("own_ship.length_m", "float", 10.0, 400.0),
    ("own_ship.beam_m", "float", 2.0, 70.0),
    ("own_ship.antenna_height_m", "float", 2.0, 60.0),
    ("own_ship.start", "choice", ["auto", "manual"], None),
    ("own_ship.start_x_nm", "float", -100.0, 100.0),
    ("own_ship.start_y_nm", "float", -100.0, 100.0),
    ("own_ship.start_heading_deg", "float", 0.0, 360.0),
    ("own_ship.start_speed_kn", "float", 0.0, 40.0),
    ("own_ship.max_speed_ahead_kn", "float", 1.0, 40.0),
    ("own_ship.max_speed_astern_kn", "float", 0.0, 20.0),
    ("own_ship.speed_command_mode", "choice", ["knots", "telegraph", "both"], None),
    ("own_ship.telegraph_full_ahead_kn", "float", 0.0, 40.0),
    ("own_ship.telegraph_half_ahead_kn", "float", 0.0, 40.0),
    ("own_ship.telegraph_slow_ahead_kn", "float", 0.0, 40.0),
    ("own_ship.telegraph_dead_slow_ahead_kn", "float", 0.0, 40.0),
    ("own_ship.telegraph_slow_astern_kn", "float", 0.0, 20.0),
    ("own_ship.telegraph_half_astern_kn", "float", 0.0, 20.0),
    ("own_ship.telegraph_full_astern_kn", "float", 0.0, 20.0),
    ("own_ship.accel_kn_per_min", "float", 0.01, 60.0),
    ("own_ship.decel_coast_kn_per_min", "float", 0.01, 60.0),
    ("own_ship.decel_astern_kn_per_min", "float", 0.01, 60.0),
    ("own_ship.max_rudder_deg", "float", 5.0, 45.0),
    ("own_ship.rudder_rate_deg_per_s", "float", 0.5, 10.0),
    ("own_ship.turn_time_constant_s", "float", 1.0, 120.0),
    ("own_ship.autopilot_max_rudder_deg", "float", 1.0, 45.0),
    ("own_ship.gyro_error_deg", "float", -10.0, 10.0),
    ("own_ship.gyro_noise_deg", "float", 0.0, 2.0),
    ("own_ship.speed_log_error_percent", "float", -20.0, 20.0),
    ("own_ship.turn_table_speed_kn", "float_list", 0.0, 40.0),
    ("own_ship.turn_table_max_rot_deg_per_min", "float_list", 0.0, 600.0),

    ("environment.wind_from_deg_true", "float", 0.0, 360.0),
    ("environment.wind_speed_kn", "float", 0.0, 80.0),
    ("environment.sea_state_from_wind", "bool", None, None),
    ("environment.sea_state_douglas", "int", 0, 9),
    ("environment.current_set_deg_true", "float", 0.0, 360.0),
    ("environment.current_drift_kn", "float", 0.0, 8.0),
    ("environment.rain_rate_mm_per_h", "float", 0.0, 100.0),
    ("environment.rain_cell_count", "int", 0, 20),
    ("environment.rain_cell_radius_nm", "float", 0.5, 20.0),
    ("environment.rain_cell_speed_fraction_of_wind", "float", 0.0, 1.0),

    ("traffic.max_contacts", "int", 0, 200),
    ("traffic.colregs_cpa_limit_in_lane_nm", "float", 0.05, 2.0),
    ("traffic.rogue_percent", "float", 0.0, 100.0),
    ("traffic.rogue_no_give_way", "bool", None, None),
    ("traffic.rogue_cross_bow", "bool", None, None),
    ("traffic.rogue_late", "bool", None, None),
    ("traffic.lane_marks", "bool", None, None),
    ("traffic.mark_radius_nm", "float", 1.0, 30.0),
    ("traffic.lateral_spacing_nm", "float", 0.1, 5.0),
    ("traffic.lane_spacing_nm", "float", 0.2, 10.0),
    ("traffic.buoyage_region", "choice", ["A", "B"], None),
    ("traffic.active_radius_nm", "float", 5.0, 50.0),
    ("traffic.density_per_100_nm2", "float", 0.0, 10.0),
    ("traffic.density_stddev_fraction", "float", 0.0, 1.0),
    ("traffic.density_time_constant_min", "float", 1.0, 600.0),
    ("traffic.mix_ship", "float", 0.0, 1.0),
    ("traffic.mix_tug_tow", "float", 0.0, 1.0),
    ("traffic.mix_fishing", "float", 0.0, 1.0),
    ("traffic.mix_pleasure", "float", 0.0, 1.0),
    ("traffic.colregs_check_interval_s", "float", 1.0, 120.0),
    ("traffic.colregs_horizon_min", "float", 1.0, 60.0),
    ("traffic.colregs_alteration_deg", "float", 5.0, 90.0),
    ("traffic.land_lookahead_min", "float", 0.5, 30.0),

    ("traffic.ship.speed_mean_kn", "float", 0.0, 60.0),
    ("traffic.ship.speed_stddev_kn", "float", 0.0, 20.0),
    ("traffic.ship.lane_heading_stddev_deg", "float", 0.0, 20.0),

    ("traffic.tug_tow.tow_length_m_range", "float_list", 10.0, 1000.0),
    ("traffic.tug_tow.tow_rcs_m2_range", "float_list", 0.1, 1000000.0),
    ("traffic.tug_tow.speed_mean_kn", "float", 0.0, 60.0),
    ("traffic.tug_tow.speed_stddev_kn", "float", 0.0, 20.0),
    ("traffic.tug_tow.lane_heading_stddev_deg", "float", 0.0, 20.0),

    ("traffic.fishing.transit_speed_kn_range", "float_list", 0.0, 60.0),
    ("traffic.fishing.trawl_speed_kn_range", "float_list", 0.0, 60.0),
    ("traffic.fishing.drift_speed_kn", "float", 0.0, 5.0),
    ("traffic.fishing.leg_length_nm_range", "float_list", 0.1, 50.0),
    ("traffic.fishing.work_duration_min_range", "float_list", 1.0, 1440.0),

    ("traffic.pleasure.power_fraction", "float", 0.0, 1.0),
    ("traffic.pleasure.power_speed_kn_range", "float_list", 0.0, 60.0),
    ("traffic.pleasure.sail_speed_kn_range", "float_list", 0.0, 60.0),
    ("traffic.pleasure.sail_no_go_deg", "float", 20.0, 80.0),
    ("traffic.pleasure.cruise_leg_nm_range", "float_list", 0.1, 50.0),

    ("radar.frequency_ghz", "float", 9.2, 9.5),
    ("radar.horizontal_beamwidth_deg", "float", 0.3, 4.0),
    ("radar.vertical_beamwidth_deg", "float", 5.0, 40.0),
    ("radar.antenna_rpm", "float", 10.0, 60.0),
    ("radar.azimuth_bins", "int", 256, 8192),
    ("radar.range_bins", "int", 128, 4096),
    ("radar.range_scales_nm", "float_list", 0.1, 96.0),
    ("radar.pulse_length_us", "float_list", 0.03, 2.0),
    ("radar.minimum_range_nm", "float", 0.0, 0.1),
    ("radar.video_range_nm", "float", 0.1, 48.0),
    ("radar.offset_max_fraction", "float", 0.0, 0.9),
    ("radar.reference_rcs_m2", "float", 0.1, 100000.0),
    ("radar.reference_range_nm", "float", 0.1, 50.0),
    ("radar.reference_snr_db", "float", 0.0, 40.0),
    ("radar.gain_nominal_percent", "float", 0.0, 100.0),
    ("radar.gain_db_per_percent", "float", 0.05, 2.0),
    ("radar.display_threshold_db", "float", 0.0, 30.0),
    ("radar.video_window_db", "float", 6.0, 80.0),
    ("radar.stc_max_db", "float", 0.0, 90.0),
    ("radar.stc_max_range_nm", "float", 0.5, 24.0),
    ("radar.ftc_window_nm", "float", 0.01, 2.0),

    ("radar_controls.gain_percent", "float", 0.0, 100.0),
    ("radar_controls.stc_percent", "float", 0.0, 100.0),
    ("radar_controls.ftc_percent", "float", 0.0, 100.0),

    ("arpa.stabilization", "choice", ["sea", "ground"], None),
    ("arpa.max_tracked_targets", "int", 1, 200),
    ("arpa.acquire_radius_nm", "float", 0.01, 1.0),
    ("arpa.lost_after_misses", "int", 1, 50),
    ("arpa.trend_after_s", "float", 10.0, 300.0),
    ("arpa.steady_after_s", "float", 30.0, 900.0),
    ("arpa.target_swap_enabled", "bool", None, None),
    ("arpa.maneuver_allowance_kn_per_min", "float", 0.05, 20.0),
    ("arpa.cpa_limit_nm", "float", 0.0, 10.0),
    ("arpa.tcpa_limit_min", "float", 1.0, 60.0),
    ("arpa.guard_zone_reference", "choice", ["relative", "true"], None),
    ("arpa.guard_hits_needed", "int", 1, 10),
    ("arpa.guard_hits_window", "int", 1, 10),
    ("arpa.history_interval_s", "float", 10.0, 600.0),
    ("arpa.history_count", "int", 0, 20),
    ("arpa.alarm_sound", "bool", None, None),

    ("display.color_mode", "choice", ["mono_green", "mono_amber", "color"], None),
    ("display.control_style", "choice", ["knob", "slider", "hybrid"], None),
    ("display.dark_mode", "choice", ["off", "on"], None),
    ("display.range_scale_nm", "float", 0.1, 96.0),
    ("display.orientation", "choice", ["north_up", "head_up", "course_up"], None),
    ("display.motion_mode", "choice", ["relative", "true"], None),
    ("display.offset_enabled", "bool", None, None),
    ("display.offset_x_fraction", "float", -0.9, 0.9),
    ("display.offset_y_fraction", "float", -0.9, 0.9),
    ("display.vector_mode", "choice", ["true", "relative"], None),
    ("display.vector_time_min", "float", 0.5, 60.0),
    ("display.trails_mode", "choice", ["off", "true", "relative"], None),
    ("display.trail_time_min", "float", 0.5, 30.0),
    ("display.trail_video_threshold", "int", 0, 255),
    ("display.true_motion_reset_fraction", "float", 0.3, 0.95),
    ("display.history_dots", "bool", None, None),
    ("display.range_rings", "bool", None, None),
    ("display.range_ring_interval_nm", "float_list", 0.01, 24.0),
    ("display.heading_line", "bool", None, None),
    ("display.bearing_scale", "bool", None, None),
    ("display.afterglow_sim_s", "float", 0.5, 60.0),
    ("display.video_brilliance_percent", "float", 0.0, 100.0),
    ("display.rings_brilliance_percent", "float", 0.0, 100.0),
    ("display.symbols_brilliance_percent", "float", 0.0, 100.0),
    ("display.ppi_bitmap_px", "int", 256, 4096),
    ("display.instructor_overlay", "bool", None, None),
    ("display.mono_green_hex", "hex", None, None),
    ("display.mono_amber_hex", "hex", None, None),
    ("display.mono_background_hex", "hex", None, None),
    ("display.color_video_stops_hex", "hex_list", None, None),
    ("display.color_symbol_hex", "hex", None, None),
    ("display.color_background_hex", "hex", None, None),

    ("game.on_collision", "choice", ["stop", "ignore"], None),
    ("game.on_grounding", "choice", ["stop", "ignore"], None),
    ("game.collision_distance_factor", "float", 0.1, 2.0),
]

# Keys that every [traffic.<kind>] block has.
TRAFFIC_KINDS = ["ship", "tug_tow", "fishing", "pleasure"]
for _kind in TRAFFIC_KINDS:
    _block = "traffic." + _kind + "."
    KEY_TABLE += [
        (_block + "length_m_range", "float_list", 1.0, 500.0),
        (_block + "rcs_m2_range", "float_list", 0.1, 1000000.0),
        (_block + "max_turn_deg_per_min", "float", 1.0, 600.0),
        (_block + "accel_kn_per_min", "float", 0.01, 60.0),
        (_block + "predictability_mean", "float", 0.0, 1.0),
        (_block + "predictability_stddev", "float", 0.0, 1.0),
        (_block + "course_change_per_hour_at_p0", "float", 0.0, 120.0),
        (_block + "course_change_stddev_deg", "float", 0.0, 180.0),
        (_block + "speed_change_per_hour_at_p0", "float", 0.0, 120.0),
        (_block + "speed_change_stddev_kn", "float", 0.0, 20.0),
        (_block + "colregs_compliance_fraction", "float", 0.0, 1.0),
        (_block + "colregs_cpa_limit_nm", "float", 0.0, 5.0),
    ]

KEY_INFO = {}
for _path, _kind, _low, _high in KEY_TABLE:
    KEY_INFO[_path] = (_kind, _low, _high)

# Lists that must have the same number of entries: (list, the list it must match).
SAME_LENGTH_LISTS = [
    ("own_ship.turn_table_max_rot_deg_per_min", "own_ship.turn_table_speed_kn"),
    ("radar.pulse_length_us", "radar.range_scales_nm"),
    ("display.range_ring_interval_nm", "radar.range_scales_nm"),
]

# Keys marked (runtime) in radarsim.toml: path -> (step, unit shown in the display).
# Steps are chosen, not from a source. Text and on/off keys have step 0.
RUNTIME_KEYS = {
    "general.sim_speed_multiplier": (1.0, "x"),
    "environment.wind_from_deg_true": (1.0, "deg T"),
    "environment.wind_speed_kn": (1.0, "KN"),
    "environment.sea_state_from_wind": (0.0, ""),
    "environment.sea_state_douglas": (1.0, "Douglas"),
    "environment.current_set_deg_true": (1.0, "deg T"),
    "environment.current_drift_kn": (0.1, "KN"),
    "environment.rain_rate_mm_per_h": (1.0, "mm/h"),
    "environment.rain_cell_count": (1.0, "cells"),
    "environment.rain_cell_radius_nm": (0.5, "NM"),
    "traffic.max_contacts": (1.0, "contacts"),
    "traffic.mix_ship": (0.05, ""),
    "traffic.mix_tug_tow": (0.05, ""),
    "traffic.mix_fishing": (0.05, ""),
    "traffic.mix_pleasure": (0.05, ""),
    "traffic.rogue_percent": (1.0, "%"),
    "traffic.rogue_no_give_way": (0.0, ""),
    "traffic.rogue_cross_bow": (0.0, ""),
    "traffic.rogue_late": (0.0, ""),
    "traffic.density_per_100_nm2": (0.1, "per 100 NM2"),
    "radar.video_range_nm": (0.01, "NM"),
    "radar_controls.gain_percent": (1.0, "%"),
    "radar_controls.stc_percent": (1.0, "%"),
    "radar_controls.ftc_percent": (1.0, "%"),
    "arpa.stabilization": (0.0, ""),
    "arpa.cpa_limit_nm": (0.1, "NM"),
    "arpa.tcpa_limit_min": (1.0, "MIN"),
    "display.afterglow_sim_s": (0.5, "s"),
    "display.video_brilliance_percent": (1.0, "%"),
    "display.rings_brilliance_percent": (1.0, "%"),
    "display.symbols_brilliance_percent": (1.0, "%"),
    "display.color_mode": (0.0, ""),
    "display.control_style": (0.0, ""),
    "display.dark_mode": (0.0, ""),
    "display.range_scale_nm": (0.0, "NM"),
    "display.orientation": (0.0, ""),
    "display.motion_mode": (0.0, ""),
    "display.offset_enabled": (0.0, ""),
    "display.offset_x_fraction": (0.05, "x radius"),
    "display.offset_y_fraction": (0.05, "x radius"),
    "display.vector_mode": (0.0, ""),
    "display.vector_time_min": (0.0, "MIN"),
    "display.trails_mode": (0.0, ""),
    "display.trail_time_min": (0.0, "MIN"),
    "display.history_dots": (0.0, ""),
    "display.instructor_overlay": (0.0, ""),
}

# Number keys that take one of a fixed list (BRIEF.md Section 11). A value not in
# the list snaps to the nearest entry with a WARN. display.range_scale_nm takes
# its list from radar.range_scales_nm.
NUMBER_CHOICES = {
    "display.vector_time_min": [0.5, 1.0, 3.0, 6.0, 12.0, 15.0, 30.0, 60.0],
    "display.trail_time_min": [0.5, 1.0, 3.0, 6.0, 12.0, 15.0, 30.0],
}


def get_value(cfg, path):
    node = cfg
    for part in path.split("."):
        node = node[part]
    return node


def put_value(cfg, path, value):
    parts = path.split(".")
    node = cfg
    for part in parts[:-1]:
        node = node[part]
    node[parts[-1]] = value


def has_value(cfg, path):
    node = cfg
    for part in path.split("."):
        if not isinstance(node, dict) or part not in node:
            return False
        node = node[part]
    return True


def number_choices_for(cfg, path):
    if path == "display.range_scale_nm":
        return get_value(cfg, "radar.range_scales_nm")
    return NUMBER_CHOICES.get(path)


def is_number(value):
    # True and False are ints to Python, but not numbers to us.
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def is_hex_colour(value):
    if not isinstance(value, str) or len(value) != 7 or value[0] != "#":
        return False
    return all(ch in "0123456789abcdefABCDEF" for ch in value[1:])


def clamp_number(path, value, low, high):
    # Returns (value, warning text or None).
    if value < low:
        return low, "%s = %s is below the minimum %s; using %s" % (path, value, low, low)
    if value > high:
        return high, "%s = %s is above the maximum %s; using %s" % (path, value, high, high)
    return value, None


def check_value(cfg, path, value):
    # Checks one value against KEY_TABLE. Returns (value to use, list of warnings).
    # Raises ConfigError when the value cannot be used at all (wrong type, unknown word).
    kind, low, high = KEY_INFO[path]
    wrong = "%s = %r: expected " % (path, value)
    warnings = []

    if kind == "bool":
        if not isinstance(value, bool):
            raise ConfigError(wrong + "true or false")
    elif kind == "text":
        if not isinstance(value, str) or value == "":
            raise ConfigError(wrong + "a non-empty text in quotes")
    elif kind == "hex":
        if not is_hex_colour(value):
            raise ConfigError(wrong + 'a colour like "#33FF33"')
    elif kind == "hex_list":
        if not isinstance(value, list) or len(value) < 2 or not all(is_hex_colour(v) for v in value):
            raise ConfigError(wrong + 'a list of at least two colours like "#33FF33"')
    elif kind == "choice":
        if value not in low:
            raise ConfigError(wrong + "one of " + ", ".join('"%s"' % word for word in low))
    elif kind == "int":
        if is_number(value) and float(value) == int(value):
            value = int(value)
        else:
            raise ConfigError(wrong + "a whole number")
        value, warning = clamp_number(path, value, low, high)
        if warning:
            warnings.append(warning)
    elif kind == "float":
        if not is_number(value):
            raise ConfigError(wrong + "a number")
        value, warning = clamp_number(path, float(value), low, high)
        if warning:
            warnings.append(warning)
        choices = number_choices_for(cfg, path)
        if choices is not None and value not in choices:
            nearest = min(choices, key=lambda choice: abs(choice - value))
            warnings.append("%s = %s is not one of %s; using %s" % (path, value, choices, nearest))
            value = nearest
    elif kind == "float_list":
        if not isinstance(value, list) or len(value) == 0 or not all(is_number(v) for v in value):
            raise ConfigError(wrong + "a list of numbers")
        checked = []
        for element in value:
            element, warning = clamp_number(path, float(element), low, high)
            if warning:
                warnings.append(warning)
            checked.append(element)
        value = checked
        if path.endswith("_range") and (len(value) != 2 or value[0] > value[1]):
            raise ConfigError(wrong + "[low, high] with low <= high")
    return value, warnings


def find_unknown_keys(node, prefix, unknown):
    for key, value in node.items():
        path = prefix + key
        if path in KEY_INFO:
            continue
        if isinstance(value, dict):
            find_unknown_keys(value, path + ".", unknown)
        else:
            unknown.append(path)


def check_config(raw, file_name):
    # raw is the dict from tomllib. Returns a checked copy. Prints WARN lines;
    # raises ConfigError (naming file, key and value) when start-up must stop.
    cfg = copy.deepcopy(raw)

    for path, kind, low, high in KEY_TABLE:
        if not has_value(cfg, path):
            raise ConfigError("%s: missing key %s. Add it to the file. %s" % (file_name, path, CONFIG_HELP))
        try:
            value, warnings = check_value(cfg, path, get_value(cfg, path))
        except ConfigError as error:
            raise ConfigError("%s: %s. %s" % (file_name, error, CONFIG_HELP))
        for warning in warnings:
            messages.warn("%s: %s" % (file_name, warning))
        put_value(cfg, path, value)

    unknown = []
    find_unknown_keys(cfg, "", unknown)
    for path in unknown:
        messages.warn("%s: unknown key %s is ignored (misspelt?)" % (file_name, path))

    for list_path, match_path in SAME_LENGTH_LISTS:
        if len(get_value(cfg, list_path)) != len(get_value(cfg, match_path)):
            raise ConfigError("%s: %s has %d entries but %s has %d; they must match." % (
                file_name, list_path, len(get_value(cfg, list_path)),
                match_path, len(get_value(cfg, match_path))))

    # The traffic mix must sum to 1.0.
    mix_paths = ["traffic.mix_" + kind for kind in TRAFFIC_KINDS]
    mix_sum = sum(get_value(cfg, path) for path in mix_paths)
    if mix_sum <= 0.0:
        raise ConfigError("%s: the traffic.mix_* fractions are all 0; give at least one a value." % file_name)
    if abs(mix_sum - 1.0) > 1e-9:
        messages.warn("%s: the traffic.mix_* fractions sum to %g, not 1.0; normalised." % (file_name, mix_sum))
        for path in mix_paths:
            put_value(cfg, path, get_value(cfg, path) / mix_sum)
    return cfg


def load_config(config_path):
    try:
        with open(config_path, "rb") as config_file:
            raw = tomllib.load(config_file)
    except FileNotFoundError:
        raise ConfigError("%s: file not found. Pass --config <file> or --root <project folder>." % config_path)
    except tomllib.TOMLDecodeError as error:
        raise ConfigError("%s: not valid TOML: %s" % (config_path, error))
    return check_config(raw, config_path)


def set_runtime_value(cfg, path, value):
    # A "set" from the display. Returns (confirmed value, note or None). The
    # confirmed value is the clamped request, or the unchanged old value when the
    # request cannot be used.
    if path not in RUNTIME_KEYS:
        return None, "%s is not a (runtime) key" % path
    try:
        value, warnings = check_value(cfg, path, value)
    except ConfigError as error:
        return get_value(cfg, path), str(error)
    put_value(cfg, path, value)
    return value, ("; ".join(warnings) if warnings else None)


def runtime_controls(cfg):
    # The list for hello.controls: one entry per (runtime) key.
    controls = []
    for path, (step, unit) in RUNTIME_KEYS.items():
        kind, low, high = KEY_INFO[path]
        control = {"path": path, "unit": unit, "value": get_value(cfg, path)}
        if kind == "choice":
            control["choices"] = low
        elif kind == "bool":
            control["choices"] = [False, True]
        elif number_choices_for(cfg, path) is not None:
            control["choices"] = number_choices_for(cfg, path)
        else:
            control["min"] = low
            control["max"] = high
            control["step"] = step
        controls.append(control)
    return controls
