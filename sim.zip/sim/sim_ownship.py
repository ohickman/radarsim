# sim_ownship.py - own-ship dynamics: speed, rudder, rate of turn, heading orders,
# current set and drift, and the instruments (gyro, log, GPS). BRIEF.md Section 8.1.
# No physics engine: rate limits and a first-order lag, so nothing changes instantly.
# Units: position nm (x east, y north), speed kn, heading deg true, rudder deg
# (+ starboard), rate of turn deg/s inside (+ = to starboard), time s.
# Called by: sim_main.py every physics step, and the tests.

import math

import numpy as np

from sim_common import (S_PER_H, S_PER_MIN, angle_difference_deg, bearing_true_deg,
                        normalise_360, velocity_xy_kn)

# Heading-order controller: rudder = KP x heading error - KD x rate of turn.
# Chosen, not from a source; tuned so test_m1.py test 4 passes from 4 to 18 kn.
AUTOPILOT_KP_DEG_PER_DEG = 3.0        # rudder deg per deg of heading error
AUTOPILOT_KD_DEG_PER_DEG_PER_S = 50.0 # rudder deg per deg/s of rate of turn

# Going astern the rudder works the other way round and half as well.
# A simplification, chosen, not from a source.
ASTERN_RUDDER_FACTOR = -0.5


def move_toward(value, target, most_change):
    # One rate-limited step of value toward target.
    if value < target:
        return min(value + most_change, target)
    return max(value - most_change, target)


class OwnShip:
    def __init__(self, cfg, rng, x_nm, y_nm, heading_deg_true, speed_kn):
        self.own = cfg["own_ship"]
        self.rng = rng                           # this ship's own random stream (gyro noise)

        # Truth.
        self.x_nm = x_nm                         # position over the ground
        self.y_nm = y_nm
        self.heading_deg_true = normalise_360(heading_deg_true)
        self.speed_water_kn = speed_kn           # through the water, - = astern
        self.rudder_deg = 0.0
        self.rot_deg_per_s = 0.0
        self.ground_vx_kn = 0.0                  # velocity over the ground, east and north
        self.ground_vy_kn = 0.0

        # Orders.
        self.mode = "rudder"                     # "rudder" = a rudder order is held; "heading" = steering a heading
        self.ordered_rudder_deg = 0.0
        self.ordered_heading_deg = None          # on the gyro compass
        self.ordered_speed_kn = speed_kn

        # Sea-stabilised reference position: dead reckoning from log and gyro only,
        # so it does not feel the current (BRIEF.md Section 5).
        self.sea_ref_x_nm = x_nm
        self.sea_ref_y_nm = y_nm

        # Instruments.
        self.gyro_heading_deg = 0.0
        self.log_speed_kn = 0.0
        self.read_instruments()

    # ---- orders ----

    def apply_order(self, order):
        if order["kind"] == "rudder":
            self.mode = "rudder"
            self.ordered_rudder_deg = order["rudder_deg"]
            self.ordered_heading_deg = None
        elif order["kind"] == "heading":
            self.mode = "heading"
            self.ordered_heading_deg = order["heading_deg"]
        elif order["kind"] == "steady":
            # The heading the ship reaches if the rudder goes amidships now: the rate
            # of turn dies away with the time constant, adding rot x time constant.
            self.mode = "heading"
            carry_deg = self.rot_deg_per_s * self.own["turn_time_constant_s"]
            self.ordered_heading_deg = normalise_360(self.gyro_heading_deg + carry_deg)
        elif order["kind"] == "speed":
            self.ordered_speed_kn = order["speed_kn"]

    # ---- one physics step ----

    def max_rot_deg_per_s(self, speed_kn):
        # Rate of turn at full rudder for this speed, from the config's turn table.
        rot_deg_per_min = np.interp(abs(speed_kn), self.own["turn_table_speed_kn"],
                                    self.own["turn_table_max_rot_deg_per_min"])
        return float(rot_deg_per_min) / S_PER_MIN            # deg/min -> deg/s

    def speed_rate_kn_per_min(self):
        # Which of the three configured rates applies now.
        speed_kn = self.speed_water_kn
        ordered_kn = self.ordered_speed_kn
        if ordered_kn < 0.0:
            # An astern order: the engine pulls astern all the way down to the ordered
            # speed. Easing an astern speed toward a smaller one is coasting.
            if speed_kn > ordered_kn:
                return self.own["decel_astern_kn_per_min"]
            return self.own["decel_coast_kn_per_min"]
        if speed_kn < 0.0:
            # Moving astern with an ahead or stop order: an ahead order pulls the ship
            # up as hard as an astern order would; stop lets it coast.
            if ordered_kn > 0.0:
                return self.own["decel_astern_kn_per_min"]
            return self.own["decel_coast_kn_per_min"]
        if speed_kn < ordered_kn:
            return self.own["accel_kn_per_min"]
        return self.own["decel_coast_kn_per_min"]

    def step(self, dt_s, current_set_deg_true, current_drift_kn):
        own = self.own

        # 1. Speed through the water moves toward the ordered speed at a limited rate.
        most_change_kn = self.speed_rate_kn_per_min() / S_PER_MIN * dt_s     # kn/min -> kn per step
        self.speed_water_kn = move_toward(self.speed_water_kn, self.ordered_speed_kn, most_change_kn)

        # 2. Rudder. With a heading order the controller sets the commanded angle.
        if self.mode == "heading":
            error_deg = angle_difference_deg(self.ordered_heading_deg, self.gyro_heading_deg)
            command_deg = (AUTOPILOT_KP_DEG_PER_DEG * error_deg
                           - AUTOPILOT_KD_DEG_PER_DEG_PER_S * self.rot_deg_per_s)
            if self.speed_water_kn < 0.0:
                command_deg = -command_deg       # the rudder works the other way round astern
            limit_deg = own["autopilot_max_rudder_deg"]
            self.ordered_rudder_deg = max(-limit_deg, min(limit_deg, command_deg))
        self.rudder_deg = move_toward(self.rudder_deg, self.ordered_rudder_deg,
                                      own["rudder_rate_deg_per_s"] * dt_s)

        # 3. Rate of turn follows the steady rate for this rudder and speed with a lag.
        rot_steady_deg_per_s = (self.rudder_deg / own["max_rudder_deg"]
                                * self.max_rot_deg_per_s(self.speed_water_kn))
        if self.speed_water_kn < 0.0:
            rot_steady_deg_per_s *= ASTERN_RUDDER_FACTOR
        # Exact solution of d(rot)/dt = (steady - rot) / time constant over one step.
        blend = 1.0 - math.exp(-dt_s / own["turn_time_constant_s"])
        self.rot_deg_per_s += (rot_steady_deg_per_s - self.rot_deg_per_s) * blend
        self.heading_deg_true = normalise_360(self.heading_deg_true + self.rot_deg_per_s * dt_s)

        # 5. Ground motion = water velocity along the heading + current (set = toward).
        water_vx_kn, water_vy_kn = velocity_xy_kn(self.speed_water_kn, self.heading_deg_true)
        current_vx_kn, current_vy_kn = velocity_xy_kn(current_drift_kn, current_set_deg_true)
        self.ground_vx_kn = float(water_vx_kn + current_vx_kn)
        self.ground_vy_kn = float(water_vy_kn + current_vy_kn)
        self.x_nm += self.ground_vx_kn * dt_s / S_PER_H                       # kn x s -> nm
        self.y_nm += self.ground_vy_kn * dt_s / S_PER_H

        # 6. Instruments, then the dead-reckoned reference position from them.
        self.read_instruments()
        log_vx_kn, log_vy_kn = velocity_xy_kn(self.log_speed_kn, self.gyro_heading_deg)
        self.sea_ref_x_nm += float(log_vx_kn) * dt_s / S_PER_H
        self.sea_ref_y_nm += float(log_vy_kn) * dt_s / S_PER_H

    def read_instruments(self):
        own = self.own
        noise_deg = 0.0
        if own["gyro_noise_deg"] > 0.0:
            noise_deg = self.rng.normal(0.0, own["gyro_noise_deg"])
        self.gyro_heading_deg = normalise_360(self.heading_deg_true + own["gyro_error_deg"] + noise_deg)
        self.log_speed_kn = self.speed_water_kn * (1.0 + own["speed_log_error_percent"] / 100.0)

    # ---- read-outs ----

    def reference_position(self, stabilization):
        # Own-ship position in the stabilisation frame: "sea" or "ground".
        if stabilization == "sea":
            return self.sea_ref_x_nm, self.sea_ref_y_nm
        return self.x_nm, self.y_nm

    def sog_kn(self):
        return math.hypot(self.ground_vx_kn, self.ground_vy_kn)

    def cog_deg_true(self):
        # Course over the ground. Stopped over the ground, there is none: show the heading.
        if self.sog_kn() < 0.001:
            return self.heading_deg_true
        return float(bearing_true_deg(self.ground_vx_kn, self.ground_vy_kn))

    def state_for_display(self):
        # The "own" part of the state message (BRIEF.md Section 7).
        ordered_heading_deg = None
        if self.ordered_heading_deg is not None:
            ordered_heading_deg = round(self.ordered_heading_deg, 2)
        return {
            "x_nm": round(self.x_nm, 5),
            "y_nm": round(self.y_nm, 5),
            "heading_deg_true": round(self.heading_deg_true, 2),
            "gyro_heading_deg": round(self.gyro_heading_deg, 2),
            "rudder_deg": round(self.rudder_deg, 2),
            "rot_deg_per_min": round(self.rot_deg_per_s * S_PER_MIN, 2),     # deg/s -> deg/min
            "speed_water_kn": round(self.speed_water_kn, 3),
            "log_speed_kn": round(self.log_speed_kn, 3),
            "speed_ground_kn": round(self.sog_kn(), 3),
            "cog_deg_true": round(self.cog_deg_true(), 2),
            "sog_kn": round(self.sog_kn(), 3),
            "ordered_heading_deg": ordered_heading_deg,
            "ordered_speed_kn": round(self.ordered_speed_kn, 2),
            "mode": self.mode,
        }
