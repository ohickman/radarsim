# test_m2.py - acceptance tests of Module M2, environment and land (BRIEF.md Section 15).
# Run: python sim/test_m2.py     Prints [OK] or [FAIL] lines with numbers; exits 0 or 1.
# Takes 2 to 4 minutes: it generates land for 20 seeds. It writes
# preview_land_1.png, _2.png and _3.png into the project root for Oliver to look at.
# Units: as named in each test.

import copy
import hashlib
import os
import socket
import subprocess
import sys
import time

import numpy as np

import devtools
import messages
import sim_common
import sim_config
import sim_environment
import sim_land
import sim_protocol

ROOT = sim_common.find_project_root()
CONFIG_PATH = os.path.join(ROOT, sim_common.CONFIG_FILE_NAME)
SIM_MAIN = os.path.join(ROOT, "sim", "sim_main.py")
CFG = sim_config.load_config(CONFIG_PATH)
SEEDS = list(range(1, 21))
PREVIEW_PX = 1000

failures = 0


def report(passed, name, detail):
    global failures
    if passed:
        messages.ok(name + ": " + detail)
    else:
        failures += 1
        messages.fail(name + ": " + detail)


def generate(seed):
    # The same land stream sim_main.py uses for this master seed.
    streams = sim_common.make_random_streams(seed)
    start_s = time.perf_counter()
    land = sim_land.generate_land(CFG, streams["land"])
    seconds = time.perf_counter() - start_s
    start = land.find_start(streams["own_ship"])
    return land, start, seconds


def land_hash(land):
    digest = hashlib.sha256(land.heights_m.tobytes())
    for lane in land.lanes:
        digest.update(lane.points_nm.tobytes())
    return digest.hexdigest()


def disc_offsets(radius_nm, spacing_nm):
    steps = np.arange(-radius_nm, radius_nm + spacing_nm / 2.0, spacing_nm)
    dx_nm, dy_nm = np.meshgrid(steps, steps)
    inside = np.hypot(dx_nm, dy_nm) <= radius_nm
    return dx_nm[inside], dy_nm[inside]


def nearest_land_closer_than(land, points_nm, radius_nm):
    # For each point: is there land within radius_nm? Checked the slow, plain way
    # (look at every raster cell spacing inside the circle), not with the land
    # model's own land_within, so this is an independent check.
    dx_nm, dy_nm = disc_offsets(radius_nm, land.cell_nm)
    near = np.zeros(len(points_nm), dtype=bool)
    for first in range(0, len(points_nm), 100):
        chunk = points_nm[first:first + 100]
        x_nm = chunk[:, 0][:, None] + dx_nm[None, :]
        y_nm = chunk[:, 1][:, None] + dy_nm[None, :]
        near[first:first + 100] = np.any(land.is_land(x_nm, y_nm), axis=1)
    return near


def check_one_land(land, start):
    # Returns a list of problems (empty = good) and a few numbers.
    problems = []
    for lane in land.lanes:
        samples, along_nm, total_nm = sim_land.sample_polyline(lane.points_nm, 0.05)
        if np.any(land.is_land(samples[:, 0], samples[:, 1])):
            problems.append("lane '%s' crosses land" % lane.name)
        must_be_clear = np.ones(len(samples), dtype=bool)
        if lane.name == sim_land.HARBOUR_APPROACH:
            must_be_clear = along_nm <= total_nm - 1.0       # the last 1 nm is exempt
        near = nearest_land_closer_than(land, samples[must_be_clear], 0.5)
        if np.any(near):
            problems.append("lane '%s' is within 0.5 nm of land at %d samples" % (lane.name, np.count_nonzero(near)))
    names = [lane.name for lane in land.lanes]
    if "coastal" not in names or sim_land.HARBOUR_APPROACH not in names:
        problems.append("lanes are %s" % names)

    start_x_nm, start_y_nm, start_heading_deg = start
    if nearest_land_closer_than(land, np.array([[start_x_nm, start_y_nm]]), 2.0)[0]:
        problems.append("find_start is within 2 nm of land")
    lane_distance_nm = min(sim_land.distance_to_polyline_nm(start_x_nm, start_y_nm, lane.points_nm)
                           for lane in land.lanes)
    if lane_distance_nm < 0.99 or lane_distance_nm > 3.01:
        problems.append("find_start is %.2f nm from the nearest lane" % lane_distance_nm)

    land_percent = 100.0 * np.count_nonzero(land.heights_m) / land.heights_m.size
    highest_m = int(land.heights_m.max())
    if land_percent < 10.0 or land_percent > 45.0:
        problems.append("land covers %.1f %%" % land_percent)
    if highest_m > 450:
        problems.append("highest point %d m" % highest_m)
    if land.heights_m.dtype != np.int16 or land.heights_m.min() < 0:
        problems.append("raster is %s with minimum %d" % (land.heights_m.dtype, land.heights_m.min()))
    return problems, land_percent, highest_m, len(land.lanes)


def test_1_2_3_land():
    all_problems = []
    slowest_s = 0.0
    hashes = {}
    percents = []
    highest = []
    three_lanes = 0
    for seed in SEEDS:
        # The generator's progress lines would bury the test output.
        messages.message_verbosity = 0
        try:
            land, start, seconds = generate(seed)
        except sim_land.LandError as error:
            all_problems.append("seed %d: %s" % (seed, error))
            continue
        finally:
            messages.message_verbosity = None
        slowest_s = max(slowest_s, seconds)
        hashes[seed] = land_hash(land)
        problems, land_percent, highest_m, lane_count = check_one_land(land, start)
        percents.append(land_percent)
        highest.append(highest_m)
        three_lanes += 1 if lane_count == 3 else 0
        all_problems += ["seed %d: %s" % (seed, problem) for problem in problems]
        messages.info("seed %2d: %4.1f s, %4.1f %% land, highest %3d m, %d lanes, start (%.1f, %.1f) nm heading %05.1f%s"
                      % (seed, seconds, land_percent, highest_m, lane_count, start[0], start[1], start[2],
                         "" if not problems else "  <-- " + "; ".join(problems)))
        if seed <= 3:
            picture = devtools.render_land(land, PREVIEW_PX, [(start[0], start[1])])
            path = os.path.join(ROOT, "preview_land_%d.png" % seed)
            devtools.write_png(path, picture)
            report(os.path.getsize(path) > 10000, "1 preview", "%s written (%d x %d px, %d bytes) - Oliver looks at it"
                   % (os.path.basename(path), PREVIEW_PX, PREVIEW_PX, os.path.getsize(path)))

    report(not all_problems and len(hashes) == len(SEEDS) and slowest_s <= 30.0, "2 land across %d seeds" % len(SEEDS),
           "%d generated; land %.1f to %.1f %% (limits 10 to 45); highest point %d m (limit 450); "
           "slowest %.1f s (limit 30); %d of %d have the island-gap lane; problems: %s"
           % (len(hashes), min(percents), max(percents), max(highest), slowest_s, three_lanes, len(SEEDS),
              all_problems if all_problems else "none"))

    messages.message_verbosity = 0
    try:
        again, start_again, seconds = generate(1)
    finally:
        messages.message_verbosity = None
    same = land_hash(again) == hashes.get(1)
    all_differ = len(set(hashes.values())) == len(hashes)
    report(same and all_differ, "3 repeatable", "seed 1 twice gives the same raster and lanes: %s (sha256 %s...); "
           "%d seeds give %d different lands" % (same, hashes.get(1, "")[:12], len(hashes), len(set(hashes.values()))))


def make_environment(changes):
    cfg = copy.deepcopy(CFG)
    cfg["environment"].update(changes)
    return sim_environment.Environment(cfg, np.random.default_rng(5), 0.0, 0.0), cfg


def test_4_sea_state():
    results = []
    for wind_kn, expected in [(0.0, 0), (3.0, 0), (5.0, 1), (12.0, 3), (16.0, 3), (17.0, 4), (25.0, 5), (40.0, 7), (60.0, 8)]:
        environment, cfg = make_environment({"wind_speed_kn": wind_kn, "sea_state_from_wind": True})
        results.append((wind_kn, environment.sea_state_douglas(), expected))
    environment, cfg = make_environment({"wind_speed_kn": 25.0, "sea_state_from_wind": False, "sea_state_douglas": 2})
    fixed = environment.sea_state_douglas()
    ok = all(got == expected for wind_kn, got, expected in results) and fixed == 2
    report(ok, "4 sea state", "wind 12 kn -> Douglas %d, 25 kn -> Douglas %d; all %d table rows right: %s; with "
           "sea_state_from_wind off and sea_state_douglas = 2 at 25 kn: %d"
           % (results[3][1], results[6][1], len(results), all(g == e for w, g, e in results), fixed))


def test_5_rain():
    environment, cfg = make_environment({"rain_rate_mm_per_h": 10.0, "wind_from_deg_true": 270.0, "wind_speed_kn": 20.0})
    radius_nm = cfg["environment"]["rain_cell_radius_nm"]
    steps = np.arange(-36.0, 36.0, 0.05)
    x_nm, y_nm = np.meshgrid(steps, steps)
    rate = environment.rain_rate_at(x_nm, y_nm)
    nearest_cell_nm = np.full(x_nm.shape, 1e9)
    for cell_x_nm, cell_y_nm in zip(environment.cell_x_nm, environment.cell_y_nm):
        nearest_cell_nm = np.minimum(nearest_cell_nm, np.hypot(x_nm - cell_x_nm, y_nm - cell_y_nm))
    outside_max = rate[nearest_cell_nm > radius_nm].max()
    peaks = [float(environment.rain_rate_at(np.array([cx]), np.array([cy]))[0])
             for cx, cy in zip(environment.cell_x_nm, environment.cell_y_nm)]
    ok = outside_max == 0.0 and all(abs(peak / 10.0 - 1.0) <= 0.05 for peak in peaks) and rate.max() <= 10.0
    report(ok, "5a rain cells at 10 mm/h", "%d cells of radius %g nm; rate outside every cell %.3f mm/h; "
           "peaks %s mm/h (10 +/- 5 %%)" % (len(peaks), radius_nm, outside_max, ["%.2f" % peak for peak in peaks]))

    dry, dry_cfg = make_environment({"rain_rate_mm_per_h": 0.0})
    report(dry.rain_rate_at(x_nm, y_nm).max() == 0.0, "5b rain rate 0", "no rain anywhere")

    # Drift: wind 20 kn from 270, cells move at half the wind speed toward 090.
    environment.cell_x_nm = np.array([-8.0, 0.0, 29.5])
    environment.cell_y_nm = np.array([3.0, -20.0, 0.0])
    dt_s = CFG["general"]["physics_step_s"]
    crossed_at_x_nm = None
    for step in range(int(3600.0 / dt_s)):
        before_x_nm = environment.cell_x_nm[2]
        environment.step(dt_s, 0.0, 0.0)
        if crossed_at_x_nm is None and environment.cell_x_nm[2] < before_x_nm:
            crossed_at_x_nm = environment.cell_x_nm[2]       # the third cell left the circle and came back
    moved_x_nm = environment.cell_x_nm[0] - (-8.0)
    moved_y_nm = environment.cell_y_nm[0] - 3.0
    ok = (abs(moved_x_nm - 10.0) <= 0.5 and abs(moved_y_nm) <= 0.01
          and crossed_at_x_nm is not None and abs(crossed_at_x_nm + 30.0) < 0.1
          and abs(environment.cell_y_nm[2]) < 0.01)
    report(ok, "5c rain drift and re-entry", "after 1 hour a cell moved %.2f nm east and %.2f nm north (10 +/- 0.5 "
           "toward 090); a cell leaving at x = +30 nm came back at x = %s nm (opposite side)"
           % (moved_x_nm, moved_y_nm, "%.2f" % crossed_at_x_nm if crossed_at_x_nm is not None else None))


def test_6_wiring_over_tcp():
    probe = socket.socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()
    sim = subprocess.Popen([sys.executable, "-u", SIM_MAIN, "--config", CONFIG_PATH, "--port", str(port)],
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        deadline_s = time.perf_counter() + 10.0
        while True:
            try:
                sock = socket.create_connection(("127.0.0.1", port), timeout=60.0)   # hello waits for the land
                break
            except OSError:
                if time.perf_counter() > deadline_s:
                    raise
                time.sleep(0.1)

        def read_until(wanted):
            for count in range(5000):
                frame_type, payload = sim_protocol.read_frame(sock)
                if frame_type != sim_protocol.FRAME_JSON:
                    continue                 # radar video (from M4 on)
                message = sim_protocol.decode_json(payload)
                if message["t"] == wanted:
                    return message
            return None

        hello = read_until("hello")
        state = read_until("state")
        env = state["env"]
        sim_protocol.send_json(sock, {"t": "set", "path": "environment.wind_speed_kn", "value": 25})
        setting = read_until("setting")
        sim_protocol.send_json(sock, {"t": "set", "path": "environment.current_drift_kn", "value": 99})
        clamped = read_until("setting")
        later = read_until("state")["env"]
        later = read_until("state")["env"]
        ok = (setting == {"t": "setting", "path": "environment.wind_speed_kn", "value": 25.0}
              and clamped["value"] == 8.0
              and env["wind_speed_kn"] == 12.0 and env["sea_state_douglas"] == 3
              and later["wind_speed_kn"] == 25.0 and later["sea_state_douglas"] == 5
              and later["current_drift_kn"] == 8.0)
        report(ok, "6 set environment.wind_speed_kn", "answered with %s; drift 99 confirmed as %s kn; state.env went "
               "from wind %s kn Douglas %s to wind %s kn Douglas %s"
               % (setting, clamped["value"], env["wind_speed_kn"], env["sea_state_douglas"],
                  later["wind_speed_kn"], later["sea_state_douglas"]))

        # The sim made the land for its own seed and started own ship with find_start.
        streams = sim_common.make_random_streams(hello["seed"])
        messages.message_verbosity = 0
        try:
            land = sim_land.generate_land(CFG, streams["land"])
            expected_start = land.find_start(streams["own_ship"])
        finally:
            messages.message_verbosity = None
        own = state["own"]
        # The first state arrives a moment after the start, so allow a little movement.
        moved_nm = float(np.hypot(own["x_nm"] - expected_start[0], own["y_nm"] - expected_start[1]))
        heading_error_deg = abs(sim_common.angle_difference_deg(own["heading_deg_true"], expected_start[2]))
        ok = moved_nm < 0.05 and heading_error_deg < 0.01
        report(ok, "6b land at start-up and find_start", "seed %d: own ship at (%.2f, %.2f) nm heading %05.1f; "
               "find_start for that seed gives (%.2f, %.2f) nm heading %05.1f"
               % (hello["seed"], own["x_nm"], own["y_nm"], own["heading_deg_true"],
                  expected_start[0], expected_start[1], expected_start[2]))
        sim_protocol.send_json(sock, {"t": "quit"})
        sim.wait(timeout=5.0)
        sock.close()
    finally:
        if sim.poll() is None:
            sim.kill()


def test_png_writer():
    # The PNG must open in any viewer: check the signature, the size in the header and
    # that the pixel data unpacks to what went in.
    import struct
    import zlib
    grey = (np.arange(6 * 4, dtype=np.uint8) * 10).reshape(4, 6)
    rgb = np.stack([grey, 255 - grey, grey // 2], axis=2)
    path = os.path.join(ROOT, "preview_test_m2_tmp.png")
    results = []
    for array, colour_type in [(grey, 0), (rgb, 2)]:
        devtools.write_png(path, array)
        with open(path, "rb") as png_file:
            data = png_file.read()
        width, height, depth, kind = struct.unpack(">IIBB", data[16:26])
        idat_length = struct.unpack(">I", data[33:37])[0]
        raw = zlib.decompress(data[41:41 + idat_length])
        rows = np.frombuffer(raw, dtype=np.uint8).reshape(4, -1)
        results.append(data[:8] == b"\x89PNG\r\n\x1a\n" and (width, height, depth, kind) == (6, 4, 8, colour_type)
                       and np.array_equal(rows[:, 1:].reshape(array.shape), array) and not rows[:, 0].any())
    os.remove(path)
    report(all(results), "PNG writer", "grey and RGB files read back correctly: %s" % results)


def main():
    test_png_writer()
    test_4_sea_state()
    test_5_rain()
    test_1_2_3_land()
    test_6_wiring_over_tcp()
    if failures:
        messages.fail("%d test line(s) failed" % failures)
    else:
        messages.ok("All M2 tests passed")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
