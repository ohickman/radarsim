# sim_contacts.py - the other vessels: kinds, behaviour, the spawner that keeps the
# traffic density, land avoidance, COLREGS-lite, and the fixed contacts of the
# calibration scenario (BRIEF.md Sections 8.4 and 12).
# Contacts move over the ground at their own course and speed; the current does not
# carry them. Nothing changes speed or heading instantly.
# Units: positions nm (x east, y north), speed kn, headings deg true, time s of sim
# time, lengths m, radar cross-section m2.
# Called by: sim_main.py every physics step. The radar (M4) reads scatterer_points.
# Plain Python numbers on purpose: with 40 contacts a loop is faster than numpy.

import math

import sim_marks
from sim_common import M_PER_NM, S_PER_H, S_PER_MIN, cpa_tcpa

KINDS = ["ship", "tug_tow", "fishing", "pleasure"]

# Everything in this block is chosen, not from a source.
THINK_INTERVAL_S = 2.0           # how often a contact reconsiders its plan
DENSITY_DEAD_BAND = 3.0          # contacts: nothing is added or removed while the count is this close to the wanted count
REMOVE_BEYOND_NM = 2.0           # a contact this far outside the active circle is removed (Section 8.4)
FILL_CLEAR_OF_OWN_NM = 1.5       # contacts put in by the TRAFFIC NOW button start at least this far from own ship
MARK_ID_BASE = 1000000           # a lane buoy's contact id is this plus its number, so it never changes
MARK_UPDATE_S = 2.0              # how often the buoys near own ship are brought up to date
MARK_REMOVE_BEYOND_NM = 1.0      # a lane buoy this far outside the mark radius is taken away
MARK_LENGTH_M = 2.0              # for the collision test
COLREGS_RANGE_NM = 12.0          # (Section 8.4)
GIVE_WAY_CLEAR_FACTOR = 1.2      # give-way ends when the planned course would pass at 1.2 x the CPA limit
ROUTE_EXTENSION_NM = 60.0        # lanes that end at the edge of the land square go on straight this far
JUNCTION_SNAP_NM = 0.2           # a lane end this close to another lane joins it
TURN_OFF_PROBABILITY = 0.4       # chance that a ship takes a side lane it passes
HARBOUR_SPEED_KN = 6.0           # speed limit on a lane that ends in a harbour
HARBOUR_DEPARTURE_PROBABILITY = 0.1
LANE_WANDER_TIME_S = 120.0       # how quickly the slow wander around the lane heading changes
LANE_CORRECTION_DEG = 15.0       # steering toward the lane position: this much per quarter lane width off
LANE_CORRECTION_MAX_DEG = 30.0
LANE_OFFSET_MAX_DEG = 30.0       # largest unplanned course change in a 2 nm wide lane; less in narrower ones
LANE_SLOT_RANGE = (0.25, 0.7)    # where vessels sit in a two-way lane: this share of the half width, right of centre
LANE_PASSING_FRACTION = 0.1      # vessels in the same lane accept a CPA of this share of the lane width
IN_LANE_ALTERATION_DEG = 10.0    # a ship giving way inside its lane shifts this much toward its side (not the full alteration)...
IN_LANE_SLOW_FRACTION = 0.7      # ...and slows to this share of its cruise speed
IN_LANE_EDGE_MARGIN_NM = 0.05    # it does not go closer than this to the edge of its lane
ESCALATE_TCPA_MIN = 5.0          # a lane ship that still cannot keep its CPA this close to the point leaves the lane with the full alteration
ESCALATE_CPA_FRACTION = 0.7      # ...when the CPA is still below this share of its limit
ROGUE_TYPES = ("no_give_way", "cross_bow", "late")      # the mistakes a misbehaving ship can make (BRIEF Section 8.4)
ROGUE_LATE_TCPA_MIN = 3.0        # a "late" ship gives way only when the TCPA is below this
ROGUE_BOW_RANGE_NM = 3.0         # a "cross_bow" ship turns toward own ship's track when it is this near and closing...
ROGUE_BOW_TURN_S = 240.0        # ...and holds that heading this long (ships turn slowly)
SHIP_RCS_SPLIT = [(-1.0 / 3.0, 0.25), (0.0, 0.5), (1.0 / 3.0, 0.25)]   # (place along the hull, share of the RCS)


def normalise_360(angle_deg):
    return angle_deg % 360.0


def signed_difference_deg(to_deg, from_deg):
    # Shortest turn from one direction to another, -180..+180, + = to starboard.
    return (to_deg - from_deg + 180.0) % 360.0 - 180.0


def bearing_deg_true(dx_nm, dy_nm):
    return math.degrees(math.atan2(dx_nm, dy_nm)) % 360.0


def clip(value, low, high):
    return max(low, min(high, value))


class Contact:
    def __init__(self, contact_id, kind, x_nm, y_nm, heading_deg_true, speed_kn):
        self.id = contact_id
        self.name = None                 # "B1", "S4", ... in the calibration scenario
        self.kind = kind
        self.length_m = 10.0
        self.scatterers = [(0.0, 10.0)]  # (offset along the hull in m, + = toward the bow; RCS in m2)
        self.x_nm = x_nm
        self.y_nm = y_nm
        self.heading_deg_true = heading_deg_true
        self.speed_kn = speed_kn
        self.max_turn_deg_per_s = 1.0
        self.accel_kn_per_s = 0.01
        self.behaviour = "straight"      # "lane", "fishing", "pleasure", "straight" or "fixed"
        self.predictability = 1.0        # 0 = unpredictable, 1 = never makes an unplanned change
        self.complies = False            # obeys COLREGS-lite
        # Whether it misbehaves is decided from these two fixed numbers (0 to 1, spread evenly over the ids; no random numbers are used,
        # so the traffic does not change): it is a rogue when rogue_u is below the setting, and rogue_v picks its mistake among the enabled ones.
        # So moving the setting makes ships turn bad or good at once, and about the right share of them is bad.
        self.rogue_u = (contact_id * 0.6180339887 + 0.137) % 1.0
        self.rogue_v = (contact_id * 0.7548776662 + 0.5) % 1.0
        self.rogue_now = None            # the mistake it is making now, or None; not changed while it is in an encounter
        self.rogue_done = False          # a cross_bow ship has made its turn for this approach
        self.cpa_limit_nm = 1.0

        # The plan: what the behaviour wants. The contact turns and speeds up toward it.
        self.desired_heading_deg = heading_deg_true
        self.desired_speed_kn = speed_kn
        self.cruise_speed_kn = speed_kn
        self.speed_range_kn = (0.0, 60.0)
        self.course_offset_deg = 0.0     # an unplanned course change in force
        self.course_offset_until_s = 0.0
        self.unplanned_course_changes = 0
        self.unplanned_speed_changes = 0
        self.age_s = 0.0
        self.last_think_s = None
        self.next_think_s = 0.0

        # Things that overrule the plan, strongest first: land, give-way, stand-on.
        self.next_land_check_s = 0.0
        self.avoid_until_s = -1.0
        self.avoid_heading_deg = 0.0
        self.avoid_speed_kn = None
        self.avoid_side = 0.0
        self.avoid_count = 0
        self.land_stops = 0              # steps on which the last-resort land check held it still
        self.give_way_to = None          # the other vessel's id, or "own"
        self.give_way_heading_deg = 0.0
        self.stand_on_for = None
        self.hold_heading_deg = 0.0
        self.hold_speed_kn = 0.0

        # Tug with tow: the barge is dragged along behind.
        self.tow_length_nm = None
        self.tow_x_nm = 0.0
        self.tow_y_nm = 0.0
        self.tow_rcs_m2 = 0.0

        # A lane buoy (sim_marks.Mark); None for everything else.
        self.mark = None

        # Lane following.
        self.plan = []                   # legs: {"route", "direction", "exit_along_nm", "then"}
        self.leg = 0
        self.segment_hint = None
        self.wander_deg = 0.0
        self.wander_stddev_deg = 0.0
        self.lane_slot = 0.0             # its own place across the lane: share of the half width, + = right of centre
        self.settled = False             # in its lane and steady (the tests look only at settled vessels)
        self.lane_heading_deg = 0.0
        self.lane_right_nm = 0.0         # distance to starboard of the lane centre line, in the travel direction
        self.lane_half_nm = None         # half the width of the lane it is in
        self.give_way_in_lane = False    # giving way by staying in the lane (a small shift and slowing) rather than turning out of it
        self.give_way_side = 1.0         # +1 shifting to starboard, -1 to port

        # Fishing and pleasure craft.
        self.state = ""
        self.goal_x_nm = 0.0
        self.goal_y_nm = 0.0
        self.work_until_s = 0.0
        self.work_mode = ""
        self.leg_heading_deg = 0.0
        self.leg_length_nm = 0.0
        self.leg_run_nm = 0.0
        self.work_speed_kn = 0.0
        self.is_sail = False
        self.tack = 1.0
        self.tack_until_s = 0.0
        self.idle_until_s = 0.0
        self.idle_speed_kn = 0.0

    def overruled(self, now_s):
        return self.give_way_to is not None or self.stand_on_for is not None or now_s < self.avoid_until_s

    def velocity_kn(self):
        heading_rad = math.radians(self.heading_deg_true)
        return self.speed_kn * math.sin(heading_rad), self.speed_kn * math.cos(heading_rad)

    def scatterer_points(self):
        # For the radar: a list of (x_nm, y_nm, rcs_m2).
        heading_rad = math.radians(self.heading_deg_true)
        points = []
        for offset_m, rcs_m2 in self.scatterers:
            offset_nm = offset_m / M_PER_NM                      # m -> nm
            points.append((self.x_nm + offset_nm * math.sin(heading_rad),
                           self.y_nm + offset_nm * math.cos(heading_rad), rcs_m2))
        if self.tow_length_nm is not None:
            points.append((self.tow_x_nm, self.tow_y_nm, self.tow_rcs_m2))
        return points


class Route:
    # A lane as the traffic uses it: the lane's centre line, made longer at each end
    # that runs out to sea, with what happens at each end.
    def __init__(self, lane, points, start_type, end_type):
        self.name = lane.name
        self.width_nm = lane.width_nm
        self.two_way = lane.two_way
        self.xs = [float(point[0]) for point in points]
        self.ys = [float(point[1]) for point in points]
        self.end_types = [start_type, end_type]      # "open", "junction" or "terminal" (a harbour)
        self.end_joins = [None, None]                # for a junction: (route index, distance along it)
        self.side_junctions = []                     # (distance along this route, other route index, its end 0 or 1)
        self.lengths = []
        self.ux = []                                 # unit vector of each segment
        self.uy = []
        self.along = [0.0]                           # distance along the route at each point
        for index in range(len(self.xs) - 1):
            dx = self.xs[index + 1] - self.xs[index]
            dy = self.ys[index + 1] - self.ys[index]
            length = math.hypot(dx, dy)
            self.lengths.append(length)
            self.ux.append(dx / length)
            self.uy.append(dy / length)
            self.along.append(self.along[-1] + length)
        self.total_nm = self.along[-1]
        self.has_terminal = "terminal" in self.end_types

    def project(self, x_nm, y_nm, hint):
        # Nearest place on the route. Returns (segment, distance along the route,
        # distance to starboard of the centre line going forward, forward heading).
        if hint is None:
            candidates = range(len(self.lengths))
        else:
            candidates = range(max(hint - 1, 0), min(hint + 2, len(self.lengths)))
        best = None
        for index in candidates:
            dx = x_nm - self.xs[index]
            dy = y_nm - self.ys[index]
            run = clip(dx * self.ux[index] + dy * self.uy[index], 0.0, self.lengths[index])
            off_x = dx - run * self.ux[index]
            off_y = dy - run * self.uy[index]
            distance_sq = off_x * off_x + off_y * off_y
            if best is None or distance_sq < best[0]:
                right_nm = dx * self.uy[index] - dy * self.ux[index]
                best = (distance_sq, index, self.along[index] + run, right_nm)
        index = best[1]
        return index, best[2], best[3], bearing_deg_true(self.ux[index], self.uy[index])

    def point_at(self, along_nm):
        along_nm = clip(along_nm, 0.0, self.total_nm)
        index = 0
        while index < len(self.lengths) - 1 and self.along[index + 1] < along_nm:
            index += 1
        run = along_nm - self.along[index]
        return self.xs[index] + run * self.ux[index], self.ys[index] + run * self.uy[index], index


def build_routes(land):
    # Works out, for each lane end, whether it runs out to sea (then the route goes
    # on straight, so ships arrive and leave along it), joins another lane, or ends
    # in a harbour.
    half_nm = land.extent_nm / 2.0
    routes = []
    for lane in land.lanes:
        points = [(float(x), float(y)) for x, y in lane.points_nm]
        end_types = []
        for end in (0, 1):
            x, y = points[0] if end == 0 else points[-1]
            if max(abs(x), abs(y)) >= half_nm - 0.3:
                end_types.append("open")
            else:
                end_types.append("terminal")             # may turn out to be a junction below
        if end_types[0] == "open":
            dx, dy = points[0][0] - points[1][0], points[0][1] - points[1][1]
            scale = ROUTE_EXTENSION_NM / math.hypot(dx, dy)
            points.insert(0, (points[0][0] + dx * scale, points[0][1] + dy * scale))
        if end_types[1] == "open":
            dx, dy = points[-1][0] - points[-2][0], points[-1][1] - points[-2][1]
            scale = ROUTE_EXTENSION_NM / math.hypot(dx, dy)
            points.append((points[-1][0] + dx * scale, points[-1][1] + dy * scale))
        routes.append(Route(lane, points, end_types[0], end_types[1]))

    for index, route in enumerate(routes):
        for end in (0, 1):
            if route.end_types[end] != "terminal":
                continue
            x, y = (route.xs[0], route.ys[0]) if end == 0 else (route.xs[-1], route.ys[-1])
            for other_index, other in enumerate(routes):
                if other_index == index:
                    continue
                segment, along_nm, right_nm, heading = other.project(x, y, None)
                near_x, near_y, segment = other.point_at(along_nm)
                if math.hypot(x - near_x, y - near_y) <= JUNCTION_SNAP_NM:
                    route.end_types[end] = "junction"
                    route.end_joins[end] = (other_index, along_nm)
                    other.side_junctions.append((along_nm, index, end))
                    break
        route.has_terminal = "terminal" in route.end_types
    return routes


class Traffic:
    def __init__(self, cfg, rng, land, environment):
        self.cfg = cfg
        self.traffic = cfg["traffic"]
        self.rng = rng
        self.land = land
        self.environment = environment
        self.routes = build_routes(land)
        self.contacts = []
        self.next_id = 1
        self.marks = sim_marks.build_marks(land, self.traffic)    # every lane buoy of the run
        self.mark_contacts = {}              # mark number -> its fixed contact, for the buoys within the mark radius
        self.next_mark_update_s = 0.0
        self.spawning = True                 # False: only contacts added by hand (calibration, tests)
        self.populated = False
        self.wanted_count = None             # the wandering target count, a float
        self.next_colregs_s = 0.0
        self.own = (0.0, 0.0, 0.0, 0.0)      # own ship: x_nm, y_nm, east and north ground speed in kn
        self.now_s = 0.0

    # ---------------------------------------------------------------- per step

    def step(self, dt_s, sim_time_s, own_x_nm, own_y_nm, own_vx_kn, own_vy_kn):
        self.own = (own_x_nm, own_y_nm, own_vx_kn, own_vy_kn)
        self.now_s = sim_time_s
        if self.spawning and sim_time_s >= self.next_mark_update_s:
            self.next_mark_update_s = sim_time_s + MARK_UPDATE_S
            self.update_marks(own_x_nm, own_y_nm)
        if self.spawning:
            self.keep_density(dt_s)
        if sim_time_s >= self.next_colregs_s:
            self.next_colregs_s = sim_time_s + self.traffic["colregs_check_interval_s"]
            self.check_colregs()

        remove_beyond_nm = self.traffic["active_radius_nm"] + REMOVE_BEYOND_NM
        gone = []
        for contact in self.contacts:
            contact.age_s += dt_s
            if contact.behaviour != "fixed":
                if sim_time_s >= contact.next_think_s:
                    think_dt_s = THINK_INTERVAL_S if contact.last_think_s is None else sim_time_s - contact.last_think_s
                    contact.last_think_s = sim_time_s
                    contact.next_think_s = sim_time_s + THINK_INTERVAL_S
                    if self.think(contact, think_dt_s) == "remove":
                        gone.append(contact)
                        continue
                if sim_time_s >= contact.next_land_check_s:
                    self.check_land(contact)
            self.move(contact, dt_s)
            if self.spawning and math.hypot(contact.x_nm - own_x_nm, contact.y_nm - own_y_nm) > remove_beyond_nm:
                gone.append(contact)
        for contact in gone:
            self.contacts.remove(contact)

    # ---------------------------------------------------------------- lane buoys

    def update_marks(self, own_x_nm, own_y_nm):
        # The lane buoys within the mark radius of own ship exist as fixed contacts, the others do not.
        # They are kept apart from self.contacts (the traffic): they do not count toward the density,
        # do not take part in COLREGS and are not removed with the traffic. everything() joins the two.
        radius_nm = self.traffic["mark_radius_nm"]
        for mark in self.marks:
            distance_nm = math.hypot(mark.x_nm - own_x_nm, mark.y_nm - own_y_nm)
            if mark.number in self.mark_contacts:
                if distance_nm > radius_nm + MARK_REMOVE_BEYOND_NM:
                    del self.mark_contacts[mark.number]
            elif distance_nm <= radius_nm:
                contact = Contact(MARK_ID_BASE + mark.number, "buoy", mark.x_nm, mark.y_nm, 0.0, 0.0)
                contact.name = mark.name
                contact.behaviour = "fixed"
                contact.length_m = MARK_LENGTH_M
                contact.scatterers = [(0.0, mark.rcs_m2)]
                contact.mark = mark
                self.mark_contacts[mark.number] = contact

    def everything(self):
        # The traffic and the lane buoys near own ship: what the radar sees, what own ship can hit,
        # and what the wheelhouse view shows.
        if not self.mark_contacts:
            return self.contacts
        return self.contacts + list(self.mark_contacts.values())

    def move(self, contact, dt_s):
        # Turn and change speed toward what is wanted, never faster than the kind's limits.
        wanted_heading_deg = contact.desired_heading_deg
        wanted_speed_kn = contact.desired_speed_kn
        if contact.stand_on_for is not None:
            wanted_heading_deg = contact.hold_heading_deg
            wanted_speed_kn = contact.hold_speed_kn
        if contact.give_way_to is not None:
            wanted_heading_deg = contact.give_way_heading_deg
            if contact.give_way_in_lane:
                # Staying in the lane: slow down, and shift toward its side only until the edge of the lane is near.
                wanted_speed_kn = min(wanted_speed_kn, IN_LANE_SLOW_FRACTION * contact.cruise_speed_kn)
                if contact.lane_half_nm is not None and contact.give_way_side * contact.lane_right_nm >= contact.lane_half_nm - IN_LANE_EDGE_MARGIN_NM:
                    wanted_heading_deg = contact.lane_heading_deg
        if self.now_s < contact.avoid_until_s:
            wanted_heading_deg = contact.avoid_heading_deg
            if contact.avoid_speed_kn is not None:
                wanted_speed_kn = min(wanted_speed_kn, contact.avoid_speed_kn)

        most_turn_deg = contact.max_turn_deg_per_s * dt_s
        turn_deg = clip(signed_difference_deg(wanted_heading_deg, contact.heading_deg_true), -most_turn_deg, most_turn_deg)
        contact.heading_deg_true = (contact.heading_deg_true + turn_deg) % 360.0
        most_speed_change_kn = contact.accel_kn_per_s * dt_s
        contact.speed_kn += clip(wanted_speed_kn - contact.speed_kn, -most_speed_change_kn, most_speed_change_kn)

        heading_rad = math.radians(contact.heading_deg_true)
        distance_nm = contact.speed_kn * dt_s / S_PER_H                      # kn x s -> nm
        new_x_nm = contact.x_nm + distance_nm * math.sin(heading_rad)
        new_y_nm = contact.y_nm + distance_nm * math.cos(heading_rad)
        if contact.behaviour != "fixed" and self.land.is_land_point(new_x_nm, new_y_nm):
            # Last resort: never onto land. It stays where it is and keeps turning away.
            contact.land_stops += 1
            contact.next_land_check_s = 0.0
        else:
            contact.x_nm = new_x_nm
            contact.y_nm = new_y_nm

        if contact.tow_length_nm is not None:
            # The tow is pulled toward the tug and stays one tow length behind it.
            dx = contact.tow_x_nm - contact.x_nm
            dy = contact.tow_y_nm - contact.y_nm
            distance_nm = math.hypot(dx, dy)
            if distance_nm > 1e-9:
                contact.tow_x_nm = contact.x_nm + dx / distance_nm * contact.tow_length_nm
                contact.tow_y_nm = contact.y_nm + dy / distance_nm * contact.tow_length_nm

    # ---------------------------------------------------------------- density and spawning

    def mean_count(self):
        area_nm2 = math.pi * self.traffic["active_radius_nm"] ** 2
        return self.traffic["density_per_100_nm2"] * area_nm2 / 100.0

    def keep_density(self, dt_s):
        # The wanted count wanders around its mean (an Ornstein-Uhlenbeck process).
        mean = self.mean_count()
        if self.wanted_count is None:
            self.wanted_count = mean
        time_constant_s = self.traffic["density_time_constant_min"] * S_PER_MIN
        stddev = self.traffic["density_stddev_fraction"] * mean
        self.wanted_count += ((mean - self.wanted_count) * dt_s / time_constant_s
                              + stddev * math.sqrt(2.0 * dt_s / time_constant_s) * self.rng.normal())
        most = self.traffic["max_contacts"]
        wanted = int(clip(round(self.wanted_count), 0, most))

        if not self.populated:
            # At the start of a run the circle is filled, so the screen is not empty.
            self.populated = True
            for count in range(wanted * 3):
                if len(self.contacts) >= wanted:
                    break
                self.spawn(at_edge=False)
        elif len(self.contacts) <= self.wanted_count - DENSITY_DEAD_BAND and len(self.contacts) < most:
            # A dead band of a few contacts either side of the wanted count, so that small
            # wobbles of it do not keep adding and removing contacts at the edge.
            self.spawn(at_edge=True)
        elif len(self.contacts) >= self.wanted_count + DENSITY_DEAD_BAND or len(self.contacts) > most:
            # Remove the farthest one, of a kind there is too much of if possible.
            own_x_nm, own_y_nm = self.own[0], self.own[1]
            total = len(self.contacts)
            surplus = [c for c in self.contacts if c.kind in KINDS
                       and sum(1 for other in self.contacts if other.kind == c.kind) > self.mix_fraction(c.kind) * total]
            farthest = max(surplus or self.contacts, key=lambda c: math.hypot(c.x_nm - own_x_nm, c.y_nm - own_y_nm))
            self.contacts.remove(farthest)

    def fill_now(self):
        # Make the contact count match the density setting at once (the TRAFFIC NOW button): contacts appear anywhere in the circle,
        # but not within FILL_CLEAR_OF_OWN_NM of own ship, or the farthest ones vanish. Nothing is tidied up behind them: to the
        # ARPA a contact that vanishes is a lost target. Returns (added, removed).
        if not self.spawning:
            return 0, 0
        own_x_nm, own_y_nm = self.own[0], self.own[1]
        self.wanted_count = self.mean_count()                 # the wandering count starts again from the setting
        wanted = int(clip(round(self.wanted_count), 0, self.traffic["max_contacts"]))
        self.populated = True
        added = removed = 0
        tries = 0
        while len(self.contacts) < wanted and tries < 6 * wanted + 20:
            tries += 1
            contact = self.spawn(at_edge=False)
            if contact is None:
                continue
            if math.hypot(contact.x_nm - own_x_nm, contact.y_nm - own_y_nm) < FILL_CLEAR_OF_OWN_NM:
                self.contacts.remove(contact)
            else:
                added += 1
        while len(self.contacts) > wanted:
            surplus = [c for c in self.contacts if c.kind in KINDS
                       and sum(1 for other in self.contacts if other.kind == c.kind) > self.mix_fraction(c.kind) * len(self.contacts)]
            farthest = max(surplus or self.contacts, key=lambda c: math.hypot(c.x_nm - own_x_nm, c.y_nm - own_y_nm))
            self.contacts.remove(farthest)
            removed += 1
        return added, removed

    def mix_fraction(self, kind):
        # The share of a kind among the four weights, which the display can change while the sim runs.
        # With every weight at 0 the four kinds are equally likely.
        total = sum(self.traffic["mix_" + other] for other in KINDS)
        if total <= 0.0:
            return 1.0 / len(KINDS)
        return self.traffic["mix_" + kind] / total

    def choose_kind(self):
        # Drawn from the mix fractions, leaning toward the kinds that are short at the
        # moment, so the mix on the water matches the config whatever each kind's stay.
        total = len(self.contacts) + 1
        weights = []
        for kind in KINDS:
            present = sum(1 for contact in self.contacts if contact.kind == kind)
            weights.append(max(self.mix_fraction(kind) * total - present, 0.0) + 1e-6)
        pick = self.rng.random() * sum(weights)
        for kind, weight in zip(KINDS, weights):
            pick -= weight
            if pick <= 0.0:
                return kind
        return KINDS[-1]

    def uniform(self, pair):
        return self.rng.uniform(pair[0], pair[1])

    def spawn(self, at_edge):
        # One new contact: on or just inside the circle edge heading inward (at_edge),
        # or anywhere in the circle (at the start of a run). Returns it, or None if no
        # place was found this time.
        kind = self.choose_kind()
        if kind in ("ship", "tug_tow"):
            contact = self.spawn_on_lane(kind, at_edge)
        else:
            contact = self.spawn_in_open_water(kind, at_edge)
        if contact is not None:
            self.contacts.append(contact)
        return contact

    def new_contact(self, kind, x_nm, y_nm, heading_deg_true, speed_kn):
        block = self.traffic[kind]
        contact = Contact(self.next_id, kind, x_nm, y_nm, heading_deg_true, speed_kn)
        self.next_id += 1
        contact.max_turn_deg_per_s = block["max_turn_deg_per_min"] / S_PER_MIN       # deg/min -> deg/s
        contact.accel_kn_per_s = block["accel_kn_per_min"] / S_PER_MIN               # kn/min -> kn/s
        contact.predictability = clip(self.rng.normal(block["predictability_mean"], block["predictability_stddev"]), 0.0, 1.0)
        contact.complies = self.rng.random() < block["colregs_compliance_fraction"]
        contact.cpa_limit_nm = block["colregs_cpa_limit_nm"]
        # Size, and a radar cross-section that grows with it (evenly on a log scale).
        size = self.rng.random()
        contact.length_m = block["length_m_range"][0] + size * (block["length_m_range"][1] - block["length_m_range"][0])
        rcs_low, rcs_high = block["rcs_m2_range"]
        rcs_m2 = rcs_low * (rcs_high / rcs_low) ** size
        if kind == "ship":
            contact.scatterers = [(place * contact.length_m, share * rcs_m2) for place, share in SHIP_RCS_SPLIT]
        else:
            contact.scatterers = [(0.0, rcs_m2)]
        if kind == "tug_tow":
            contact.tow_length_nm = self.uniform(block["tow_length_m_range"]) / M_PER_NM      # m -> nm
            contact.tow_rcs_m2 = self.uniform(block["tow_rcs_m2_range"])
            heading_rad = math.radians(heading_deg_true)
            contact.tow_x_nm = x_nm - contact.tow_length_nm * math.sin(heading_rad)
            contact.tow_y_nm = y_nm - contact.tow_length_nm * math.cos(heading_rad)
        # The first think and land check are spread out so contacts do not all think at once.
        contact.next_think_s = self.now_s + self.rng.random() * THINK_INTERVAL_S
        contact.next_land_check_s = self.now_s + self.rng.random() * 3.0
        return contact

    def spawn_on_lane(self, kind, at_edge):
        own_x_nm, own_y_nm = self.own[0], self.own[1]
        radius_nm = self.traffic["active_radius_nm"]
        block = self.traffic[kind]
        cruise_kn = clip(self.rng.normal(block["speed_mean_kn"], block["speed_stddev_kn"]),
                         0.4 * block["speed_mean_kn"], 2.0 * block["speed_mean_kn"])

        # A ship leaving harbour now and then, if a harbour is in the circle.
        if at_edge and self.rng.random() < HARBOUR_DEPARTURE_PROBABILITY:
            for index, route in enumerate(self.routes):
                for end in (0, 1):
                    if route.end_types[end] != "terminal":
                        continue
                    direction = 1 if end == 0 else -1
                    along_nm = 0.05 if end == 0 else route.total_nm - 0.05
                    x_nm, y_nm, segment = route.point_at(along_nm)
                    if math.hypot(x_nm - own_x_nm, y_nm - own_y_nm) < radius_nm - 1.0:
                        return self.start_on_route(kind, index, direction, along_nm, min(cruise_kn, HARBOUR_SPEED_KN), cruise_kn)

        # Places where a route crosses the circle edge (or any place inside it).
        places = []
        for index, route in enumerate(self.routes):
            along_nm = 0.0
            while along_nm <= route.total_nm:
                x_nm, y_nm, segment = route.point_at(along_nm)
                distance_nm = math.hypot(x_nm - own_x_nm, y_nm - own_y_nm)
                if (at_edge and radius_nm - 0.5 <= distance_nm <= radius_nm) or (not at_edge and distance_nm < radius_nm):
                    places.append((index, along_nm, distance_nm))
                along_nm += 0.25
        if not places:
            # No lane near: an ocean passage, straight across the circle.
            return self.spawn_in_open_water(kind, at_edge)
        index, along_nm, distance_nm = places[int(self.rng.integers(0, len(places)))]
        route = self.routes[index]
        direction = 1 if self.rng.random() < 0.5 else -1
        if at_edge:
            # Inward: the way along the route that brings it nearer own ship.
            x_nm, y_nm, segment = route.point_at(along_nm + 0.25)
            direction = 1 if math.hypot(x_nm - own_x_nm, y_nm - own_y_nm) < distance_nm else -1
        return self.start_on_route(kind, index, direction, along_nm, cruise_kn, cruise_kn)

    def start_on_route(self, kind, route_index, direction, along_nm, speed_kn, cruise_kn):
        route = self.routes[route_index]
        x_nm, y_nm, segment = route.point_at(along_nm)
        forward_deg = bearing_deg_true(route.ux[segment], route.uy[segment])
        heading_deg = forward_deg if direction > 0 else (forward_deg + 180.0) % 360.0
        # Its own place across the lane: right of the centre line in a two-way lane.
        lane_slot = self.uniform(LANE_SLOT_RANGE) if route.two_way else self.rng.uniform(-0.5, 0.5)
        right_nm = lane_slot * route.width_nm / 2.0 * direction
        x_nm += right_nm * route.uy[segment]
        y_nm -= right_nm * route.ux[segment]
        if route.has_terminal:
            speed_kn = min(speed_kn, HARBOUR_SPEED_KN)
        contact = self.new_contact(kind, x_nm, y_nm, heading_deg, speed_kn)
        block = self.traffic[kind]
        contact.behaviour = "lane"
        contact.cruise_speed_kn = cruise_kn
        contact.speed_range_kn = (0.4 * block["speed_mean_kn"], 2.0 * block["speed_mean_kn"])
        contact.wander_stddev_deg = block["lane_heading_stddev_deg"]
        contact.wander_deg = self.rng.normal(0.0, contact.wander_stddev_deg)
        contact.lane_slot = lane_slot
        contact.lane_heading_deg = heading_deg
        contact.lane_right_nm = lane_slot * route.width_nm / 2.0
        contact.plan = self.build_plan(route_index, direction, along_nm)
        contact.settled = True
        return contact

    def build_plan(self, route_index, direction, along_nm):
        # The legs a lane vessel will sail. A leg ends by joining the next lane
        # ("next"), by arriving in harbour ("arrive"), or never (out to sea).
        plan = []
        for leg_number in range(4):
            route = self.routes[route_index]
            # A side lane ahead that it may turn into.
            ahead = [junction for junction in route.side_junctions if (junction[0] - along_nm) * direction > 2.0]
            if ahead and self.rng.random() < TURN_OFF_PROBABILITY:
                junction_along_nm, other_index, other_end = ahead[int(self.rng.integers(0, len(ahead)))]
                plan.append({"route": route_index, "direction": direction, "exit_along_nm": junction_along_nm, "then": "next"})
                route_index = other_index
                direction = 1 if other_end == 0 else -1
                along_nm = 0.0 if other_end == 0 else self.routes[other_index].total_nm
                continue
            far_end = 1 if direction > 0 else 0
            end_along_nm = route.total_nm if direction > 0 else 0.0
            end_type = route.end_types[far_end]
            if end_type == "junction":
                plan.append({"route": route_index, "direction": direction, "exit_along_nm": end_along_nm, "then": "next"})
                route_index, along_nm = route.end_joins[far_end]
                direction = 1 if self.rng.random() < 0.5 else -1
                continue
            if end_type == "terminal":
                plan.append({"route": route_index, "direction": direction, "exit_along_nm": end_along_nm, "then": "arrive"})
            else:
                plan.append({"route": route_index, "direction": direction, "exit_along_nm": None, "then": None})
            return plan
        plan.append({"route": route_index, "direction": direction, "exit_along_nm": None, "then": None})
        return plan

    def spawn_in_open_water(self, kind, at_edge):
        own_x_nm, own_y_nm = self.own[0], self.own[1]
        radius_nm = self.traffic["active_radius_nm"]
        for attempt in range(20):
            bearing_deg = self.rng.uniform(0.0, 360.0)
            if at_edge:
                distance_nm = radius_nm - self.rng.uniform(0.0, 0.5)
            else:
                distance_nm = radius_nm * math.sqrt(self.rng.random())       # evenly over the circle's area
            x_nm = own_x_nm + distance_nm * math.sin(math.radians(bearing_deg))
            y_nm = own_y_nm + distance_nm * math.cos(math.radians(bearing_deg))
            if self.land.land_within(x_nm, y_nm, 1.0):
                continue
            inward_deg = (bearing_deg + 180.0 + self.rng.uniform(-50.0, 50.0)) % 360.0
            heading_deg = inward_deg if at_edge else self.rng.uniform(0.0, 360.0)
            if kind == "fishing":
                return self.start_fishing(x_nm, y_nm, heading_deg, at_edge)
            if kind == "pleasure":
                return self.start_pleasure(x_nm, y_nm, heading_deg)
            # A ship or tug with no lane to follow: straight across.
            block = self.traffic[kind]
            contact = self.new_contact(kind, x_nm, y_nm, heading_deg, block["speed_mean_kn"])
            contact.behaviour = "straight"
            return contact
        return None

    def start_fishing(self, x_nm, y_nm, heading_deg, at_edge):
        block = self.traffic["fishing"]
        transit_kn = self.uniform(block["transit_speed_kn_range"])
        contact = self.new_contact("fishing", x_nm, y_nm, heading_deg, transit_kn)
        contact.behaviour = "fishing"
        contact.cruise_speed_kn = transit_kn
        contact.state = "transit_in"
        # The fishing grounds: 5 to 15 nm on, in clear water.
        contact.goal_x_nm, contact.goal_y_nm = x_nm, y_nm
        for attempt in range(10):
            distance_nm = self.rng.uniform(5.0, 15.0)
            bearing_deg = heading_deg + self.rng.uniform(-30.0, 30.0)
            goal_x_nm = x_nm + distance_nm * math.sin(math.radians(bearing_deg))
            goal_y_nm = y_nm + distance_nm * math.cos(math.radians(bearing_deg))
            if not self.land.land_within(goal_x_nm, goal_y_nm, 1.0):
                contact.goal_x_nm, contact.goal_y_nm = goal_x_nm, goal_y_nm
                break
        if not at_edge and self.rng.random() < 0.7:
            # At the start of a run most fishing boats are already at work.
            self.start_working(contact)
            contact.work_until_s = self.now_s + self.rng.random() * (contact.work_until_s - self.now_s)
            contact.speed_kn = contact.work_speed_kn
        return contact

    def start_working(self, contact):
        block = self.traffic["fishing"]
        contact.state = "working"
        contact.work_until_s = self.now_s + self.uniform(block["work_duration_min_range"]) * S_PER_MIN
        contact.leg_heading_deg = self.rng.uniform(0.0, 360.0)
        contact.leg_run_nm = 0.0
        if self.rng.random() < 0.7:
            contact.work_mode = "trawl"
            contact.work_speed_kn = self.uniform(block["trawl_speed_kn_range"])
            contact.leg_length_nm = self.uniform(block["leg_length_nm_range"])
        else:
            contact.work_mode = "drift"
            contact.work_speed_kn = block["drift_speed_kn"]

    def start_pleasure(self, x_nm, y_nm, heading_deg):
        block = self.traffic["pleasure"]
        is_sail = self.rng.random() >= block["power_fraction"]
        speed_range = block["sail_speed_kn_range"] if is_sail else block["power_speed_kn_range"]
        cruise_kn = self.uniform(speed_range)
        contact = self.new_contact("pleasure", x_nm, y_nm, heading_deg, cruise_kn)
        contact.behaviour = "pleasure"
        contact.is_sail = is_sail
        contact.cruise_speed_kn = cruise_kn
        contact.speed_range_kn = (speed_range[0], speed_range[1])
        contact.tack = 1.0 if self.rng.random() < 0.5 else -1.0
        self.choose_waypoint(contact, heading_deg, 60.0)
        return contact

    def choose_waypoint(self, contact, toward_deg, spread_deg):
        # A point 2 to 8 nm away with clear water on the way, inside the active circle.
        block = self.traffic["pleasure"]
        own_x_nm, own_y_nm = self.own[0], self.own[1]
        radius_nm = self.traffic["active_radius_nm"] - 1.0
        for attempt in range(12):
            distance_nm = self.uniform(block["cruise_leg_nm_range"])
            bearing_deg = toward_deg + self.rng.uniform(-spread_deg, spread_deg)
            x_nm = contact.x_nm + distance_nm * math.sin(math.radians(bearing_deg))
            y_nm = contact.y_nm + distance_nm * math.cos(math.radians(bearing_deg))
            if math.hypot(x_nm - own_x_nm, y_nm - own_y_nm) > radius_nm:
                continue
            if self.land.first_land_along(contact.x_nm, contact.y_nm, bearing_deg, distance_nm + 0.5) is None:
                contact.goal_x_nm, contact.goal_y_nm = x_nm, y_nm
                return
            spread_deg = 180.0
        # Nothing clear: head back toward own ship's part of the sea.
        contact.goal_x_nm = contact.x_nm + (own_x_nm - contact.x_nm) * 0.2
        contact.goal_y_nm = contact.y_nm + (own_y_nm - contact.y_nm) * 0.2

    # ---------------------------------------------------------------- behaviour

    def happens(self, per_hour, dt_s):
        return self.rng.random() < per_hour * dt_s / S_PER_H

    def think(self, contact, dt_s):
        block = self.traffic[contact.kind]
        unpredictable = 1.0 - contact.predictability
        free = not contact.overruled(self.now_s)
        change_course = free and self.happens(block["course_change_per_hour_at_p0"] * unpredictable, dt_s)
        change_speed = free and self.happens(block["speed_change_per_hour_at_p0"] * unpredictable, dt_s)
        if contact.course_offset_deg != 0.0 and self.now_s >= contact.course_offset_until_s:
            contact.course_offset_deg = 0.0

        if contact.behaviour == "lane":
            return self.think_lane(contact, dt_s, block, change_course, change_speed)
        if contact.behaviour == "fishing":
            self.think_fishing(contact, dt_s, block, change_course, change_speed)
        elif contact.behaviour == "pleasure":
            self.think_pleasure(contact, block, change_course, change_speed)
        return None

    def think_lane(self, contact, dt_s, block, change_course, change_speed):
        leg = contact.plan[contact.leg]
        route = self.routes[leg["route"]]
        direction = leg["direction"]
        segment, along_nm, right_nm, forward_deg = route.project(contact.x_nm, contact.y_nm, contact.segment_hint)
        contact.segment_hint = segment
        lane_heading_deg = forward_deg if direction > 0 else (forward_deg + 180.0) % 360.0
        quarter_width_nm = route.width_nm / 4.0
        wanted_right_nm = contact.lane_slot * route.width_nm / 2.0
        contact.lane_heading_deg = lane_heading_deg
        contact.lane_half_nm = route.width_nm / 2.0
        contact.lane_right_nm = right_nm * direction
        error_nm = contact.lane_right_nm - wanted_right_nm

        # The end of this leg.
        speed_limit_kn = HARBOUR_SPEED_KN if route.has_terminal else None
        if leg["exit_along_nm"] is not None:
            remaining_nm = (leg["exit_along_nm"] - along_nm) * direction
            if leg["then"] == "arrive":
                if remaining_nm <= 0.05:
                    return "remove"                          # in harbour
            else:
                # Start the turn early by the turning radius, so it comes round onto the next lane.
                turn_radius_nm = (contact.speed_kn / S_PER_H) / math.radians(contact.max_turn_deg_per_s)
                next_route = self.routes[contact.plan[contact.leg + 1]["route"]]
                if next_route.has_terminal:
                    # Slow down in time for the harbour lane: (v2 - limit2) / (2 x deceleration).
                    decel_kn_per_h = contact.accel_kn_per_s * S_PER_H
                    slow_nm = max(contact.speed_kn ** 2 - HARBOUR_SPEED_KN ** 2, 0.0) / (2.0 * decel_kn_per_h) + 0.3
                    if remaining_nm <= slow_nm:
                        speed_limit_kn = HARBOUR_SPEED_KN
                if remaining_nm <= clip(turn_radius_nm, 0.1, 3.0):
                    contact.leg += 1
                    contact.segment_hint = None
                    contact.settled = False
                    contact.course_offset_deg = 0.0
                    return None
        elif (direction > 0 and along_nm >= route.total_nm) or (direction < 0 and along_nm <= 0.0):
            contact.behaviour = "straight"                   # the lane has ended: it continues straight
            return None

        # Unplanned changes. A course change ends early if it takes the vessel out of its place.
        if contact.course_offset_deg != 0.0 and abs(error_nm) > 0.2 * quarter_width_nm:
            if error_nm * contact.course_offset_deg > 0.0:
                contact.course_offset_deg = 0.0
        if change_course and contact.settled and contact.course_offset_deg == 0.0:
            most_deg = LANE_OFFSET_MAX_DEG * min(route.width_nm / 2.0, 1.0)
            contact.course_offset_deg = clip(self.rng.normal(0.0, block["course_change_stddev_deg"]), -most_deg, most_deg)
            contact.course_offset_until_s = self.now_s + self.rng.uniform(120.0, 360.0)
            contact.unplanned_course_changes += 1
        if change_speed:
            contact.cruise_speed_kn = clip(contact.cruise_speed_kn + self.rng.normal(0.0, block["speed_change_stddev_kn"]),
                                           contact.speed_range_kn[0], contact.speed_range_kn[1])
            contact.unplanned_speed_changes += 1

        # A slow wander around the lane heading.
        blend = dt_s / LANE_WANDER_TIME_S
        contact.wander_deg += (-contact.wander_deg * blend
                               + contact.wander_stddev_deg * math.sqrt(2.0 * blend) * self.rng.normal())
        correction_deg = clip(-LANE_CORRECTION_DEG * error_nm / quarter_width_nm,
                              -LANE_CORRECTION_MAX_DEG, LANE_CORRECTION_MAX_DEG)
        contact.desired_heading_deg = (lane_heading_deg + correction_deg + contact.wander_deg
                                       + contact.course_offset_deg) % 360.0
        contact.desired_speed_kn = contact.cruise_speed_kn
        if speed_limit_kn is not None:
            contact.desired_speed_kn = min(contact.desired_speed_kn, speed_limit_kn)

        off_heading_deg = abs(signed_difference_deg(contact.heading_deg_true, lane_heading_deg))
        if contact.overruled(self.now_s):
            contact.settled = False
        elif not contact.settled and abs(error_nm) < 0.3 * quarter_width_nm and off_heading_deg < 10.0:
            contact.settled = True
        return None

    def think_fishing(self, contact, dt_s, block, change_course, change_speed):
        own_x_nm, own_y_nm = self.own[0], self.own[1]
        if contact.state == "transit_in":
            dx = contact.goal_x_nm - contact.x_nm
            dy = contact.goal_y_nm - contact.y_nm
            if math.hypot(dx, dy) < 0.3 or contact.avoid_count >= 3:
                self.start_working(contact)
            else:
                contact.desired_heading_deg = (bearing_deg_true(dx, dy) + contact.course_offset_deg) % 360.0
                contact.desired_speed_kn = contact.cruise_speed_kn
        if contact.state == "working":
            if self.now_s >= contact.work_until_s:
                # Done: head out of the area, roughly away from own ship.
                contact.state = "transit_out"
                away_deg = bearing_deg_true(contact.x_nm - own_x_nm, contact.y_nm - own_y_nm)
                contact.leg_heading_deg = (away_deg + self.rng.uniform(-50.0, 50.0)) % 360.0
            elif contact.work_mode == "trawl":
                contact.leg_run_nm += contact.speed_kn * dt_s / S_PER_H
                if contact.leg_run_nm >= contact.leg_length_nm:
                    contact.leg_heading_deg = (contact.leg_heading_deg + 180.0) % 360.0     # turn at the end of the leg
                    contact.leg_run_nm = 0.0
                    contact.leg_length_nm = self.uniform(block["leg_length_nm_range"])
            else:
                contact.leg_heading_deg = (contact.leg_heading_deg + self.rng.normal(0.0, 2.0)) % 360.0
            if contact.state == "working":
                contact.desired_heading_deg = contact.leg_heading_deg
                contact.desired_speed_kn = contact.work_speed_kn
        if contact.state == "transit_out":
            contact.desired_heading_deg = (contact.leg_heading_deg + contact.course_offset_deg) % 360.0
            contact.desired_speed_kn = contact.cruise_speed_kn

        if change_course:
            change_deg = self.rng.normal(0.0, block["course_change_stddev_deg"])
            if contact.state == "working":
                contact.leg_heading_deg = (contact.leg_heading_deg + change_deg) % 360.0
            else:
                contact.course_offset_deg = clip(change_deg, -90.0, 90.0)
                contact.course_offset_until_s = self.now_s + self.rng.uniform(60.0, 180.0)
            contact.unplanned_course_changes += 1
        if change_speed:
            change_kn = self.rng.normal(0.0, block["speed_change_stddev_kn"])
            if contact.state == "working" and contact.work_mode == "trawl":
                low, high = block["trawl_speed_kn_range"]
                contact.work_speed_kn = clip(contact.work_speed_kn + change_kn, low, high)
            elif contact.state != "working":
                low, high = block["transit_speed_kn_range"]
                contact.cruise_speed_kn = clip(contact.cruise_speed_kn + change_kn, low, high)
            contact.unplanned_speed_changes += 1

    def think_pleasure(self, contact, block, change_course, change_speed):
        own_x_nm, own_y_nm = self.own[0], self.own[1]
        dx = contact.goal_x_nm - contact.x_nm
        dy = contact.goal_y_nm - contact.y_nm
        goal_from_own_nm = math.hypot(contact.goal_x_nm - own_x_nm, contact.goal_y_nm - own_y_nm)
        if math.hypot(dx, dy) < 0.2 or goal_from_own_nm > self.traffic["active_radius_nm"]:
            self.choose_waypoint(contact, self.rng.uniform(0.0, 360.0), 180.0)
            dx = contact.goal_x_nm - contact.x_nm
            dy = contact.goal_y_nm - contact.y_nm
        if change_course:
            if self.rng.random() < 0.5:
                self.choose_waypoint(contact, self.rng.uniform(0.0, 360.0), 180.0)
                dx = contact.goal_x_nm - contact.x_nm
                dy = contact.goal_y_nm - contact.y_nm
            else:
                contact.course_offset_deg = clip(self.rng.normal(0.0, block["course_change_stddev_deg"]), -120.0, 120.0)
                contact.course_offset_until_s = self.now_s + self.rng.uniform(60.0, 240.0)
            contact.unplanned_course_changes += 1
        if change_speed:
            if not contact.is_sail and self.rng.random() < 0.25:
                contact.idle_until_s = self.now_s + self.rng.uniform(120.0, 360.0)      # stops for a while
                contact.idle_speed_kn = self.rng.uniform(0.0, 2.0)
            else:
                contact.cruise_speed_kn = clip(contact.cruise_speed_kn + self.rng.normal(0.0, block["speed_change_stddev_kn"]),
                                               contact.speed_range_kn[0], contact.speed_range_kn[1])
            contact.unplanned_speed_changes += 1

        heading_deg = (bearing_deg_true(dx, dy) + contact.course_offset_deg) % 360.0
        if contact.is_sail:
            # A sailboat cannot point closer to the wind than the no-go angle: it tacks.
            wind_from_deg, wind_speed_kn = self.environment.wind()
            if abs(signed_difference_deg(heading_deg, wind_from_deg)) < block["sail_no_go_deg"]:
                if self.now_s >= contact.tack_until_s:
                    contact.tack = -contact.tack
                    contact.tack_until_s = self.now_s + self.rng.uniform(180.0, 480.0)
                heading_deg = (wind_from_deg + contact.tack * block["sail_no_go_deg"]) % 360.0
        contact.desired_heading_deg = heading_deg
        contact.desired_speed_kn = contact.idle_speed_kn if self.now_s < contact.idle_until_s else contact.cruise_speed_kn

    # ---------------------------------------------------------------- land avoidance

    def check_land(self, contact):
        # Looks ahead along the heading. With land ahead the contact turns toward the
        # side where clear water needs the smaller turn, and slows if the land is close.
        speed_nm_per_s = max(contact.speed_kn, 1.0) / S_PER_H
        turn_radius_nm = speed_nm_per_s / math.radians(contact.max_turn_deg_per_s)
        # land_lookahead_min of travel, but never less than the room it needs to turn away.
        look_nm = max(contact.speed_kn * self.traffic["land_lookahead_min"] / 60.0, 1.5 * turn_radius_nm + 0.2, 0.3)
        contact.next_land_check_s = self.now_s + clip(0.25 * look_nm / speed_nm_per_s, 3.0, 20.0)
        land = self.land
        hit_nm = land.first_land_along(contact.x_nm, contact.y_nm, contact.heading_deg_true, look_nm)
        if hit_nm is None:
            if self.now_s >= contact.avoid_until_s:
                contact.avoid_side = 0.0
            return
        sides = [contact.avoid_side] if contact.avoid_side != 0.0 else [1.0, -1.0]
        best = None
        for side in sides:
            for turn_deg in (20.0, 40.0, 60.0, 80.0, 100.0, 120.0, 150.0, 180.0):
                way_deg = contact.heading_deg_true + side * turn_deg
                if land.first_land_along(contact.x_nm, contact.y_nm, way_deg, look_nm) is None:
                    if best is None or turn_deg < best[0]:
                        best = (turn_deg, side)
                    break
        if best is None:
            best = (180.0, sides[0])
        turn_deg, side = best
        contact.avoid_side = side
        contact.avoid_heading_deg = (contact.heading_deg_true + side * min(turn_deg + 10.0, 180.0)) % 360.0
        contact.avoid_until_s = self.now_s + turn_deg / contact.max_turn_deg_per_s + 120.0
        contact.avoid_speed_kn = max(0.3 * contact.cruise_speed_kn, 2.0) if hit_nm < 0.5 * look_nm else None
        contact.avoid_count += 1
        contact.course_offset_deg = 0.0
        if contact.behaviour == "pleasure":
            self.choose_waypoint(contact, contact.avoid_heading_deg, 20.0)

    # ---------------------------------------------------------------- COLREGS-lite

    def check_colregs(self):
        # Every contact that obeys looks at every vessel within 12 nm, own ship included.
        horizon_min = self.traffic["colregs_horizon_min"]
        vessels = [("own", self.own[0], self.own[1], self.own[2], self.own[3], None)]
        for contact in self.contacts:
            vx_kn, vy_kn = contact.velocity_kn()
            vessels.append((contact.id, contact.x_nm, contact.y_nm, vx_kn, vy_kn, contact))

        for me_id, x_nm, y_nm, vx_kn, vy_kn, me in vessels:
            if me is not None and me.behaviour != "fixed":
                self.rogue_type(me)
            if me is None or not me.complies or me.behaviour == "fixed":
                continue
            rogue = me.rogue_now
            # Release first. Give-way ends when the planned course would pass clear or
            # the range is opening; stand-on ends when the risk has gone.
            # The planned course of a lane vessel is along its lane.
            in_lane = me.behaviour == "lane"
            # Inside the lane of a traffic scheme the CPA that matters is much smaller than in open water.
            inside_lane = in_lane and me.lane_half_nm is not None and abs(me.lane_right_nm) <= me.lane_half_nm + IN_LANE_EDGE_MARGIN_NM
            planned_rad = math.radians(me.lane_heading_deg if in_lane else me.desired_heading_deg)
            my_route = me.plan[me.leg]["route"] if in_lane else None
            planned_vx_kn = me.desired_speed_kn * math.sin(planned_rad)
            planned_vy_kn = me.desired_speed_kn * math.cos(planned_rad)
            threat = None
            still_giving_way = False
            still_standing_on = False
            for other_id, ox_nm, oy_nm, ovx_kn, ovy_kn, other in vessels:
                if other_id == me_id:
                    continue
                rel_x_nm = ox_nm - x_nm
                rel_y_nm = oy_nm - y_nm
                if abs(rel_x_nm) > COLREGS_RANGE_NM or abs(rel_y_nm) > COLREGS_RANGE_NM:
                    continue
                if math.hypot(rel_x_nm, rel_y_nm) > COLREGS_RANGE_NM:
                    continue
                cpa_nm, tcpa_min = cpa_tcpa((rel_x_nm, rel_y_nm), (ovx_kn - vx_kn, ovy_kn - vy_kn))
                # Vessels following the same lane pass closer than they would in open water.
                limit_nm = me.cpa_limit_nm
                if inside_lane:
                    limit_nm = min(limit_nm, self.traffic["colregs_cpa_limit_in_lane_nm"])
                same_lane = (in_lane and other is not None and other.behaviour == "lane"
                             and other.plan[other.leg]["route"] == my_route)
                if same_lane:
                    limit_nm = min(limit_nm, LANE_PASSING_FRACTION * self.routes[my_route].width_nm)
                risk = 0.0 < tcpa_min < horizon_min and cpa_nm < limit_nm
                if other_id == me.give_way_to:
                    planned_cpa_nm, planned_tcpa_min = cpa_tcpa((rel_x_nm, rel_y_nm),
                                                                (ovx_kn - planned_vx_kn, ovy_kn - planned_vy_kn))
                    if planned_tcpa_min > 0.0 and planned_cpa_nm < GIVE_WAY_CLEAR_FACTOR * limit_nm:
                        still_giving_way = True
                    if (me.give_way_in_lane and risk and tcpa_min < ESCALATE_TCPA_MIN and cpa_nm < ESCALATE_CPA_FRACTION * limit_nm):
                        # Staying in the lane is not enough: leave it, with the full alteration (not ideal, but better than a close quarters situation).
                        me.give_way_in_lane = False
                        me.give_way_heading_deg = (me.heading_deg_true + me.give_way_side * self.traffic["colregs_alteration_deg"]) % 360.0
                if other_id == me.stand_on_for and risk:
                    still_standing_on = True
                if risk and (threat is None or tcpa_min < threat[0]):
                    threat = (tcpa_min, other_id, rel_x_nm, rel_y_nm, ovx_kn, ovy_kn, other, same_lane)
            if me.give_way_to is not None and not still_giving_way:
                me.give_way_to = None
                me.give_way_in_lane = False
                if in_lane:
                    # Back in the lane it keeps the place it moved to, if that is a proper place.
                    route = self.routes[my_route]
                    low, high = LANE_SLOT_RANGE if route.two_way else (-0.5, 0.5)
                    me.lane_slot = clip(me.lane_right_nm / (route.width_nm / 2.0), low, high)
            if me.stand_on_for is not None and not still_standing_on:
                me.stand_on_for = None
            if threat is None or me.give_way_to is not None:
                continue

            tcpa_min, other_id, rel_x_nm, rel_y_nm, ovx_kn, ovy_kn, other, same_lane = threat
            role = self.encounter_role(me, vx_kn, vy_kn, rel_x_nm, rel_y_nm, ovx_kn, ovy_kn, other)
            if role == "give_way" and rogue == "no_give_way":
                continue                                    # a mistake: it does not give way
            if role == "give_way" and rogue == "late" and tcpa_min > ROGUE_LATE_TCPA_MIN:
                continue                                    # a mistake: it waits too long (it will act when the TCPA is small)
            if role == "give_way":
                # A clear turn to starboard, held until the way is clear. One exception:
                # overtaking a vessel that sits on the outer side of the same lane, it
                # passes to port, where the room is (Rule 13 names no side).
                side = 1.0
                if same_lane and other.plan[other.leg]["direction"] == me.plan[me.leg]["direction"]:
                    middle = (LANE_SLOT_RANGE[0] + LANE_SLOT_RANGE[1]) / 2.0 if self.routes[my_route].two_way else 0.0
                    if other.lane_slot > middle:
                        side = -1.0
                my_course_deg = me.heading_deg_true
                me.give_way_to = other_id
                me.give_way_side = side
                me.give_way_in_lane = inside_lane
                alteration_deg = IN_LANE_ALTERATION_DEG if inside_lane else self.traffic["colregs_alteration_deg"]
                me.give_way_heading_deg = (my_course_deg + side * alteration_deg) % 360.0
                me.stand_on_for = None
                me.course_offset_deg = 0.0
            elif me.stand_on_for is None:
                me.stand_on_for = other_id
                me.hold_heading_deg = me.heading_deg_true
                me.hold_speed_kn = me.speed_kn
        self.rogue_cross_bow()

    def rogue_type(self, me):
        # The mistake this contact makes now (settings: traffic.rogue_percent and the rogue_* switches). A ship that is giving way,
        # standing on or avoiding keeps what it has until it is clear, so nothing changes in the middle of an encounter.
        if me.give_way_to is not None or me.stand_on_for is not None or self.now_s < me.avoid_until_s:
            return me.rogue_now
        enabled = [name for name in ROGUE_TYPES if self.traffic["rogue_" + name]]
        if not enabled or me.rogue_u * 100.0 >= self.traffic["rogue_percent"]:
            me.rogue_now = None
        else:
            me.rogue_now = enabled[min(int(me.rogue_v * len(enabled)), len(enabled) - 1)]
        return me.rogue_now

    def rogue_cross_bow(self):
        # A "cross_bow" ship that is closing own ship inside ROGUE_BOW_RANGE_NM turns toward where own ship will be, whatever the rules say.
        own_x_nm, own_y_nm, own_vx_kn, own_vy_kn = self.own
        for contact in self.contacts:
            if contact.behaviour == "fixed" or contact.rogue_now != "cross_bow":
                continue
            rel_x_nm = own_x_nm - contact.x_nm
            rel_y_nm = own_y_nm - contact.y_nm
            distance_nm = math.hypot(rel_x_nm, rel_y_nm)
            if distance_nm > 2.5 * ROGUE_BOW_RANGE_NM:
                contact.rogue_done = False                  # ready again for the next approach
                continue
            if contact.rogue_done or distance_nm > ROGUE_BOW_RANGE_NM or distance_nm < 0.3:
                continue
            vx_kn, vy_kn = contact.velocity_kn()
            if rel_x_nm * (vx_kn - own_vx_kn) + rel_y_nm * (vy_kn - own_vy_kn) <= 0.0:
                continue                                    # not closing
            aim_x_nm = own_x_nm + own_vx_kn * 3.0 / 60.0    # where own ship will be in 3 min (kn x min / 60 = nm)
            aim_y_nm = own_y_nm + own_vy_kn * 3.0 / 60.0
            contact.avoid_heading_deg = bearing_deg_true(aim_x_nm - contact.x_nm, aim_y_nm - contact.y_nm)
            contact.avoid_until_s = self.now_s + ROGUE_BOW_TURN_S
            contact.avoid_speed_kn = None
            contact.course_offset_deg = 0.0
            contact.rogue_done = True

    def encounter_role(self, me, vx_kn, vy_kn, rel_x_nm, rel_y_nm, ovx_kn, ovy_kn, other):
        # Rules 13 to 15 as in BRIEF.md Section 8.4. Returns "give_way" or "stand_on".
        my_speed_kn = math.hypot(vx_kn, vy_kn)
        other_speed_kn = math.hypot(ovx_kn, ovy_kn)
        my_course_deg = bearing_deg_true(vx_kn, vy_kn) if my_speed_kn > 0.1 else me.heading_deg_true
        if other_speed_kn > 0.1:
            other_course_deg = bearing_deg_true(ovx_kn, ovy_kn)
        elif other is not None:
            other_course_deg = other.heading_deg_true
        else:
            other_course_deg = my_course_deg + 180.0         # own ship stopped: its heading is not known here
        other_from_me_rel_deg = (bearing_deg_true(rel_x_nm, rel_y_nm) - my_course_deg) % 360.0
        me_from_other_rel_deg = (bearing_deg_true(-rel_x_nm, -rel_y_nm) - other_course_deg) % 360.0

        # Rule 13, overtaking: coming up from more than 22.5 deg abaft the other's beam, and faster.
        if 112.5 < me_from_other_rel_deg < 247.5 and my_speed_kn > other_speed_kn:
            return "give_way"
        if 112.5 < other_from_me_rel_deg < 247.5 and other_speed_kn > my_speed_kn:
            return "stand_on"
        # Rule 14, head-on: reciprocal courses within 10 deg, each within 10 deg of dead ahead of the other.
        reciprocal = abs(signed_difference_deg(my_course_deg, other_course_deg + 180.0)) <= 10.0
        ahead_of_me = abs(signed_difference_deg(other_from_me_rel_deg, 0.0)) <= 10.0
        ahead_of_other = abs(signed_difference_deg(me_from_other_rel_deg, 0.0)) <= 10.0
        if reciprocal and ahead_of_me and ahead_of_other:
            return "give_way"
        # Rule 15, crossing: the vessel with the other on her starboard side gives way.
        if other_from_me_rel_deg <= 112.5:
            return "give_way"
        return "stand_on"

    # ---------------------------------------------------------------- contacts added by hand

    def add_contact(self, kind, x_nm, y_nm, heading_deg_true, speed_kn, behaviour="straight"):
        # For tests and the calibration scenario. kind may be any of KINDS (its config
        # block gives the turn and speed limits) or "buoy".
        if kind in KINDS:
            contact = self.new_contact(kind, x_nm, y_nm, heading_deg_true, speed_kn)
        else:
            contact = Contact(self.next_id, kind, x_nm, y_nm, heading_deg_true, speed_kn)
            self.next_id += 1
        contact.behaviour = behaviour
        contact.predictability = 1.0
        self.contacts.append(contact)
        return contact

    def truth_for_display(self):
        # The contact list of the "truth" message (instructor overlay).
        contacts = []
        for contact in self.everything():
            entry = {"id": contact.id, "name": contact.name, "kind": contact.kind,
                             "x_nm": round(contact.x_nm, 4), "y_nm": round(contact.y_nm, 4),
                             "course_deg_true": round(contact.heading_deg_true, 1),
                             "speed_kn": round(contact.speed_kn, 2), "length_m": round(contact.length_m, 1),
                             "sail": bool(contact.is_sail)}
            if contact.rogue_now:
                entry["rogue"] = contact.rogue_now          # for the instructor: the mistake this ship is making
            if contact.mark is not None:
                # The wheelhouse view draws a lane buoy in its colour and shape, with its light.
                entry["mark"] = contact.mark.display_entry()
            if contact.tow_length_nm is not None:
                # The wheelhouse view draws the barge behind a tug.
                entry["tow"] = {"x_nm": round(contact.tow_x_nm, 4), "y_nm": round(contact.tow_y_nm, 4),
                                "length_m": round(contact.tow_length_nm * M_PER_NM, 1)}
            contacts.append(entry)
        return contacts


# ---------------------------------------------------------------- calibration scenario

# BRIEF.md Section 12: name, kind, bearing deg true and range nm from own ship's start,
# course deg true, speed kn, length m, RCS m2.
CALIBRATION_CONTACTS = [
    ("B1", "buoy", 0.0, 2.0, 0.0, 0.0, 2.0, 10.0),
    ("B2", "buoy", 90.0, 4.0, 0.0, 0.0, 2.0, 10.0),
    ("B3", "buoy", 180.0, 6.0, 0.0, 0.0, 2.0, 10.0),
    ("B4", "buoy", 270.0, 3.0, 0.0, 0.0, 2.0, 10.0),
    ("S1", "ship", 45.0, 12.0, 225.0, 12.0, 150.0, 8000.0),
    ("S2", "ship", 300.0, 8.0, 90.0, 14.0, 150.0, 8000.0),
    ("S3", "pleasure", 20.0, 2.5, 200.0, 5.0, 8.0, 3.0),
    ("S4", "ship", 180.0, 3.0, 0.0, 16.0, 120.0, 5000.0),
    ("T1", "tug_tow", 130.0, 4.0, 310.0, 4.0, 30.0, 50.0),
]
CALIBRATION_TOW_LENGTH_M = 180.0
CALIBRATION_TOW_RCS_M2 = 800.0
CALIBRATION_OWN_START = (0.0, 0.0, 0.0, 10.0)    # x_nm, y_nm, heading deg true, speed kn


def apply_calibration_environment(cfg):
    # The calibration scenario has no wind, sea or rain. The current stays as configured.
    environment = cfg["environment"]
    environment["wind_speed_kn"] = 0.0
    environment["sea_state_from_wind"] = False
    environment["sea_state_douglas"] = 0
    environment["rain_rate_mm_per_h"] = 0.0


def add_calibration_contacts(traffic):
    # Fixed behaviour: exact course and speed for ever. No wander, COLREGS or land avoidance.
    traffic.spawning = False
    for name, kind, bearing_deg, range_nm, course_deg, speed_kn, length_m, rcs_m2 in CALIBRATION_CONTACTS:
        x_nm = range_nm * math.sin(math.radians(bearing_deg))
        y_nm = range_nm * math.cos(math.radians(bearing_deg))
        contact = Contact(traffic.next_id, kind, x_nm, y_nm, course_deg, speed_kn)
        traffic.next_id += 1
        contact.name = name
        contact.behaviour = "fixed"
        contact.length_m = length_m
        if kind == "ship":
            contact.scatterers = [(place * length_m, share * rcs_m2) for place, share in SHIP_RCS_SPLIT]
        else:
            contact.scatterers = [(0.0, rcs_m2)]
        if kind == "tug_tow":
            contact.tow_length_nm = CALIBRATION_TOW_LENGTH_M / M_PER_NM          # m -> nm
            contact.tow_rcs_m2 = CALIBRATION_TOW_RCS_M2
            contact.tow_x_nm = x_nm - contact.tow_length_nm * math.sin(math.radians(course_deg))
            contact.tow_y_nm = y_nm - contact.tow_length_nm * math.cos(math.radians(course_deg))
        traffic.contacts.append(contact)
