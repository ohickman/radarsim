# test_m1.py - acceptance tests of Module M1, own ship (BRIEF.md Section 15).
# Run: python sim/test_m1.py     Prints [OK] or [FAIL] lines with numbers; exits 0 or 1.
# Tests 1-9 are headless and use the own-ship values of radarsim.toml. Test 10 (the
# display) is manual. One extra test sends orders to a running sim over TCP.
# Units: as named in each test.

import copy
import math
import os
import subprocess
import sys
import time

import numpy as np

import messages
import sim_commands
import sim_common
import sim_config
import sim_ownship
import sim_protocol

ROOT = sim_common.find_project_root()
CONFIG_PATH = os.path.join(ROOT, sim_common.CONFIG_FILE_NAME)
SIM_MAIN = os.path.join(ROOT, "sim", "sim_main.py")
CFG = sim_config.load_config(CONFIG_PATH)
DT_S = CFG["general"]["physics_step_s"]

failures = 0
# Test 3 (no jumps) watches every step of every other test.
worst_heading_step_ratio = 0.0
worst_speed_step_ratio = 0.0


def report(passed, name, detail):
    global failures
    if passed:
        messages.ok(name + ": " + detail)
    else:
        failures += 1
        messages.fail(name + ": " + detail)


def make_ship(heading_deg_true, speed_kn, cfg=CFG):
    rng = np.random.default_rng(1)
    return sim_ownship.OwnShip(cfg, rng, 0.0, 0.0, heading_deg_true, speed_kn)


def order(ship, text, cfg=CFG):
    parsed = sim_commands.parse_order(text, cfg)
    if isinstance(parsed, str):
        raise RuntimeError("order refused: " + parsed)
    ship.apply_order(parsed)


def run(ship, duration_s, set_deg_true=0.0, drift_kn=0.0, each_step=None):
    # Steps the ship and checks the size of every heading and speed step (test 3).
    global worst_heading_step_ratio, worst_speed_step_ratio
    own = CFG["own_ship"]
    most_heading_step_deg = max(own["turn_table_max_rot_deg_per_min"]) / 60.0 * DT_S       # deg/min -> deg per step
    most_speed_step_kn = max(own["accel_kn_per_min"], own["decel_coast_kn_per_min"],
                             own["decel_astern_kn_per_min"]) / 60.0 * DT_S                 # kn/min -> kn per step
    time_s = 0.0
    for step in range(int(round(duration_s / DT_S))):
        heading_before = ship.heading_deg_true
        speed_before = ship.speed_water_kn
        ship.step(DT_S, set_deg_true, drift_kn)
        time_s += DT_S
        heading_step_deg = abs(sim_common.angle_difference_deg(ship.heading_deg_true, heading_before))
        speed_step_kn = abs(ship.speed_water_kn - speed_before)
        worst_heading_step_ratio = max(worst_heading_step_ratio, heading_step_deg / most_heading_step_deg)
        worst_speed_step_ratio = max(worst_speed_step_ratio, speed_step_kn / most_speed_step_kn)
        if each_step is not None:
            each_step(time_s)


def test_1_rudder_rate():
    ship = make_ship(0.0, 10.0)
    order(ship, "hard port")
    reached_s = [None]

    def watch(time_s):
        if reached_s[0] is None and ship.rudder_deg <= -CFG["own_ship"]["max_rudder_deg"]:
            reached_s[0] = time_s
    run(ship, 30.0, each_step=watch)
    ok = reached_s[0] is not None and abs(reached_s[0] - 15.2) <= 1.0 and ship.rudder_deg == -35.0
    report(ok, "1 rudder rate", "hard port reached %.1f deg in %s s (15.2 +/- 1)" % (ship.rudder_deg, reached_s[0]))


def test_2_steady_turn():
    ship = make_ship(0.0, 10.0)
    order(ship, "hard starboard")
    run(ship, 300.0)
    rot_deg_per_min = ship.rot_deg_per_s * 60.0
    ok = abs(rot_deg_per_min / 48.0 - 1.0) <= 0.05
    report(ok, "2 steady turn", "10 kn, hard starboard for 5 min: %.2f deg/min (48 +/- 5 %%)" % rot_deg_per_min)


def heading_order_case(speed_kn, limit_min):
    ship = make_ship(90.0, speed_kn)
    order(ship, "heading 248")
    own = CFG["own_ship"]
    table_max_deg_per_min = ship.max_rot_deg_per_s(speed_kn) * 60.0
    seen = {"settled_s": 0.0, "overshoot_deg": 0.0, "rudder_deg": 0.0, "rot_deg_per_min": 0.0}

    def watch(time_s):
        error_deg = sim_common.angle_difference_deg(248.0, ship.heading_deg_true)   # + = still short of 248
        if abs(error_deg) > 0.5:
            seen["settled_s"] = time_s
        seen["overshoot_deg"] = max(seen["overshoot_deg"], -error_deg)
        seen["rudder_deg"] = max(seen["rudder_deg"], abs(ship.rudder_deg))
        seen["rot_deg_per_min"] = max(seen["rot_deg_per_min"], abs(ship.rot_deg_per_s) * 60.0)
    run(ship, 40.0 * 60.0, each_step=watch)
    ok = (seen["settled_s"] <= limit_min * 60.0 and seen["overshoot_deg"] <= 3.0
          and seen["rudder_deg"] <= own["autopilot_max_rudder_deg"] + 1e-9
          and seen["rot_deg_per_min"] <= table_max_deg_per_min * 1.05)
    report(ok, "4 heading order at %g kn" % speed_kn,
           "090 -> 248: within 0.5 deg after %.1f min (limit %.1f), overshoot %.2f deg (limit 3), "
           "max rudder %.1f deg (limit %g), max rate %.1f deg/min (table max %.1f)" % (
               seen["settled_s"] / 60.0, limit_min, seen["overshoot_deg"], seen["rudder_deg"],
               own["autopilot_max_rudder_deg"], seen["rot_deg_per_min"], table_max_deg_per_min))


def test_4_heading_orders():
    heading_order_case(10.0, 10.0)
    heading_order_case(18.0, 10.0)
    # At 4 kn the brief's 10-minute limit cannot be met with the config as written:
    # the autopilot may use 20 of 35 deg of rudder and full rudder gives 18 deg/min at
    # 4 kn, so the best possible rate is 10.3 deg/min and 158 deg takes 15.4 min at
    # least. The limit used here is that best time x 1.3. Logged in BRIEF.md Section 16.
    own = CFG["own_ship"]
    ship = make_ship(90.0, 4.0)
    best_rate_deg_per_min = (ship.max_rot_deg_per_s(4.0) * 60.0
                             * own["autopilot_max_rudder_deg"] / own["max_rudder_deg"])
    heading_order_case(4.0, 158.0 / best_rate_deg_per_min * 1.3)


def test_5_speed():
    ship = make_ship(0.0, 10.0)
    order(ship, "speed 14")
    reached_s = [None]

    def watch_14(time_s):
        if reached_s[0] is None and ship.speed_water_kn >= 14.0:
            reached_s[0] = time_s
    run(ship, 600.0, each_step=watch_14)
    minutes = reached_s[0] / 60.0 if reached_s[0] else None
    ok = minutes is not None and abs(minutes / 4.0 - 1.0) <= 0.15
    report(ok, "5a speed 14 from 10 kn", "reached 14.0 kn in %s min (4.0 +/- 15 %%)" % minutes)

    order(ship, "stop")
    run(ship, 300.0)
    rate = (14.0 - ship.speed_water_kn) / 5.0
    ok = abs(rate / 0.7 - 1.0) <= 0.10
    report(ok, "5b stop from 14 kn", "after 5 min: %.2f kn, falling %.3f kn/min (0.7 +/- 10 %%)"
           % (ship.speed_water_kn, rate))

    ship = make_ship(0.0, 10.0)
    order(ship, "full astern")
    reached_s[0] = None
    at_zero_s = [None]

    def watch_astern(time_s):
        if at_zero_s[0] is None and ship.speed_water_kn <= 0.0:
            at_zero_s[0] = time_s
        if reached_s[0] is None and ship.speed_water_kn <= -8.0:
            reached_s[0] = time_s
    run(ship, 600.0, each_step=watch_astern)
    rate_to_zero = 10.0 / (at_zero_s[0] / 60.0)
    rate_overall = 18.0 / (reached_s[0] / 60.0)
    ok = (abs(rate_to_zero / 3.0 - 1.0) <= 0.10 and abs(rate_overall / 3.0 - 1.0) <= 0.10
          and ship.speed_water_kn == -8.0)
    report(ok, "5c full astern from 10 kn", "%.3f kn/min down to zero, %.3f kn/min over the whole 18 kn "
           "(3.0 +/- 10 %%); ends at %.1f kn" % (rate_to_zero, rate_overall, ship.speed_water_kn))


def test_6_current():
    ship = make_ship(0.0, 0.0)
    order(ship, "speed 0")
    run(ship, 3600.0, set_deg_true=90.0, drift_kn=2.0)
    ok = (abs(ship.x_nm - 2.0) <= 0.01 and abs(ship.y_nm) <= 0.01
          and abs(ship.cog_deg_true() - 90.0) <= 0.1 and abs(ship.sog_kn() - 2.0) <= 0.01)
    report(ok, "6a drifting, set 090 drift 2 kn, 1 hour", "position (%.4f, %.4f) nm (2.0 +/- 0.01 east), "
           "COG %.2f deg T, SOG %.3f kn" % (ship.x_nm, ship.y_nm, ship.cog_deg_true(), ship.sog_kn()))

    ship = make_ship(0.0, 10.0)
    run(ship, 60.0, set_deg_true=90.0, drift_kn=2.0)
    ok = abs(ship.cog_deg_true() - 11.3) <= 0.1 and abs(ship.sog_kn() - 10.20) <= 0.01
    report(ok, "6b heading 000 at 10 kn in the same current", "COG %.2f deg T (011.3 +/- 0.1), SOG %.3f kn "
           "(10.20 +/- 0.01)" % (ship.cog_deg_true(), ship.sog_kn()))


def test_7_reference_position():
    ship = make_ship(0.0, 10.0)
    run(ship, 3600.0, set_deg_true=90.0, drift_kn=2.0)
    sea_x, sea_y = ship.reference_position("sea")
    ground_x, ground_y = ship.reference_position("ground")
    ok = (abs(sea_x) <= 0.01 and abs(sea_y - 10.0) <= 0.01
          and abs(ship.x_nm - 2.0) <= 0.01 and abs(ship.y_nm - 10.0) <= 0.01
          and (ground_x, ground_y) == (ship.x_nm, ship.y_nm))
    report(ok, "7 reference position", "sea (%.4f, %.4f) nm, expected (0, 10.0); true and ground "
           "(%.4f, %.4f) nm, expected (2.0, 10.0)" % (sea_x, sea_y, ship.x_nm, ship.y_nm))


def test_8_steady():
    # 30 deg/min at 10 kn needs 35 x 30 / 48 = 21.875 deg of rudder.
    ship = make_ship(0.0, 10.0)
    order(ship, "starboard 21.875")
    run(ship, 300.0)
    rot_at_order = ship.rot_deg_per_s * 60.0
    heading_at_order = ship.heading_deg_true
    expected = sim_common.normalise_360(heading_at_order + 12.5)
    order(ship, "steady")
    seen = {"past_deg": -999.0}

    def watch(time_s):
        seen["past_deg"] = max(seen["past_deg"], sim_common.angle_difference_deg(ship.heading_deg_true, expected))
    run(ship, 300.0, each_step=watch)
    final_error = sim_common.angle_difference_deg(ship.heading_deg_true, expected)
    ok = (abs(rot_at_order - 30.0) < 0.5 and abs(final_error) <= 2.0 and seen["past_deg"] <= 2.0
          and abs(ship.rot_deg_per_s * 60.0) < 0.5)
    report(ok, "8 steady", "ordered while turning at %.1f deg/min on %.1f; expected stop at %.1f; "
           "furthest %.2f deg past it, ends %.2f deg from it, rate %.2f deg/min (limit 2 deg)" % (
               rot_at_order, heading_at_order, expected, seen["past_deg"], final_error,
               ship.rot_deg_per_s * 60.0))


def test_9_parser():
    def with_mode(mode):
        cfg = copy.deepcopy(CFG)
        cfg["own_ship"]["speed_command_mode"] = mode
        return cfg
    both = CFG
    knots = with_mode("knots")
    telegraph = with_mode("telegraph")
    # (cfg, text, expected kind, expected value, expected echo) - or a refusal text.
    accepted = [
        (both, "Port 10", "rudder", -10.0, "Port 10"),
        (both, "starboard 5", "rudder", 5.0, "Starboard 5"),
        (both, "stbd 5", "rudder", 5.0, "Starboard 5"),
        (both, "  PORT   10  ", "rudder", -10.0, "Port 10"),
        (both, "port 10 degrees", "rudder", -10.0, "Port 10"),
        (both, "starboard 5 degrees rudder, aye", "rudder", 5.0, "Starboard 5"),
        (both, "port 7.5", "rudder", -7.5, "Port 7.5"),
        (both, "port 0", "rudder", 0.0, "Port 0"),
        (both, "midships", "rudder", 0.0, "Midships"),
        (both, "Midships aye", "rudder", 0.0, "Midships"),
        (both, "hard port", "rudder", -35.0, "Hard port"),
        (both, "hard starboard", "rudder", 35.0, "Hard starboard"),
        (both, "hard stbd", "rudder", 35.0, "Hard starboard"),
        (both, "port 40", "rudder", -35.0, "Rudder limited to 35"),
        (both, "starboard 90", "rudder", 35.0, "Rudder limited to 35"),
        (both, "steady", "steady", None, "Steady"),
        (both, "heading 248", "heading", 248.0, "Heading 248"),
        (both, "steer 000", "heading", 0.0, "Heading 000"),
        (both, "Heading 248 degrees", "heading", 248.0, "Heading 248"),
        (both, "heading 360", "heading", 0.0, "Heading 000"),
        (both, "steer 90.5", "heading", 90.5, "Heading 090.5"),
        (both, "speed 12", "speed", 12.0, "Speed 12 kn"),
        (both, "speed 12 knots", "speed", 12.0, "Speed 12 kn"),
        (both, "speed -4", "speed", -4.0, "Speed -4 kn"),
        (both, "speed 25", "speed", 18.0, "Speed limited to 18"),
        (both, "half ahead", "speed", 11.0, "Half ahead, 11 kn"),
        (both, "Dead  Slow  Ahead", "speed", 4.0, "Dead slow ahead, 4 kn"),
        (both, "full astern", "speed", -8.0, "Full astern, 8 kn"),
        (both, "stop", "speed", 0.0, "Stop"),
        (both, "stop engines", "speed", 0.0, "Stop"),
        (knots, "speed 12", "speed", 12.0, "Speed 12 kn"),
        (telegraph, "slow ahead", "speed", 7.0, "Slow ahead, 7 kn"),
    ]
    refused = [
        (both, "port ten", "Not understood: port ten"),
        (both, "heading 361", "Not understood: heading 361"),
        (both, "sideways", "Not understood: sideways"),
        (both, "", "Not understood: "),
        (both, "port", "Not understood: port"),
        (both, "port -5", "Not understood: port -5"),
        (both, "heading nan", "Not understood: heading nan"),
        (both, "half", "Not understood: half"),
        (both, "port 10 20", "Not understood: port 10 20"),
        (knots, "half ahead", "Telegraph orders not enabled"),
        (knots, "stop", "Telegraph orders not enabled"),
        (telegraph, "speed 12", "Speed orders in knots not enabled"),
    ]
    wrong = []
    for cfg, text, kind, value, echo in accepted:
        got = sim_commands.parse_order(text, cfg)
        if isinstance(got, str) or got["kind"] != kind or got["echo"] != echo:
            wrong.append("%r -> %r" % (text, got))
            continue
        got_value = got.get("rudder_deg", got.get("heading_deg", got.get("speed_kn")))
        if got_value != value:
            wrong.append("%r -> %r" % (text, got))
    for cfg, text, expected in refused:
        got = sim_commands.parse_order(text, cfg)
        if got != expected:
            wrong.append("%r -> %r, expected %r" % (text, got, expected))
    # "port 40" must also put the rudder at 35.
    ship = make_ship(0.0, 10.0)
    order(ship, "port 40")
    run(ship, 20.0)
    if ship.rudder_deg != -35.0:
        wrong.append("port 40 left the rudder at %r" % ship.rudder_deg)
    report(not wrong, "9 parser", "%d accepted and %d refused strings; wrong: %s"
           % (len(accepted), len(refused), wrong if wrong else "none"))


def test_3_no_jumps():
    ok = worst_heading_step_ratio <= 1.05 and worst_speed_step_ratio <= 1.05
    report(ok, "3 no jumps", "over every step of tests 1-9: largest heading step %.3f x and largest speed "
           "step %.3f x the configured maximum (limit 1.05)" % (worst_heading_step_ratio, worst_speed_step_ratio))


def test_instrument_errors():
    cfg = copy.deepcopy(CFG)
    cfg["own_ship"]["gyro_error_deg"] = 2.0
    cfg["own_ship"]["speed_log_error_percent"] = 10.0
    ship = make_ship(90.0, 10.0, cfg)
    ok = abs(ship.gyro_heading_deg - 92.0) < 1e-9 and abs(ship.log_speed_kn - 11.0) < 1e-9
    # A heading order is steered on the gyro, so the true heading ends 2 deg low.
    ship.apply_order(sim_commands.parse_order("heading 100", cfg))
    for step in range(int(600.0 / DT_S)):
        ship.step(DT_S, 0.0, 0.0)
    ok = ok and abs(ship.gyro_heading_deg - 100.0) < 0.1 and abs(ship.heading_deg_true - 98.0) < 0.1
    report(ok, "gyro and log errors", "gyro error +2 deg, log error +10 %%: after 'heading 100' the gyro reads "
           "%.2f and the true heading is %.2f; log reads %.2f kn at 10 kn" % (
               ship.gyro_heading_deg, ship.heading_deg_true, ship.log_speed_kn))


def test_wiring_over_tcp():
    # A running sim takes "order" messages, echoes them in "log", and reports the
    # ship in state.own. Run at 10x to keep the test short.
    import socket
    probe = socket.socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()
    sim = subprocess.Popen([sys.executable, "-u", SIM_MAIN, "--config", CONFIG_PATH, "--port", str(port)],
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        deadline_s = time.perf_counter() + 10.0
        while True:
            try:
                sock = socket.create_connection(("127.0.0.1", port), timeout=60.0)   # hello waits for the land
                break
            except OSError:
                if time.perf_counter() > deadline_s:
                    raise
                time.sleep(0.1)

        def read_until(wanted):
            for count in range(5000):
                frame_type, payload = sim_protocol.read_frame(sock)
                if frame_type != sim_protocol.FRAME_JSON:
                    continue                 # radar video (from M4 on)
                message = sim_protocol.decode_json(payload)
                if message["t"] == wanted:
                    return message
            return None

        hello = read_until("hello")
        first = read_until("state")["own"]
        sim_protocol.send_json(sock, {"t": "set", "path": "general.sim_speed_multiplier", "value": 10})
        sim_protocol.send_json(sock, {"t": "order", "text": "port 10"})
        echo = read_until("log")
        sim_protocol.send_json(sock, {"t": "order", "text": "sideways"})
        refusal = read_until("log")
        time.sleep(1.5)                      # about 15 s of sim time
        sim_protocol.send_json(sock, {"t": "order", "text": "heading 248"})
        read_until("log")
        own = read_until("state")["own"]
        for count in range(5):
            own = read_until("state")["own"]
        wanted_keys = ["x_nm", "y_nm", "heading_deg_true", "gyro_heading_deg", "rudder_deg", "rot_deg_per_min",
                       "speed_water_kn", "log_speed_kn", "speed_ground_kn", "cog_deg_true", "sog_kn",
                       "ordered_heading_deg", "ordered_speed_kn", "mode"]
        missing = [key for key in wanted_keys if key not in own]
        turned_deg = sim_common.angle_difference_deg(own["heading_deg_true"], first["heading_deg_true"])
        ok = (hello["own_ship"]["speed_command_mode"] == "both" and echo["text"] == "Port 10"
              and refusal["text"] == "Not understood: sideways" and not missing
              and first["mode"] == "rudder" and first["ordered_heading_deg"] is None
              and turned_deg < -1.0 and own["mode"] == "heading" and own["ordered_heading_deg"] == 248.0
              and first["speed_water_kn"] == CFG["own_ship"]["start_speed_kn"])
        report(ok, "wiring over TCP", "log %r and %r; heading turned %.1f deg to port; then mode %s, ordered "
               "heading %s; missing state.own keys: %s" % (echo["text"], refusal["text"], turned_deg,
                                                           own["mode"], own["ordered_heading_deg"], missing or "none"))
        sim_protocol.send_json(sock, {"t": "quit"})
        sim.wait(timeout=5.0)
        sock.close()
    finally:
        if sim.poll() is None:
            sim.kill()


def main():
    test_1_rudder_rate()
    test_2_steady_turn()
    test_4_heading_orders()
    test_5_speed()
    test_6_current()
    test_7_reference_position()
    test_8_steady()
    test_9_parser()
    test_3_no_jumps()
    test_instrument_errors()
    test_wiring_over_tcp()
    messages.warn("NOT RUN: 10 display: manual, on Windows (BRIEF.md Section 15, M1 test 10)")
    if failures:
        messages.fail("%d test line(s) failed" % failures)
    else:
        messages.ok("All M1 headless tests passed")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
