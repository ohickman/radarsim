# test_m0.py - acceptance tests of Module M0 (BRIEF.md Section 15).
# Run: python sim/test_m0.py     Prints [OK] or [FAIL] lines with numbers; exits 0 or 1.
# Takes about 25 s: it runs the sim for 10 s at 5x and talks to a second sim over TCP,
# the way the display will.
# Units: as named in each test.

import contextlib
import copy
import io
import os
import socket
import subprocess
import sys
import time
import tomllib

import numpy as np

import messages
import sim_common
import sim_config
import sim_protocol

ROOT = sim_common.find_project_root()
CONFIG_PATH = os.path.join(ROOT, sim_common.CONFIG_FILE_NAME)
SIM_MAIN = os.path.join(ROOT, "sim", "sim_main.py")
TEMP_CONFIG_PATH = os.path.join(ROOT, "test_m0_tmp.toml")   # deleted at the end

failures = 0


def report(passed, name, detail):
    global failures
    if passed:
        messages.ok(name + ": " + detail)
    else:
        failures += 1
        messages.fail(name + ": " + detail)


def load_raw_config():
    with open(CONFIG_PATH, "rb") as config_file:
        return tomllib.load(config_file)


def check_quietly(raw):
    # Runs check_config and returns (cfg or None, console text, error text or None).
    console = io.StringIO()
    try:
        with contextlib.redirect_stdout(console), contextlib.redirect_stderr(console):
            cfg = sim_config.check_config(raw, "radarsim.toml")
        return cfg, console.getvalue(), None
    except sim_config.ConfigError as error:
        return None, console.getvalue(), str(error)


class DribbleSocket:
    # A fake socket that hands out at most 3 bytes per recv, to force short reads.
    def __init__(self, data):
        self.data = data
        self.position = 0

    def recv(self, byte_count):
        chunk = self.data[self.position:self.position + min(byte_count, 3)]
        self.position += len(chunk)
        return chunk


# ---------------------------------------------------------------- protocol

def test_json_round_trip():
    message = {"t": "set", "path": "radar_controls.gain_percent", "value": 62.5,
               "text": "deg ° ok", "list": [1, 2.5, None, True]}
    left, right = socket.socketpair()
    sim_protocol.send_json(left, message)
    frame_type, payload = sim_protocol.read_frame(right)
    left.close()
    right.close()
    same = frame_type == sim_protocol.FRAME_JSON and sim_protocol.decode_json(payload) == message
    report(same, "JSON frame round trip", "type %d, %d payload bytes" % (frame_type, len(payload)))


def make_spokes():
    rng = np.random.default_rng(1)
    return {
        "video_range_nm": 9.0,
        "azimuth_index": np.array([2046, 2047, 0], dtype=np.uint16),
        "gyro_heading_cdeg": np.array([35998, 35999, 0], dtype=np.uint16),
        "sim_time_s": np.array([12.5, 12.501220703125, 9000.00244140625], dtype=np.float64),
        "ref_x_nm": np.array([-1.25, -1.2501, -1.2502], dtype=np.float32),
        "ref_y_nm": np.array([3.5, 3.5003, 3.5006], dtype=np.float32),
        "video": rng.integers(0, 256, size=(3, 1024), dtype=np.uint8),
    }


def pack(spokes):
    return sim_protocol.pack_spokes(
        spokes["video_range_nm"], spokes["azimuth_index"], spokes["gyro_heading_cdeg"],
        spokes["sim_time_s"], spokes["ref_x_nm"], spokes["ref_y_nm"], spokes["video"])


def test_spokes_round_trip():
    spokes = make_spokes()
    payload = pack(spokes)
    left, right = socket.socketpair()
    sim_protocol.write_frame(left, sim_protocol.FRAME_SPOKES, payload)
    frame_type, received = sim_protocol.read_frame(right)
    left.close()
    right.close()
    back = sim_protocol.unpack_spokes(received)
    same = frame_type == sim_protocol.FRAME_SPOKES and back["video_range_nm"] == spokes["video_range_nm"]
    for name in ["azimuth_index", "gyro_heading_cdeg", "sim_time_s", "ref_x_nm", "ref_y_nm", "video"]:
        same = same and np.array_equal(back[name], spokes[name]) and back[name].dtype == spokes[name].dtype
    expected_bytes = 8 + 3 * (20 + 1024)     # header + 3 x (20-byte spoke header + 1024 bins)
    same = same and len(payload) == expected_bytes
    report(same, "SPOKES round trip", "3 spokes x 1024 bins, %d bytes (expected %d), every value preserved: %s"
           % (len(payload), expected_bytes, same))


def test_short_reads():
    message = {"t": "order", "text": "port 10"}
    body = sim_protocol.encode_json(message)
    frame = (len(body) + 1).to_bytes(4, "little") + bytes([sim_protocol.FRAME_JSON]) + body
    fake = DribbleSocket(frame + frame)
    first = sim_protocol.read_frame(fake)
    second = sim_protocol.read_frame(fake)
    same = sim_protocol.decode_json(first[1]) == message and sim_protocol.decode_json(second[1]) == message
    closed = False
    try:
        sim_protocol.read_frame(fake)        # nothing left: must raise, not hang or return rubbish
    except ConnectionError:
        closed = True
    report(same and closed, "short reads", "2 frames of %d bytes read 3 bytes at a time; end of data raises: %s"
           % (len(frame), closed))


def test_oversize_frame():
    too_long = sim_protocol.MAX_FRAME_BYTES + 1
    read_rejected = False
    try:
        sim_protocol.read_frame(DribbleSocket(too_long.to_bytes(4, "little") + b"\x01"))
    except sim_protocol.ProtocolError:
        read_rejected = True
    write_rejected = False
    left, right = socket.socketpair()
    try:
        sim_protocol.write_frame(left, sim_protocol.FRAME_SPOKES, bytes(sim_protocol.MAX_FRAME_BYTES))
    except sim_protocol.ProtocolError:
        write_rejected = True
    left.close()
    right.close()
    report(read_rejected and write_rejected, "oversize frame rejected",
           "length %d on read: %s; on write: %s" % (too_long, read_rejected, write_rejected))


# ---------------------------------------------------------------- config

def test_config_loads():
    cfg, console, error = check_quietly(load_raw_config())
    ok = error is None and "[WARN]" not in console
    key_count = len(sim_config.KEY_TABLE)
    ok = ok and cfg["general"]["port"] == 47615 and cfg["radar"]["azimuth_bins"] == 2048
    report(ok, "config loads", "%d keys checked, no warnings, error: %s" % (key_count, error))

    controls = sim_config.runtime_controls(cfg)
    by_path = {control["path"]: control for control in controls}
    gain = by_path.get("radar_controls.gain_percent", {})
    ok = (len(controls) == len(sim_config.RUNTIME_KEYS)
          and gain.get("min") == 0.0 and gain.get("max") == 100.0 and gain.get("unit") == "%"
          and gain.get("value") == 60.0
          and by_path["display.orientation"]["choices"] == ["north_up", "head_up", "course_up"]
          and by_path["display.range_scale_nm"]["choices"] == cfg["radar"]["range_scales_nm"])
    report(ok, "runtime keys for hello.controls", "%d controls; gain: %s" % (len(controls), gain))


def test_missing_key():
    raw = load_raw_config()
    del raw["radar"]["antenna_rpm"]
    cfg, console, error = check_quietly(raw)
    ok = error is not None and "radar.antenna_rpm" in error
    report(ok, "missing key names section.key", str(error))

    raw = load_raw_config()
    del raw["traffic"]["fishing"]["drift_speed_kn"]
    cfg, console, error = check_quietly(raw)
    ok = error is not None and "traffic.fishing.drift_speed_kn" in error
    report(ok, "missing nested key names its path", str(error))


def test_unknown_key():
    raw = load_raw_config()
    raw["radar"]["antena_rpm"] = 24.0
    cfg, console, error = check_quietly(raw)
    ok = error is None and "[WARN]" in console and "radar.antena_rpm" in console
    report(ok, "unknown key gives WARN", console.strip())


def test_out_of_range():
    raw = load_raw_config()
    raw["radar_controls"]["gain_percent"] = 130.0
    raw["general"]["sim_speed_multiplier"] = 0.2
    cfg, console, error = check_quietly(raw)
    ok = (error is None and cfg["radar_controls"]["gain_percent"] == 100.0
          and cfg["general"]["sim_speed_multiplier"] == 1.0 and console.count("[WARN]") == 2)
    report(ok, "out-of-range value clamps with WARN", "gain 130 -> %s, speed 0.2 -> %s; %s" % (
        cfg["radar_controls"]["gain_percent"] if cfg else None,
        cfg["general"]["sim_speed_multiplier"] if cfg else None,
        console.strip().replace("\n", " | ")))


def test_mix_and_types():
    raw = load_raw_config()
    raw["traffic"]["mix_ship"] = 0.7     # the four now sum to 1.35
    cfg, console, error = check_quietly(raw)
    mix_sum = sum(cfg["traffic"]["mix_" + kind] for kind in sim_config.TRAFFIC_KINDS) if cfg else 0.0
    ok = error is None and abs(mix_sum - 1.0) < 1e-12 and "[WARN]" in console
    report(ok, "traffic mix normalised with WARN", "sum after loading %.12f" % mix_sum)

    raw = load_raw_config()
    raw["display"]["orientation"] = "sideways"
    cfg, console, error = check_quietly(raw)
    ok = error is not None and "display.orientation" in error and "north_up" in error
    report(ok, "unknown word stops start-up", str(error))

    cfg, console, error = check_quietly(load_raw_config())
    value, note = sim_config.set_runtime_value(cfg, "general.sim_speed_multiplier", 50)
    bad_value, bad_note = sim_config.set_runtime_value(cfg, "general.sim_speed_multiplier", "fast")
    ok = value == 10.0 and note is not None and bad_value == 10.0 and bad_note is not None
    report(ok, "runtime set clamps, and keeps the old value for rubbish",
           "set 50 -> %s; set 'fast' -> %s" % (value, bad_value))


# ---------------------------------------------------------------- common helpers

def test_latlon():
    cfg, console, error = check_quietly(load_raw_config())
    lat0 = cfg["general"]["origin_lat_deg"]
    lon0 = cfg["general"]["origin_lon_deg"]
    worst_deg = 0.0
    for lat, lon in [(37.80, -122.45), (38.5, -123.2), (37.1, -121.9), (37.8001, -122.4499), (36.3, -124.0)]:
        x_nm, y_nm = sim_common.latlon_to_xy_nm(lat, lon, lat0, lon0)
        lat_back, lon_back = sim_common.xy_nm_to_latlon(x_nm, y_nm, lat0, lon0)
        worst_deg = max(worst_deg, abs(lat_back - lat), abs(lon_back - lon))
    # One degree of latitude north of the origin is 60 nm; one minute of longitude east
    # is cos(latitude) nm.
    x_nm, y_nm = sim_common.latlon_to_xy_nm(lat0 + 1.0, lon0 + 1.0 / 60.0, lat0, lon0)
    expected_x_nm = np.cos(np.radians(lat0))
    ok = worst_deg < 1e-6 and abs(y_nm - 60.0) < 1e-9 and abs(x_nm - expected_x_nm) < 1e-9
    report(ok, "lat/lon round trip", "worst error %.2e deg (limit 1e-6); 1 deg N = %.6f nm; 1' E = %.6f nm"
           % (worst_deg, y_nm, x_nm))


def test_angles():
    c = sim_common
    cases = [
        ("normalise_360(370)", c.normalise_360(370.0), 10.0),
        ("normalise_360(-10)", c.normalise_360(-10.0), 350.0),
        ("normalise_360(360)", c.normalise_360(360.0), 0.0),
        ("normalise_360(-1e-17)", c.normalise_360(-1e-17), 0.0),
        ("normalise_360(725.5)", c.normalise_360(725.5), 5.5),
        ("normalise_180(190)", c.normalise_180(190.0), -170.0),
        ("normalise_180(-190)", c.normalise_180(-190.0), 170.0),
        ("normalise_180(180)", c.normalise_180(180.0), -180.0),
        ("normalise_180(90)", c.normalise_180(90.0), 90.0),
        ("difference 010 from 350", c.angle_difference_deg(10.0, 350.0), 20.0),
        ("difference 350 from 010", c.angle_difference_deg(350.0, 10.0), -20.0),
        ("difference 248 from 090", c.angle_difference_deg(248.0, 90.0), 158.0),
        ("difference 000 from 181", c.angle_difference_deg(0.0, 181.0), 179.0),
        ("bearing of north", c.bearing_true_deg(0.0, 1.0), 0.0),
        ("bearing of east", c.bearing_true_deg(1.0, 0.0), 90.0),
        ("bearing of south", c.bearing_true_deg(0.0, -1.0), 180.0),
        ("bearing of west", c.bearing_true_deg(-1.0, 0.0), 270.0),
        ("bearing of north-west", c.bearing_true_deg(-2.0, 2.0), 315.0),
        ("true 000 -> maths", c.true_to_maths_deg(0.0), 90.0),
        ("true 090 -> maths", c.true_to_maths_deg(90.0), 0.0),
        ("true 180 -> maths", c.true_to_maths_deg(180.0), 270.0),
        ("true 225 -> maths", c.true_to_maths_deg(225.0), 225.0),
        ("maths 0 -> true", c.maths_to_true_deg(0.0), 90.0),
        ("maths 180 -> true", c.maths_to_true_deg(180.0), 270.0),
        ("maths 45 -> true", c.maths_to_true_deg(45.0), 45.0),
    ]
    wrong = []
    for name, got, expected in cases:
        if abs(got - expected) > 1e-9 or not (got < 360.0):
            wrong.append("%s = %r, expected %r" % (name, got, expected))
    array_result = c.bearing_true_deg(np.array([0.0, 1.0, -1.0]), np.array([1.0, 0.0, 0.0]))
    if not np.allclose(array_result, [0.0, 90.0, 270.0]):
        wrong.append("bearing_true_deg on arrays = %r" % array_result)
    unit_checks = [
        ("10 kn for 360 s", c.distance_nm_from(10.0, 360.0), 1.0),
        ("1 nm in m", c.nm_to_m(1.0), 1852.0),
        ("926 m in nm", c.m_to_nm(926.0), 0.5),
        ("pulse 1 us in nm", c.M_PER_US_PULSE / c.M_PER_NM, c.NM_PER_US_PULSE),
        ("radar mile in us", 2.0 * c.M_PER_NM / 299.792458, c.RADAR_MILE_US),   # c = 299.79 m per us
    ]
    for name, got, expected in unit_checks:
        if abs(got - expected) > 0.005 * abs(expected):
            wrong.append("%s = %r, expected %r" % (name, got, expected))
    report(not wrong, "angle and unit helpers", "%d angle cases, %d unit cases; wrong: %s"
           % (len(cases) + 1, len(unit_checks), wrong if wrong else "none"))


# ---------------------------------------------------------------- the sim as a process

def write_temp_config(changes):
    # Copies radarsim.toml with some "key = value" lines of [general] replaced.
    with open(CONFIG_PATH, "r", encoding="utf-8") as config_file:
        lines = config_file.read().split("\n")
    for key, value in changes.items():
        for index, line in enumerate(lines):
            if line.startswith(key + " ="):
                lines[index] = "%s = %s" % (key, value)
                break
    with open(TEMP_CONFIG_PATH, "w", encoding="utf-8") as config_file:
        config_file.write("\n".join(lines))


def free_port():
    probe = socket.socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()
    return port


def test_headless():
    write_temp_config({"sim_speed_multiplier": "5.0"})
    port = free_port()
    start_s = time.perf_counter()
    # cwd is a different folder on purpose: the sim must not depend on it.
    result = subprocess.run(
        [sys.executable, SIM_MAIN, "--config", TEMP_CONFIG_PATH, "--port", str(port), "--headless-test", "10"],
        capture_output=True, text=True, cwd=os.path.expanduser("~"), stdin=subprocess.DEVNULL)
    wall_s = time.perf_counter() - start_s
    sim_time_s = None
    for line in result.stdout.split("\n"):
        if "Headless test: sim time" in line:
            sim_time_s = float(line.split("sim time")[1].split("s")[0])
    ok = result.returncode == 0 and sim_time_s is not None and abs(sim_time_s - 50.0) <= 2.5
    report(ok, "headless 10 s at 5x", "sim time %s s (50 +/- 2.5), exit code %d, process took %.1f s"
           % (sim_time_s, result.returncode, wall_s))
    if not ok:
        print(result.stdout + result.stderr)


def connect_with_retry(port, timeout_s):
    deadline_s = time.perf_counter() + timeout_s
    while True:
        try:
            return socket.create_connection(("127.0.0.1", port), timeout=60.0)   # hello waits for the land
        except OSError:
            if time.perf_counter() > deadline_s:
                raise
            time.sleep(0.1)


def read_until(sock, wanted, timeout_s):
    # Reads JSON messages until one named `wanted` arrives. Returns it, or None.
    deadline_s = time.perf_counter() + timeout_s
    while time.perf_counter() < deadline_s:
        frame_type, payload = sim_protocol.read_frame(sock)
        if frame_type != sim_protocol.FRAME_JSON:
            continue                         # radar video (from M4 on)
        message = sim_protocol.decode_json(payload)
        if message["t"] == wanted:
            return message
    return None


def read_states(sock, duration_s):
    states = []
    end_s = time.perf_counter() + duration_s
    while time.perf_counter() < end_s:
        message = read_until(sock, "state", 2.0)
        if message is not None:
            states.append(message)
    return states


def test_sim_over_tcp():
    # Plays the display's part: start the sim as a child with stdin held open, connect,
    # and use every message M0 handles.
    port = free_port()
    sim = subprocess.Popen(
        [sys.executable, "-u", SIM_MAIN, "--config", CONFIG_PATH, "--port", str(port)],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        cwd=os.path.expanduser("~"))
    try:
        sock = connect_with_retry(port, 10.0)
        hello = read_until(sock, "hello", 60.0)
        ok = (hello is not None and hello["protocol"] == 1 and hello["seed"] > 0
              and hello["scenario"] == "random" and hello["radar"]["azimuth_bins"] == 2048
              and hello["display"]["range_scale_nm"] == 6.0 and len(hello["controls"]) > 20
              and hello["own_ship"]["length_m"] == 150.0
              and hello["own_ship"]["telegraph_half_ahead_kn"] == 11.0)
        report(ok, "hello after connect", "protocol %s, seed %s, %d controls" % (
            hello and hello["protocol"], hello and hello["seed"], len(hello["controls"]) if hello else 0))

        # 1x: state 10 times a second, clock in step with real time.
        wall_start_s = time.perf_counter()
        states = read_states(sock, 3.0)
        wall_s = time.perf_counter() - wall_start_s
        sim_s = states[-1]["sim_time_s"] - states[0]["sim_time_s"]
        rate_hz = len(states) / wall_s
        ok = 9.0 <= rate_hz <= 11.0 and abs(sim_s / wall_s - 1.0) < 0.08 and states[-1]["speed_requested"] == 1.0
        report(ok, "state rate and clock at 1x", "%.1f states/s (10 +/- 1); sim %.2f s in %.2f s wall; achieved %.2f x"
               % (rate_hz, sim_s, wall_s, states[-1]["speed_achieved"]))

        # Speed 50 is clamped to 10 and confirmed; then the sim runs at 10x.
        sim_protocol.send_json(sock, {"t": "set", "path": "general.sim_speed_multiplier", "value": 50})
        setting = read_until(sock, "setting", 2.0)
        states = read_states(sock, 3.0)
        achieved = states[-1]["speed_achieved"]
        ok = setting is not None and setting["value"] == 10.0 and abs(achieved - 10.0) <= 0.3
        report(ok, "set speed 50 -> setting 10, achieved 10.0 +/- 0.3",
               "setting %s; achieved %.2f x" % (setting and setting["value"], achieved))

        # Pause stops the clock; resume restarts it.
        sim_protocol.send_json(sock, {"t": "pause", "paused": True})
        read_states(sock, 0.5)
        paused_states = read_states(sock, 1.0)
        stopped = paused_states[-1]["sim_time_s"] == paused_states[0]["sim_time_s"] and paused_states[-1]["paused"]
        sim_protocol.send_json(sock, {"t": "pause", "paused": False})
        read_states(sock, 0.5)
        running_states = read_states(sock, 1.0)
        moved_s = running_states[-1]["sim_time_s"] - running_states[0]["sim_time_s"]
        ok = stopped and moved_s > 5.0 and not running_states[-1]["paused"]
        report(ok, "pause and resume", "clock stopped while paused: %s; then moved %.1f s in about 1 s at 10x"
               % (stopped, moved_s))

        # The display goes away and comes back: the sim keeps running and says hello again.
        time_before_s = running_states[-1]["sim_time_s"]
        sock.close()
        time.sleep(1.0)
        sock = connect_with_retry(port, 5.0)
        hello = read_until(sock, "hello", 5.0)
        state = read_until(sock, "state", 2.0)
        ok = hello is not None and state is not None and state["sim_time_s"] > time_before_s + 5.0
        report(ok, "survives disconnect and reconnect", "clock went from %.1f s to %.1f s while no display was connected"
               % (time_before_s, state["sim_time_s"] if state else -1.0))

        # Closing stdin (the display has gone) ends the sim.
        sock.close()
        sim.stdin.close()
        try:
            exit_code = sim.wait(timeout=5.0)
        except subprocess.TimeoutExpired:
            exit_code = None
        report(exit_code == 0, "sim exits when stdin closes", "exit code %s" % exit_code)
    finally:
        if sim.poll() is None:
            sim.kill()
        output = sim.stdout.read()
    seed_printed = "Seed " in output
    report(seed_printed, "seed printed", [line for line in output.split("\n") if "Seed" in line][:1].__repr__())

    # quit message, and a busy port.
    port = free_port()
    sim = subprocess.Popen(
        [sys.executable, "-u", SIM_MAIN, "--config", CONFIG_PATH, "--port", str(port)],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        sock = connect_with_retry(port, 10.0)
        read_until(sock, "hello", 5.0)
        second = subprocess.run([sys.executable, SIM_MAIN, "--config", CONFIG_PATH, "--port", str(port),
                                 "--headless-test", "1"], capture_output=True, text=True)
        ok = second.returncode == 1 and "[ABORT]" in second.stderr and "general.port" in second.stderr
        report(ok, "busy port gives a clear ABORT", second.stderr.strip().split("\n")[-1])
        sim_protocol.send_json(sock, {"t": "quit"})
        try:
            exit_code = sim.wait(timeout=5.0)
        except subprocess.TimeoutExpired:
            exit_code = None
        report(exit_code == 0, "quit message ends the sim", "exit code %s" % exit_code)
        sock.close()
    finally:
        if sim.poll() is None:
            sim.kill()


def main():
    try:
        test_json_round_trip()
        test_spokes_round_trip()
        test_short_reads()
        test_oversize_frame()
        test_config_loads()
        test_missing_key()
        test_unknown_key()
        test_out_of_range()
        test_mix_and_types()
        test_latlon()
        test_angles()
        test_headless()
        test_sim_over_tcp()
    finally:
        if os.path.exists(TEMP_CONFIG_PATH):
            os.remove(TEMP_CONFIG_PATH)
    if failures:
        messages.fail("%d test line(s) failed" % failures)
    else:
        messages.ok("All M0 tests passed")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
