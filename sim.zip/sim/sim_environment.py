# sim_environment.py - wind, sea state, current and rain cells (BRIEF.md Section 8.2).
# Wind, sea state, current and rain rate are read from the config every time, so a
# runtime "set" takes effect at once.
# Units: wind and current kn and deg true (wind = direction it blows FROM, current
# set = direction it flows TOWARD), rain mm/h, positions nm, time s.
# Called by: sim_main.py every physics step; the radar (M4) uses rain_rate_at.

import numpy as np

from sim_common import S_PER_H, velocity_xy_kn

# Douglas sea state from wind speed: (highest wind speed in kn, Douglas state).
# Chosen, not from a source (BRIEF.md Section 8.2). Above 40 kn the state is 8.
WIND_TO_DOUGLAS = [(3, 0), (6, 1), (10, 2), (16, 3), (21, 4), (27, 5), (33, 6), (40, 7)]


def douglas_from_wind(wind_speed_kn):
    whole_kn = round(wind_speed_kn)
    for highest_kn, douglas in WIND_TO_DOUGLAS:
        if whole_kn <= highest_kn:
            return douglas
    return 8


class Environment:
    def __init__(self, cfg, rng, own_x_nm, own_y_nm):
        self.env = cfg["environment"]
        self.rng = rng
        self.active_radius_nm = cfg["traffic"]["active_radius_nm"]
        # Rain cell centres, placed evenly at random over the active circle around
        # own ship. The cells always exist; a rain rate of 0 makes them empty.
        cell_count = self.env["rain_cell_count"]
        distance_nm = self.active_radius_nm * np.sqrt(rng.uniform(0.0, 1.0, cell_count))
        direction_deg = rng.uniform(0.0, 360.0, cell_count)
        offset_x_nm, offset_y_nm = velocity_xy_kn(distance_nm, direction_deg)   # same sin/cos split
        self.cell_x_nm = own_x_nm + offset_x_nm
        self.cell_y_nm = own_y_nm + offset_y_nm

    # ---- wind, sea, current ----

    def wind(self):
        return self.env["wind_from_deg_true"], self.env["wind_speed_kn"]

    def sea_state_douglas(self):
        if self.env["sea_state_from_wind"]:
            return douglas_from_wind(self.env["wind_speed_kn"])
        return self.env["sea_state_douglas"]

    def current(self):
        # Uniform and constant in Gen 1: (set deg true, drift kn).
        return self.env["current_set_deg_true"], self.env["current_drift_kn"]

    # ---- rain ----

    def match_cell_count(self, own_x_nm, own_y_nm):
        # The cell count can be changed while the sim runs: cells are added at random places in the active circle, or the last ones dropped.
        wanted = int(self.env["rain_cell_count"])
        have = len(self.cell_x_nm)
        if wanted < have:
            self.cell_x_nm = self.cell_x_nm[:wanted]
            self.cell_y_nm = self.cell_y_nm[:wanted]
        elif wanted > have:
            extra = wanted - have
            distance_nm = self.active_radius_nm * np.sqrt(self.rng.uniform(0.0, 1.0, extra))
            direction_deg = self.rng.uniform(0.0, 360.0, extra)
            offset_x_nm, offset_y_nm = velocity_xy_kn(distance_nm, direction_deg)
            self.cell_x_nm = np.concatenate([self.cell_x_nm, own_x_nm + offset_x_nm])
            self.cell_y_nm = np.concatenate([self.cell_y_nm, own_y_nm + offset_y_nm])

    def step(self, dt_s, own_x_nm, own_y_nm):
        self.match_cell_count(own_x_nm, own_y_nm)
        # Rain cells drift downwind, toward (wind direction + 180), at a fraction of
        # the wind speed.
        wind_from_deg_true, wind_speed_kn = self.wind()
        cell_speed_kn = wind_speed_kn * self.env["rain_cell_speed_fraction_of_wind"]
        vx_kn, vy_kn = velocity_xy_kn(cell_speed_kn, wind_from_deg_true + 180.0)
        self.cell_x_nm = self.cell_x_nm + vx_kn * dt_s / S_PER_H              # kn x s -> nm
        self.cell_y_nm = self.cell_y_nm + vy_kn * dt_s / S_PER_H

        # A cell that leaves the active circle comes back in on the opposite side.
        offset_x_nm = self.cell_x_nm - own_x_nm
        offset_y_nm = self.cell_y_nm - own_y_nm
        distance_nm = np.hypot(offset_x_nm, offset_y_nm)
        outside = distance_nm > self.active_radius_nm
        if np.any(outside):
            # 0.999: just inside the circle, so it is not thrown across again next step.
            scale = -0.999 * self.active_radius_nm / distance_nm[outside]
            self.cell_x_nm[outside] = own_x_nm + offset_x_nm[outside] * scale
            self.cell_y_nm[outside] = own_y_nm + offset_y_nm[outside] * scale

    def rain_rate_at(self, x_nm, y_nm):
        # Rain rate in mm/h at each point; x_nm and y_nm are arrays of the same shape.
        # Each cell is a smooth round blob: the peak rate at its centre, falling as a
        # raised cosine to zero at rain_cell_radius_nm. Overlapping cells do not add.
        x_nm = np.asarray(x_nm, dtype=float)
        y_nm = np.asarray(y_nm, dtype=float)
        rate_mm_per_h = np.zeros(x_nm.shape)
        peak_mm_per_h = self.env["rain_rate_mm_per_h"]
        if peak_mm_per_h <= 0.0:
            return rate_mm_per_h
        radius_nm = self.env["rain_cell_radius_nm"]
        for cell_x_nm, cell_y_nm in zip(self.cell_x_nm, self.cell_y_nm):
            distance_nm = np.hypot(x_nm - cell_x_nm, y_nm - cell_y_nm)
            blob = 0.5 * (1.0 + np.cos(np.pi * np.minimum(distance_nm / radius_nm, 1.0)))
            rate_mm_per_h = np.maximum(rate_mm_per_h, peak_mm_per_h * blob)
        return rate_mm_per_h

    # ---- for the display ----

    def state_for_display(self):
        # The "env" part of the state message (BRIEF.md Section 7).
        return {
            "wind_from_deg_true": self.env["wind_from_deg_true"],
            "wind_speed_kn": self.env["wind_speed_kn"],
            "sea_state_douglas": self.sea_state_douglas(),
            "current_set_deg_true": self.env["current_set_deg_true"],
            "current_drift_kn": self.env["current_drift_kn"],
            "rain_rate_mm_per_h": self.env["rain_rate_mm_per_h"],
        }

    def rain_for_display(self, own_x_nm, own_y_nm, within_nm=25.0):
        # The "rain" part of the view message: what the wheelhouse needs to draw the showers. Peak rate, cell radius and the
        # centres of the cells near own ship (positions nm), so what is seen is the same blob the radar shows.
        peak = float(self.env["rain_rate_mm_per_h"])
        if peak <= 0.0:
            return {"peak_mm_per_h": 0.0, "radius_nm": float(self.env["rain_cell_radius_nm"]), "cells": []}
        cells = []
        for x_nm, y_nm in zip(self.cell_x_nm, self.cell_y_nm):
            if np.hypot(x_nm - own_x_nm, y_nm - own_y_nm) <= within_nm + self.env["rain_cell_radius_nm"]:
                cells.append([round(float(x_nm), 3), round(float(y_nm), 3)])
        return {"peak_mm_per_h": peak, "radius_nm": float(self.env["rain_cell_radius_nm"]), "cells": cells}
