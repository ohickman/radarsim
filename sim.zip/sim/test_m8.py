# test_m8.py - acceptance tests of Module M8, the ARPA engine (BRIEF.md Section 15).
# Run: python sim/test_m8.py            (20 seeds, about 15 minutes)
#      python sim/test_m8.py --quick    (5 seeds)
# Prints [OK] or [FAIL] lines with the numbers; exits 0 or 1.
# Units: ranges nm, speeds kn, bearings and courses deg true, times s or min as named.
# To save time the radar video is made only for the sectors that hold a contact or a
# guard zone; the ARPA never looks anywhere else. Test 16 runs the whole sim over TCP.

import copy
import math
import os
import socket
import subprocess
import sys
import time

import numpy as np

import messages
import sim_arpa
import sim_commands
import sim_common
import sim_config
import sim_contacts
import sim_environment
import sim_land
import sim_ownship
import sim_protocol
import sim_radar

ROOT = sim_common.find_project_root()
CONFIG_PATH = os.path.join(ROOT, sim_common.CONFIG_FILE_NAME)
SIM_MAIN = os.path.join(ROOT, "sim", "sim_main.py")
TEMP_CONFIG_PATH = os.path.join(ROOT, "test_m8_tmp.toml")     # deleted at the end
messages.message_verbosity = 5                                # results and progress; the ARPA's own remarks stay quiet
CFG = sim_config.load_config(CONFIG_PATH)
QUICK = "--quick" in sys.argv
SEEDS = 5 if QUICK else 20
REVOLUTION_S = 60.0 / CFG["radar"]["antenna_rpm"]

# IMO Resolution MSC.192(79), Annex, section 5.25.4.7.1, Table 3, "Tracked Target
# Accuracy (95% probability figures)". Speed limits are "x kn or y %, whichever is
# greater". None = the table gives no figure.
#                 rel course  rel speed     CPA    TCPA   true course  true speed
#                 deg         (kn, %)       NM     min    deg          (kn, %)
MSC_TABLE_3 = {
    "1 min trend":  {"rel_course_deg": 11.0, "rel_speed": (1.5, 10.0), "cpa_nm": 1.0, "tcpa_min": None,
                     "course_deg": None, "speed": None},
    "3 min motion": {"rel_course_deg": 3.0, "rel_speed": (0.8, 1.0), "cpa_nm": 0.3, "tcpa_min": 0.5,
                     "course_deg": 5.0, "speed": (0.5, 1.0)},
}

failures = 0


def report(passed, name, detail):
    global failures
    if passed:
        messages.ok(f"{name}: {detail}")
    else:
        failures += 1
        messages.fail(f"{name}: {detail}")


# ---------------------------------------------------------------- the test world

def test_cfg(changes=None):
    # The calibration scenario's conditions: calm, no rain, gain 60, STC 0, FTC 0.
    cfg = copy.deepcopy(CFG)
    sim_contacts.apply_calibration_environment(cfg)
    cfg["radar_controls"].update({"gain_percent": 60.0, "stc_percent": 0.0, "ftc_percent": 0.0})
    cfg["arpa"]["stabilization"] = "sea"
    cfg["display"]["range_scale_nm"] = 6.0
    cfg["radar"]["video_range_nm"] = 10.0
    for path, value in (changes or {}).items():
        sim_config.put_value(cfg, path, value)
    return cfg


def at(bearing_deg, range_nm):
    return range_nm * math.sin(math.radians(bearing_deg)), range_nm * math.cos(math.radians(bearing_deg))


class World:
    # Own ship, contacts, radar and ARPA stepped together the way sim_main.py does it.
    def __init__(self, cfg, seed, calibration=True, own=sim_contacts.CALIBRATION_OWN_START):
        self.cfg = cfg
        streams = sim_common.make_random_streams(seed)
        self.land = sim_land.make_open_sea(cfg)
        self.own_ship = sim_ownship.OwnShip(cfg, streams["own_ship"], own[0], own[1], own[2], own[3])
        self.environment = sim_environment.Environment(cfg, streams["environment"], own[0], own[1])
        self.traffic = sim_contacts.Traffic(cfg, streams["traffic"], self.land, self.environment)
        self.traffic.spawning = False
        if calibration:
            sim_contacts.add_calibration_contacts(self.traffic)
        self.radar = sim_radar.RadarVideo(cfg, streams["radar"], self.land, self.environment)
        self.arpa = sim_arpa.Arpa(cfg, streams["arpa"])
        self.dt_s = cfg["general"]["physics_step_s"]
        self.step_count = 0
        self.time_s = 0.0
        self.extra_sectors = []                  # (centre deg relative, half width deg) always given video
        self.targets = {}                        # id -> entry of the latest "targets" message
        self.radar_cpu_s = 0.0
        self.arpa_cpu_s = 0.0
        self.snapshot = self.take_snapshot()

    def add_fixed(self, name, bearing_deg, range_nm, course_deg, speed_kn, rcs_m2=5000.0, length_m=10.0):
        # A contact that holds an exact course and speed, placed from own ship's present position.
        x_nm, y_nm = at(bearing_deg, range_nm)
        contact = self.traffic.add_contact("buoy", self.own_ship.x_nm + x_nm, self.own_ship.y_nm + y_nm,
                                           course_deg, speed_kn, "fixed")
        contact.name = name
        contact.length_m = length_m
        contact.scatterers = [(0.0, rcs_m2)]
        if length_m >= 50.0:
            # A ship echoes from three places along its hull, as in sim_contacts.py.
            contact.scatterers = [(place * length_m, share * rcs_m2) for place, share in sim_contacts.SHIP_RCS_SPLIT]
        self.snapshot = self.take_snapshot()
        return contact

    def keep(self, names):
        # Removes every contact not named: less video to make.
        self.traffic.contacts = [contact for contact in self.traffic.contacts if contact.name in names]
        self.snapshot = self.take_snapshot()

    def set_stabilization(self, stabilization):
        # As sim_main.py does it on "set arpa.stabilization".
        self.cfg["arpa"]["stabilization"] = stabilization
        self.snapshot = self.take_snapshot()
        self.arpa.set_stabilization(stabilization)

    def contact(self, name):
        for contact in self.traffic.contacts:
            if contact.name == name:
                return contact
        return None

    def take_snapshot(self):
        own = self.own_ship
        ref_x_nm, ref_y_nm = own.reference_position(self.cfg["arpa"]["stabilization"])
        ids, xs, ys, rcss, heights = sim_radar.scatterers_of(self.traffic.contacts)
        return sim_radar.Snapshot(self.time_s, own.x_nm, own.y_nm, own.heading_deg_true, own.gyro_heading_deg,
                                  ref_x_nm, ref_y_nm, ids, xs, ys, rcss, heights)

    def wanted(self, numbers):
        # True for the spokes that point near a contact or into an extra sector.
        spokes = self.cfg["radar"]["azimuth_bins"]
        bearing_rel_deg = (numbers % spokes + 0.5) * 360.0 / spokes
        keep = np.zeros(len(numbers), dtype=bool)
        own = self.own_ship
        now = self.snapshot
        sectors = list(self.extra_sectors)
        for x_nm, y_nm in zip(now.scatterer_x_nm, now.scatterer_y_nm):
            range_nm = math.hypot(x_nm - own.x_nm, y_nm - own.y_nm)
            centre_deg = math.degrees(math.atan2(x_nm - own.x_nm, y_nm - own.y_nm)) - own.heading_deg_true
            half_deg = 5.0 + math.degrees(math.asin(min(1.0, 0.3 / max(range_nm, 0.01))))
            sectors.append((centre_deg, half_deg))
        for centre_deg, half_deg in sectors:
            keep |= np.abs((bearing_rel_deg - centre_deg + 180.0) % 360.0 - 180.0) <= half_deg
        return keep

    def step(self):
        own = self.own_ship
        current_set_deg_true, current_drift_kn = self.environment.current()
        own.step(self.dt_s, current_set_deg_true, current_drift_kn)
        self.environment.step(self.dt_s, own.x_nm, own.y_nm)
        self.traffic.step(self.dt_s, self.time_s, own.x_nm, own.y_nm, own.ground_vx_kn, own.ground_vy_kn)
        self.step_count += 1
        self.time_s = self.step_count * self.dt_s
        before = self.snapshot
        self.snapshot = self.take_snapshot()
        started_s = time.process_time()
        numbers = self.radar.spoke_numbers_between(before.sim_time_s, self.snapshot.sim_time_s)
        numbers = numbers[self.wanted(numbers)]
        if len(numbers) > 0:
            levels_db, spokes = self.radar.compute_levels_db(numbers, before, self.snapshot)
            spokes["video"] = sim_radar.quantise(levels_db, self.cfg["radar"]["display_threshold_db"],
                                                 self.cfg["radar"]["video_window_db"])
            self.arpa.add_spokes(spokes, self.radar.pulse_bins())
        middle_s = time.process_time()
        self.arpa.step(sim_arpa.own_data_from(own, self.time_s))
        if self.arpa.targets_due:
            self.arpa.targets_due = False
            self.targets = {target["id"]: target for target in self.arpa.targets_message()["targets"]}
        self.radar_cpu_s += middle_s - started_s
        self.arpa_cpu_s += time.process_time() - middle_s

    def run(self, seconds):
        for step in range(int(round(seconds / self.dt_s))):
            self.step()

    def run_until(self, time_s):
        while self.time_s < time_s - 1e-9:
            self.step()

    def order(self, text):
        self.own_ship.apply_order(sim_commands.parse_order(text, self.cfg))

    def acquire(self, name):
        # Acquires a contact the way the display would: range and true bearing by the gyro.
        contact = self.contact(name)
        own_x_nm, own_y_nm = self.own_ship.x_nm, self.own_ship.y_nm
        range_nm = math.hypot(contact.x_nm - own_x_nm, contact.y_nm - own_y_nm)
        bearing_deg = math.degrees(math.atan2(contact.x_nm - own_x_nm, contact.y_nm - own_y_nm))
        bearing_deg += self.own_ship.gyro_heading_deg - self.own_ship.heading_deg_true
        return self.arpa.acquire(range_nm, bearing_deg % 360.0)

    def truth(self, name):
        # What the ARPA should report for a contact: exact relative motion, CPA and
        # TCPA, and course and speed in the stabilisation frame (through the water in
        # sea mode: the contact's ground velocity less the current).
        contact = self.contact(name)
        own = self.own_ship
        rel_x_nm, rel_y_nm = contact.x_nm - own.x_nm, contact.y_nm - own.y_nm
        vx_kn, vy_kn = contact.velocity_kn()
        rel_vx_kn, rel_vy_kn = vx_kn - own.ground_vx_kn, vy_kn - own.ground_vy_kn
        cpa_nm, tcpa_min = sim_common.cpa_tcpa((rel_x_nm, rel_y_nm), (rel_vx_kn, rel_vy_kn))
        if self.cfg["arpa"]["stabilization"] == "sea":
            set_deg, drift_kn = self.environment.current()
            current_vx_kn, current_vy_kn = sim_common.velocity_xy_kn(drift_kn, set_deg)
            vx_kn, vy_kn = vx_kn - float(current_vx_kn), vy_kn - float(current_vy_kn)
        return {"range_nm": math.hypot(rel_x_nm, rel_y_nm),
                "bearing_deg_true": float(sim_common.bearing_true_deg(rel_x_nm, rel_y_nm)),
                "rel_x_nm": rel_x_nm, "rel_y_nm": rel_y_nm, "rel_vx_kn": rel_vx_kn, "rel_vy_kn": rel_vy_kn,
                "vx_kn": vx_kn, "vy_kn": vy_kn,
                "rel_course_deg_true": float(sim_common.bearing_true_deg(rel_vx_kn, rel_vy_kn)),
                "rel_speed_kn": math.hypot(rel_vx_kn, rel_vy_kn), "cpa_nm": cpa_nm, "tcpa_min": tcpa_min,
                "course_deg_true": float(sim_common.bearing_true_deg(vx_kn, vy_kn)),
                "speed_kn": math.hypot(vx_kn, vy_kn)}


def angle_error(value_deg, truth_deg):
    return abs(sim_common.normalise_180(value_deg - truth_deg))


def three_ships(cfg, seed):
    # The three geometries of test 3: S2 of Section 12 crosses ahead from port, S4 of
    # Section 12 overtakes from dead astern, and H1 (150 m, 8000 m2) comes down
    # nearly head-on from 9 nm.
    world = World(cfg, seed)
    world.keep(["S2", "S4"])
    world.add_fixed("H1", 3.0, 9.0, 180.0, 12.0, 8000.0, 150.0)
    return world


GEOMETRIES = [("crossing", "S2"), ("overtaking", "S4"), ("head-on", "H1")]


# ---------------------------------------------------------------- 1 plots

def test_1_plots():
    world = World(test_cfg(), 1, own=(0.0, 0.0, 0.0, 0.0))
    world.keep(["B1", "B2"])
    arpa = world.arpa
    revolutions = 100
    range_errors = {"B1": [], "B2": []}
    bearing_errors = {"B1": [], "B2": []}
    for revolution in range(1, revolutions + 1):
        # 225 deg into the revolution the antenna has swept both buoys (dead ahead and abeam).
        world.run_until((revolution + 0.625) * REVOLUTION_S)
        for name in ("B1", "B2"):
            truth = world.truth(name)
            bearing_rel_deg = sim_common.normalise_360(truth["bearing_deg_true"] - world.own_ship.heading_deg_true)
            first_index, spoke_count, first_bin, last_bin = arpa.window_around(truth["range_nm"], bearing_rel_deg, 0.2)
            plots, flooded = arpa.find_plots(first_index, spoke_count, first_bin, last_bin, sim_arpa.PLOT_MIN_CELLS)
            best = None
            for plot in plots:
                arpa.place_plot(plot, False)
                range_error_nm = abs(plot["range_nm"] - truth["range_nm"])
                bearing_error_deg = angle_error(plot["bearing_deg_true"], truth["bearing_deg_true"])
                if range_error_nm <= 0.05 and bearing_error_deg <= 1.5:
                    if best is None or range_error_nm < best[0]:
                        best = (range_error_nm, bearing_error_deg)
            if best is not None:
                range_errors[name].append(best[0])
                bearing_errors[name].append(best[1])
    for name, range_nm in (("B1", 2.0), ("B2", 4.0)):
        found = len(range_errors[name]) / revolutions
        mean_range_nm = float(np.mean(range_errors[name])) if range_errors[name] else 9.9
        mean_bearing_deg = float(np.mean(bearing_errors[name])) if bearing_errors[name] else 9.9
        report(found >= 0.9 and mean_range_nm <= 0.02 and mean_bearing_deg <= 0.6, f"1 plots, buoy {name} at {range_nm:.0f} nm",
               f"a plot within 0.05 nm and 1.5 deg of the truth in {100 * found:.0f} % of {revolutions} revolutions "
               f"(90 % needed); mean error {mean_range_nm:.4f} nm in range (limit 0.02), {mean_bearing_deg:.3f} deg in "
               f"bearing (limit 0.6)")


# ---------------------------------------------------------------- 2 states

def test_2_states():
    cfg = test_cfg()
    world = World(cfg, 1)
    world.keep(["S4"])
    world.run(4.0)
    track_id = world.acquire("S4")
    acquired_s = world.time_s
    at_30 = None
    first = {}
    vector_at = {}
    while world.time_s < acquired_s + 190.0 and track_id is not None:
        world.step()
        target = world.targets.get(track_id)
        if target is None:
            continue
        age_s = world.time_s - acquired_s
        if at_30 is None and age_s >= 30.0:
            at_30 = (target["state"], target["course_deg_true"])
        if target["state"] not in first:
            first[target["state"]] = age_s
            vector_at[target["state"]] = target["course_deg_true"] is not None
    ok = (track_id is not None and at_30 == ("ACQ", None) and abs(first.get("TREND", 0.0) - 60.0) <= 3.0
          and abs(first.get("TRACK", 0.0) - 180.0) <= 3.0 and vector_at.get("TREND") and vector_at.get("TRACK"))
    report(ok, "2 states", f"S4 acquired as target {track_id}; at 30 s: state {at_30[0] if at_30 else None}, "
           f"course {at_30[1] if at_30 else None} (no vector); TREND first reported {first.get('TREND', -1):.1f} s after "
           f"acquisition (60 +/-3), TRACK {first.get('TRACK', -1):.1f} s (180 +/-3); both carry a vector")


# ---------------------------------------------------------------- 3 accuracy

ACCURACY_KEYS = ["rel_course_deg", "rel_speed", "cpa_nm", "tcpa_min", "course_deg", "speed"]
MESSAGE_KEYS = {"rel_course_deg": "rel_course_deg_true", "rel_speed": "rel_speed_kn", "cpa_nm": "cpa_nm",
                "tcpa_min": "tcpa_min", "course_deg": "course_deg_true", "speed": "speed_kn"}
UNITS = {"rel_course_deg": "deg", "rel_speed": "kn", "cpa_nm": "nm", "tcpa_min": "min", "course_deg": "deg", "speed": "kn"}


def table_limit(row, key, truth):
    # The limit of MSC.192(79) Table 3 for one figure; speeds are "kn or %, whichever is greater".
    limit = MSC_TABLE_3[row][key]
    if limit is None:
        return None
    if key == "rel_speed":
        return max(limit[0], limit[1] / 100.0 * truth["rel_speed_kn"])
    if key == "speed":
        return max(limit[0], limit[1] / 100.0 * truth["speed_kn"])
    return limit


def target_errors(target, truth):
    errors = {}
    for key in ACCURACY_KEYS:
        value = target[MESSAGE_KEYS[key]]
        if key.endswith("course_deg"):
            errors[key] = angle_error(value, truth[MESSAGE_KEYS[key]])
        else:
            errors[key] = abs(value - truth[MESSAGE_KEYS[key]])
    return errors


def test_3_accuracy():
    errors = {}
    limits = {}
    for seed in range(1, SEEDS + 1):
        world = three_ships(test_cfg(), seed)
        world.run(4.0)
        ids = {name: world.acquire(name) for geometry, name in GEOMETRIES}
        acquired_s = world.time_s
        for row, after_s in (("1 min trend", 60.0), ("3 min motion", 180.0)):
            # The first "targets" message at or after the time.
            world.run_until(acquired_s + after_s + REVOLUTION_S + 0.1)
            for geometry, name in GEOMETRIES:
                truth = world.truth(name)
                target = world.targets.get(ids[name])
                if target is None or target["course_deg_true"] is None:
                    errors.setdefault((geometry, row, "missing"), []).append(1.0)
                    continue
                for key, error in target_errors(target, truth).items():
                    errors.setdefault((geometry, row, key), []).append(error)
                    limits[(geometry, row, key)] = table_limit(row, key, truth)
    well_beaten = []
    for geometry, name in GEOMETRIES:
        for row in ("1 min trend", "3 min motion"):
            parts = []
            passed = (geometry, row, "missing") not in errors
            for key in ACCURACY_KEYS:
                limit = limits.get((geometry, row, key))
                if limit is None or (geometry, row, key) not in errors:
                    continue
                worst = float(np.percentile(errors[(geometry, row, key)], 95.0))
                ratio = limit / max(worst, 1e-6)
                passed = passed and worst <= limit
                parts.append(f"{key.replace('_deg', '').replace('_nm', '').replace('_min', '')} {worst:.3f} {UNITS[key]} "
                             f"(limit {limit:.2f}, {ratio:.1f} x inside)")
                if ratio > 3.0:
                    well_beaten.append(ratio)
            report(passed, f"3 accuracy, {geometry} ({name}), {row}",
                   f"95th percentile of the error over {SEEDS} seeds: " + "; ".join(parts))
    messages.status(f"3 accuracy: {len(well_beaten)} of the figures above are more than 3 x inside the table "
                    f"(up to {max(well_beaten, default=0.0):.0f} x). MSC.192(79) 5.25.4.7.1 Table 3; plot jitter "
                    f"{sim_arpa.PLOT_JITTER_RANGE_NM} nm and {sim_arpa.PLOT_JITTER_BEARING_DEG} deg is in use.")


# ---------------------------------------------------------------- 4 own-ship maneuver

def test_4_own_maneuver():
    world = three_ships(test_cfg(), 1)
    world.run(4.0)
    ids = {name: world.acquire(name) for geometry, name in GEOMETRIES}
    world.run_until(200.0)
    world.order("heading 030")
    lost = set()
    while world.time_s < 600.0:
        world.step()
        for name, track_id in ids.items():
            if track_id not in world.arpa.tracks or world.arpa.tracks[track_id].state == "LOST":
                lost.add(name)
        own = world.own_ship
        if abs(sim_common.normalise_180(own.heading_deg_true - 30.0)) < 0.5 and abs(own.rot_deg_per_s) < 0.02:
            break
    turn_end_s = world.time_s
    while world.time_s < turn_end_s + 180.0 + REVOLUTION_S:
        world.step()
        for name, track_id in ids.items():
            if track_id not in world.arpa.tracks or world.arpa.tracks[track_id].state == "LOST":
                lost.add(name)
    parts = []
    passed = not lost
    for geometry, name in GEOMETRIES:
        truth = world.truth(name)
        target = world.targets.get(ids[name])
        if target is None or target["course_deg_true"] is None:
            passed = False
            continue
        errors = target_errors(target, truth)
        course_limit = table_limit("3 min motion", "course_deg", truth)
        speed_limit = table_limit("3 min motion", "speed", truth)
        passed = passed and errors["course_deg"] <= course_limit and errors["speed"] <= speed_limit
        parts.append(f"{name} true course error {errors['course_deg']:.2f} deg (limit {course_limit:.0f}), "
                     f"true speed error {errors['speed']:.2f} kn (limit {speed_limit:.2f})")
    report(passed, "4 own-ship maneuver", f"own ship turned 000 -> 030 from 200 s, steady at {turn_end_s:.0f} s; "
           f"tracks lost: {sorted(lost) if lost else 'none'}; 180 s after the turn: " + "; ".join(parts))


# ---------------------------------------------------------------- 5 small boat

def test_5_small_boat():
    world = World(test_cfg(), 1)
    world.keep(["S3"])
    world.run(4.0)
    track_id = world.acquire("S3")
    lost_at_s = None
    most_misses = 0
    range_nm = 0.0
    while world.time_s < 4.0 + 1800.0 and track_id is not None:
        world.step()
        track = world.arpa.tracks[track_id]
        most_misses = max(most_misses, track.misses)
        if track.state == "LOST":
            lost_at_s = world.time_s
            break
        range_nm = world.truth("S3")["range_nm"]
    passed = track_id is not None and lost_at_s is None
    detail = (f"S3 (3 m2) acquired at 2.5 nm, own ship 10 kn north as in Section 12; closest 0.58 nm, {range_nm:.2f} nm "
              f"off at the end; most revolutions running without an echo: {most_misses} (lost at "
              f"{CFG['arpa']['lost_after_misses']})")
    if lost_at_s is not None:
        detail += f"; LOST after {(lost_at_s - 4.0) / 60.0:.1f} min at {world.truth('S3')['range_nm']:.2f} nm"
    else:
        detail += "; never LOST in 30 min"
    report(passed, "5 small boat", detail)


# ---------------------------------------------------------------- 6 lost target

def test_6_lost():
    world = World(test_cfg(), 1)
    world.keep(["B1", "B2", "B4"])
    world.run(4.0)
    id_b2 = world.acquire("B2")
    id_b4 = world.acquire("B4")
    world.run_until(40.0)
    truth = world.truth("B2")
    world.extra_sectors.append((truth["bearing_deg_true"] - world.own_ship.heading_deg_true, 12.0))
    world.keep(["B1", "B4"])                                     # B2 is gone from the world
    gone_s = world.time_s
    while world.time_s < gone_s + 60.0 and world.arpa.tracks[id_b2].state != "LOST":
        world.step()
    revolutions = (world.time_s - gone_s) / REVOLUTION_S
    arpa = world.arpa
    alarm = arpa.find_alarm("LOST_TARGET", id_b2, None)
    raised = alarm is not None and alarm["active"] and not alarm["acknowledged"]
    still_listed = id_b2 in arpa.tracks
    if alarm is not None:
        arpa.acknowledge(alarm["id"])
    removed = id_b2 not in arpa.tracks and arpa.find_alarm("LOST_TARGET", id_b2, None) is None
    id_b1 = world.acquire("B1")
    needed = CFG["arpa"]["lost_after_misses"]
    passed = (abs(revolutions - needed) <= 1.0 and raised and still_listed and removed and id_b1 == id_b2
              and arpa.tracks[id_b4].state != "LOST")
    report(passed, "6 lost target", f"B2 (target {id_b2}) removed from the world: LOST after {revolutions:.1f} revolutions "
           f"({needed} +/-1); LOST_TARGET alarm raised: {raised}; track kept until acknowledged: {still_listed}; "
           f"acknowledging removes track and alarm: {removed}; the next acquisition gets the lowest free id: {id_b1}")


# ---------------------------------------------------------------- 7 capacity

def many_contacts(seed, count):
    # Strong fixed contacts spread round own ship between 3 and 8 nm.
    world = World(test_cfg(), seed, calibration=False)
    for number in range(count):
        world.add_fixed(f"C{number + 1}", number * 360.0 / count, 3.0 + number % 6, 90.0, 5.0, 2000.0)
    return world


def test_7a_empty_box():
    # A box dropped on empty water: accepted, looks every revolution, gives up after lost_after_misses.
    world = World(test_cfg(), 1, own=(0.0, 0.0, 0.0, 0.0))
    world.keep([])
    world.extra_sectors = [(90.0, 20.0)]
    world.run(6.0)
    track_id = world.arpa.acquire(2.0, 90.0)
    created = track_id is not None and world.arpa.tracks[track_id].state == "ACQ"
    world.run(40.0)
    track = world.arpa.tracks.get(track_id)
    alarm = world.arpa.find_alarm("LOST_TARGET", track_id, None)
    passed = created and track is not None and track.state == "LOST" and alarm is not None
    report(passed, "7a box on empty water", f"accepted as an ACQ target: {created}; gives up within 40 s and raises LOST_TARGET: "
           f"{track is not None and track.state == 'LOST' and alarm is not None}")


def test_7b_close_pass():
    # A 10 m2 buoy passed 0.3 nm abeam in sea state 3 stays tracked through the closest approach and after it (the
    # window round a close target is very wide and its corners are full of clutter).
    cfg = copy.deepcopy(CFG)
    cfg["radar"]["video_range_nm"] = 10.0
    cfg["display"]["range_scale_nm"] = 6.0
    world = World(cfg, 3, calibration=False, own=(0.0, 0.0, 0.0, 12.0))
    world.keep([])
    world.add_fixed("BX", math.degrees(math.atan2(0.3, 4.0)), math.hypot(0.3, 4.0), 0.0, 0.0, rcs_m2=10.0, length_m=10.0)
    world.run(8.0)
    track_id = None
    while track_id is None and world.time_s < 600.0:
        if world.truth("BX")["range_nm"] < 3.0:
            track_id = world.acquire("BX")
        world.run(2.5)
    closest = 9.9
    states = set()
    ended = 0.0
    while world.time_s < 3000.0:
        world.run(2.5)
        truth = world.truth("BX")
        closest = min(closest, truth["range_nm"])
        track = world.arpa.tracks.get(track_id)
        if track is not None:
            states.add(track.state)
        ended = truth["range_nm"]
        if closest < 1.0 and ended > 3.2:
            break
    passed = track_id is not None and "LOST" not in states and closest < 0.3
    report(passed, "7b close pass", f"buoy passed at {closest:.2f} nm and followed to {ended:.1f} nm astern: states seen {sorted(states)}")


def test_7_capacity():
    world = many_contacts(1, 41)
    arpa = world.arpa
    world.run(4.0)
    arpa.targets_due = False
    arpa.alarms_changed = False
    nothing = arpa.acquire(1.0, 200.0)                             # empty water: the box goes down anyway
    silent = nothing is not None and len(arpa.tracks) == 1 and arpa.tracks[nothing].state == "ACQ"
    arpa.cancel_target(nothing)
    arpa.targets_due = False
    arpa.alarms_changed = False
    silent = silent and not arpa.tracks and not arpa.alarms
    ids = [world.acquire(f"C{number + 1}") for number in range(40)]
    accepted = sum(1 for track_id in ids if track_id is not None)
    extra = world.acquire("C41")
    alarm = arpa.find_alarm("CAPACITY", None, None)
    raised = alarm is not None and alarm["active"]
    world.run(10.0)
    passed = silent and accepted == 40 and sorted(ids) == list(range(1, 41)) and extra is None and raised and len(arpa.tracks) == 40
    report(passed, "7 capacity", f"a box on empty water is accepted (ACQ) and can be cancelled: {silent}; {accepted} of 40 "
           f"acquisitions accepted, ids 1 to {max(track_id or 0 for track_id in ids)}; the 41st raises CAPACITY: {raised}; "
           f"tracked count after it: {len(arpa.tracks)}")


# ---------------------------------------------------------------- 8 CPA, TCPA, bow crossing (no radar)

def test_8_cpa_and_bow_crossing():
    cfg = test_cfg()
    arpa = sim_arpa.Arpa(cfg, np.random.default_rng(1))
    # Own ship at the origin, heading 000 at 10 kn, no current.
    arpa.own = sim_arpa.OwnData(100.0, 0.0, 0.0, 0.0, 0.0, 10.0, 0.0, 0.0, 0.0, 10.0)
    # (name, x_nm, y_nm, vx_kn, vy_kn, expected BCR nm, expected BCT min), worked by hand:
    cases = [
        # On the port bow, crossing left to right at own ship's speed: relative motion
        # is 10 kn due east, so it crosses the heading line 3 nm ahead after 2 nm / 10 kn = 12 min.
        ("crossing ahead", -2.0, 3.0, 10.0, 10.0, 3.0, 12.0),
        # The same, but 1 nm abaft the beam: it crosses the line astern.
        ("crossing astern", -2.0, -1.0, 10.0, 10.0, None, None),
        # Same course, 2 kn faster, 2 nm to starboard: it never crosses.
        ("never crossing", 2.0, 3.0, 0.0, 12.0, None, None),
        # On the starboard bow and moving away to starboard: opening.
        ("opening", 2.0, 3.0, 10.0, 15.0, None, None),
    ]
    worst = 0.0
    passed = True
    parts = []
    for number, (name, x_nm, y_nm, vx_kn, vy_kn, bcr_nm, bct_min) in enumerate(cases):
        track = sim_arpa.Track(number + 1, x_nm, y_nm, 100.0, np.eye(2) * 1e-6)
        track.vector[2] = vx_kn
        track.vector[3] = vy_kn
        track.state = "TRACK"
        data = arpa.target_numbers(track)
        cpa_nm, tcpa_min = sim_common.cpa_tcpa((x_nm, y_nm), (vx_kn, vy_kn - 10.0))
        worst = max(worst, abs(data["cpa_nm"] - cpa_nm), abs(data["tcpa_min"] - tcpa_min))
        if bcr_nm is None:
            passed = passed and data["bcr_nm"] is None and data["bct_min"] is None
        else:
            passed = passed and data["bcr_nm"] is not None and abs(data["bcr_nm"] - bcr_nm) < 1e-6 and abs(data["bct_min"] - bct_min) < 1e-6
        if name == "opening":
            passed = passed and data["tcpa_min"] < 0.0 and abs(data["cpa_nm"] - math.hypot(x_nm, y_nm)) < 1e-6
        parts.append(f"{name}: CPA {data['cpa_nm']:.3f} nm, TCPA {data['tcpa_min']:.2f} min, BCR {data['bcr_nm']}, BCT {data['bct_min']}")
    report(passed and worst < 1e-6, "8 CPA, TCPA, bow crossing", f"largest difference from cpa_tcpa of the true states "
           f"{worst:.1e} (limit 1e-6); " + "; ".join(parts))


# ---------------------------------------------------------------- 9 CPA/TCPA alarm

def alarm_run(cpa_limit_nm):
    # S4 comes up from astern. Own ship alters 30 deg to starboard when the alarm sounds.
    # Returns the times and numbers the two halves of test 9 need.
    world = World(test_cfg({"arpa.cpa_limit_nm": cpa_limit_nm}), 1)
    world.keep(["S4"])
    world.run(4.0)
    track_id = world.acquire("S4")
    arpa = world.arpa
    result = {"raised_tcpa_min": None, "truth_clear_s": None, "alarm_clear_s": None}
    while world.time_s < 25.0 * 60.0:
        world.step()
        alarm = arpa.find_alarm("CPA_TCPA", track_id, None)
        if alarm is not None and alarm["active"]:
            result["raised_tcpa_min"] = world.truth("S4")["tcpa_min"]
            result["raised_cpa_nm"] = world.truth("S4")["cpa_nm"]
            break
    if result["raised_tcpa_min"] is None:
        return result
    world.order("heading 030")
    turn_s = world.time_s
    result["cpa_after_turn_nm"] = None
    while world.time_s < turn_s + 15.0 * 60.0:
        world.step()
        truth = world.truth("S4")
        if result["cpa_after_turn_nm"] is None and world.time_s >= turn_s + 90.0:
            result["cpa_after_turn_nm"] = truth["cpa_nm"]
        dangerous = truth["cpa_nm"] < cpa_limit_nm and 0.0 < truth["tcpa_min"] < CFG["arpa"]["tcpa_limit_min"]
        if not dangerous and result["truth_clear_s"] is None:
            result["truth_clear_s"] = world.time_s - turn_s
        alarm = arpa.find_alarm("CPA_TCPA", track_id, None)
        if alarm is None or not alarm["active"]:
            result["alarm_clear_s"] = world.time_s - turn_s
            result["cpa_at_clear_nm"] = truth["cpa_nm"]
            break
    return result


def test_9_cpa_alarm():
    limit_min = CFG["arpa"]["tcpa_limit_min"]
    result = alarm_run(1.0)
    raised = result["raised_tcpa_min"]
    report(raised is not None and abs(raised - limit_min) <= 1.0, "9a CPA/TCPA alarm raised",
           f"S4 from dead astern, CPA limit 1.0 nm, TCPA limit {limit_min:.0f} min: the alarm came up with the true TCPA at "
           f"{raised if raised is None else round(raised, 2)} min ({limit_min:.0f} +/-1) and the true CPA at "
           f"{result.get('raised_cpa_nm', 0.0):.2f} nm")
    # With S4 only about 1.2 nm off, no 30 deg turn can open the CPA to 1.0 nm: the
    # alarm has to stay until S4 is past, and go then.
    if raised is not None:
        late_s = (result["alarm_clear_s"] or 9e9) - (result["truth_clear_s"] or 0.0)
        report(result["cpa_after_turn_nm"] < 1.0 and 0.0 <= late_s <= 60.0, "9b alarm follows the truth, CPA limit 1.0 nm",
               f"after own ship's 30 deg turn to starboard the true CPA is {result['cpa_after_turn_nm']:.2f} nm, still "
               f"inside the limit; the danger was truly over {result['truth_clear_s']:.0f} s after the turn order and "
               f"the alarm cleared at {result['alarm_clear_s']:.0f} s ({late_s:.0f} s later; limit 60)")
    result = alarm_run(0.5)
    cleared = result["alarm_clear_s"]
    report(result["raised_tcpa_min"] is not None and cleared is not None and cleared <= 180.0,
           "9c the 30 deg turn clears the alarm, CPA limit 0.5 nm",
           f"alarm raised at true TCPA {result['raised_tcpa_min']:.2f} min; alarm cleared "
           f"{cleared if cleared is None else round(cleared)} s after the turn order (limit 180), with the true CPA at "
           f"{result.get('cpa_at_clear_nm', 0.0):.2f} nm")


# ---------------------------------------------------------------- 10 trial maneuver

def exact_trial(truth, own_vx_kn, own_vy_kn, course_deg, speed_kn, delay_s):
    # Worked out here independently of sim_arpa.py: carry the relative position
    # forward to the time of the maneuver, then find the closest approach on the new
    # relative track.
    delay_h = delay_s / 3600.0
    x_nm = truth["rel_x_nm"] + (truth["vx_kn"] - own_vx_kn) * delay_h
    y_nm = truth["rel_y_nm"] + (truth["vy_kn"] - own_vy_kn) * delay_h
    vx_kn = truth["vx_kn"] - speed_kn * math.sin(math.radians(course_deg))
    vy_kn = truth["vy_kn"] - speed_kn * math.cos(math.radians(course_deg))
    time_h = -(x_nm * vx_kn + y_nm * vy_kn) / (vx_kn ** 2 + vy_kn ** 2)
    if time_h < 0.0:
        return math.hypot(x_nm, y_nm), (delay_h + time_h) * 60.0
    return math.hypot(x_nm + vx_kn * time_h, y_nm + vy_kn * time_h), (delay_h + time_h) * 60.0


def test_10_trial():
    world = three_ships(test_cfg(), 1)
    world.run(4.0)
    ids = {name: world.acquire(name) for geometry, name in GEOMETRIES}
    world.run_until(240.0)
    course_deg, speed_kn, delay_s = 60.0, 12.0, 60.0
    world.arpa.set_trial(True, course_deg, speed_kn, delay_s)
    world.run(REVOLUTION_S + 0.1)
    own = world.own_ship
    own_vx_kn, own_vy_kn = sim_common.velocity_xy_kn(own.speed_water_kn, own.heading_deg_true)
    parts = []
    passed = True
    for geometry, name in GEOMETRIES:
        target = world.targets[ids[name]]
        cpa_nm, tcpa_min = exact_trial(world.truth(name), float(own_vx_kn), float(own_vy_kn), course_deg, speed_kn, delay_s)
        passed = (passed and target["trial_cpa_nm"] is not None and abs(target["trial_cpa_nm"] - cpa_nm) <= 0.02
                  and abs(target["trial_tcpa_min"] - tcpa_min) <= 0.5)
        parts.append(f"{name} trial CPA {target['trial_cpa_nm']} nm (exact {cpa_nm:.3f}), TCPA {target['trial_tcpa_min']} "
                     f"min (exact {tcpa_min:.2f})")
    world.arpa.set_trial(False, 0.0, 0.0, 0.0)
    world.run(REVOLUTION_S + 0.1)
    cancelled = all(world.targets[ids[name]]["trial_cpa_nm"] is None and world.targets[ids[name]]["trial_tcpa_min"] is None
                    for geometry, name in GEOMETRIES)
    report(passed and cancelled, "10 trial maneuver", f"trial {course_deg:03.0f} deg true, {speed_kn:.0f} kn after "
           f"{delay_s:.0f} s (limits 0.02 nm, 0.5 min): " + "; ".join(parts) + f"; cancelling clears them: {cancelled}")


# ---------------------------------------------------------------- 11 stabilisation switch

def test_11_stabilisation():
    cfg = test_cfg({"environment.current_set_deg_true": 90.0, "environment.current_drift_kn": 2.0})
    world = World(cfg, 1)
    world.keep(["B1", "B4"])
    world.run(4.0)
    ids = {"B1": world.acquire("B1"), "B4": world.acquire("B4")}
    world.run_until(200.0)
    sea = dict(world.targets[ids["B1"]])
    before = {track_id: (track.state, track.acquired_s) for track_id, track in world.arpa.tracks.items()}
    world.set_stabilization("ground")
    world.run(0.1)
    at_once = dict(world.targets[ids["B1"]])
    after = {track_id: (track.state, track.acquired_s) for track_id, track in world.arpa.tracks.items()}
    world.run(30.0)
    ground = dict(world.targets[ids["B1"]])
    world.set_stabilization("sea")
    world.run(30.0)
    back = dict(world.targets[ids["B1"]])
    passed = (abs(sea["speed_kn"] - 2.0) <= 0.3 and angle_error(sea["course_deg_true"], 270.0) <= 15.0
              and at_once["speed_kn"] < 0.3 and ground["speed_kn"] < 0.3 and before == after
              and abs(back["speed_kn"] - 2.0) <= 0.3 and angle_error(back["course_deg_true"], 270.0) <= 15.0)
    report(passed, "11 stabilisation switch", f"current 2.0 kn setting 090; buoy B1 in sea mode: {sea['speed_kn']:.2f} kn, "
           f"course {sea['course_deg_true']:05.1f} (2.0 +/-0.3 kn, 270 +/-15); switched to ground: {at_once['speed_kn']:.2f} kn "
           f"at once and {ground['speed_kn']:.2f} kn 30 s later (below 0.3); ids, states and ages unchanged: "
           f"{before == after}; back to sea: {back['speed_kn']:.2f} kn, course {back['course_deg_true']:05.1f}")


# ---------------------------------------------------------------- 12 guard zone

def test_12_guard_zone():
    # (a) A zone 3 to 5 nm ahead, 10 deg either side of the bow. G1 comes down from
    # ahead and enters it; G2 keeps station 30 deg on the bow and never does.
    world = World(test_cfg(), 1, calibration=False)
    world.add_fixed("G1", 0.0, 5.5, 180.0, 10.0, 2000.0)
    world.add_fixed("G2", 30.0, 4.0, 0.0, 10.0, 2000.0)
    world.extra_sectors.append((0.0, 12.0))
    arpa = world.arpa
    arpa.set_guard_zone(1, True, 3.0, 5.0, 350.0, 10.0)
    entered_s = None
    alarm_s = None
    early = False
    while world.time_s < 200.0 and alarm_s is None:
        world.step()
        range_nm = world.truth("G1")["range_nm"]
        if entered_s is None and range_nm <= 5.0:
            entered_s = world.time_s
        alarm = arpa.find_alarm("GUARD_ZONE", None, 1)
        if alarm is not None and alarm["active"]:
            alarm_s = world.time_s
            early = range_nm > 5.06
    passed = entered_s is not None and alarm_s is not None and not early and alarm_s - entered_s <= 4.0 * REVOLUTION_S
    report(passed, "12a guard zone, contact", f"zone 3 to 5 nm, 350 to 010 deg relative; G1 entered at {entered_s or 0.0:.1f} s, "
           f"GUARD_ZONE raised at {alarm_s or 0.0:.1f} s (within 4 revolutions = {4.0 * REVOLUTION_S:.0f} s; needs "
           f"{CFG['arpa']['guard_hits_needed']} hits in {CFG['arpa']['guard_hits_window']} revolutions); nothing was raised "
           f"while G1 was outside and G2 stayed outside: {not early}")

    # (b) No contacts at all, Douglas 5, the zone looking upwind.
    results = {}
    lit = {}
    for stc_percent in (0.0, 100.0):
        cfg = test_cfg({"environment.sea_state_douglas": 5, "environment.wind_from_deg_true": 0.0,
                        "environment.wind_speed_kn": 25.0, "radar_controls.stc_percent": stc_percent})
        world = World(cfg, 1, calibration=False)
        world.extra_sectors.append((0.0, 12.0))
        world.arpa.set_guard_zone(1, True, 3.0, 5.0, 350.0, 10.0)
        raised = False
        while world.time_s < 120.0:
            world.step()
            alarm = world.arpa.find_alarm("GUARD_ZONE", None, 1)
            raised = raised or (alarm is not None and alarm["active"])
        results[stc_percent] = raised
        bin_nm = world.arpa.video_range_nm / CFG["radar"]["range_bins"]
        zone = world.arpa.video[np.arange(-50, 51) % CFG["radar"]["azimuth_bins"], int(3.0 / bin_nm):int(5.0 / bin_nm)]
        lit[stc_percent] = 100.0 * float(np.mean(zone > 0))
    report(results[0.0] and not results[100.0], "12b guard zone, sea clutter", f"sea state 5, no contacts, 120 s: with STC 0 "
           f"({lit[0.0]:.1f} % of the zone's cells lit) clutter raises GUARD_ZONE: {results[0.0]}; with STC 100 % "
           f"({lit[100.0]:.2f} % lit) it does not: {not results[100.0]}")


# ---------------------------------------------------------------- 13 history

def test_13_history():
    cfg = test_cfg()
    world = World(cfg, 1)
    world.keep(["S2", "S4"])
    world.run(4.0)
    ids = [world.acquire("S2"), world.acquire("S4")]
    own_at = {}
    while world.time_s < 4.0 + 300.0 + REVOLUTION_S + 0.2:
        world.step()
        own_at[round(world.time_s, 1)] = (world.own_ship.sea_ref_x_nm, world.own_ship.sea_ref_y_nm)
    interval_s = cfg["arpa"]["history_interval_s"]
    count = cfg["arpa"]["history_count"]
    passed = True
    parts = []
    for track_id in ids:
        history = world.targets[track_id]["history"]
        times = [entry[0] for entry in history]
        gaps = [later - earlier for earlier, later in zip(times, times[1:])]
        own_error_nm = 0.0
        for time_s, target_x_nm, target_y_nm, own_x_nm, own_y_nm in history:
            own_error_nm = max(own_error_nm, math.hypot(own_x_nm - own_at[time_s][0], own_y_nm - own_at[time_s][1]))
        passed = (passed and len(history) == count and all(abs(gap - interval_s) <= 0.11 for gap in gaps)
                  and own_error_nm < 1e-3)
        parts.append(f"target {track_id}: {len(history)} entries at {times} s, own-ship reference position stored with "
                     f"each (largest difference {own_error_nm:.5f} nm)")
    report(passed, "13 history", f"after 5 min, {count} entries {interval_s:.0f} s apart expected; " + "; ".join(parts))


# ---------------------------------------------------------------- 14 swaps

def crossing_run(seed, swap_enabled):
    # Two equal contacts cross at right angles 4 nm ahead, 0.05 nm apart at the closest,
    # 180 s into the run. Returns True if a track ended on the wrong contact (or lost).
    cfg = test_cfg({"arpa.target_swap_enabled": swap_enabled})
    world = World(cfg, seed, calibration=False, own=(0.0, 0.0, 0.0, 0.0))
    first = world.traffic.add_contact("buoy", -0.5, 4.0, 90.0, 10.0, "fixed")
    second = world.traffic.add_contact("buoy", 0.0707, 3.5, 0.0, 10.0, "fixed")
    for name, contact in (("X1", first), ("X2", second)):
        contact.name = name
        contact.scatterers = [(0.0, 1000.0)]
    world.snapshot = world.take_snapshot()
    world.run(4.0)
    ids = {"X1": world.acquire("X1"), "X2": world.acquire("X2")}
    world.run_until(360.0)
    swapped = False
    for name, track_id in ids.items():
        track = world.arpa.tracks.get(track_id)
        contact = world.contact(name)
        own_x_nm, own_y_nm = world.arpa.own_position()
        if track is None or track.state == "LOST":
            return True
        # The track is in the sea-stabilised frame: compare positions relative to own ship.
        x_nm, y_nm = track.position_at(world.time_s)
        error_nm = math.hypot((x_nm - own_x_nm) - (contact.x_nm - world.own_ship.x_nm),
                              (y_nm - own_y_nm) - (contact.y_nm - world.own_ship.y_nm))
        swapped = swapped or error_nm > 0.15
    return swapped


def test_14_swaps():
    wrong_without = sum(1 for seed in range(1, SEEDS + 1) if crossing_run(seed, False))
    wrong_with = sum(1 for seed in range(1, SEEDS + 1) if crossing_run(seed, True))
    report(wrong_without == 0, "14 swaps", f"two contacts crossing 0.05 nm apart, {SEEDS} seeds: with "
           f"target_swap_enabled = false, {wrong_without} runs ended with a track on the wrong contact or lost (0 allowed); "
           f"with it true, {wrong_with} of {SEEDS} runs did (reported only)")


# ---------------------------------------------------------------- 15 cost

def test_15_cost():
    world = many_contacts(1, 40)
    world.run(4.0)
    ids = [world.acquire(f"C{number + 1}") for number in range(40)]
    world.arpa.set_guard_zone(1, True, 3.0, 5.0, 350.0, 10.0)
    world.arpa.set_guard_zone(2, True, 1.0, 2.0, 90.0, 270.0)
    world.extra_sectors.append((180.0, 180.0))                    # the whole revolution, as in the sim
    world.run(10.0)
    world.arpa_cpu_s = 0.0
    revolutions = 20
    world.run(revolutions * REVOLUTION_S)
    per_revolution_s = world.arpa_cpu_s / revolutions
    share_1x = 100.0 * per_revolution_s / REVOLUTION_S
    tracked = sum(1 for track in world.arpa.tracks.values() if track.state != "LOST")
    report(share_1x <= 10.0 and tracked == 40, "15 cost", f"{tracked} tracked targets and two guard zones: "
           f"{1000.0 * per_revolution_s:.0f} ms of CPU per revolution, {share_1x:.1f} % of a revolution's wall time at 1x "
           f"(limit 10 %); at 10x that is {10.0 * share_1x:.0f} % of one core. The radar is not counted.")
    return per_revolution_s


# ---------------------------------------------------------------- 16 wiring over TCP

def test_16_wiring_over_tcp():
    with open(CONFIG_PATH, "r", encoding="utf-8") as config_file:
        text = config_file.read()
    with open(TEMP_CONFIG_PATH, "w", encoding="utf-8") as config_file:
        config_file.write(text.replace('scenario = "random"', 'scenario = "calibration"', 1))
    probe = socket.socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()
    sim = subprocess.Popen([sys.executable, "-u", SIM_MAIN, "--config", TEMP_CONFIG_PATH, "--port", str(port)],
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        deadline_s = time.perf_counter() + 10.0
        while True:
            try:
                sock = socket.create_connection(("127.0.0.1", port), timeout=60.0)
                break
            except OSError:
                if time.perf_counter() > deadline_s:
                    raise
                time.sleep(0.1)
        seen = {"targets": [], "alarms": [], "setting": {}, "state": {}}

        def read_until(done, wall_s):
            # Reads frames until done() is true or wall_s has passed. Radar video is skipped.
            end_s = time.perf_counter() + wall_s
            while not done() and time.perf_counter() < end_s:
                frame_type, payload = sim_protocol.read_frame(sock)
                if frame_type != sim_protocol.FRAME_JSON:
                    continue
                message = sim_protocol.decode_json(payload)
                if message["t"] == "targets":
                    seen["targets"].append(message)
                elif message["t"] == "alarms":
                    seen["alarms"].append(message)
                elif message["t"] == "setting":
                    seen["setting"][message["path"]] = message["value"]
                elif message["t"] == "state":
                    seen["state"] = message
            return done()

        def send(message):
            sim_protocol.send_json(sock, message)

        send({"t": "set", "path": "general.sim_speed_multiplier", "value": 5})
        read_until(lambda: seen["state"].get("sim_time_s", 0.0) >= 6.0, 30.0)
        # Buoy B1 lies 000 deg true from the start position, 2 nm less what own ship has run.
        own = seen["state"]["own"]
        send({"t": "acquire", "range_nm": math.hypot(0.0 - own["x_nm"], 2.0 - own["y_nm"]),
              "bearing_deg_true": math.degrees(math.atan2(0.0 - own["x_nm"], 2.0 - own["y_nm"])) % 360.0})
        got = read_until(lambda: any(message["targets"] for message in seen["targets"]), 20.0)
        target = seen["targets"][-1]["targets"][0] if got else {}
        report(got and target.get("id") == 1 and target.get("state") == "ACQ" and "ref_x_nm" in seen["targets"][-1],
               "16a acquire over TCP", f"targets message with target {target.get('id')}, state {target.get('state')}, "
               f"range {target.get('range_nm')} nm, bearing {target.get('bearing_deg_true')} deg true")

        # The message that answered the acquisition came at once; the regular ones follow.
        count = len(seen["targets"]) + 1
        read_until(lambda: len(seen["targets"]) >= count, 20.0)
        start_s = seen["targets"][-1]["sim_time_s"]
        read_until(lambda: len(seen["targets"]) >= count + 4, 30.0)
        spacing_s = (seen["targets"][-1]["sim_time_s"] - start_s) / max(1, len(seen["targets"]) - count)
        report(abs(spacing_s - REVOLUTION_S) < 0.2, "16b targets once per revolution",
               f"messages {spacing_s:.2f} s of sim time apart (one revolution = {REVOLUTION_S:.2f} s)")

        send({"t": "set", "path": "arpa.cpa_limit_nm", "value": 2.5})
        send({"t": "set", "path": "arpa.stabilization", "value": "ground"})
        read_until(lambda: "arpa.stabilization" in seen["setting"], 10.0)
        count = len(seen["targets"])
        read_until(lambda: len(seen["targets"]) >= count + 2, 20.0)
        still = [entry["id"] for entry in seen["targets"][-1]["targets"]]
        report(seen["setting"].get("arpa.cpa_limit_nm") == 2.5 and seen["setting"].get("arpa.stabilization") == "ground"
               and still == [1], "16c set arpa.*", f"settings confirmed: cpa_limit_nm {seen['setting'].get('arpa.cpa_limit_nm')}, "
               f"stabilization {seen['setting'].get('arpa.stabilization')}; target ids after the switch: {still}")

        # A guard zone round buoy B4 (270 deg true, 3 nm at the start; own ship heads north).
        send({"t": "guard_zone", "index": 1, "enabled": True, "inner_nm": 2.5, "outer_nm": 3.5, "start_deg": 240.0, "end_deg": 280.0})
        got = read_until(lambda: any(alarm["kind"] == "GUARD_ZONE" for message in seen["alarms"] for alarm in message["alarms"]), 30.0)
        alarm = [alarm for message in seen["alarms"] for alarm in message["alarms"] if alarm["kind"] == "GUARD_ZONE"]
        alarm_id = alarm[0]["id"] if alarm else None
        send({"t": "ack_alarm", "id": alarm_id})
        acknowledged = read_until(lambda: any(entry["id"] == alarm_id and entry["acknowledged"]
                                              for entry in seen["alarms"][-1]["alarms"]), 10.0) if alarm else False
        report(got and acknowledged, "16d guard_zone and ack_alarm", f"GUARD_ZONE alarm {alarm_id} raised for buoy B4: {got}; "
               f"shown as acknowledged after ack_alarm: {acknowledged}")

        send({"t": "trial", "enabled": True, "course_deg_true": 90.0, "speed_kn": 10.0, "delay_s": 0.0})
        send({"t": "cancel_all_targets"})
        got = read_until(lambda: seen["targets"][-1]["targets"] == [], 20.0)
        report(got, "16e cancel_all_targets", f"the targets message is empty again: {got}")
        send({"t": "quit"})
        sim.wait(timeout=5.0)
        sock.close()
    finally:
        if sim.poll() is None:
            sim.kill()
        if os.path.exists(TEMP_CONFIG_PATH):
            os.remove(TEMP_CONFIG_PATH)


def main():
    started_s = time.perf_counter()
    messages.status(f"M8 tests, {SEEDS} seeds" + (" (--quick)" if QUICK else ""))
    test_8_cpa_and_bow_crossing()
    test_1_plots()
    test_2_states()
    test_3_accuracy()
    test_4_own_maneuver()
    test_5_small_boat()
    test_6_lost()
    test_7_capacity()
    test_7a_empty_box()
    test_7b_close_pass()
    test_9_cpa_alarm()
    test_10_trial()
    test_11_stabilisation()
    test_12_guard_zone()
    test_13_history()
    test_14_swaps()
    test_15_cost()
    test_16_wiring_over_tcp()
    messages.status(f"Took {(time.perf_counter() - started_s) / 60.0:.1f} min")
    if failures:
        messages.fail(f"{failures} test line(s) failed")
        return 1
    messages.done("All M8 tests passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
