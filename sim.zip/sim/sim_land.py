# sim_land.py - the land: a raster of heights plus the traffic lanes, and the only
# file that knows how land is made (BRIEF.md Sections 8.3 and 13). Gen 1 generates
# the land from a seed; Gen 3A will fill the same raster from charts.
# Everyone else uses only: height_m_at, is_land, lanes, find_start (and land_within).
# Units: positions and distances nm (x east, y north, origin at the centre of the
# land square), heights m above sea level (0 = water), bearings deg true.
# Called by: sim_main.py at start-up; later the traffic, radar and game code.

import time
from dataclasses import dataclass

import numpy as np

import messages
from sim_common import bearing_true_deg

LANE_SAMPLE_NM = 0.05            # lanes are checked every 0.05 nm (BRIEF.md Section 8.3)
LANE_CLEARANCE_NM = 0.5          # every lane sample is at least this far from land ...
HARBOUR_EXEMPT_NM = 1.0          # ... except the last 1 nm of the harbour approach
START_LAND_CLEARANCE_NM = 2.0    # find_start: at least this far from land
START_LANE_NEAREST_NM = 1.0      # find_start: this far from a lane, at least ...
START_LANE_FARTHEST_NM = 3.0     # ... and at most
MAX_TRIES = 20
HARBOUR_APPROACH = "harbour approach"

# Everything below this line is chosen, not from a source: the sizes that shape the
# generated coast. They assume a land square of 30 nm or more.
MIN_EXTENT_NM = 30.0
MAX_RASTER_CELLS = 8192          # per side; 4000 by default
COAST_FROM_CENTRE_NM = (7.0, 10.0)      # the mainland's mean coastline lies this far from the centre
COAST_NOISE_NM = 5.0                    # bays and headlands move the coast by up to this much
COAST_NOISE_WAVELENGTHS_NM = [16.0, 8.0, 4.0, 2.0, 1.0, 0.5, 0.25]
COAST_NOISE_FALLOFF = 0.55              # nearer 1 = a more ragged coast
INLAND_RISE_NM = 8.0                    # distance inland over which the ground reaches full height
COAST_HEIGHT_M = (3.0, 30.0)
INLAND_HEIGHT_M = (100.0, 400.0)
ISLAND_COUNT = (3, 10)
ISLAND_HEIGHT_M = (10.0, 150.0)
ISLAND_RADIUS_NM = (0.4, 1.6)
ISLAND_SHAPE_NOISE = 0.35               # an island's shore wanders this fraction of its radius
THROUGH_LANE_OFFSHORE_NM = (6.0, 10.0)
THROUGH_LANE_WIDTH_NM = 2.0
APPROACH_LANE_WIDTH_NM = 0.4
GAP_LANE_WIDTH_NM = 1.0
BASIN_RADIUS_NM = 0.6
CHANNEL_HALF_WIDTH_NM = 0.2
BREAKWATER_HALF_WIDTH_NM = 0.025
BREAKWATER_HEIGHT_M = 4.0


class LandError(Exception):
    pass


@dataclass
class Lane:
    name: str
    points_nm: np.ndarray        # shape (N, 2): x_nm, y_nm along the centre line
    width_nm: float
    two_way: bool


# ---------------------------------------------------------------- geometry helpers

def sample_polyline(points_nm, spacing_nm):
    # Points every spacing_nm along a polyline. Returns (samples (M, 2), distance
    # along the line of each sample, total length).
    steps = np.diff(points_nm, axis=0)
    step_lengths = np.hypot(steps[:, 0], steps[:, 1])
    along_nm = np.concatenate([[0.0], np.cumsum(step_lengths)])
    total_nm = along_nm[-1]
    sample_along_nm = np.arange(0.0, total_nm, spacing_nm)
    sample_along_nm = np.append(sample_along_nm, total_nm)
    x_nm = np.interp(sample_along_nm, along_nm, points_nm[:, 0])
    y_nm = np.interp(sample_along_nm, along_nm, points_nm[:, 1])
    return np.column_stack([x_nm, y_nm]), sample_along_nm, total_nm


def distance_to_polyline_nm(x_nm, y_nm, points_nm):
    # Shortest distance from one point to a polyline.
    start = points_nm[:-1]
    step = points_nm[1:] - start
    step_length_sq = np.maximum(step[:, 0] ** 2 + step[:, 1] ** 2, 1e-12)
    along = ((x_nm - start[:, 0]) * step[:, 0] + (y_nm - start[:, 1]) * step[:, 1]) / step_length_sq
    along = np.clip(along, 0.0, 1.0)
    nearest_x = start[:, 0] + along * step[:, 0]
    nearest_y = start[:, 1] + along * step[:, 1]
    return float(np.min(np.hypot(x_nm - nearest_x, y_nm - nearest_y)))


# ---------------------------------------------------------------- the model

class LandModel:
    def __init__(self, heights_m, cell_nm, lanes):
        # heights_m: square int16 raster, row 0 = southern edge, column 0 = western edge.
        self.heights_m = heights_m
        self.cell_nm = cell_nm
        self.cells = heights_m.shape[0]
        self.extent_nm = self.cells * cell_nm        # side of the square, centred on the origin
        self.lanes = lanes

    def height_m_at(self, x_nm, y_nm):
        # Vectorised. Metres above sea level; 0 = water; 0 outside the land square.
        x_nm = np.asarray(x_nm, dtype=float)
        y_nm = np.asarray(y_nm, dtype=float)
        half_nm = self.extent_nm / 2.0
        columns = np.floor((x_nm + half_nm) / self.cell_nm).astype(np.int64)
        rows = np.floor((y_nm + half_nm) / self.cell_nm).astype(np.int64)
        inside = (columns >= 0) & (columns < self.cells) & (rows >= 0) & (rows < self.cells)
        heights = self.heights_m[np.clip(rows, 0, self.cells - 1), np.clip(columns, 0, self.cells - 1)]
        return np.where(inside, heights, 0)

    def is_land(self, x_nm, y_nm):
        return self.height_m_at(x_nm, y_nm) > 0

    def is_land_point(self, x_nm, y_nm):
        # is_land for one point, in plain Python: much faster than the array version
        # when the traffic code asks about one contact at a time.
        half_nm = self.extent_nm / 2.0
        column = int((x_nm + half_nm) // self.cell_nm)
        row = int((y_nm + half_nm) // self.cell_nm)
        if column < 0 or row < 0 or column >= self.cells or row >= self.cells:
            return False
        return self.heights_m[row, column] > 0

    def first_land_along(self, x_nm, y_nm, bearing_deg_true, distance_nm):
        # Looks from a point along a bearing. Returns the distance in nm to the first
        # land, or None if the way is clear for distance_nm.
        half_nm = self.extent_nm / 2.0
        if abs(x_nm) > half_nm + distance_nm or abs(y_nm) > half_nm + distance_nm:
            return None                                  # too far out at sea to meet any land
        steps_nm = np.arange(0.0, distance_nm + self.cell_nm, 2.0 * self.cell_nm)
        bearing_rad = np.radians(bearing_deg_true)
        on_land = self.is_land(x_nm + steps_nm * np.sin(bearing_rad), y_nm + steps_nm * np.cos(bearing_rad))
        if not on_land.any():
            return None
        return float(steps_nm[np.argmax(on_land)])

    def land_within(self, x_nm, y_nm, radius_nm):
        # True if any land cell lies within radius_nm of one point.
        half_nm = self.extent_nm / 2.0
        column = (x_nm + half_nm) / self.cell_nm - 0.5      # in cell units, cell centres at whole numbers
        row = (y_nm + half_nm) / self.cell_nm - 0.5
        reach = radius_nm / self.cell_nm
        row_low = max(int(np.floor(row - reach)), 0)
        row_high = min(int(np.ceil(row + reach)) + 1, self.cells)
        column_low = max(int(np.floor(column - reach)), 0)
        column_high = min(int(np.ceil(column + reach)) + 1, self.cells)
        if row_low >= row_high or column_low >= column_high:
            return False
        window = self.heights_m[row_low:row_high, column_low:column_high]
        row_offset = np.arange(row_low, row_high)[:, None] - row
        column_offset = np.arange(column_low, column_high)[None, :] - column
        in_circle = row_offset ** 2 + column_offset ** 2 <= reach ** 2
        return bool(np.any((window > 0) & in_circle))

    def find_start(self, rng):
        # A start for own ship: open water, at least 2 nm from land and 1 to 3 nm from
        # the nearest lane, heading along that lane. Returns (x_nm, y_nm, heading_deg_true).
        if not self.lanes:
            raise LandError("find_start needs at least one lane; set own_ship.start = \"manual\".")
        lane_lengths = np.array([sample_polyline(lane.points_nm, 1.0)[2] for lane in self.lanes])
        edge_nm = self.extent_nm / 2.0 - START_LAND_CLEARANCE_NM
        for attempt in range(5000):
            lane = self.lanes[rng.choice(len(self.lanes), p=lane_lengths / lane_lengths.sum())]
            samples, along_nm, total_nm = sample_polyline(lane.points_nm, LANE_SAMPLE_NM)
            index = int(rng.integers(0, len(samples) - 1))
            direction = samples[index + 1] - samples[index]
            direction = direction / np.hypot(direction[0], direction[1])
            to_starboard = np.array([direction[1], -direction[0]])
            offset_nm = rng.uniform(START_LANE_NEAREST_NM, START_LANE_FARTHEST_NM) * rng.choice([-1.0, 1.0])
            x_nm, y_nm = samples[index] + offset_nm * to_starboard
            if rng.uniform() < 0.5:
                direction = -direction
            if abs(x_nm) > edge_nm or abs(y_nm) > edge_nm:
                continue
            nearest_lane_nm = min(distance_to_polyline_nm(x_nm, y_nm, other.points_nm) for other in self.lanes)
            if nearest_lane_nm < START_LANE_NEAREST_NM or nearest_lane_nm > START_LANE_FARTHEST_NM:
                continue
            if self.land_within(x_nm, y_nm, START_LAND_CLEARANCE_NM):
                continue
            return float(x_nm), float(y_nm), float(bearing_true_deg(direction[0], direction[1]))
        raise LandError("find_start found no open water near a lane. Set own_ship.start = \"manual\" "
                        "or try another general.seed.")


def make_open_sea(cfg):
    # No land and no lanes: the calibration scenario (BRIEF.md Section 12).
    extent_nm = cfg["general"]["land_extent_nm"]
    return LandModel(np.zeros((2, 2), dtype=np.int16), extent_nm / 2.0, [])


def check_lanes(land):
    # Every lane sample must be water and at least 0.5 nm from land, except the last
    # 1 nm of the harbour approach (which must still be water).
    # Returns None, or a text saying what is wrong.
    for lane in land.lanes:
        samples, along_nm, total_nm = sample_polyline(lane.points_nm, LANE_SAMPLE_NM)
        on_land = land.is_land(samples[:, 0], samples[:, 1])
        if np.any(on_land):
            return "lane '%s' crosses land %.2f nm from its start" % (lane.name, along_nm[np.argmax(on_land)])
        for (x_nm, y_nm), distance_nm in zip(samples, along_nm):
            if lane.name == HARBOUR_APPROACH and distance_nm > total_nm - HARBOUR_EXEMPT_NM:
                continue
            if land.land_within(x_nm, y_nm, LANE_CLEARANCE_NM):
                return "lane '%s' passes within %.1f nm of land %.2f nm from its start" % (
                    lane.name, LANE_CLEARANCE_NM, distance_nm)
    return None


# ---------------------------------------------------------------- generated land (Gen 1)
# The land is built in a "canonical" frame, u along the coast and v across it, with
# the mainland on the +v side. At the end the raster and the lanes are turned by a
# quarter turn 0 to 3 times, so the mainland can be on any side.

def value_noise(rows, columns, wavelength_cells, rng):
    # Smooth random field in -1..+1: random values on a coarse lattice, blended in
    # between. float32, shape (rows, columns).
    lattice_rows = int(rows / wavelength_cells) + 2
    lattice_columns = int(columns / wavelength_cells) + 2
    lattice = rng.uniform(-1.0, 1.0, (lattice_rows, lattice_columns)).astype(np.float32)

    def blend_positions(count):
        position = np.arange(count, dtype=np.float32) / np.float32(wavelength_cells)
        lower = np.floor(position).astype(np.int64)
        fraction = position - lower
        return lower, fraction * fraction * (3.0 - 2.0 * fraction)       # smoothstep

    column_lower, column_blend = blend_positions(columns)
    along_rows = lattice[:, column_lower] * (1.0 - column_blend) + lattice[:, column_lower + 1] * column_blend
    row_lower, row_blend = blend_positions(rows)
    row_blend = row_blend[:, None]
    return along_rows[row_lower] * (1.0 - row_blend) + along_rows[row_lower + 1] * row_blend


def layered_noise(rows, columns, wavelengths_cells, rng, falloff=0.5):
    # Several value-noise layers, each `falloff` times as strong as the one before. -1..+1.
    total = np.zeros((rows, columns), dtype=np.float32)
    strength = 1.0
    strength_sum = 0.0
    for wavelength_cells in wavelengths_cells:
        total += np.float32(strength) * value_noise(rows, columns, max(wavelength_cells, 2.0), rng)
        strength_sum += strength
        strength *= falloff
    total /= np.float32(strength_sum)
    return total


def turn_points(points_uv, quarter_turns):
    # Canonical (u, v) -> world (x, y), matching numpy.rot90(raster, quarter_turns):
    # one quarter turn sends (u, v) to (v, -u).
    points = np.array(points_uv, dtype=float)
    for turn in range(quarter_turns):
        points = np.column_stack([points[:, 1], -points[:, 0]])
    return points


def clear_of_lines(u_nm, v_nm, reach_nm, lines):
    # True if a round shape of radius reach_nm at (u, v) leaves every lane its width
    # plus the 0.5 nm clearance, and 0.3 nm to spare.
    for points_uv, width_nm in lines:
        needed_nm = reach_nm + LANE_CLEARANCE_NM + width_nm / 2.0 + 0.3
        if distance_to_polyline_nm(u_nm, v_nm, points_uv) < needed_nm:
            return False
    return True


def stamp_island(heights, cell_nm, half_nm, island, rng):
    # Draws one island into the canonical raster. island = (u, v, radius, stretch,
    # stretch direction in radians, peak height).
    u_nm, v_nm, radius_nm, stretch, direction_rad, peak_m = island
    reach_nm = radius_nm * stretch * (1.0 + ISLAND_SHAPE_NOISE)
    cells = heights.shape[0]
    column_low = max(int((u_nm - reach_nm + half_nm) / cell_nm), 0)
    column_high = min(int((u_nm + reach_nm + half_nm) / cell_nm) + 1, cells)
    row_low = max(int((v_nm - reach_nm + half_nm) / cell_nm), 0)
    row_high = min(int((v_nm + reach_nm + half_nm) / cell_nm) + 1, cells)
    rows = row_high - row_low
    columns = column_high - column_low
    du_nm = (np.arange(column_low, column_high) + 0.5) * cell_nm - half_nm - u_nm
    dv_nm = ((np.arange(row_low, row_high) + 0.5) * cell_nm - half_nm - v_nm)[:, None]
    # Distance from the centre, shortened along the stretch direction to make the island longer that way.
    along_nm = du_nm * np.cos(direction_rad) + dv_nm * np.sin(direction_rad)
    across_nm = -du_nm * np.sin(direction_rad) + dv_nm * np.cos(direction_rad)
    distance_nm = np.hypot(along_nm / stretch, across_nm)
    radius_cells = radius_nm / cell_nm
    wobble = layered_noise(rows, columns, [radius_cells, radius_cells / 2.0, radius_cells / 4.0,
                                           radius_cells / 8.0], rng)
    inside_nm = radius_nm * (1.0 + ISLAND_SHAPE_NOISE * wobble) - distance_nm     # > 0 = on the island
    shape = np.clip(inside_nm / radius_nm, 0.0, 1.0) ** 0.7
    island_heights = np.where(inside_nm > 0.0, 3.0 + (peak_m - 3.0) * shape, 0.0)
    window = heights[row_low:row_high, column_low:column_high]
    np.maximum(window, island_heights.astype(np.int16), out=window)


def build_land_once(cells, cell_nm, rng):
    # One attempt, in the canonical frame. Returns a LandModel (lanes not yet checked).
    half_nm = cells * cell_nm / 2.0
    u_nm = (np.arange(cells) + 0.5) * cell_nm - half_nm           # along the coast, one per column
    v_nm = u_nm[:, None]                                          # across the coast, one per row

    # ---- mainland: a smooth baseline coast plus noise for bays and headlands ----
    coast_v_nm = np.full(cells, rng.uniform(*COAST_FROM_CENTRE_NM))
    for wave in range(3):
        wavelength_nm = rng.uniform(30.0, 90.0)
        coast_v_nm += rng.uniform(0.3, 0.8) * np.sin(2.0 * np.pi * u_nm / wavelength_nm + rng.uniform(0.0, 2.0 * np.pi))
    wavelengths_cells = [wavelength_nm / cell_nm for wavelength_nm in COAST_NOISE_WAVELENGTHS_NM]
    # inland_nm > 0 is mainland; its value is roughly the distance inland from the shore.
    inland_nm = layered_noise(cells, cells, wavelengths_cells, rng, COAST_NOISE_FALLOFF)
    inland_nm *= np.float32(COAST_NOISE_NM)
    inland_nm += (v_nm - coast_v_nm[None, :]).astype(np.float32)

    # Heights: low at the shore (beaches to low cliffs), rising to hills inland.
    shore_m = layered_noise(cells, cells, [6.0 / cell_nm], rng)
    shore_m = COAST_HEIGHT_M[0] + (COAST_HEIGHT_M[1] - COAST_HEIGHT_M[0]) * (shore_m + 1.0) / 2.0
    hills = layered_noise(cells, cells, [4.0 / cell_nm, 2.0 / cell_nm, 1.0 / cell_nm], rng)
    inland_peak_m = rng.uniform(*INLAND_HEIGHT_M)
    rise = np.clip(inland_nm / INLAND_RISE_NM, 0.0, 1.0)
    rise = rise * rise * (3.0 - 2.0 * rise)
    heights = shore_m + (inland_peak_m - shore_m) * rise * (0.6 + 0.2 * (hills + 1.0))
    heights = np.where(inland_nm > 0.0, np.maximum(heights, 1.0), 0.0).astype(np.int16)
    del inland_nm, shore_m, hills, rise

    # ---- lane 1: two-way coastal through lane, parallel to the baseline coast ----
    offshore_nm = rng.uniform(*THROUGH_LANE_OFFSHORE_NM)
    lane_u_nm = np.linspace(-half_nm, half_nm, int(round(2.0 * half_nm)) + 1)      # a point every nm
    lane_v_nm = np.interp(lane_u_nm, u_nm, coast_v_nm) - offshore_nm
    through_uv = np.column_stack([lane_u_nm, lane_v_nm])
    lines = [(through_uv, THROUGH_LANE_WIDTH_NM)]

    # ---- harbour: a basin cut into the most seaward piece of coast near u = harbour_u ----
    harbour_u_nm = rng.uniform(-12.0, 12.0)
    side = rng.choice([-1.0, 1.0])                                # which side the breakwater is on
    strip = np.abs(u_nm - harbour_u_nm) <= 1.2
    land_rows = np.nonzero(np.any(heights[:, strip] > 0, axis=1))[0]
    shore_v_nm = (land_rows[0] + 0.5) * cell_nm - half_nm         # the first land met coming in from seaward
    # Work in a small window around the harbour, not on the whole raster.
    columns = np.nonzero(np.abs(u_nm - harbour_u_nm) <= 1.5)[0]
    rows = np.nonzero(np.abs(u_nm - shore_v_nm) <= 1.5)[0]            # u_nm doubles as the row coordinate
    window = heights[rows[0]:rows[-1] + 1, columns[0]:columns[-1] + 1]
    du_nm = u_nm[columns][None, :] - harbour_u_nm
    dv_nm = u_nm[rows][:, None] - shore_v_nm
    basin = np.hypot(du_nm, dv_nm - 0.7) <= BASIN_RADIUS_NM
    channel = (np.abs(du_nm) <= CHANNEL_HALF_WIDTH_NM) & (dv_nm >= -0.2) & (dv_nm <= 0.7)
    window[basin | channel] = 0
    # Breakwater: an arm out from the shore beside the entrance, then a short hook across.
    arm_u_nm = side * 0.55
    arm = (np.abs(du_nm - arm_u_nm) <= BREAKWATER_HALF_WIDTH_NM) & (dv_nm >= -0.6) & (dv_nm <= 0.4)
    hook = ((np.abs(dv_nm + 0.6) <= BREAKWATER_HALF_WIDTH_NM)
            & (side * du_nm >= 0.33) & (side * du_nm <= 0.55 + BREAKWATER_HALF_WIDTH_NM))
    breakwater = (arm | hook) & (window == 0)
    window[breakwater] = int(BREAKWATER_HEIGHT_M)

    # ---- lane 2: harbour approach, from the through lane straight in to the entrance ----
    approach_uv = np.array([[harbour_u_nm, float(np.interp(harbour_u_nm, lane_u_nm, lane_v_nm))],
                            [harbour_u_nm, shore_v_nm - 0.3]])
    lines.append((approach_uv, APPROACH_LANE_WIDTH_NM))

    # ---- lane 3: through a gap between two islands, if a place for it can be found ----
    islands = []
    gap_uv = None
    for attempt in range(50):
        gap_u_nm = rng.uniform(-15.0, 15.0)
        if abs(gap_u_nm - harbour_u_nm) < 6.0:
            continue
        gap_top_v_nm = float(np.interp(gap_u_nm, lane_u_nm, lane_v_nm))
        gap_v_nm = gap_top_v_nm - rng.uniform(4.5, 8.0)
        radius_nm = rng.uniform(0.6, 1.3, 2)
        reach_nm = radius_nm * (1.0 + ISLAND_SHAPE_NOISE)
        # Shore to shore the gap is the lane width + 0.5 nm clearance each side + 0.6 nm to spare.
        half_gap_nm = GAP_LANE_WIDTH_NM / 2.0 + LANE_CLEARANCE_NM + 0.3
        centres_u_nm = [gap_u_nm - half_gap_nm - reach_nm[0], gap_u_nm + half_gap_nm + reach_nm[1]]
        fits = gap_v_nm - reach_nm.max() > -half_nm + 0.5
        for centre_u_nm, reach in zip(centres_u_nm, reach_nm):
            fits = fits and abs(centre_u_nm) + reach < half_nm - 0.5
            fits = fits and clear_of_lines(centre_u_nm, gap_v_nm, reach, lines)
        if fits:
            for centre_u_nm, radius in zip(centres_u_nm, radius_nm):
                islands.append((centre_u_nm, gap_v_nm, radius, 1.0, 0.0, rng.uniform(*ISLAND_HEIGHT_M)))
            gap_uv = np.array([[gap_u_nm, gap_top_v_nm], [gap_u_nm, -half_nm]])
            lines.append((gap_uv, GAP_LANE_WIDTH_NM))
            break

    # ---- more islands, 3 to 10 in all, clear of the lanes and of each other ----
    wanted = int(rng.integers(ISLAND_COUNT[0], ISLAND_COUNT[1] + 1))
    seaward_limit_v_nm = coast_v_nm.min() - COAST_NOISE_NM - 0.5
    for attempt in range(400):
        if len(islands) >= wanted:
            break
        radius_nm = rng.uniform(*ISLAND_RADIUS_NM)
        stretch = rng.uniform(1.0, 1.8)
        reach_nm = radius_nm * stretch * (1.0 + ISLAND_SHAPE_NOISE)
        centre_u_nm = rng.uniform(-half_nm + reach_nm + 0.5, half_nm - reach_nm - 0.5)
        centre_v_nm = rng.uniform(-half_nm + reach_nm + 0.5, seaward_limit_v_nm - reach_nm)
        if not clear_of_lines(centre_u_nm, centre_v_nm, reach_nm, lines):
            continue
        crowded = False
        for other in islands:
            other_reach_nm = other[2] * other[3] * (1.0 + ISLAND_SHAPE_NOISE)
            if np.hypot(centre_u_nm - other[0], centre_v_nm - other[1]) < reach_nm + other_reach_nm + 0.5:
                crowded = True
        if crowded:
            continue
        islands.append((centre_u_nm, centre_v_nm, radius_nm, stretch, rng.uniform(0.0, np.pi),
                        rng.uniform(*ISLAND_HEIGHT_M)))
    if len(islands) < ISLAND_COUNT[0]:
        return None, "only %d islands could be placed" % len(islands)
    for island in islands:
        stamp_island(heights, cell_nm, half_nm, island, rng)

    # ---- turn the whole picture so the mainland is on a side chosen by the seed ----
    quarter_turns = int(rng.integers(0, 4))
    lanes = [Lane("coastal", turn_points(through_uv, quarter_turns), THROUGH_LANE_WIDTH_NM, True),
             Lane(HARBOUR_APPROACH, turn_points(approach_uv, quarter_turns), APPROACH_LANE_WIDTH_NM, True)]
    if gap_uv is not None:
        lanes.append(Lane("island gap", turn_points(gap_uv, quarter_turns), GAP_LANE_WIDTH_NM, True))
    heights = np.ascontiguousarray(np.rot90(heights, quarter_turns))
    return LandModel(heights, cell_nm, lanes), None


def generate_land(cfg, rng):
    # Gen 1 land from the land random stream. The same seed gives the same land.
    extent_nm = cfg["general"]["land_extent_nm"]
    cell_nm = cfg["general"]["land_cell_nm"]
    cells = int(round(extent_nm / cell_nm))
    if extent_nm < MIN_EXTENT_NM or cells > MAX_RASTER_CELLS:
        raise LandError("general.land_extent_nm = %g with general.land_cell_nm = %g gives a %d x %d raster. "
                        "Generated land needs an extent of %g nm or more and at most %d cells a side."
                        % (extent_nm, cell_nm, cells, cells, MIN_EXTENT_NM, MAX_RASTER_CELLS))
    sub_seeds = rng.integers(0, 2 ** 32, size=MAX_TRIES)
    for attempt, sub_seed in enumerate(sub_seeds):
        start_s = time.perf_counter()
        messages.status("Generating land, %d x %d cells of %g nm (try %d of %d) ..." % (
            cells, cells, cell_nm, attempt + 1, MAX_TRIES))
        land, problem = build_land_once(cells, cell_nm, np.random.default_rng(int(sub_seed)))
        if problem is None:
            problem = check_lanes(land)
        if problem is None:
            messages.done("Land ready in %.1f s: %d lanes, %.0f %% land, highest point %d m" % (
                time.perf_counter() - start_s, len(land.lanes),
                100.0 * np.count_nonzero(land.heights_m) / land.heights_m.size, land.heights_m.max()))
            return land
        messages.warn("Land rejected (%s); trying the next sub-seed" % problem)
    raise LandError("No valid land after %d tries. Try another general.seed." % MAX_TRIES)
