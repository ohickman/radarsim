import sys
import time

# VERBOSITY
#   A message prints if the verbosity setting is higher than the message's verbosity.
#   Turn up the verbosity to hear more messages.
#   verbosity 0 always prints, because message_verbosity is never below 0.
#
#   Programs should set message_verbosity as follows:
#       import messages
#       messages.message_verbosity = 5
#   If verbosity is not set then all messages print.
#   Regardless of message_verbosity, danger and prompt always print
#
# LOG
#   Messages can also be written to a log file, with a timestamp and no color:
#       messages.log_file = open("run.log", "a")
#       messages.log_verbosity = 9
#   Logging uses the same rule as printing, with log_verbosity in place of message_verbosity.
#   A message is logged even if it is too quiet to print.
#   If log_verbosity is not set then all messages are logged.
#   Regardless of log_verbosity, danger and prompt are always logged.
#
# STREAMS
#   danger, abort, error, fail, warn and prompt write to stderr.
#   done, ok, status, info and debug write to stdout.

message_verbosity = None
log_file = None
log_verbosity = 10


def danger(message, verbosity=None):
    # Physical harm to person. Always prints and logs. verbosity is accepted but ignored.
    if log_file is not None:
        log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} [DANGER]  {message}\n")
        log_file.flush()
    if sys.stderr.isatty():
        print(f"\033[1;97;101m[DANGER]\033[0m  {message}", file=sys.stderr)
    else:
        print(f"[DANGER]  {message}", file=sys.stderr)


def prompt(message, verbosity=None):
    # User input required.  Blocking.  The question and answer are logged.
    print(f"[PROMPT]  {message} ", end="", file=sys.stderr, flush=True)
    answer = sys.stdin.readline().strip()
    if log_file is not None:
        log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} [PROMPT]  {message} {answer}\n")
        log_file.flush()
    return answer


def abort(message, verbosity=0):
    # The program cannot continue. Prints the message, then exits with status 1.
    tag = "[ABORT]   "
    if log_file is not None and verbosity <= log_verbosity:
        log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {tag}{message}\n")
        log_file.flush()
    quiet = message_verbosity is not None and verbosity > message_verbosity
    if not quiet:
        if sys.stderr.isatty():
            tag = f"\033[38;5;196m{tag}\033[0m"
        print(f"{tag}{message}", file=sys.stderr)
    sys.exit(1)


def error(message, verbosity=1):
    # Something went wrong, but the program can continue.
    tag = "[ERROR]   "
    if log_file is not None and verbosity <= log_verbosity:
        log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {tag}{message}\n")
        log_file.flush()
    if message_verbosity is not None and verbosity > message_verbosity:
        return
    if sys.stderr.isatty():
        tag = f"\033[38;5;160m{tag}\033[0m"
    print(f"{tag}{message}", file=sys.stderr)


def fail(message, verbosity=1):
    # Negative outcome of test or check
    tag = "[FAIL]    "
    if log_file is not None and verbosity <= log_verbosity:
        log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {tag}{message}\n")
        log_file.flush()
    if message_verbosity is not None and verbosity > message_verbosity:
        return
    if sys.stderr.isatty():
        tag = f"\033[38;5;202m{tag}\033[0m"
    print(f"{tag}{message}", file=sys.stderr)


def warn(message, verbosity=2):
    # Deserves attention: irreversible action, etc.
    tag = "[WARN]    "
    if log_file is not None and verbosity <= log_verbosity:
        log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {tag}{message}\n")
        log_file.flush()
    if message_verbosity is not None and verbosity > message_verbosity:
        return
    if sys.stderr.isatty():
        tag = f"\033[38;5;214m{tag}\033[0m"
    print(f"{tag}{message}", file=sys.stderr)


def status(message, verbosity=3):
    # Progress of program
    tag = "[STATUS]  "
    if log_file is not None and verbosity <= log_verbosity:
        log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {tag}{message}\n")
        log_file.flush()
    if message_verbosity is not None and verbosity > message_verbosity:
        return
    if sys.stdout.isatty():
        tag = f"\033[38;5;39m{tag}\033[0m"
    print(f"{tag}{message}")


def ok(message, verbosity=4):
    # Positive outcome of test or check.
    tag = "[OK]      "
    if log_file is not None and verbosity <= log_verbosity:
        log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {tag}{message}\n")
        log_file.flush()
    if message_verbosity is not None and verbosity > message_verbosity:
        return
    if sys.stdout.isatty():
        tag = f"\033[38;5;77m{tag}\033[0m"
    print(f"{tag}{message}")


def done(message, verbosity=5):
    # An action finished successfully.
    tag = "[DONE]    "
    if log_file is not None and verbosity <= log_verbosity:
        log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {tag}{message}\n")
        log_file.flush()
    if message_verbosity is not None and verbosity > message_verbosity:
        return
    if sys.stdout.isatty():
        tag = f"\033[38;5;34m{tag}\033[0m"
    print(f"{tag}{message}")


def info(message, verbosity=6):
    # Useful, but non-essential information.  Extra instructions, etc.
    tag = "[INFO]    "
    if log_file is not None and verbosity <= log_verbosity:
        log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {tag}{message}\n")
        log_file.flush()
    if message_verbosity is not None and verbosity > message_verbosity:
        return
    if sys.stdout.isatty():
        tag = f"\033[38;5;33m{tag}\033[0m"
    print(f"{tag}{message}")


def debug(message, verbosity=7):
    tag = "[DEBUG]   "
    if log_file is not None and verbosity <= log_verbosity:
        log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {tag}{message}\n")
        log_file.flush()
    if message_verbosity is not None and verbosity > message_verbosity:
        return
    if sys.stdout.isatty():
        tag = f"\033[38;5;99m{tag}\033[0m"
    print(f"{tag}{message}")


def trace(message, verbosity=8):
    # Help the user understand what the program is doing so they can learn from it.
    tag = "[TRACE]   "
    if log_file is not None and verbosity <= log_verbosity:
        log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {tag}{message}\n")
        log_file.flush()
    if message_verbosity is not None and verbosity > message_verbosity:
        return
    if sys.stdout.isatty():
        tag = f"\033[38;5;207m{tag}\033[0m"
    print(f"{tag}{message}")


def why(message, verbosity=9):
    # Help the user understand why the program is working the way it is so they can learn from it.
    tag = "[WHY]     "
    if log_file is not None and verbosity <= log_verbosity:
        log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {tag}{message}\n")
        log_file.flush()
    if message_verbosity is not None and verbosity > message_verbosity:
        return
    if sys.stdout.isatty():
        tag = f"\033[38;5;219m{tag}\033[0m"
    print(f"{tag}{message}")

