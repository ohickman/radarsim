# sim_protocol.py - the wire format between display and sim (BRIEF.md Section 7).
# Every frame: u32 length (bytes that follow), u8 type, payload. Little-endian.
# Type 1 = JSON object with a "t" field. Type 2 = SPOKES (binary radar video).
# Units: as named in each field (nm, s, hundredths of a degree).
# Called by: sim_main.py and the tests.

import json
import struct

import numpy as np

FRAME_JSON = 1
FRAME_SPOKES = 2
MAX_FRAME_BYTES = 8 * 1024 * 1024    # largest value allowed in the length field
PROTOCOL_VERSION = 1

SPOKES_HEADER = struct.Struct("<HHf")   # spoke_count, bins_per_spoke, video_range_nm


class ProtocolError(Exception):
    pass


def read_exact(sock, byte_count):
    # recv may return fewer bytes than asked for (a short read), so loop.
    data = bytearray()
    while len(data) < byte_count:
        chunk = sock.recv(byte_count - len(data))
        if not chunk:
            raise ConnectionError("connection closed by the other side")
        data += chunk
    return bytes(data)


def read_frame(sock):
    # Returns (frame_type, payload bytes). Blocks until a whole frame has arrived.
    (length,) = struct.unpack("<I", read_exact(sock, 4))
    if length < 1 or length > MAX_FRAME_BYTES:
        raise ProtocolError("frame length %d is outside 1..%d bytes" % (length, MAX_FRAME_BYTES))
    body = read_exact(sock, length)
    return body[0], body[1:]


def write_frame(sock, frame_type, payload):
    length = 1 + len(payload)
    if length > MAX_FRAME_BYTES:
        raise ProtocolError("frame of %d bytes is larger than %d" % (length, MAX_FRAME_BYTES))
    sock.sendall(struct.pack("<IB", length, frame_type) + payload)


def encode_json(message):
    return json.dumps(message, separators=(",", ":")).encode("utf-8")


def decode_json(payload):
    message = json.loads(payload.decode("utf-8"))
    if not isinstance(message, dict) or "t" not in message:
        raise ProtocolError("JSON frame is not an object with a 't' field")
    return message


def send_json(sock, message):
    write_frame(sock, FRAME_JSON, encode_json(message))


def spoke_record_type(bins_per_spoke):
    # One spoke as numpy sees it: packed, little-endian, no padding.
    return np.dtype([
        ("azimuth_index", "<u2"),
        ("gyro_heading_cdeg", "<u2"),      # hundredths of a degree, 0..35999
        ("sim_time_s", "<f8"),              # f64: f32 is too coarse after a few sim-hours
        ("ref_x_nm", "<f4"),
        ("ref_y_nm", "<f4"),
        ("video", "u1", (bins_per_spoke,)),
    ])


def pack_spokes(video_range_nm, azimuth_index, gyro_heading_cdeg, sim_time_s,
                ref_x_nm, ref_y_nm, video):
    # video is a 2D uint8 array, one row per spoke. The other arguments are
    # one value per spoke, except video_range_nm (one for the frame).
    spoke_count, bins_per_spoke = video.shape
    records = np.zeros(spoke_count, dtype=spoke_record_type(bins_per_spoke))
    records["azimuth_index"] = azimuth_index
    records["gyro_heading_cdeg"] = gyro_heading_cdeg
    records["sim_time_s"] = sim_time_s
    records["ref_x_nm"] = ref_x_nm
    records["ref_y_nm"] = ref_y_nm
    records["video"] = video
    return SPOKES_HEADER.pack(spoke_count, bins_per_spoke, video_range_nm) + records.tobytes()


def unpack_spokes(payload):
    # Returns a dict with video_range_nm and one array per spoke field.
    if len(payload) < SPOKES_HEADER.size:
        raise ProtocolError("SPOKES payload is shorter than its header")
    spoke_count, bins_per_spoke, video_range_nm = SPOKES_HEADER.unpack_from(payload, 0)
    record_type = spoke_record_type(bins_per_spoke)
    expected_bytes = SPOKES_HEADER.size + spoke_count * record_type.itemsize
    if len(payload) != expected_bytes:
        raise ProtocolError("SPOKES payload is %d bytes, expected %d" % (len(payload), expected_bytes))
    records = np.frombuffer(payload, dtype=record_type, count=spoke_count, offset=SPOKES_HEADER.size)
    return {
        "video_range_nm": video_range_nm,
        "azimuth_index": records["azimuth_index"].copy(),
        "gyro_heading_cdeg": records["gyro_heading_cdeg"].copy(),
        "sim_time_s": records["sim_time_s"].copy(),
        "ref_x_nm": records["ref_x_nm"].copy(),
        "ref_y_nm": records["ref_y_nm"].copy(),
        "video": records["video"].copy(),
    }
