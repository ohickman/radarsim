# sim_main.py - entry point of the sim: config, clock, TCP server, message dispatch.
# Started by the display as: python sim/sim_main.py --config <root>/radarsim.toml
# Units: sim time in s; wall time in s; speed multiplier = sim seconds per wall second.
# Called by: the display (as a child process), or by hand, or by the tests.

import argparse
import collections
import base64
import math
import os
import queue
import socket
import sys
import threading
import time

import numpy as np

import messages
import sim_arpa
import sim_chart
import sim_commands
import sim_config
import sim_contacts
import sim_environment
import sim_game
import sim_land
import sim_ownship
import sim_protocol
import sim_radar
from sim_common import CONFIG_FILE_NAME, find_project_root, make_random_streams

STATE_INTERVAL_WALL_S = 0.1      # state goes out 10 times per wall second (BRIEF.md Section 7)
ACHIEVED_WINDOW_WALL_S = 2.0     # achieved speed is measured over the last 2 s of wall time
MAX_BACKLOG_WALL_S = 0.25        # chosen, not from a source: if the PC falls further behind
                                 # than this, the sim clock runs slower instead of catching up
SPEED_PATH = "general.sim_speed_multiplier"
OUTBOX_FRAMES = 400              # chosen: frames that may wait for a slow display before any are dropped ...
OUTBOX_SPOKES_LIMIT = 100        # ... and radar video is dropped first, from this many waiting frames
SPOKES_PER_FRAME = 64            # a SPOKES frame carries at most this many spokes (BRIEF.md Section 15, M4)
TRUTH_INTERVAL_WALL_S = 0.2      # truth goes out 5 times per wall second, only while enabled
VIEW_INTERVAL_WALL_S = 0.2       # the wheelhouse view's data goes out 5 times per wall second, only while enabled
LAND_VIEW_CELLS = 600            # chosen: the land raster is sent to the wheelhouse view at about this many cells a side ...
LAND_VIEW_HEIGHT_STEP_M = 2.0    # ... one byte per cell, in steps of 2 m (up to 510 m)
OWN_TRACK_INTERVAL_S = 30.0      # chosen: own-ship ground track for the overlay, a point every 30 s of sim time ...
OWN_TRACK_POINTS = 240           # ... and the last 240 of them (2 hours)


def number_in(message, key):
    # A number from a message of the display, or None if it is missing or not a number.
    value = message.get(key)
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value != value:
        return None
    return float(value)


def pick_seed(seed):
    # Seed 0 means: pick one at random, and print it so the run can be repeated.
    if seed == 0:
        seed = int(np.random.SeedSequence().generate_state(1)[0])
        messages.status("Seed %d (picked at random; put it in general.seed to repeat this run)" % seed)
    else:
        messages.status("Seed %d" % seed)
    return seed


def serve_connections(server_socket, inbox):
    # Background thread. Accepts one display at a time, reads its frames and puts
    # them in the inbox for the main loop. The main loop does all the sending.
    while True:
        try:
            client, address = server_socket.accept()
        except OSError:
            return
        client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        inbox.put(("connected", client))
        try:
            while True:
                frame_type, payload = sim_protocol.read_frame(client)
                inbox.put(("frame", client, frame_type, payload))
        except (OSError, sim_protocol.ProtocolError) as error:
            reason = str(error)
        inbox.put(("disconnected", client, reason))


def send_frames(outbox):
    # Background thread. Sends the queued frames, each to the display it was meant for.
    while True:
        client, frame_type, payload = outbox.get()
        try:
            sim_protocol.write_frame(client, frame_type, payload)
        except OSError:
            pass                             # that display has gone; the reader thread reports it


def watch_stdin(inbox):
    # Background thread. The display holds our stdin open; when the display goes
    # away (even by crashing) stdin closes and the sim must exit.
    # os.read on the raw handle, not sys.stdin.read: a thread blocked inside
    # sys.stdin holds its lock and makes Python abort when the sim exits.
    try:
        stdin_handle = sys.stdin.fileno()
        while os.read(stdin_handle, 1024):
            pass
    except (OSError, ValueError, AttributeError):
        pass
    inbox.put(("stdin_closed",))


class Sim:
    def __init__(self, cfg, seed):
        self.cfg = cfg
        self.seed = seed
        self.physics_step_s = cfg["general"]["physics_step_s"]
        self.step_count = 0              # sim_time_s = step_count x physics_step_s, so no rounding drift
        self.sim_time_s = 0.0
        self.owed_sim_s = 0.0            # sim time the clock owes that is not yet stepped
        self.paused = False
        self.speed_achieved = 0.0
        self.clock_samples = collections.deque()   # (wall_s, sim_time_s) for the achieved speed
        self.client = None               # the connected display's socket, or None
        self.running = True

        self.truth_enabled = False       # instructor overlay data on or off
        self.view_enabled = False        # the wheelhouse view is open: send it the `view` message
        self.land_view = None            # the `land_view` message of this run, built when first needed
        self.outbox = queue.Queue(maxsize=OUTBOX_FRAMES)
        threading.Thread(target=send_frames, args=(self.outbox,), daemon=True).start()
        self.start_run(seed, cfg["general"]["scenario"])

    def start_run(self, seed, scenario):
        # Builds the world for a run: at start-up and on "new_run". Runtime settings
        # made so far are kept. The land comes first: it is the only part that can
        # fail, and then the old run is left as it was.
        cfg = self.cfg
        streams = make_random_streams(seed)
        if scenario == "random":
            land = sim_land.generate_land(cfg, streams["land"])
        else:
            land = sim_land.make_open_sea(cfg)

        self.seed = seed
        cfg["general"]["scenario"] = scenario
        self.random_streams = streams
        self.land = land
        self.land_view = None
        self.step_count = 0
        self.sim_time_s = 0.0
        self.owed_sim_s = 0.0
        self.clock_samples.clear()

        # Own ship: the calibration scenario fixes its start; otherwise open water near
        # a lane ("auto") or the configured place.
        own = cfg["own_ship"]
        if scenario == "calibration":
            sim_contacts.apply_calibration_environment(cfg)
            start_x_nm, start_y_nm, start_heading_deg, start_speed_kn = sim_contacts.CALIBRATION_OWN_START
        elif own["start"] == "auto" and land.lanes:
            start_x_nm, start_y_nm, start_heading_deg = land.find_start(streams["own_ship"])
            start_speed_kn = own["start_speed_kn"]
        else:
            start_x_nm, start_y_nm, start_heading_deg = own["start_x_nm"], own["start_y_nm"], own["start_heading_deg"]
            start_speed_kn = own["start_speed_kn"]
        messages.info("Scenario %s, seed %d: own ship starts at x %.2f nm, y %.2f nm, heading %05.1f deg true, %.1f kn" % (
            scenario, seed, start_x_nm, start_y_nm, start_heading_deg, start_speed_kn))
        self.own_ship = sim_ownship.OwnShip(cfg, streams["own_ship"], start_x_nm, start_y_nm,
                                            start_heading_deg, start_speed_kn)
        self.environment = sim_environment.Environment(cfg, streams["environment"], start_x_nm, start_y_nm)
        self.traffic = sim_contacts.Traffic(cfg, streams["traffic"], land, self.environment)
        if scenario == "calibration":
            sim_contacts.add_calibration_contacts(self.traffic)
        if cfg["general"]["write_chart"]:
            self.write_chart(seed, scenario, (start_x_nm, start_y_nm, start_heading_deg))
        self.own_track = [[round(start_x_nm, 3), round(start_y_nm, 3)]]     # ground track for the instructor overlay
        self.radar_video = sim_radar.RadarVideo(cfg, streams["radar"], land, self.environment)
        self.arpa = sim_arpa.Arpa(cfg, streams["arpa"])
        self.game = sim_game.Game(cfg)
        self.snapshot = self.take_snapshot()

    def write_chart(self, seed, scenario, own_start, now=False):
        # A practice chart of this run's land, lanes and buoys (sim_chart.py). It must never stop a run.
        # now: asked for by the display; own ship is drawn where it is, with its track. Returns the path or None.
        try:
            buoys = [(contact.x_nm, contact.y_nm, contact.name or "buoy", "", "") for contact in self.traffic.contacts if contact.kind == "buoy"]
            buoys += [(mark.x_nm, mark.y_nm, mark.name, mark.colour, mark.light["code"]) for mark in self.traffic.marks]
            file_name = self.cfg["general"]["chart_file"].replace("{seed}", str(seed))
            path = file_name if os.path.isabs(file_name) else os.path.join(find_project_root(), file_name)
            if now:
                sim_chart.write_chart(path, self.land, self.cfg, seed, scenario, own_start, buoys, self.own_track, "Own ship")
            else:
                sim_chart.write_chart(path, self.land, self.cfg, seed, scenario, own_start, buoys)
            messages.done("Chart written to %s (open it in a browser)" % path)
            return path
        except Exception as error:
            messages.warn("The chart could not be written: %s" % error)
            return None

    # ---- clock ----

    def advance_clock(self, elapsed_wall_s):
        if self.paused:
            return
        multiplier = self.cfg["general"]["sim_speed_multiplier"]
        self.owed_sim_s += elapsed_wall_s * multiplier
        # A PC that cannot keep up makes the sim run slower. No physics step is skipped.
        most_owed_sim_s = max(self.physics_step_s, MAX_BACKLOG_WALL_S * multiplier)
        self.owed_sim_s = min(self.owed_sim_s, most_owed_sim_s)
        while self.owed_sim_s >= self.physics_step_s and not self.paused:     # a game event may pause the sim
            self.physics_step()
            self.owed_sim_s -= self.physics_step_s

    def physics_step(self):
        current_set_deg_true, current_drift_kn = self.environment.current()
        self.own_ship.step(self.physics_step_s, current_set_deg_true, current_drift_kn)
        own = self.own_ship
        self.environment.step(self.physics_step_s, own.x_nm, own.y_nm)
        self.traffic.step(self.physics_step_s, self.sim_time_s, own.x_nm, own.y_nm, own.ground_vx_kn, own.ground_vy_kn)
        self.step_count += 1
        self.sim_time_s = self.step_count * self.physics_step_s
        self.radar_step()
        for kind, text in self.game.check(own, self.traffic.everything(), self.land):
            self.handle_game_event(kind, text)
        if self.sim_time_s >= len(self.own_track) * OWN_TRACK_INTERVAL_S:
            self.own_track.append([round(own.x_nm, 3), round(own.y_nm, 3)])

    def handle_game_event(self, kind, text):
        # Collision or grounding. The display shows the text in its message pane and status
        # line. With on_collision or on_grounding = "stop" the sim pauses; P resumes.
        stop = self.cfg["game"]["on_" + kind] == "stop"
        messages.warn(text + (": the sim is paused, P resumes" if stop else ""), verbosity=8)    # the display prints it too
        self.send({"t": "event", "kind": kind, "text": text})
        if stop:
            self.paused = True
            self.owed_sim_s = 0.0

    def take_snapshot(self):
        # The world as the radar needs it, at the present sim time.
        own = self.own_ship
        ref_x_nm, ref_y_nm = own.reference_position(self.cfg["arpa"]["stabilization"])
        ids, xs, ys, rcss, heights = sim_radar.scatterers_of(self.traffic.everything())
        return sim_radar.Snapshot(self.sim_time_s, own.x_nm, own.y_nm, own.heading_deg_true, own.gyro_heading_deg,
                                  ref_x_nm, ref_y_nm, ids, xs, ys, rcss, heights)

    def radar_step(self):
        # The spokes the antenna swept during this physics step go to the display and
        # to the ARPA, which works from the same video. With no display and nothing
        # for the ARPA to watch, no radar work is done.
        before = self.snapshot
        self.snapshot = self.take_snapshot()
        if self.client is not None or self.arpa.wants_video():
            spokes = self.radar_video.make_spokes(before, self.snapshot)
            if spokes is not None:
                self.arpa.add_spokes(spokes, self.radar_video.pulse_bins())
                self.send_spokes(spokes)
        self.arpa.step(sim_arpa.own_data_from(self.own_ship, self.sim_time_s))
        self.send_arpa_news()

    def send_spokes(self, spokes):
        if self.client is None:
            return
        for first in range(0, len(spokes["azimuth_index"]), SPOKES_PER_FRAME):
            last = first + SPOKES_PER_FRAME
            payload = sim_protocol.pack_spokes(
                spokes["video_range_nm"], spokes["azimuth_index"][first:last], spokes["gyro_heading_cdeg"][first:last],
                spokes["sim_time_s"][first:last], spokes["ref_x_nm"][first:last], spokes["ref_y_nm"][first:last],
                spokes["video"][first:last])
            self.queue_frame(sim_protocol.FRAME_SPOKES, payload, True)

    def send_arpa_news(self):
        # "targets" once per antenna revolution (and at once after an acquisition or a
        # cancel); "alarms" whenever the list has changed.
        if self.arpa.targets_due:
            self.arpa.targets_due = False
            self.send(self.arpa.targets_message())
        if self.arpa.alarms_changed:
            self.arpa.alarms_changed = False
            self.send(self.arpa.alarms_message())

    def measure_achieved_speed(self, wall_s):
        self.clock_samples.append((wall_s, self.sim_time_s))
        while len(self.clock_samples) > 2 and wall_s - self.clock_samples[1][0] >= ACHIEVED_WINDOW_WALL_S:
            self.clock_samples.popleft()
        oldest_wall_s, oldest_sim_time_s = self.clock_samples[0]
        if wall_s > oldest_wall_s:
            self.speed_achieved = (self.sim_time_s - oldest_sim_time_s) / (wall_s - oldest_wall_s)

    # ---- messages out ----

    def send(self, message):
        self.queue_frame(sim_protocol.FRAME_JSON, sim_protocol.encode_json(message), False)

    def queue_frame(self, frame_type, payload, may_drop):
        # Frames go to the display through a queue and a sender thread, so a display
        # that has stopped reading can never hold up the sim. Radar video is dropped
        # when the display falls behind; everything is dropped when the queue is full.
        if self.client is None:
            return
        if may_drop and self.outbox.qsize() >= OUTBOX_SPOKES_LIMIT:
            return
        try:
            self.outbox.put_nowait((self.client, frame_type, payload))
        except queue.Full:
            pass

    def hello_message(self):
        cfg = self.cfg
        own_ship = {"length_m": cfg["own_ship"]["length_m"], "beam_m": cfg["own_ship"]["beam_m"],
                    "speed_command_mode": cfg["own_ship"]["speed_command_mode"]}
        for key, value in cfg["own_ship"].items():
            if key.startswith("telegraph_"):
                own_ship[key] = value
        radar = {}
        for key in ["azimuth_bins", "range_bins", "range_scales_nm", "antenna_rpm", "offset_max_fraction"]:
            radar[key] = cfg["radar"][key]
        return {
            "t": "hello",
            "protocol": sim_protocol.PROTOCOL_VERSION,
            "seed": self.seed,
            "scenario": cfg["general"]["scenario"],
            "radar": radar,
            "display": cfg["display"],
            "controls": sim_config.runtime_controls(cfg),
            "own_ship": own_ship,
        }

    def state_message(self):
        return {
            "t": "state",
            "sim_time_s": round(self.sim_time_s, 3),
            "speed_requested": self.cfg["general"]["sim_speed_multiplier"],
            "speed_achieved": round(self.speed_achieved, 2),
            "paused": self.paused,
            "own": self.own_ship.state_for_display(),
            "env": self.environment.state_for_display(),
        }

    def truth_message(self):
        return {"t": "truth", "contacts": self.traffic.truth_for_display(),
                "own_track": self.own_track[-OWN_TRACK_POINTS:]}

    def land_view_message(self):
        # The land for the wheelhouse view's skyline: the raster pooled to about LAND_VIEW_CELLS a side
        # (the highest cell of each block), one byte per cell in steps of LAND_VIEW_HEIGHT_STEP_M,
        # row 0 = south, as base64. Open sea sends no cells. Built once per run.
        if self.land_view is None:
            land = self.land
            if land.cells < 100:
                self.land_view = {"t": "land_view", "size": 0, "cell_nm": 0.0, "west_nm": 0.0, "south_nm": 0.0,
                                  "height_step_m": LAND_VIEW_HEIGHT_STEP_M, "data": ""}
            else:
                block = max(1, int(math.ceil(land.cells / LAND_VIEW_CELLS)))
                size = int(math.ceil(land.cells / block))
                padded = np.zeros((size * block, size * block), dtype=np.int16)
                padded[:land.cells, :land.cells] = land.heights_m
                pooled = padded.reshape(size, block, size, block).max(axis=(1, 3))
                steps = np.minimum(np.ceil(np.maximum(pooled, 0) / LAND_VIEW_HEIGHT_STEP_M), 255).astype(np.uint8)
                self.land_view = {"t": "land_view", "size": size, "cell_nm": block * land.cell_nm,
                                  "west_nm": -land.extent_nm / 2.0, "south_nm": -land.extent_nm / 2.0,
                                  "height_step_m": LAND_VIEW_HEIGHT_STEP_M,
                                  "data": base64.b64encode(steps.tobytes()).decode("ascii")}
        return self.land_view

    def view_message(self):
        # What the wheelhouse view needs 5 times a second: where own ship is and where every contact is.
        own = self.own_ship
        return {"t": "view",
                "own": {"x_nm": round(own.x_nm, 4), "y_nm": round(own.y_nm, 4),
                        "heading_deg_true": round(own.heading_deg_true, 2), "gyro_heading_deg": round(own.gyro_heading_deg, 2)},
                "env": self.environment.state_for_display(),
                "rain": self.environment.rain_for_display(own.x_nm, own.y_nm),
                "contacts": self.traffic.truth_for_display()}

    # ---- messages in ----

    def handle_inbox_item(self, item):
        kind = item[0]
        if kind == "connected":
            self.client = item[1]
            messages.status("Display connected")
            self.send(self.hello_message())
            self.send(self.land_view_message())
            self.send(self.arpa.alarms_message())
        elif kind == "disconnected":
            if item[1] is self.client:
                self.client = None
                self.view_enabled = False
            item[1].close()
            messages.status("Display disconnected (%s); waiting for a display" % item[2])
        elif kind == "stdin_closed":
            messages.status("stdin closed (display gone); the sim exits")
            self.running = False
        elif kind == "frame":
            self.handle_frame(item[2], item[3])

    def handle_frame(self, frame_type, payload):
        if frame_type != sim_protocol.FRAME_JSON:
            messages.warn("Frame of type %d from the display ignored" % frame_type)
            return
        try:
            message = sim_protocol.decode_json(payload)
        except (ValueError, sim_protocol.ProtocolError) as error:
            messages.warn("Bad JSON frame from the display ignored: %s" % error)
            return

        name = message["t"]
        if name == "set":
            self.handle_set(message.get("path"), message.get("value"))
        elif name == "order":
            self.handle_order(str(message.get("text", "")))
        elif name == "pause":
            self.paused = bool(message.get("paused"))
            messages.status("Paused" if self.paused else "Resumed")
        elif name == "truth":
            self.truth_enabled = bool(message.get("enabled"))
        elif name == "view":
            self.view_enabled = bool(message.get("enabled"))
        elif name == "new_run":
            self.handle_new_run(message.get("seed", 0), message.get("scenario", self.cfg["general"]["scenario"]))
        elif name == "acquire":
            range_nm = number_in(message, "range_nm")
            bearing_deg_true = number_in(message, "bearing_deg_true")
            if range_nm is not None and bearing_deg_true is not None:
                self.arpa.acquire(range_nm, bearing_deg_true % 360.0)
        elif name == "cancel_target":
            self.arpa.cancel_target(message.get("id"))
        elif name == "cancel_all_targets":
            self.arpa.cancel_all_targets()
        elif name == "ack_alarm":
            self.arpa.acknowledge(message.get("id", "all"))
        elif name == "guard_zone":
            self.handle_guard_zone(message)
        elif name == "trial":
            self.handle_trial(message)
        elif name == "traffic_now":
            added, removed = self.traffic.fill_now()
            self.send({"t": "log", "text": "Traffic set to %d contacts (%d added, %d removed)" % (len(self.traffic.contacts), added, removed)}
                      if self.traffic.spawning else {"t": "log", "text": "This scenario has no random traffic"})
        elif name == "chart":
            own = self.own_ship
            path = self.write_chart(self.seed, self.cfg["general"]["scenario"], (own.x_nm, own.y_nm, own.heading_deg_true), True)
            if path is None:
                self.send({"t": "log", "text": "The chart could not be written; see the sim's console"})
            else:
                self.send({"t": "chart", "path": path})
        elif name == "quit":
            messages.status("Quit received; the sim exits")
            self.running = False
        else:
            messages.warn("Message '%s' is not handled yet" % name)

    def handle_order(self, text):
        # Typed orders and telegraph buttons both arrive here. One log line answers each.
        order = sim_commands.parse_order(text, self.cfg)
        if isinstance(order, str):
            self.send({"t": "log", "text": order})
            return
        self.own_ship.apply_order(order)
        self.send({"t": "log", "text": order["echo"]})

    def handle_guard_zone(self, message):
        values = [number_in(message, key) for key in ("inner_nm", "outer_nm", "start_deg", "end_deg")]
        if message.get("index") not in (1, 2) or None in values:
            messages.warn(f"guard_zone message not understood: {message}")
            return
        self.arpa.set_guard_zone(message["index"], bool(message.get("enabled")), values[0], values[1], values[2], values[3])

    def handle_trial(self, message):
        if not message.get("enabled"):
            self.arpa.set_trial(False, 0.0, 0.0, 0.0)
            return
        values = [number_in(message, key) for key in ("course_deg_true", "speed_kn", "delay_s")]
        if None in values:
            messages.warn(f"trial message not understood: {message}")
            return
        self.arpa.set_trial(True, values[0], values[1], values[2])

    def handle_new_run(self, seed, scenario):
        # Restarts the world. Seed 0 picks a new random seed.
        if scenario not in ("random", "calibration") or isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
            self.send({"t": "log", "text": "new_run not understood: seed %r, scenario %r" % (seed, scenario)})
            return
        try:
            self.start_run(pick_seed(seed), scenario)
        except sim_land.LandError as error:
            messages.error(str(error))
            self.send({"t": "log", "text": str(error)})
            return
        self.send(self.hello_message())
        self.send(self.land_view_message())
        self.send(self.arpa.alarms_message())

    def handle_set(self, path, value):
        # Every (runtime) key. The radar and the ARPA read their settings from the
        # config when they use them, so a change takes effect at once. The display.*
        # keys other than the range scale are only checked, stored and echoed: the
        # display itself acts on them.
        if not isinstance(path, str) or path not in sim_config.RUNTIME_KEYS:
            messages.warn("set %s: not a (runtime) key" % path)
            return
        confirmed, note = sim_config.set_runtime_value(self.cfg, path, value)
        if note:
            messages.warn(note)
        if path == "environment.sea_state_douglas" and self.cfg["environment"]["sea_state_from_wind"]:
            # A hand-set sea state replaces the one derived from the wind.
            self.cfg["environment"]["sea_state_from_wind"] = False
            self.send({"t": "setting", "path": "environment.sea_state_from_wind", "value": False})
            self.send({"t": "log", "text": "Sea state from wind is off: the sea state is now set by hand."})
        if path == "arpa.stabilization" and confirmed != self.arpa.stabilization:
            # The snapshot in hand carries the reference position of the old frame.
            self.snapshot = self.take_snapshot()
            self.arpa.set_stabilization(confirmed)
        self.send({"t": "setting", "path": path, "value": confirmed})

    # ---- main loop ----

    def run(self, inbox, headless_test_s):
        start_wall_s = time.perf_counter()
        last_wall_s = start_wall_s
        next_state_wall_s = start_wall_s
        next_truth_wall_s = start_wall_s
        next_view_wall_s = start_wall_s
        while self.running:
            # Sleep until the next physics step or state message is due, or a message arrives.
            now_wall_s = time.perf_counter()
            wait_s = next_state_wall_s - now_wall_s
            if not self.paused:
                multiplier = self.cfg["general"]["sim_speed_multiplier"]
                step_due_s = (self.physics_step_s - self.owed_sim_s) / multiplier   # sim s -> wall s
                wait_s = min(wait_s, step_due_s)
            wait_s = max(wait_s, 0.001)
            try:
                self.handle_inbox_item(inbox.get(timeout=wait_s))
                while True:
                    self.handle_inbox_item(inbox.get_nowait())
            except queue.Empty:
                pass

            now_wall_s = time.perf_counter()
            self.advance_clock(now_wall_s - last_wall_s)
            last_wall_s = now_wall_s

            if now_wall_s >= next_state_wall_s:
                self.measure_achieved_speed(now_wall_s)
                self.send(self.state_message())
                next_state_wall_s += STATE_INTERVAL_WALL_S
                if next_state_wall_s < now_wall_s:
                    next_state_wall_s = now_wall_s + STATE_INTERVAL_WALL_S

            if self.truth_enabled and self.client is not None and now_wall_s >= next_truth_wall_s:
                self.send(self.truth_message())
                next_truth_wall_s = max(next_truth_wall_s + TRUTH_INTERVAL_WALL_S, now_wall_s)

            if self.view_enabled and self.client is not None and now_wall_s >= next_view_wall_s:
                self.send(self.view_message())
                next_view_wall_s = max(next_view_wall_s + VIEW_INTERVAL_WALL_S, now_wall_s)

            if headless_test_s is not None and now_wall_s - start_wall_s >= headless_test_s:
                wall_s = now_wall_s - start_wall_s
                messages.ok("Headless test: sim time %.1f s in %.2f s of wall time, speed requested %.1f x, "
                            "achieved %.2f x" % (self.sim_time_s, wall_s,
                                                 self.cfg["general"]["sim_speed_multiplier"],
                                                 self.sim_time_s / wall_s), verbosity=0)
                self.running = False


def main():
    parser = argparse.ArgumentParser(description="Marine radar and ARPA simulator (sim side)")
    parser.add_argument("--config", help="path of radarsim.toml (default: <root>/radarsim.toml)")
    parser.add_argument("--root", help="project folder (default: found by walking up from this file)")
    parser.add_argument("--port", type=int, help="TCP port on 127.0.0.1 (default: general.port)")
    parser.add_argument("--headless-test", type=float, metavar="SECONDS",
                        help="run for this many wall-clock seconds, report the sim time, exit")
    args = parser.parse_args()

    try:
        config_path = args.config
        if config_path is None:
            root = args.root if args.root else find_project_root()
            config_path = os.path.join(root, CONFIG_FILE_NAME)
        cfg = sim_config.load_config(config_path)
    except (sim_config.ConfigError, FileNotFoundError) as error:
        messages.abort(str(error))
    messages.message_verbosity = cfg["general"]["message_verbosity"]
    messages.done("Config loaded from %s" % config_path)

    seed = pick_seed(cfg["general"]["seed"])

    port = args.port if args.port else cfg["general"]["port"]
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    if os.name != "nt":
        # Lets a restarted sim reuse the port at once. Not on Windows, where this
        # option would let two sims share one port.
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        server_socket.bind(("127.0.0.1", port))
    except OSError as error:
        messages.abort("Cannot listen on 127.0.0.1:%d (%s). Is another sim running? "
                       "Close it, or change general.port in %s." % (port, error, config_path))
    server_socket.listen(1)
    messages.status("Listening on 127.0.0.1:%d" % port)

    inbox = queue.Queue()
    threading.Thread(target=serve_connections, args=(server_socket, inbox), daemon=True).start()
    if args.headless_test is None:
        threading.Thread(target=watch_stdin, args=(inbox,), daemon=True).start()

    # The port is open before the land is made, so the display can connect while it waits.
    try:
        sim = Sim(cfg, seed)
    except sim_land.LandError as error:
        messages.abort(str(error))
    try:
        sim.run(inbox, args.headless_test)
    except KeyboardInterrupt:
        messages.status("Interrupted; the sim exits")
    return 0


if __name__ == "__main__":
    sys.exit(main())
