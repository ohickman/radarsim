# sim_commands.py - turns a typed or button order ("port 10", "heading 248",
# "half ahead") into an order for the own-ship model (BRIEF.md Section 8.1).
# Units: rudder and heading in degrees, speed in knots.
# Called by: sim_main.py for every "order" message, and the tests.

import math

# Words that carry no meaning in an order and are dropped before parsing.
FILLER_WORDS = ["degrees", "degree", "deg", "aye", "please", "rudder", "helm", "to",
                "knots", "knot", "kn", "kts", "engine", "engines", "the", "come"]

# Telegraph order -> (config key in [own_ship], +1 ahead or -1 astern, echo text).
TELEGRAPH_ORDERS = {
    "full ahead": ("telegraph_full_ahead_kn", 1.0, "Full ahead"),
    "half ahead": ("telegraph_half_ahead_kn", 1.0, "Half ahead"),
    "slow ahead": ("telegraph_slow_ahead_kn", 1.0, "Slow ahead"),
    "dead slow ahead": ("telegraph_dead_slow_ahead_kn", 1.0, "Dead slow ahead"),
    "slow astern": ("telegraph_slow_astern_kn", -1.0, "Slow astern"),
    "half astern": ("telegraph_half_astern_kn", -1.0, "Half astern"),
    "full astern": ("telegraph_full_astern_kn", -1.0, "Full astern"),
}


def read_number(word):
    # A plain number, or None. "ten", "nan" and "inf" are not numbers here.
    try:
        number = float(word)
    except ValueError:
        return None
    if not math.isfinite(number):
        return None
    return number


def number_text(number):
    return "%g" % round(number, 2)


def heading_text(heading_deg):
    # Headings are spoken with three digits: 005, 248, 090.5.
    if heading_deg == int(heading_deg):
        return "%03d" % int(heading_deg)
    return "%05.1f" % heading_deg


def parse_order(text, cfg):
    # Returns an order (a dict with "kind", its values, and "echo" for the message
    # pane) or an error string. Kinds:
    #   rudder   rudder_deg (+ starboard, - port); cancels a heading order
    #   heading  heading_deg (on the gyro compass)
    #   steady   steer the heading the ship will reach with the rudder amidships now
    #   speed    speed_kn (through the water, - astern)
    own = cfg["own_ship"]
    not_understood = "Not understood: " + text.strip()
    words = [word for word in text.lower().replace(",", " ").split() if word not in FILLER_WORDS]
    if not words:
        return not_understood
    phrase = " ".join(words)
    if words[0] == "stbd":
        words[0] = "starboard"
    if len(words) == 2 and words[1] == "stbd":
        words[1] = "starboard"

    # ---- rudder ----
    if phrase in ["midships", "amidships"]:
        return {"kind": "rudder", "rudder_deg": 0.0, "echo": "Midships"}
    if len(words) == 2 and words[0] == "hard" and words[1] in ["port", "starboard"]:
        sign = -1.0 if words[1] == "port" else 1.0
        return {"kind": "rudder", "rudder_deg": sign * own["max_rudder_deg"], "echo": "Hard " + words[1]}
    if len(words) == 2 and words[0] in ["port", "starboard"]:
        angle_deg = read_number(words[1])
        if angle_deg is None or angle_deg < 0.0:
            return not_understood
        sign = -1.0 if words[0] == "port" else 1.0
        if angle_deg > own["max_rudder_deg"]:
            return {"kind": "rudder", "rudder_deg": sign * own["max_rudder_deg"],
                    "echo": "Rudder limited to " + number_text(own["max_rudder_deg"])}
        return {"kind": "rudder", "rudder_deg": sign * angle_deg,
                "echo": words[0].capitalize() + " " + number_text(angle_deg)}

    # ---- heading ----
    if phrase == "steady":
        return {"kind": "steady", "echo": "Steady"}
    if len(words) == 2 and words[0] in ["heading", "steer"]:
        heading_deg = read_number(words[1])
        if heading_deg is None or heading_deg < 0.0 or heading_deg > 360.0:
            return not_understood
        heading_deg = heading_deg % 360.0          # 360 is the same heading as 000
        return {"kind": "heading", "heading_deg": heading_deg, "echo": "Heading " + heading_text(heading_deg)}

    # ---- speed ----
    mode = own["speed_command_mode"]
    if len(words) == 2 and words[0] == "speed":
        speed_kn = read_number(words[1])
        if speed_kn is None:
            return not_understood
        if mode == "telegraph":
            return "Speed orders in knots not enabled"
        if speed_kn > own["max_speed_ahead_kn"]:
            speed_kn = own["max_speed_ahead_kn"]
            return {"kind": "speed", "speed_kn": speed_kn, "echo": "Speed limited to " + number_text(speed_kn)}
        if speed_kn < -own["max_speed_astern_kn"]:
            speed_kn = -own["max_speed_astern_kn"]
            return {"kind": "speed", "speed_kn": speed_kn,
                    "echo": "Speed limited to " + number_text(-speed_kn) + " astern"}
        return {"kind": "speed", "speed_kn": speed_kn, "echo": "Speed " + number_text(speed_kn) + " kn"}
    if phrase == "stop" or phrase in TELEGRAPH_ORDERS:
        if mode == "knots":
            return "Telegraph orders not enabled"
        if phrase == "stop":
            return {"kind": "speed", "speed_kn": 0.0, "echo": "Stop"}
        key, sign, name = TELEGRAPH_ORDERS[phrase]
        return {"kind": "speed", "speed_kn": sign * own[key], "echo": name + ", " + number_text(own[key]) + " kn"}

    return not_understood
