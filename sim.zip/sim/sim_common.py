# sim_common.py - shared helpers for the sim: unit conversions,
# angle helpers, lat/lon <-> local x/y, project root.
# Units: distance nm, speed kn, time s, angles degrees (true = clockwise from north).
# Called by: every sim file and the tests. The helpers accept floats or numpy arrays.

import math
import os

import numpy as np

# ---- unit constants (BRIEF.md Section 5) ----
M_PER_NM = 1852.0                # 1 nm = 1852 m
S_PER_H = 3600.0                 # a knot is one nm per hour
S_PER_MIN = 60.0
NM_PER_DEG_LAT = 60.0            # 1 degree of latitude = 60 nm
M_PER_US_PULSE = 149.9           # range covered by 1 us of pulse length, c * tau / 2
NM_PER_US_PULSE = 0.0809         # the same in nm (149.9 m / 1852 m)
RADAR_MILE_US = 12.36            # time for a pulse to go 1 nm out and back

CONFIG_FILE_NAME = "radarsim.toml"


# ---- randomness ----
# Each subsystem gets its own random stream from the master seed, so a change in one
# does not alter another. The order of this list must never change; add at the end.
RANDOM_STREAMS = ["own_ship", "environment", "land", "traffic", "radar", "arpa"]


def make_random_streams(seed):
    children = np.random.SeedSequence(seed).spawn(len(RANDOM_STREAMS))
    streams = {}
    for name, child in zip(RANDOM_STREAMS, children):
        streams[name] = np.random.default_rng(child)
    return streams


# ---- unit conversions ----

def nm_to_m(distance_nm):
    return distance_nm * M_PER_NM          # nm -> m


def m_to_nm(distance_m):
    return distance_m / M_PER_NM           # m -> nm


def distance_nm_from(speed_kn, time_s):
    return speed_kn * time_s / S_PER_H     # kn x s -> nm


def deg_per_min_to_deg_per_s(rate_deg_per_min):
    return rate_deg_per_min / S_PER_MIN    # deg/min -> deg/s


def deg_per_s_to_deg_per_min(rate_deg_per_s):
    return rate_deg_per_s * S_PER_MIN      # deg/s -> deg/min


# ---- angle helpers ----

def normalise_360(angle_deg):
    # Into 0 <= angle < 360. The second % catches a tiny negative input, which
    # the first % rounds up to exactly 360.0.
    return (angle_deg % 360.0) % 360.0


def normalise_180(angle_deg):
    # Into -180 <= angle < +180.
    return (angle_deg + 180.0) % 360.0 - 180.0


def angle_difference_deg(to_deg, from_deg):
    # Shortest turn from one direction to another, -180..+180. + is clockwise (to starboard).
    return normalise_180(to_deg - from_deg)


def bearing_true_deg(dx_nm, dy_nm):
    # True bearing of a point dx_nm east and dy_nm north of the observer.
    return normalise_360(np.degrees(np.arctan2(dx_nm, dy_nm)))


def velocity_xy_kn(speed_kn, direction_deg_true):
    # East and north parts of a velocity pointing toward direction_deg_true
    # (a true bearing is clockwise from north, so east goes with the sine).
    direction_rad = np.radians(direction_deg_true)
    return speed_kn * np.sin(direction_rad), speed_kn * np.cos(direction_rad)


def cpa_tcpa(rel_pos_nm, rel_vel_kn):
    # Closest point of approach from a relative position (x, y) in nm and a relative
    # velocity (x, y) in kn, both "other minus me". Returns (cpa_nm, tcpa_min).
    # TCPA = -(P.V) / |V|^2 comes out in hours; x 60 gives minutes. A TCPA below 0
    # means the range is opening, and the CPA is then the present range.
    # (BRIEF.md Section 10.)
    px_nm, py_nm = rel_pos_nm
    vx_kn, vy_kn = rel_vel_kn
    speed_sq = vx_kn * vx_kn + vy_kn * vy_kn
    range_nm = math.hypot(px_nm, py_nm)
    if speed_sq < 1e-12:
        return range_nm, 0.0                 # no relative motion: the range never changes
    tcpa_h = -(px_nm * vx_kn + py_nm * vy_kn) / speed_sq
    if tcpa_h < 0.0:
        return range_nm, tcpa_h * 60.0       # h -> min
    cpa_nm = math.hypot(px_nm + vx_kn * tcpa_h, py_nm + vy_kn * tcpa_h)
    return cpa_nm, tcpa_h * 60.0             # h -> min


# The only two places that convert between true bearings (clockwise from north)
# and the maths convention (counter-clockwise from east).

def true_to_maths_deg(angle_deg_true):
    return normalise_360(90.0 - angle_deg_true)


def maths_to_true_deg(angle_deg_maths):
    return normalise_360(90.0 - angle_deg_maths)


# ---- latitude and longitude (BRIEF.md Section 13; flat earth around the origin) ----

def latlon_to_xy_nm(lat_deg, lon_deg, origin_lat_deg, origin_lon_deg):
    x_nm = (lon_deg - origin_lon_deg) * NM_PER_DEG_LAT * math.cos(math.radians(origin_lat_deg))
    y_nm = (lat_deg - origin_lat_deg) * NM_PER_DEG_LAT
    return x_nm, y_nm


def xy_nm_to_latlon(x_nm, y_nm, origin_lat_deg, origin_lon_deg):
    lat_deg = origin_lat_deg + y_nm / NM_PER_DEG_LAT
    lon_deg = origin_lon_deg + x_nm / (NM_PER_DEG_LAT * math.cos(math.radians(origin_lat_deg)))
    return lat_deg, lon_deg


# ---- project root ----

def find_project_root(start_folder=None):
    # Walk up from this file's folder (or start_folder) until radarsim.toml is found,
    # so the sim runs from any working directory.
    if start_folder is None:
        start_folder = os.path.dirname(os.path.abspath(__file__))
    folder = os.path.abspath(start_folder)
    while True:
        if os.path.isfile(os.path.join(folder, CONFIG_FILE_NAME)):
            return folder
        parent = os.path.dirname(folder)
        if parent == folder:
            raise FileNotFoundError(
                CONFIG_FILE_NAME + " not found in " + os.path.abspath(start_folder)
                + " or any folder above it. Pass --root <project folder>.")
        folder = parent
