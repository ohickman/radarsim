# sim_game.py - collision and grounding checks (BRIEF.md Section 15, M10; [game] keys).
# Units: positions nm, lengths m, distances nm unless the name says m.
# Called by: sim_main.py once per physics step.

import math

from sim_common import M_PER_NM


class Game:
    def __init__(self, cfg):
        self.cfg = cfg
        self.aground = False             # own ship is on land now (grounding already reported)
        self.colliding = set()           # ids of contacts that are inside the collision distance now

    def check(self, own_ship, contacts, land):
        # Returns the new events of this step as (kind, text) pairs: "grounding" when
        # own ship's position or bow point first reaches land, "collision" when a contact
        # first comes inside the collision distance. Neither repeats until own ship has
        # been afloat again (grounding) or that contact has moved apart (collision).
        events = []
        own_length_m = self.cfg["own_ship"]["length_m"]

        bow_nm = own_length_m / 2.0 / M_PER_NM                              # m -> nm
        heading_rad = math.radians(own_ship.heading_deg_true)
        bow_x_nm = own_ship.x_nm + bow_nm * math.sin(heading_rad)
        bow_y_nm = own_ship.y_nm + bow_nm * math.cos(heading_rad)
        on_land = land.is_land_point(own_ship.x_nm, own_ship.y_nm) or land.is_land_point(bow_x_nm, bow_y_nm)
        if on_land and not self.aground:
            events.append(("grounding", "Grounding"))
        self.aground = on_land

        factor = self.cfg["game"]["collision_distance_factor"]
        now_colliding = set()
        for contact in contacts:
            limit_nm = factor * (own_length_m + contact.length_m) / 2.0 / M_PER_NM     # m -> nm
            dx_nm = contact.x_nm - own_ship.x_nm
            dy_nm = contact.y_nm - own_ship.y_nm
            if dx_nm * dx_nm + dy_nm * dy_nm < limit_nm * limit_nm:
                now_colliding.add(contact.id)
                if contact.id not in self.colliding:
                    name = contact.kind if contact.name is None else "%s %s" % (contact.kind, contact.name)
                    events.append(("collision", "Collision (%s)" % name))
        self.colliding = now_colliding
        return events
