# sim_radar.py - the radar video generator: turns the world into spokes of 8-bit
# video that behave like an X-band marine radar (BRIEF.md Section 9).
# Signal chain: point targets and land -> sea clutter -> rain clutter -> receiver
# noise -> STC -> log amplifier -> FTC -> gain -> quantise.
# Units: ranges and positions nm, heights m, radar cross-section m2, powers as a
# multiple of the mean receiver noise power, levels dB above that noise, time s of
# sim time, bearings deg (true unless named _rel).
# Called by: sim_main.py every physics step (make_spokes), and the tests
# (compute_levels_db, quantise).
# Everything is worked out for a block of spokes at once with numpy; no Python loop
# runs over range bins.

import math
from dataclasses import dataclass

import numpy as np

from sim_common import M_PER_NM, NM_PER_US_PULSE

EARTH_RADIUS_M = 6371000.0
EARTH_K = 4.0 / 3.0              # standard atmosphere: the beam bends as if the earth were 4/3 as large
                                 # (BRIEF.md Section 9; gives Bowditch's radar horizon of about 2.2 x sqrt(h) nm)

# ---- everything below is chosen, not from a source ----
SCATTERER_HEIGHT_M = 10.0        # height of a contact's echoing point (BRIEF.md Section 9 default)
BEAM_CUT_WIDTHS = 2.0            # a scatterer is ignored further than this many beamwidths off the beam axis

# Land. A face that rises toward the radar echoes like an area of (visible height x
# width of the beam there) x LAND_FACE_REFLECTIVITY. Ground seen at a grazing angle
# adds a weak diffuse echo of LAND_DIFFUSE_REFLECTIVITY per m2 of ground.
# With the K below, shorelines rising to 60, 6 and 3 m are then detected near the
# ranges of MSC.192(79) Table 2 (test_m4.py, test 4).
LAND_FACE_REFLECTIVITY = 0.0172
LAND_DIFFUSE_REFLECTIVITY = 0.00017
LAND_SMOOTH_NM = 0.15            # the ground's height is averaged over this distance along a spoke

# Sea clutter: mean power = SEA_CLUTTER_AT_1_NM[Douglas state] / range^3, range in nm.
# Douglas 3 is set by the extent test (clutter fades into the noise near 2.5 nm upwind);
# each Douglas step is 3 dB. Sea state 0 has none.
SEA_CLUTTER_DOUGLAS_3 = 8.6
SEA_CLUTTER_DB_PER_STEP = 3.0
SEA_CLUTTER_MIN_RANGE_NM = 0.05  # the 1/range^3 law is held flat inside this range
SEA_UPWIND_DOWNWIND_DB = 6.0     # upwind is this much stronger than downwind (BRIEF.md Section 9)
SEA_TEXTURE_STDDEV = 0.5         # strength of the slow patchiness of sea clutter (and of land echoes)
SEA_TEXTURE_DRIFT_FRACTION = 0.05   # the patches drift downwind at this fraction of the wind speed

# Rain clutter: mean power = RAIN_CLUTTER_REFERENCE x rate^1.6 x (RAIN_REFERENCE_RANGE_NM / range)^2.
# The 1.6 power is from BRIEF.md Section 9; 1/range^2 is the usual law for clutter that fills the beam.
RAIN_CLUTTER_REFERENCE = 0.8     # power at 1 mm/h at the reference range (10 mm/h there is about +15 dB)
RAIN_REFERENCE_RANGE_NM = 6.0
RAIN_MIN_RANGE_NM = 0.5
RAIN_SMOOTH_PULSES = 3           # rain speckle is smoothed over this many pulse lengths
RAIN_LOSS_DB_PER_NM_PER_MM_H = 0.03   # one-way loss through rain; applied twice (out and back)

TEXTURE_CELLS = 512              # the texture map is 512 x 512 cells ...
TEXTURE_CELL_NM = 0.02           # ... of 0.02 nm, repeating every 10.24 nm
TEXTURE_SMOOTH_CELLS = 3.0
BLANK_DB = -200.0                # level written inside the minimum range: nothing is shown there


@dataclass
class Snapshot:
    # The world at one physics step, as the radar needs it.
    sim_time_s: float
    own_x_nm: float              # the antenna's true position
    own_y_nm: float
    heading_deg_true: float
    gyro_heading_deg: float
    ref_x_nm: float              # own-ship reference position (BRIEF.md Section 5)
    ref_y_nm: float
    scatterer_id: np.ndarray     # one entry per scatterer; the id stays the same from step to step
    scatterer_x_nm: np.ndarray
    scatterer_y_nm: np.ndarray
    scatterer_rcs_m2: np.ndarray
    scatterer_height_m: np.ndarray


def scatterers_of(contacts):
    # The scatterer arrays of a Snapshot from the traffic's contacts.
    ids, xs, ys, rcss = [], [], [], []
    for contact in contacts:
        for index, (x_nm, y_nm, rcs_m2) in enumerate(contact.scatterer_points()):
            ids.append(contact.id * 8 + index)
            xs.append(x_nm)
            ys.append(y_nm)
            rcss.append(rcs_m2)
    heights = np.full(len(ids), SCATTERER_HEIGHT_M)
    return (np.array(ids, dtype=np.int64), np.array(xs, dtype=float), np.array(ys, dtype=float),
            np.array(rcss, dtype=float), heights)


def quantise(levels_db, display_threshold_db, video_window_db):
    # Step 10: dB above noise -> 8-bit video. The threshold maps to 0, threshold + window to 255.
    video = (levels_db - display_threshold_db) * (255.0 / video_window_db)
    return np.clip(video, 0.0, 255.0).astype(np.uint8)


def steady_random_exponential(ids, revolutions, seed):
    # An exponentially distributed number (mean 1) that depends only on the scatterer,
    # the antenna revolution and the seed: the same every time it is asked for.
    # (SplitMix64 integer mixing, then -ln of a uniform number.)
    with np.errstate(over="ignore"):
        z = (ids.astype(np.uint64) * np.uint64(0x9E3779B97F4A7C15)
             + revolutions.astype(np.uint64) * np.uint64(0xD1B54A32D192ED03) + np.uint64(seed))
        z = (z ^ (z >> np.uint64(30))) * np.uint64(0xBF58476D1CE4E5B9)
        z = (z ^ (z >> np.uint64(27))) * np.uint64(0x94D049BB133111EB)
        z = z ^ (z >> np.uint64(31))
    uniform = ((z >> np.uint64(11)).astype(np.float64) + 0.5) / float(1 << 53)
    return -np.log(uniform)


def make_texture(rng):
    # A patchy map with mean 1 that repeats without a seam: random numbers smoothed
    # with a filter that wraps round (done in the frequency domain).
    noise = rng.standard_normal((TEXTURE_CELLS, TEXTURE_CELLS))
    frequency = np.fft.fftfreq(TEXTURE_CELLS)
    fx, fy = np.meshgrid(frequency, frequency)
    blur = np.exp(-2.0 * (np.pi * TEXTURE_SMOOTH_CELLS) ** 2 * (fx ** 2 + fy ** 2))
    smooth = np.real(np.fft.ifft2(np.fft.fft2(noise) * blur))
    smooth = smooth / smooth.std()
    texture = np.exp(SEA_TEXTURE_STDDEV * smooth)
    return (texture / texture.mean()).astype(np.float32)


def box_sum(values, bins):
    # Sum of each bin and the (bins - 1) before it, along range.
    if bins <= 1:
        return values
    total = np.cumsum(values, axis=1)
    total[:, bins:] -= total[:, :-bins].copy()
    return total


class RadarVideo:
    def __init__(self, cfg, rng, land, environment, fluctuate=True):
        self.cfg = cfg
        self.radar = cfg["radar"]
        self.controls = cfg["radar_controls"]        # gain, STC, FTC: read every block, so a change takes effect at once
        self.rng = rng
        self.land = land
        self.environment = environment
        self.fluctuate = fluctuate                   # False: no Swerling fading (tests)
        self.antenna_height_m = cfg["own_ship"]["antenna_height_m"]
        self.azimuth_bins = self.radar["azimuth_bins"]
        self.range_bins = self.radar["range_bins"]
        # Time between spokes: 60 s / (rpm x spokes per revolution).
        self.spoke_time_s = 60.0 / (self.radar["antenna_rpm"] * self.azimuth_bins)
        # Calibration: a target of reference_rcs_m2 at reference_range_nm gives reference_snr_db.
        self.power_per_m2_at_1_nm = (10.0 ** (self.radar["reference_snr_db"] / 10.0)
                                     * self.radar["reference_range_nm"] ** 4 / self.radar["reference_rcs_m2"])
        self.texture = make_texture(rng)
        self.fluctuation_seed = int(rng.integers(0, 2 ** 62))

    # ---------------------------------------------------------------- settings

    def video_range_nm(self):
        return self.radar["video_range_nm"]

    def pulse_length_us(self):
        # The pulse length goes with the range scale in use.
        scales = self.radar["range_scales_nm"]
        scale_nm = self.cfg["display"]["range_scale_nm"]
        nearest = min(range(len(scales)), key=lambda index: abs(scales[index] - scale_nm))
        return self.radar["pulse_length_us"][nearest]

    def pulse_bins(self):
        bin_nm = self.video_range_nm() / self.range_bins
        return max(1, int(round(NM_PER_US_PULSE * self.pulse_length_us() / bin_nm)))

    def spoke_numbers_between(self, from_time_s, to_time_s):
        # Spoke n is taken at n x spoke_time_s. Returns the spokes with
        # from_time_s <= time < to_time_s.
        first = int(math.ceil(from_time_s / self.spoke_time_s - 1e-9))
        last = int(math.ceil(to_time_s / self.spoke_time_s - 1e-9))
        return np.arange(first, last, dtype=np.int64)

    # ---------------------------------------------------------------- the signal chain

    def compute_levels_db(self, spoke_numbers, before, after):
        # Levels in dB above mean noise for a block of spokes, after STC, log amplifier,
        # FTC and gain, before quantising. Each spoke samples the world at its own
        # time, between the snapshots `before` and `after`.
        # Returns (levels float32 [spokes, bins], header dict with one array per spoke).
        radar = self.radar
        count = len(spoke_numbers)
        bins = self.range_bins
        video_range_nm = self.video_range_nm()
        bin_nm = video_range_nm / bins
        pulse_bins = self.pulse_bins()

        # ---- where and when each spoke looks ----
        time_s = spoke_numbers * self.spoke_time_s
        span_s = after.sim_time_s - before.sim_time_s
        part = np.clip((time_s - before.sim_time_s) / span_s, 0.0, 1.0) if span_s > 0.0 else np.zeros(count)
        own_x_nm = before.own_x_nm + part * (after.own_x_nm - before.own_x_nm)
        own_y_nm = before.own_y_nm + part * (after.own_y_nm - before.own_y_nm)
        ref_x_nm = before.ref_x_nm + part * (after.ref_x_nm - before.ref_x_nm)
        ref_y_nm = before.ref_y_nm + part * (after.ref_y_nm - before.ref_y_nm)
        turn_deg = (after.heading_deg_true - before.heading_deg_true + 180.0) % 360.0 - 180.0
        heading_deg_true = before.heading_deg_true + part * turn_deg
        gyro_turn_deg = (after.gyro_heading_deg - before.gyro_heading_deg + 180.0) % 360.0 - 180.0
        gyro_heading_deg = (before.gyro_heading_deg + part * gyro_turn_deg) % 360.0
        azimuth_index = spoke_numbers % self.azimuth_bins
        # Antenna angle clockwise from the bow; the spoke's true bearing adds the true heading.
        bearing_rel_deg = (azimuth_index + 0.5) * 360.0 / self.azimuth_bins
        bearing_deg_true = bearing_rel_deg + heading_deg_true
        bearing_rad = np.radians(bearing_deg_true)

        range_nm = ((np.arange(bins) + 0.5) * bin_nm).astype(np.float32)
        range_m = range_nm * np.float32(M_PER_NM)                         # nm -> m
        x_nm = (own_x_nm[:, None] + np.sin(bearing_rad)[:, None] * range_nm[None, :]).astype(np.float32)
        y_nm = (own_y_nm[:, None] + np.cos(bearing_rad)[:, None] * range_nm[None, :]).astype(np.float32)
        texture_column = np.floor(x_nm / TEXTURE_CELL_NM).astype(np.int32)
        texture_row = np.floor(y_nm / TEXTURE_CELL_NM).astype(np.int32)

        # ---- step 2, land, and the horizon and shadow test ----
        # Elevation angle of each sample seen from the antenna, on a 4/3 earth (radians):
        # (height - antenna height) / distance - distance / (2 k R_earth), distances in m.
        height_m = self.land.height_m_at(x_nm, y_nm).astype(np.float32)
        is_land = height_m > 0.0
        # The land raster holds whole metres. On a gentle slope that makes steps, and
        # each step would echo like a little cliff, drawing contour lines on the
        # picture. So the ground is smoothed along the spoke - land only, so that the
        # shoreline stays a sharp edge.
        smooth_bins = max(3, int(round(LAND_SMOOTH_NM / bin_nm)))
        half = smooth_bins // 2
        padded_height = np.pad(height_m, ((0, 0), (half + 1, half)))
        padded_land = np.pad(is_land.astype(np.float32), ((0, 0), (half + 1, half)))
        height_sum = np.cumsum(padded_height, axis=1)
        land_sum = np.cumsum(padded_land, axis=1)
        width = 2 * half + 1
        height_sum = height_sum[:, width:] - height_sum[:, :-width]
        land_sum = land_sum[:, width:] - land_sum[:, :-width]
        height_m = np.where(is_land, height_sum / np.maximum(land_sum, np.float32(1.0)), np.float32(0.0))
        angle = (height_m - np.float32(self.antenna_height_m)) / range_m - range_m / np.float32(2.0 * EARTH_K * EARTH_RADIUS_M)
        highest = np.maximum.accumulate(angle, axis=1)        # the skyline so far along the spoke
        highest_before = np.empty_like(highest)
        highest_before[:, 0] = highest[:, 0]
        highest_before[:, 1:] = highest[:, :-1]
        in_view = angle >= highest                            # not hidden by anything nearer
        # The height of ground newly risen above the skyline, as seen from the antenna.
        face_m = (highest - highest_before) * range_m
        beam_width_m = range_m * np.float32(math.radians(radar["horizontal_beamwidth_deg"]))
        land_texture = self.texture[texture_row % TEXTURE_CELLS, texture_column % TEXTURE_CELLS]
        echo_m2 = np.where(is_land, (LAND_FACE_REFLECTIVITY * face_m * beam_width_m
                                     + LAND_DIFFUSE_REFLECTIVITY * in_view * beam_width_m * (bin_nm * M_PER_NM)) * land_texture,
                           np.float32(0.0)).astype(np.float32)

        # ---- step 1, point targets ----
        self.add_point_targets(echo_m2, before, after, part, spoke_numbers, own_x_nm, own_y_nm,
                               heading_deg_true, bearing_deg_true, highest_before, bin_nm)

        # An echo lasts one pulse length: each scatterer fills pulse_bins bins, starting at its range.
        signal = box_sum(echo_m2, pulse_bins)
        signal *= np.float32(self.power_per_m2_at_1_nm) / range_nm ** 4          # K x RCS / R^4

        # ---- step 4, rain: clutter, and loss for everything behind it ----
        rain_peak_mm_per_h = self.environment.env["rain_rate_mm_per_h"]
        raining = rain_peak_mm_per_h > 0.0 and self.rain_in_reach(own_x_nm, own_y_nm, video_range_nm)
        if raining:
            rate_mm_per_h = self.environment.rain_rate_at(x_nm, y_nm).astype(np.float32)
            speckle = self.rng.standard_exponential((count, bins), dtype=np.float32)
            smooth_bins = RAIN_SMOOTH_PULSES * pulse_bins
            speckle = box_sum(speckle, smooth_bins) / np.float32(smooth_bins)
            rain_range_nm = np.maximum(range_nm, np.float32(RAIN_MIN_RANGE_NM))
            signal += (np.float32(RAIN_CLUTTER_REFERENCE) * rate_mm_per_h ** np.float32(1.6)
                       * (np.float32(RAIN_REFERENCE_RANGE_NM) / rain_range_nm) ** 2 * speckle)
            # Two-way loss in dB up to each bin, then as a factor.
            loss_db = np.cumsum(rate_mm_per_h, axis=1) * np.float32(2.0 * RAIN_LOSS_DB_PER_NM_PER_MM_H * bin_nm)

        # ---- step 3, sea clutter ----
        sea_state = self.environment.sea_state_douglas()
        if sea_state > 0:
            strength = SEA_CLUTTER_DOUGLAS_3 * 10.0 ** (SEA_CLUTTER_DB_PER_STEP * (sea_state - 3) / 10.0)
            wind_from_deg, wind_speed_kn = self.environment.wind()
            # +3 dB looking upwind, -3 dB looking downwind.
            wind_db = 0.5 * SEA_UPWIND_DOWNWIND_DB * np.cos(np.radians(bearing_deg_true - wind_from_deg))
            by_range = strength / np.maximum(range_nm, np.float32(SEA_CLUTTER_MIN_RANGE_NM)) ** 3
            # The patchiness drifts downwind.
            drift_nm = SEA_TEXTURE_DRIFT_FRACTION * wind_speed_kn * float(time_s[0]) / 3600.0      # kn x s -> nm
            drift_columns = int(round(-drift_nm * math.sin(math.radians(wind_from_deg)) / TEXTURE_CELL_NM))
            drift_rows = int(round(-drift_nm * math.cos(math.radians(wind_from_deg)) / TEXTURE_CELL_NM))
            sea_texture = self.texture[(texture_row - drift_rows + 137) % TEXTURE_CELLS,
                                       (texture_column - drift_columns + 59) % TEXTURE_CELLS]
            speckle = self.rng.standard_exponential((count, bins), dtype=np.float32)
            sea = (10.0 ** (wind_db / 10.0)).astype(np.float32)[:, None] * by_range[None, :] * sea_texture * speckle
            # Only water that the antenna can see: none on land, behind land or beyond the horizon.
            signal += np.where(is_land | ~in_view, np.float32(0.0), sea)

        if raining:
            signal *= np.float32(10.0) ** (-loss_db / np.float32(10.0))

        # ---- step 6, STC: attenuates echoes and clutter, not the receiver noise ----
        stc_range_nm = self.controls["stc_percent"] / 100.0 * radar["stc_max_range_nm"]
        if stc_range_nm > 0.0:
            # The textbook law: 30 dB per decade of range inside the STC range, limited to stc_max_db.
            stc_db = np.where(range_nm < stc_range_nm,
                              np.minimum(radar["stc_max_db"], 30.0 * np.log10(stc_range_nm / range_nm)), 0.0)
            signal *= (10.0 ** (-stc_db / 10.0)).astype(np.float32)[None, :]

        # ---- step 5, receiver noise (mean 1), and step 7, the log amplifier ----
        signal += self.rng.standard_exponential((count, bins), dtype=np.float32)
        levels_db = np.float32(10.0) * np.log10(np.maximum(signal, np.float32(1e-6)))

        # ---- step 8, FTC: subtract a share of the average level just before each bin ----
        # The knob is not linear: the first half already takes off three quarters (1 - (1 - p)^2).
        ftc_knob = self.controls["ftc_percent"] / 100.0
        ftc_share = 1.0 - (1.0 - ftc_knob) ** 2
        if ftc_share > 0.0:
            window_bins = max(1, int(round(radar["ftc_window_nm"] / bin_nm)))
            total = np.cumsum(levels_db, axis=1, dtype=np.float64)
            before_sum = np.zeros_like(total)
            before_sum[:, 1:] = total[:, :-1]                       # sum of all bins before this one
            window_sum = before_sum.copy()
            window_sum[:, window_bins:] -= before_sum[:, :-window_bins]
            bins_in_window = np.minimum(np.arange(bins), window_bins)
            bins_in_window[0] = 1
            average_db = window_sum / bins_in_window[None, :]
            # Floored at the noise mean (0 dB), so noise alone is left as it is.
            levels_db -= (ftc_share * np.maximum(average_db, 0.0)).astype(np.float32)

        # ---- step 9, gain ----
        levels_db += np.float32(radar["gain_db_per_percent"] * (self.controls["gain_percent"] - radar["gain_nominal_percent"]))
        # Nothing inside the minimum range.
        levels_db[:, range_nm < radar["minimum_range_nm"]] = BLANK_DB

        header = {"azimuth_index": azimuth_index.astype(np.uint16),
                  "gyro_heading_cdeg": (np.round(gyro_heading_deg * 100.0).astype(np.int64) % 36000).astype(np.uint16),
                  "sim_time_s": time_s, "ref_x_nm": ref_x_nm.astype(np.float32), "ref_y_nm": ref_y_nm.astype(np.float32),
                  "video_range_nm": video_range_nm, "bearing_deg_true": bearing_deg_true % 360.0}
        return levels_db, header

    def add_point_targets(self, echo_m2, before, after, part, spoke_numbers, own_x_nm, own_y_nm,
                          heading_deg_true, bearing_deg_true, highest_before, bin_nm):
        # Adds each scatterer's radar cross-section (with fading, beam pattern and the
        # horizon and shadow test) to the bins it falls in.
        if len(after.scatterer_id) == 0:
            return
        # Where each scatterer was at the earlier snapshot; one that is new stays where it is now.
        x_after = after.scatterer_x_nm
        y_after = after.scatterer_y_nm
        x_before = x_after.copy()
        y_before = y_after.copy()
        if len(before.scatterer_id) > 0:
            order = np.argsort(before.scatterer_id)
            place = np.clip(np.searchsorted(before.scatterer_id[order], after.scatterer_id), 0, len(order) - 1)
            found = before.scatterer_id[order][place] == after.scatterer_id
            x_before[found] = before.scatterer_x_nm[order][place][found]
            y_before[found] = before.scatterer_y_nm[order][place][found]

        # Position of each scatterer at each spoke's own time: [spokes, scatterers].
        dx_nm = x_before[None, :] + part[:, None] * (x_after - x_before)[None, :] - own_x_nm[:, None]
        dy_nm = y_before[None, :] + part[:, None] * (y_after - y_before)[None, :] - own_y_nm[:, None]
        target_range_nm = np.hypot(dx_nm, dy_nm)
        target_bearing_deg = np.degrees(np.arctan2(dx_nm, dy_nm))
        off_axis_deg = (target_bearing_deg - bearing_deg_true[:, None] + 180.0) % 360.0 - 180.0
        beamwidth_deg = self.radar["horizontal_beamwidth_deg"]
        target_bin = np.floor(target_range_nm / bin_nm).astype(np.int64)
        lit = (np.abs(off_axis_deg) < BEAM_CUT_WIDTHS * beamwidth_deg) & (target_bin < self.range_bins) & (target_range_nm > 0.0)
        spoke, scatterer = np.nonzero(lit)
        if len(spoke) == 0:
            return
        off_axis_deg = off_axis_deg[spoke, scatterer]
        target_bin = target_bin[spoke, scatterer]
        target_range_m = target_range_nm[spoke, scatterer] * M_PER_NM          # nm -> m
        # Two-way beam pattern: half power at half a beamwidth off the axis.
        echo = after.scatterer_rcs_m2[scatterer] * np.exp(-math.log(2.0) * (2.0 * off_axis_deg / beamwidth_deg) ** 2)

        # Horizon and shadow: the scatterer's elevation angle against the skyline in front of it.
        angle = ((after.scatterer_height_m[scatterer] - self.antenna_height_m) / target_range_m
                 - target_range_m / (2.0 * EARTH_K * EARTH_RADIUS_M))
        echo = np.where(angle >= highest_before[spoke, target_bin], echo, 0.0)

        if self.fluctuate:
            # Swerling 1: one fading factor per scatterer per antenna revolution. The
            # revolution is counted from when the antenna points away from the target,
            # so the factor never changes while the beam is on it.
            antenna_deg = (spoke_numbers[spoke] + 0.5) * 360.0 / self.azimuth_bins
            target_rel_deg = (target_bearing_deg[spoke, scatterer] - heading_deg_true[spoke]) % 360.0
            revolution = np.floor((antenna_deg - target_rel_deg) / 360.0 + 0.5).astype(np.int64)
            echo = echo * steady_random_exponential(after.scatterer_id[scatterer], revolution, self.fluctuation_seed)
        np.add.at(echo_m2, (spoke, target_bin), echo.astype(np.float32))

    def rain_in_reach(self, own_x_nm, own_y_nm, video_range_nm):
        # True if any rain cell can touch the picture: saves the rain work when none does.
        environment = self.environment
        if len(environment.cell_x_nm) == 0:
            return False
        distance_nm = np.hypot(environment.cell_x_nm - own_x_nm[0], environment.cell_y_nm - own_y_nm[0])
        return bool(np.any(distance_nm < video_range_nm + environment.env["rain_cell_radius_nm"] + 0.5))

    # ---------------------------------------------------------------- spokes for the display

    def make_spokes(self, before, after):
        # The spokes taken between two physics steps, ready for sim_protocol.pack_spokes.
        # Returns None when the step holds no spoke.
        spoke_numbers = self.spoke_numbers_between(before.sim_time_s, after.sim_time_s)
        if len(spoke_numbers) == 0:
            return None
        levels_db, header = self.compute_levels_db(spoke_numbers, before, after)
        header["video"] = quantise(levels_db, self.radar["display_threshold_db"], self.radar["video_window_db"])
        return header
