# test_m3.py - acceptance tests of Module M3, contacts and traffic (BRIEF.md Section 15).
# Run: python sim/test_m3.py     Prints [OK] or [FAIL] lines with numbers; exits 0 or 1.
# Takes 2 to 3 minutes. Headless, no radar. The long statistical runs use a physics
# step of 1 s to compress time; a shorter run checks the limits at the real step.
# Writes preview_traffic_1.png and _2.png into the project root for Oliver to look at.
# Units: as named in each test.

import copy
import math
import os
import socket
import subprocess
import sys
import time

import numpy as np

import devtools
import messages
import sim_common
import sim_config
import sim_contacts
import sim_environment
import sim_land
import sim_protocol

ROOT = sim_common.find_project_root()
CONFIG_PATH = os.path.join(ROOT, sim_common.CONFIG_FILE_NAME)
SIM_MAIN = os.path.join(ROOT, "sim", "sim_main.py")
TEMP_CONFIG_PATH = os.path.join(ROOT, "test_m3_tmp.toml")     # deleted at the end
CFG = sim_config.load_config(CONFIG_PATH)
KIND_RGB = {"ship": (255, 255, 255), "tug_tow": (255, 0, 255), "fishing": (255, 90, 90), "pleasure": (120, 255, 120)}

failures = 0


def report(passed, name, detail):
    global failures
    if passed:
        messages.ok(name + ": " + detail)
    else:
        failures += 1
        messages.fail(name + ": " + detail)


def quiet_land(seed):
    streams = sim_common.make_random_streams(seed)
    messages.message_verbosity = 0
    try:
        return sim_land.generate_land(CFG, streams["land"])
    finally:
        messages.message_verbosity = None


def make_world(seed, land, cfg):
    # Traffic for one seed, built the way sim_main.py builds it. Own ship sits still
    # at its start position.
    streams = sim_common.make_random_streams(seed)
    if land.lanes:
        start_x_nm, start_y_nm, start_heading_deg = land.find_start(streams["own_ship"])
    else:
        start_x_nm, start_y_nm = 0.0, 0.0
    environment = sim_environment.Environment(cfg, streams["environment"], start_x_nm, start_y_nm)
    traffic = sim_contacts.Traffic(cfg, streams["traffic"], land, environment)
    return traffic, start_x_nm, start_y_nm


# ---------------------------------------------------------------- 1 cpa_tcpa

def test_1_cpa_tcpa():
    cases = []
    # Head-on: 10 nm apart, closing at 20 kn -> CPA 0, TCPA 30 min.
    cases.append(("head-on", sim_common.cpa_tcpa((0.0, 10.0), (0.0, -20.0)), (0.0, 30.0)))
    # Crossing, by hand: other is 6 nm east and 8 nm north; I go north at 10 kn, it goes west at 10 kn.
    # Relative velocity (-10, -10) kn. TCPA = -((6)(-10) + (8)(-10)) / 200 = 0.7 h = 42 min.
    # Position then (6 - 7, 8 - 7) = (-1, 1) nm, so CPA = sqrt(2) = 1.4142 nm.
    cases.append(("crossing", sim_common.cpa_tcpa((6.0, 8.0), (-10.0, -10.0)), (math.sqrt(2.0), 42.0)))
    # Opening: other is 3 nm north and 4 nm east, moving away north-east at (4, 3) kn.
    # TCPA = -(16 + 9... ) -> -(4*4 + 3*3) / 25 = -1 h = -60 min; CPA = present range 5 nm.
    cases.append(("opening", sim_common.cpa_tcpa((4.0, 3.0), (4.0, 3.0)), (5.0, -60.0)))
    # No relative motion: range stays, TCPA 0.
    cases.append(("no relative motion", sim_common.cpa_tcpa((3.0, 4.0), (0.0, 0.0)), (5.0, 0.0)))
    wrong = [name for name, got, expected in cases
             if abs(got[0] - expected[0]) > 1e-9 or abs(got[1] - expected[1]) > 1e-9]
    report(not wrong, "1 cpa_tcpa", "; ".join("%s: CPA %.4f nm, TCPA %.2f min" % (name, got[0], got[1])
                                              for name, got, expected in cases) + "; wrong: %s" % (wrong or "none"))


# ---------------------------------------------------------------- 2 determinism

def record_tracks(seed, land, hours):
    cfg = copy.deepcopy(CFG)
    traffic, own_x_nm, own_y_nm = make_world(seed, land, cfg)
    record = []
    for step in range(int(hours * 3600)):
        traffic.step(1.0, float(step), own_x_nm, own_y_nm, 0.0, 0.0)
        if step % 60 == 0:
            record.append([(c.id, c.kind, c.x_nm, c.y_nm, c.heading_deg_true, c.speed_kn) for c in traffic.contacts])
    return record


def test_2_determinism(land):
    first = record_tracks(11, land, 1.0)
    second = record_tracks(11, land, 1.0)
    other = record_tracks(12, land, 1.0)
    report(first == second and first != other, "2 determinism", "seed 11 twice for 1 hour: identical tracks: %s "
           "(%d contacts at the end); seed 12 differs: %s" % (first == second, len(first[-1]), first != other))


# ---------------------------------------------------------------- 3-8 the long run

def long_run(land, hours, dt_s, cfg, seed, draw=None):
    # Runs the traffic and gathers everything tests 3 to 8 need.
    traffic, own_x_nm, own_y_nm = make_world(seed, land, cfg)
    stats = {"counts": [], "kind_samples": {kind: 0 for kind in sim_contacts.KINDS}, "samples": 0,
             "on_land": 0, "lane_samples": 0, "lane_settled": 0, "lane_outside": 0, "lane_worst": 0.0,
             "course_errors": [], "tow_min_m": 1e9, "tow_max_m": 0.0, "turn_worst": 0.0, "accel_worst": 0.0,
             "seen": {}, "land_stops": 0, "own": (own_x_nm, own_y_nm), "tracks": {kind: ([], []) for kind in sim_contacts.KINDS}}
    before = {}
    steps = int(round(hours * 3600.0 / dt_s))
    for step in range(steps):
        now_s = step * dt_s
        traffic.step(dt_s, now_s, own_x_nm, own_y_nm, 0.0, 0.0)
        contacts = traffic.contacts
        stats["counts"].append(len(contacts))
        slow_sample = step % int(round(10.0 / dt_s)) == 0          # every 10 s of sim time
        after = {}
        for c in contacts:
            # Test 8: turn rate and acceleration against the kind's limits.
            previous = before.get(c.id)
            if previous is not None:
                turned = abs((c.heading_deg_true - previous[0] + 180.0) % 360.0 - 180.0)
                stats["turn_worst"] = max(stats["turn_worst"], turned / (c.max_turn_deg_per_s * dt_s))
                stats["accel_worst"] = max(stats["accel_worst"], abs(c.speed_kn - previous[1]) / (c.accel_kn_per_s * dt_s))
            after[c.id] = (c.heading_deg_true, c.speed_kn)
            # Test 5: never on land.
            if land.is_land_point(c.x_nm, c.y_nm):
                stats["on_land"] += 1
            if not slow_sample:
                continue
            stats["kind_samples"][c.kind] += 1
            stats["samples"] += 1
            stats["seen"][c.id] = (c.kind, c.unplanned_course_changes, c.age_s, c.land_stops)
            if draw is not None and step % int(round(20.0 / dt_s)) == 0:
                stats["tracks"][c.kind][0].append(c.x_nm)
                stats["tracks"][c.kind][1].append(c.y_nm)
            if c.tow_length_nm is not None:
                tow_m = math.hypot(c.tow_x_nm - c.x_nm, c.tow_y_nm - c.y_nm) * 1852.0       # nm -> m
                stats["tow_min_m"] = min(stats["tow_min_m"], tow_m)
                stats["tow_max_m"] = max(stats["tow_max_m"], tow_m)
            if c.behaviour == "lane":
                stats["lane_samples"] += 1
                if c.settled:
                    half_width_nm = traffic.routes[c.plan[c.leg]["route"]].width_nm / 2.0
                    stats["lane_settled"] += 1
                    stats["lane_worst"] = max(stats["lane_worst"], abs(c.lane_right_nm) / half_width_nm)
                    if abs(c.lane_right_nm) > half_width_nm:
                        stats["lane_outside"] += 1
                    if c.kind == "ship" and c.predictability >= 0.95 and c.course_offset_deg == 0.0:
                        stats["course_errors"].append((c.heading_deg_true - c.lane_heading_deg + 180.0) % 360.0 - 180.0)
        before = after
    stats["traffic"] = traffic
    return stats


def test_3_to_8(land):
    cfg = copy.deepcopy(CFG)
    cfg["traffic"]["max_contacts"] = 200           # so the cap does not bite
    start_s = time.perf_counter()
    stats = long_run(land, 24.0, 1.0, cfg, 1, draw=True)
    wall_s = time.perf_counter() - start_s
    traffic = stats["traffic"]

    # 3 density
    expected_mean = cfg["traffic"]["density_per_100_nm2"] * math.pi * cfg["traffic"]["active_radius_nm"] ** 2 / 100.0
    expected_std = cfg["traffic"]["density_stddev_fraction"] * expected_mean
    mean = float(np.mean(stats["counts"]))
    std = float(np.std(stats["counts"]))
    ok = abs(mean / expected_mean - 1.0) <= 0.10 and abs(std / expected_std - 1.0) <= 0.35 and wall_s <= 120.0
    report(ok, "3a density over 24 sim-hours", "mean count %.2f (expected %.2f +/- 10 %%), standard deviation %.2f "
           "(expected %.2f +/- 35 %%); the run took %.0f s of wall time (limit 120)"
           % (mean, expected_mean, std, expected_std, wall_s))

    # 4 mix
    fractions = {kind: stats["kind_samples"][kind] / stats["samples"] for kind in sim_contacts.KINDS}
    worst_points = max(abs(fractions[kind] - cfg["traffic"]["mix_" + kind]) * 100.0 for kind in sim_contacts.KINDS)
    report(worst_points <= 5.0, "4 mix", ", ".join("%s %.1f %% (config %.0f %%)" % (
        kind, fractions[kind] * 100.0, cfg["traffic"]["mix_" + kind] * 100.0) for kind in sim_contacts.KINDS)
        + "; worst difference %.1f points (limit 5)" % worst_points)

    # 5 land and lanes
    land_stops = sum(seen[3] for seen in stats["seen"].values())
    report(stats["on_land"] == 0, "5a never on land", "%d contact-steps checked on generated land: %d on land. "
           "(The last-resort check held a contact still on %d steps.)"
           % (sum(stats["counts"]), stats["on_land"], land_stops))
    settled_percent = 100.0 * stats["lane_settled"] / max(stats["lane_samples"], 1)
    report(stats["lane_outside"] == 0 and stats["lane_settled"] > 1000, "5b ships and tugs keep to their lane",
           "%d samples of vessels settled in a lane (%.0f %% of their time; the rest is giving way, standing on, "
           "avoiding land, joining a lane or returning to it): %d outside half the lane width; farthest %.2f of "
           "the half width" % (stats["lane_settled"], settled_percent, stats["lane_outside"], stats["lane_worst"]))
    course_std = float(np.std(stats["course_errors"])) if stats["course_errors"] else -1.0
    wanted_std = cfg["traffic"]["ship"]["lane_heading_stddev_deg"]
    report(abs(course_std / wanted_std - 1.0) <= 0.5, "5c course spread about the lane heading",
           "ships with predictability >= 0.95 and no unplanned change: %.2f deg over %d samples (config %.1f +/- 50 %%)"
           % (course_std, len(stats["course_errors"]), wanted_std))

    # 6 predictability
    per_hour = {}
    for kind in sim_contacts.KINDS:
        changes = sum(seen[1] for seen in stats["seen"].values() if seen[0] == kind)
        hours = sum(seen[2] for seen in stats["seen"].values() if seen[0] == kind) / 3600.0
        per_hour[kind] = changes / max(hours, 1e-9)
    ok = per_hour["ship"] < 0.5 and per_hour["pleasure"] >= 10.0
    report(ok, "6 predictability", "unplanned course changes per hour: ship %.2f (limit below 0.5), tug %.2f, "
           "fishing %.2f, pleasure %.1f (limit 10 or more)"
           % (per_hour["ship"], per_hour["tug_tow"], per_hour["fishing"], per_hour["pleasure"]))

    # 7 tug and tow
    ok = stats["tow_min_m"] >= 100.0 and stats["tow_max_m"] <= 250.0
    report(ok, "7 tug and tow", "separation between %.1f and %.1f m over the whole run (limits 100 to 250)"
           % (stats["tow_min_m"], stats["tow_max_m"]))

    # 8 limits, here and at the real physics step
    real = long_run(land, 0.5, CFG["general"]["physics_step_s"], copy.deepcopy(cfg), 3)
    worst_turn = max(stats["turn_worst"], real["turn_worst"])
    worst_accel = max(stats["accel_worst"], real["accel_worst"])
    report(worst_turn <= 1.05 and worst_accel <= 1.05, "8 limits", "largest turn step %.3f x and largest speed step "
           "%.3f x the kind's limit (limit 1.05), over 24 h at a 1 s step and 30 min at the real %.1f s step"
           % (worst_turn, worst_accel, CFG["general"]["physics_step_s"]))

    # 3 again: the default cap, with twice the density so the cap is reached
    capped_cfg = copy.deepcopy(CFG)
    capped_cfg["traffic"]["density_per_100_nm2"] = 2.0
    capped = long_run(land, 3.0, 1.0, capped_cfg, 2)
    cap = capped_cfg["traffic"]["max_contacts"]
    report(max(capped["counts"]) <= cap and max(capped["counts"]) == cap, "3b default cap",
           "with density 2.0 (mean 56.5 wanted) the count peaked at %d (max_contacts %d) and averaged %.1f"
           % (max(capped["counts"]), cap, float(np.mean(capped["counts"]))))
    return stats


# ---------------------------------------------------------------- 9 COLREGS

def encounter(x_nm, y_nm, heading_deg, speed_kn, complies):
    # Own ship: from the origin, 000 at 10 kn, doing nothing. One ship contact.
    cfg = copy.deepcopy(CFG)
    land = sim_land.make_open_sea(cfg)
    environment = sim_environment.Environment(cfg, np.random.default_rng(1), 0.0, 0.0)
    traffic = sim_contacts.Traffic(cfg, np.random.default_rng(2), land, environment)
    traffic.spawning = False
    contact = traffic.add_contact("ship", x_nm, y_nm, heading_deg, speed_kn)
    contact.complies = complies
    dt_s = cfg["general"]["physics_step_s"]
    result = {"closest_nm": 1e9, "most_starboard_deg": 0.0, "most_port_deg": 0.0, "speed_change_kn": 0.0,
              "passed_astern": None}
    for step in range(int(45.0 * 60.0 / dt_s)):
        own_y_nm = 10.0 * step * dt_s / 3600.0                      # kn x s -> nm
        x_before_nm = contact.x_nm
        traffic.step(dt_s, step * dt_s, 0.0, own_y_nm, 0.0, 10.0)
        result["closest_nm"] = min(result["closest_nm"], math.hypot(contact.x_nm, contact.y_nm - own_y_nm))
        turned_deg = (contact.heading_deg_true - heading_deg + 180.0) % 360.0 - 180.0
        result["most_starboard_deg"] = max(result["most_starboard_deg"], turned_deg)
        result["most_port_deg"] = min(result["most_port_deg"], turned_deg)
        result["speed_change_kn"] = max(result["speed_change_kn"], abs(contact.speed_kn - speed_kn))
        if result["passed_astern"] is None and x_before_nm * contact.x_nm < 0.0:
            result["passed_astern"] = contact.y_nm < own_y_nm        # crossing own ship's track: ahead or astern?
    return result


def test_9_colregs():
    scenes = {
        "a head-on": (-0.1, 8.0, 180.0, 10.0),            # 8 nm ahead, 0.1 nm to port, reciprocal course
        "b crossing from own port side": (-5.0, 5.0, 90.0, 10.0),   # collision course; own ship is on its starboard bow
        "c crossing from own starboard side": (5.0, 5.0, 270.0, 10.0),
        "d overtaking": (0.2, -1.5, 0.0, 16.0),           # astern, 6 kn faster, 0.2 nm off own ship's track
    }
    got = {name: encounter(*scene, complies=True) for name, scene in scenes.items()}

    a = got["a head-on"]
    report(a["most_starboard_deg"] >= 30.0 and a["most_port_deg"] > -1.0 and a["closest_nm"] >= 0.5, "9a head-on",
           "contact turned %.0f deg to starboard; closest %.2f nm (limit 0.5 or more)"
           % (a["most_starboard_deg"], a["closest_nm"]))
    b = got["b crossing from own port side"]
    report(b["most_starboard_deg"] >= 30.0 and b["most_port_deg"] > -1.0 and b["closest_nm"] >= 0.5 and b["passed_astern"] is True,
           "9b crossing, contact gives way", "turned %.0f deg to starboard; passed astern of own ship: %s; closest "
           "%.2f nm (limit 0.5 or more)" % (b["most_starboard_deg"], b["passed_astern"], b["closest_nm"]))
    c = got["c crossing from own starboard side"]
    held = max(c["most_starboard_deg"], -c["most_port_deg"])
    report(held <= 1.0 and c["speed_change_kn"] <= 0.1, "9c crossing, contact stands on",
           "course held within %.2f deg (limit 1), speed within %.2f kn (limit 0.1)" % (held, c["speed_change_kn"]))
    d = got["d overtaking"]
    report(d["most_starboard_deg"] >= 30.0 and d["most_port_deg"] > -1.0 and d["closest_nm"] >= 0.3, "9d overtaking",
           "contact turned %.0f deg to starboard; closest %.2f nm (limit 0.3 or more)"
           % (d["most_starboard_deg"], d["closest_nm"]))

    ignoring = {name: encounter(*scene, complies=False) for name, scene in scenes.items()}
    most_turn = max(max(r["most_starboard_deg"], -r["most_port_deg"]) for r in ignoring.values())
    report(most_turn == 0.0, "9e compliance 0", "the same four scenes: largest course change %.3f deg; closest "
           "approaches %s nm" % (most_turn, ", ".join("%.2f" % r["closest_nm"] for r in ignoring.values())))


# ---------------------------------------------------------------- 10 calibration scenario

def test_10_calibration():
    cfg = copy.deepcopy(CFG)
    sim_contacts.apply_calibration_environment(cfg)
    land = sim_land.make_open_sea(cfg)
    environment = sim_environment.Environment(cfg, np.random.default_rng(1), 0.0, 0.0)
    traffic = sim_contacts.Traffic(cfg, np.random.default_rng(2), land, environment)
    sim_contacts.add_calibration_contacts(traffic)

    def worst_error_nm(time_s):
        worst = 0.0
        for contact, row in zip(traffic.contacts, sim_contacts.CALIBRATION_CONTACTS):
            name, kind, bearing_deg, range_nm, course_deg, speed_kn, length_m, rcs_m2 = row
            run_nm = speed_kn * time_s / 3600.0
            x_nm = range_nm * math.sin(math.radians(bearing_deg)) + run_nm * math.sin(math.radians(course_deg))
            y_nm = range_nm * math.cos(math.radians(bearing_deg)) + run_nm * math.cos(math.radians(course_deg))
            worst = max(worst, math.hypot(contact.x_nm - x_nm, contact.y_nm - y_nm))
        return worst

    at_start_nm = worst_error_nm(0.0)
    dt_s = cfg["general"]["physics_step_s"]
    steps = int(round(600.0 / dt_s))
    for step in range(steps):
        own_y_nm = 10.0 * step * dt_s / 3600.0
        traffic.step(dt_s, step * dt_s, 0.0, own_y_nm, 0.0, 10.0)
    after_nm = worst_error_nm(steps * dt_s)
    tug = traffic.contacts[-1]
    tow_m = math.hypot(tug.tow_x_nm - tug.x_nm, tug.tow_y_nm - tug.y_nm) * 1852.0
    tow_bearing_deg = sim_common.bearing_true_deg(tug.tow_x_nm - tug.x_nm, tug.tow_y_nm - tug.y_nm)
    names = [contact.name for contact in traffic.contacts]
    ship_rcs = sum(rcs for offset, rcs in traffic.contacts[4].scatterers)
    ok = (at_start_nm < 1e-9 and after_nm <= 0.001 and len(traffic.contacts) == 9 and abs(tow_m - 180.0) < 0.1
          and abs(sim_common.angle_difference_deg(tow_bearing_deg, 130.0)) < 0.1
          and len(traffic.contacts[4].scatterers) == 3 and abs(ship_rcs - 8000.0) < 1e-6
          and environment.sea_state_douglas() == 0 and environment.wind()[1] == 0.0)
    report(ok, "10 calibration scenario", "%s: worst position error %.2e nm at t = 0 and %.2e nm after 10 min "
           "(limit 0.001); tow %.1f m astern of T1 on bearing %05.1f; S1 has 3 scatterers totalling %.0f m2; wind "
           "%.0f kn, sea state %d" % (" ".join(names), at_start_nm, after_nm, tow_m, tow_bearing_deg, ship_rcs,
                                      environment.wind()[1], environment.sea_state_douglas()))


# ---------------------------------------------------------------- 11 previews

def test_11_previews(land_1, stats_1):
    view_nm = 70.0
    for seed in (1, 2):
        if seed == 1:
            land, stats = land_1, long_run(land_1, 2.0, 1.0, copy.deepcopy(CFG), 1, draw=True)
        else:
            land = quiet_land(seed)
            stats = long_run(land, 2.0, 1.0, copy.deepcopy(CFG), seed, draw=True)
        picture = devtools.render_land(land, 1000, [stats["own"]], view_nm)
        for kind in sim_contacts.KINDS:
            xs, ys = stats["tracks"][kind]
            devtools.draw_points(picture, view_nm, np.array(xs), np.array(ys), KIND_RGB[kind])
        path = os.path.join(ROOT, "preview_traffic_%d.png" % seed)
        devtools.write_png(path, picture)
        report(os.path.getsize(path) > 10000, "11 preview", "%s written: 2 hours of tracks, %d NM across; ships white, "
               "tugs magenta, fishing red, pleasure green, own ship (stopped) the red cross - Oliver looks at it"
               % (os.path.basename(path), view_nm))


# ---------------------------------------------------------------- wiring over TCP

def test_wiring_over_tcp():
    # The calibration scenario starts at once (no land to make).
    with open(CONFIG_PATH, "r", encoding="utf-8") as config_file:
        text = config_file.read()
    with open(TEMP_CONFIG_PATH, "w", encoding="utf-8") as config_file:
        config_file.write(text.replace('scenario = "random"', 'scenario = "calibration"', 1))
    probe = socket.socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()
    sim = subprocess.Popen([sys.executable, "-u", SIM_MAIN, "--config", TEMP_CONFIG_PATH, "--port", str(port)],
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        deadline_s = time.perf_counter() + 10.0
        while True:
            try:
                sock = socket.create_connection(("127.0.0.1", port), timeout=60.0)
                break
            except OSError:
                if time.perf_counter() > deadline_s:
                    raise
                time.sleep(0.1)

        def read_for(seconds):
            messages = []
            end_s = time.perf_counter() + seconds
            while time.perf_counter() < end_s:
                frame_type, payload = sim_protocol.read_frame(sock)
                if frame_type == sim_protocol.FRAME_JSON:      # skip radar video (from M4 on)
                    messages.append(sim_protocol.decode_json(payload))
            return messages

        def read_until(wanted):
            for count in range(5000):
                frame_type, payload = sim_protocol.read_frame(sock)
                if frame_type != sim_protocol.FRAME_JSON:
                    continue                 # radar video (from M4 on)
                message = sim_protocol.decode_json(payload)
                if message["t"] == wanted:
                    return message
            return None

        hello = read_until("hello")
        state = read_until("state")
        silent = [m for m in read_for(1.0) if m["t"] == "truth"]
        sim_protocol.send_json(sock, {"t": "truth", "enabled": True})
        read_until("truth")
        truths = [m for m in read_for(2.0) if m["t"] == "truth"]
        sim_protocol.send_json(sock, {"t": "truth", "enabled": False})
        read_for(0.5)
        after_off = [m for m in read_for(1.0) if m["t"] == "truth"]
        last = truths[-1]
        names = [contact["name"] for contact in last["contacts"]]
        keys = sorted(last["contacts"][0].keys())
        ok = (hello["scenario"] == "calibration" and state["own"]["speed_water_kn"] == 10.0
              and state["own"]["heading_deg_true"] == 0.0 and state["env"]["wind_speed_kn"] == 0.0
              and not silent and 8 <= len(truths) <= 12 and not after_off
              and names == [row[0] for row in sim_contacts.CALIBRATION_CONTACTS]
              and keys == ["course_deg_true", "id", "kind", "length_m", "name", "sail", "speed_kn", "x_nm", "y_nm"]
              and len(last["own_track"]) >= 1)
        report(ok, "truth message", "none before it is enabled; %d in 2 s while enabled (5 per second); none after it "
               "is disabled; contacts %s; fields %s; own_track has %d point(s)"
               % (len(truths), " ".join(names), keys, len(last["own_track"])))

        sim_protocol.send_json(sock, {"t": "set", "path": "traffic.max_contacts", "value": 25})
        setting = read_until("setting")
        sim_protocol.send_json(sock, {"t": "set", "path": "traffic.density_per_100_nm2", "value": 99})
        clamped = read_until("setting")
        report(setting["value"] == 25 and clamped["value"] == 10.0, "set traffic.*",
               "max_contacts 25 confirmed as %s; density 99 confirmed as %s" % (setting["value"], clamped["value"]))

        time.sleep(1.0)
        before = read_until("state")["sim_time_s"]
        sim_protocol.send_json(sock, {"t": "new_run", "seed": 7, "scenario": "calibration"})
        hello_again = read_until("hello")
        restarted = read_until("state")
        ok = (hello_again["seed"] == 7 and hello_again["scenario"] == "calibration" and before > 3.0
              and restarted["sim_time_s"] < 1.0 and abs(restarted["own"]["y_nm"]) < 0.01)
        report(ok, "new_run", "sim clock was %.1f s; after new_run (seed 7) hello came again with seed %s and the "
               "clock reads %.1f s, own ship back at y = %.3f nm"
               % (before, hello_again["seed"], restarted["sim_time_s"], restarted["own"]["y_nm"]))
        sim_protocol.send_json(sock, {"t": "quit"})
        sim.wait(timeout=5.0)
        sock.close()
    finally:
        if sim.poll() is None:
            sim.kill()
        if os.path.exists(TEMP_CONFIG_PATH):
            os.remove(TEMP_CONFIG_PATH)


def main():
    test_1_cpa_tcpa()
    test_9_colregs()
    test_10_calibration()
    land = quiet_land(1)
    test_2_determinism(land)
    stats = test_3_to_8(land)
    test_11_previews(land, stats)
    test_wiring_over_tcp()
    if failures:
        messages.fail("%d test line(s) failed" % failures)
    else:
        messages.ok("All M3 tests passed")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
