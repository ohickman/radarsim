# devtools.py - helpers for the tests only: a PNG writer that needs nothing but the
# standard library, and preview pictures of the land.
# Units: positions nm, heights m; pictures are uint8 arrays, row 0 at the top.
# Called by: the test scripts. The sim itself never imports this file.

import struct
import zlib

import numpy as np

import sim_land

WATER_RGB = (12, 32, 72)
LANE_RGBS = [(255, 220, 0), (255, 120, 0), (0, 230, 255), (255, 0, 255)]
MARK_RGB = (255, 40, 40)


def png_chunk(kind, data):
    # A PNG chunk: length, 4-letter kind, data, CRC of kind + data. Big-endian.
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)


def write_png(path, array):
    # array: 2D uint8 (grey) or 3D uint8 with 3 channels (RGB). Row 0 is the top row.
    array = np.ascontiguousarray(array)
    if array.dtype != np.uint8 or array.ndim not in (2, 3) or (array.ndim == 3 and array.shape[2] != 3):
        raise ValueError("write_png needs a uint8 array of shape (rows, columns) or (rows, columns, 3)")
    rows, columns = array.shape[0], array.shape[1]
    colour_type = 0 if array.ndim == 2 else 2            # 0 = grey, 2 = RGB
    header = struct.pack(">IIBBBBB", columns, rows, 8, colour_type, 0, 0, 0)
    # Each row starts with a filter byte; 0 = no filter.
    row_bytes = array.reshape(rows, -1)
    raw = np.concatenate([np.zeros((rows, 1), dtype=np.uint8), row_bytes], axis=1).tobytes()
    with open(path, "wb") as png_file:
        png_file.write(b"\x89PNG\r\n\x1a\n")
        png_file.write(png_chunk(b"IHDR", header))
        png_file.write(png_chunk(b"IDAT", zlib.compress(raw, 6)))
        png_file.write(png_chunk(b"IEND", b""))


def render_land(land, size_px, marks_nm=(), view_nm=None):
    # North-up picture centred on the origin, view_nm across (default: the whole land
    # square): height shading (green shore to pale hilltops), the lanes in colour,
    # and a cross at each marked point (x_nm, y_nm).
    if view_nm is None:
        view_nm = land.extent_nm
    half_nm = view_nm / 2.0
    px_nm = view_nm / size_px
    centre_nm = (np.arange(size_px) + 0.5) * px_nm - half_nm
    x_nm = centre_nm[None, :]
    y_nm = centre_nm[::-1][:, None]                      # row 0 is the northern edge
    heights_m = land.height_m_at(np.broadcast_to(x_nm, (size_px, size_px)),
                                 np.broadcast_to(y_nm, (size_px, size_px))).astype(float)

    shade = np.clip(heights_m / 400.0, 0.0, 1.0) ** 0.5     # 0 at the shore, 1 at 400 m
    picture = np.zeros((size_px, size_px, 3), dtype=np.uint8)
    low_rgb = np.array([40.0, 110.0, 50.0])
    high_rgb = np.array([235.0, 225.0, 190.0])
    for channel in range(3):
        land_colour = low_rgb[channel] + (high_rgb[channel] - low_rgb[channel]) * shade
        picture[:, :, channel] = np.where(heights_m > 0, land_colour, WATER_RGB[channel])

    def to_px(x, y):
        column = np.clip(((np.asarray(x) + half_nm) / px_nm).astype(int), 0, size_px - 1)
        row = np.clip(((half_nm - np.asarray(y)) / px_nm).astype(int), 0, size_px - 1)
        return row, column

    for index, lane in enumerate(land.lanes):
        samples, along_nm, total_nm = sim_land.sample_polyline(lane.points_nm, px_nm / 2.0)
        row, column = to_px(samples[:, 0], samples[:, 1])
        picture[row, column] = LANE_RGBS[index % len(LANE_RGBS)]
        picture[np.clip(row + 1, 0, size_px - 1), column] = LANE_RGBS[index % len(LANE_RGBS)]

    arm_px = max(size_px // 100, 4)
    for mark_x_nm, mark_y_nm in marks_nm:
        row, column = to_px(mark_x_nm, mark_y_nm)
        for offset in range(-arm_px, arm_px + 1):
            for thick in (-1, 0, 1):
                picture[np.clip(row + offset, 0, size_px - 1), np.clip(column + offset + thick, 0, size_px - 1)] = MARK_RGB
                picture[np.clip(row + offset, 0, size_px - 1), np.clip(column - offset + thick, 0, size_px - 1)] = MARK_RGB
    return picture


def draw_points(picture, view_nm, x_nm, y_nm, rgb):
    # Marks points (arrays of x_nm, y_nm) on a picture made by render_land with the
    # same view_nm. Points outside the picture are skipped.
    size_px = picture.shape[0]
    column = np.floor((np.asarray(x_nm) + view_nm / 2.0) / (view_nm / size_px)).astype(int)
    row = np.floor((view_nm / 2.0 - np.asarray(y_nm)) / (view_nm / size_px)).astype(int)
    inside = (column >= 0) & (column < size_px) & (row >= 0) & (row < size_px)
    picture[row[inside], column[inside]] = rgb


def render_ppi(spokes, size_px, video_range_nm):
    # A radar picture from spokes (as unpack_spokes or RadarVideo.make_spokes gives
    # them): mono green, own ship at the centre, north-up, video_range_nm from the
    # centre to the edge. Returns an RGB uint8 array.
    video = spokes["video"]
    bins = video.shape[1]
    spokes_per_turn = 2048
    # A spoke's true bearing = antenna angle from the bow + the gyro heading it carries.
    bearing_rel_deg = (spokes["azimuth_index"].astype(float) + 0.5) * 360.0 / spokes_per_turn
    bearing_deg_true = (bearing_rel_deg + spokes["gyro_heading_cdeg"].astype(float) / 100.0) % 360.0
    # Which spoke to show in each direction; the latest one wins, gaps take a neighbour.
    slots = 4096
    spoke_for_slot = np.full(slots, -1)
    spoke_for_slot[(bearing_deg_true / 360.0 * slots).astype(int) % slots] = np.arange(len(bearing_deg_true))
    filled = np.nonzero(spoke_for_slot >= 0)[0]
    nearest = filled[np.clip(np.searchsorted(filled, np.arange(slots)), 0, len(filled) - 1)]
    spoke_for_slot = spoke_for_slot[nearest]

    offset = np.arange(size_px) + 0.5 - size_px / 2.0
    east_px = offset[None, :]
    north_px = -offset[:, None]                          # row 0 is the top of the picture
    range_nm = np.hypot(east_px, north_px) * video_range_nm / (size_px / 2.0)
    pixel_bearing_deg = np.degrees(np.arctan2(east_px, north_px)) % 360.0
    row = spoke_for_slot[(pixel_bearing_deg / 360.0 * slots).astype(int) % slots]
    column = (range_nm / (spokes["video_range_nm"] / bins)).astype(int)
    inside = (column < bins) & (range_nm <= video_range_nm)
    level = np.where(inside, video[row, np.clip(column, 0, bins - 1)], 0).astype(float)
    picture = np.zeros((size_px, size_px, 3), dtype=np.uint8)
    picture[:, :, 0] = (level * 0.2).astype(np.uint8)
    picture[:, :, 1] = level.astype(np.uint8)
    picture[:, :, 2] = (level * 0.2).astype(np.uint8)
    return picture
